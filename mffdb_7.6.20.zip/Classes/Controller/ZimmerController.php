<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * ZimmerController
 */
class ZimmerController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * zimmerRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\ZimmerRepository
	 * @inject
	 */
	protected $zimmerRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$zimmers = $this->zimmerRepository->findAll();
		if ($this->request->hasArgument('download')) {
			$aZimmer = array();
			foreach( $zimmers as $ix => $fch ){
			      $aZimmer[$ix] = array(
				  'Haus' => $fch->getHaus(),
				  'Zimmer' => $fch->getZimmer(),
				  'Besonderes' => $fch->getBesonderes(),
				  'Ausschliessen' => $fch->getAusschliessen() ? 1 : '',
				  'EcoId' => $fch->getLocationId()
			      );
			}
			$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
			$downloader->downloadAsXls( array( 'zimmer'=>$aZimmer ) , 'zimmerListe_' . date('ymd_Hi') . '.xlsx');
			return;
		}
		$this->view->assign('zimmers', $zimmers);
	}

	/**
	 * action show
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @return void
	 */
	public function showAction(\Mff\Mffdb\Domain\Model\Zimmer $zimmer) {
		$this->view->assign('zimmer', $zimmer);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $newZimmer
	 * @return void
	 */
	public function createAction(\Mff\Mffdb\Domain\Model\Zimmer $newZimmer) {
		$this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->zimmerRepository->add($newZimmer);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @ignorevalidation $zimmer
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\Zimmer $zimmer) {
		$this->view->assign('zimmer', $zimmer);
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\Zimmer $zimmer) {
		$this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->zimmerRepository->update($zimmer);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->forward('edit', NULL, NULL, array('zimmer' => $zimmer));
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @return void
	 */
	public function deleteAction(\Mff\Mffdb\Domain\Model\Zimmer $zimmer) {
		$this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->zimmerRepository->remove($zimmer);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->redirect('list');
	}

}