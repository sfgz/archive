<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * KursregelController
 */
class KursregelController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * kursregelRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KursregelRepository
	 * @inject
	 */
	protected $kursregelRepository = NULL;

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 * @inject
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 * @inject
	 */
	protected $fachRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$kursregels = $this->kursregelRepository->findAll();
		$this->view->assign('kursregels', $kursregels);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		$fachbereich = $this->fachbereichRepository->findAll();
		$this->view->assign('fachbereich', $fachbereich);
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $newKursregel
	 * @return void
	 */
	public function createAction(\Mff\Mffdb\Domain\Model\Kursregel $newKursregel) {
		$this->addFlashMessage('The object was created. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->kursregelRepository->add($newKursregel);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $kursregel
	 * @ignorevalidation $kursregel
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\Kursregel $kursregel) {
		$this->view->assign('kursregel', $kursregel);
		$fachbereich = $this->fachbereichRepository->findAll();
		$this->view->assign('fachbereich', $fachbereich);
		$kursregelUid = $kursregel->getUid();
		$rel2kursregel = array();
		$allFachs = $this->fachRepository->findAll();
		if(count($allFachs)){
		    foreach( $allFachs as $fach ){
			$r2kr = $fach->getFachKursregel();
			if($r2kr) {
			    $regelUid = $r2kr->getUid();
			    if( $regelUid != $kursregelUid )continue;
			    $fachUid = $fach->getFachkurz();
			    $rel2kursregel[ $fachUid ]['fachkurz'] = $fachUid;
			    $rel2kursregel[ $fachUid ]['fachbezeichnung'] = $fach->getFachbezeichnung();
			}
		    }
		}
		ksort($rel2kursregel);
		$this->view->assign('fachliste', $rel2kursregel);
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $kursregel
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\Kursregel $kursregel) {
		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
		if( isset($rawGetArguments['tx_mffdb_fbv']['abort']) ) {
		    $this->redirect('list');
		    return;
		}
		$this->kursregelRepository->update($kursregel);
		$this->addFlashMessage('The object was updated. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		
		$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
		$persistenceManager->persistAll();
		$kursregelService = new \Mff\MffImport\Command\KursregelCommandController();
		$kursregelService->execute();
		
		if( isset($rawGetArguments['tx_mffdb_fbv']['save']) ) {
		    $this->redirect('edit', NULL, NULL, array('kursregel' => $kursregel));
		}else{
		    $this->redirect('list');
		}
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $kursregel
	 * @return void
	 */
	public function deleteAction(\Mff\Mffdb\Domain\Model\Kursregel $kursregel) {
		$this->addFlashMessage('The object was deleted. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->kursregelRepository->remove($kursregel);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->redirect('list');
	}

}