<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * FachbereichController
 */
class FachbereichController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 * @inject
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * kurzklasseRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KurzklasseRepository
	 * @inject
	 */
	protected $kurzklasseRepository = NULL;

	/**
	 * kursregelRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KursregelRepository
	 * @inject
	 */
	protected $kursregelRepository = NULL;

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 * @inject
	 */
	protected $fachRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\TeacherRelationRepository
	 * @inject
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\CloudquotaRepository
	 * @inject
	 */
	protected $cloudquotaRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
	 * @inject
	 */
	protected $ecouserRepository = NULL;

	/**
	 * userPids
	 *
	 * @var array()
	 */
	protected $userPids = array();
	
	/**
	* pathToPHPExcel
	*
	* @var string
	*/
	public $pathToPHPExcel = 'typo3conf/ext/mff_contrib/Resources/Private/PHP/PHPExcel_1.8.0/Classes/';
	
	public function initializeAction() {
		/** get PIDs where users are stored from plugin tx_mffdb_fbv **/
		/** set PIDs for ecouserRepository **/
		
		/** @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings */
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');

		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$this->userPids['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
		$this->userPids['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		  
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds( $this->userPids );
		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$fachbereiches = $this->fachbereichRepository->findAll();
		$this->view->assign('fachbereiches', $fachbereiches);
		$this->view->assign('settings', $this->settings );
	}

	/**
	 * action maillists
	 *
	 * @return void
	 */
	public function maillistsAction() {
		if( $this->request->hasArgument('download') ){
		    $requestNames['ausgabeformat'] = $this->request->getArgument('download');
		}elseif( $this->request->hasArgument('ausgabeformat') ){
		    $requestNames['ausgabeformat'] = $this->request->getArgument('ausgabeformat');
		}else{
		    $requestNames['ausgabeformat'] = 0;
		}
		
		if( $this->request->hasArgument('emaillistDate') ){
		    $emaillistDate = $this->date2unix($this->request->getArgument('emaillistDate'));
		}
		$this->settings['emaillistDate'] =  $emaillistDate !== FALSE ? $emaillistDate : time();
		$this->settings['quotaDate'] =  $this->settings['emaillistDate'];

		if($requestNames['ausgabeformat']==1) {
			$tabelle = $this->dwnDocument_fachbereiche();
			$this->settings['csv_options']['text_qualifier'] = '"';
			return $this->download_asCsv( $tabelle , 'Fachbereiche');
		    
		}elseif($requestNames['ausgabeformat']==2) {
			$tabelleKontingente = $this->dwnDocument_quotas($this->settings['quotaDate']);
			$this->settings['csv_options']['text_qualifier'] = '';
			return $this->download_asCsv( $tabelleKontingente , 'Kontingente');
		    
		}elseif($requestNames['ausgabeformat']==3) {
			$tabelle = $this->dwnDocument_infoLehrpersonen();
			return $this->download_asXls( $tabelle , 'Fachbereiche-Lehrpersonen' );
		    
		}elseif($requestNames['ausgabeformat']==4) {
			$tabelle = $this->dwnDocument_infoLernende($this->settings['quotaDate']);
			return $this->download_asXls( $tabelle , 'Klassen-Lernende' );
		    
		}elseif($requestNames['ausgabeformat']==5) {
			$tabelle = $this->dwnDocument_emailLehrpersonen();
			$this->settings['csv_options']['text_qualifier'] = '"';
			$this->settings['csv_options']['delimiter'] = ',';
			return $this->download_asCsv( $tabelle , 'Emaillisten-Lehrpersonen' );
		    
		}elseif($requestNames['ausgabeformat']==6) {
			$tabelle = $this->dwnDocument_emailLernende($this->settings['emaillistDate']);
			$this->settings['csv_options']['text_qualifier'] = '"';
			$this->settings['csv_options']['delimiter'] = ',';
			return $this->download_asCsv( $tabelle , 'Emaillisten-Lernende' );
		}
		
		$this->view->assign('ausgabeformat', $requestNames['ausgabeformat'] );
		$this->view->assign('settings', $this->settings );
		
	}

	/**
	 * action downloads
	 *
	 * @return void
	 */
	public function downloadsAction() {
		if( $this->request->hasArgument('download') ){
		    $requestNames['ausgabeformat'] = $this->request->getArgument('download');
		}elseif( $this->request->hasArgument('ausgabeformat') ){
		    $requestNames['ausgabeformat'] = $this->request->getArgument('ausgabeformat');
		}else{
		    $requestNames['ausgabeformat'] = 0;
		}
		
		if( $this->request->hasArgument('quotaDate') ){
		    $quotaDate = $this->date2unix($this->request->getArgument('quotaDate'));
		    $emaillistDate = $quotaDate;
		}elseif( $this->request->hasArgument('emaillistDate') ){
		    $emaillistDate = $this->date2unix($this->request->getArgument('emaillistDate'));
		}
		$this->settings['emaillistDate'] =  $emaillistDate !== FALSE ? $emaillistDate : time();
		$this->settings['quotaDate'] =  $quotaDate !== FALSE ? $quotaDate : time();

		if($requestNames['ausgabeformat']==1) {
			$tabelle = $this->dwnDocument_fachbereiche();
			$this->settings['csv_options']['text_qualifier'] = '';
			return $this->download_asCsv( $tabelle , 'Fachbereiche');
		    
		}elseif($requestNames['ausgabeformat']==2) {
//  			$tabelleKontingente = $this->dwnDocument_quotas($this->settings['quotaDate']);
			$cloudQuotaUtility = new \Mff\MffCloud\Utility\IntranetUsersUtility();
			$tabelleKontingente =  $cloudQuotaUtility->readIntranetUsersAndCloudgroups($this->settings['quotaDate']);
			$this->settings['csv_options']['text_qualifier'] = '';
			return $this->download_asCsv( $tabelleKontingente , 'Kontingente');
		    
		}elseif($requestNames['ausgabeformat']==3) {
			$tabelle = $this->dwnDocument_infoLehrpersonen();
			return $this->download_asXls( $tabelle , 'Fachbereiche-Lehrpersonen' );
		    
		}elseif($requestNames['ausgabeformat']==4) {
			$tabelle = $this->dwnDocument_infoLernende($this->settings['quotaDate']);
			return $this->download_asXls( $tabelle , 'Klassen-Lernende' );
		    
		}elseif($requestNames['ausgabeformat']==5) {
			$tabelle = $this->dwnDocument_emailLehrpersonen();
			$this->settings['csv_options']['text_qualifier'] = '"';
			return $this->download_asCsv( $tabelle , 'Emaillisten-Lehrpersonen' );
		    
		}elseif($requestNames['ausgabeformat']==6) {
			$tabelle = $this->dwnDocument_emailLernende($this->settings['emaillistDate']);
			$this->settings['csv_options']['text_qualifier'] = '"';
			return $this->download_asCsv( $tabelle , 'Emaillisten-Lernende' );
		}

		// no download, show page
		$tabelleKontingente = $this->dwnDocument_quotas($this->settings['quotaDate']);
		$qsum=array();
		$quotaSumme = 0;
		$personenSumme = 0;
		foreach($tabelleKontingente as $userRow){	
		      if(!isset($userRow['grp_quota'])) continue;
		      $quotaSumme += $userRow['grp_quota'];
		      $personenSumme += 1;
		      $qsum[$userRow['grp_quota']]['summe'] += $userRow['grp_quota'] ;
		      $qsum[$userRow['grp_quota']]['anzahl'] += 1 ;
		}
		ksort($qsum);
		$this->view->assign('ausgabeformat', $requestNames['ausgabeformat'] );
		$this->view->assign('quotaGruppen', $qsum );
		$this->view->assign('summen', array( 'quotas'=>$quotaSumme , 'personen'=>$personenSumme ) );
		$this->view->assign('settings', $this->settings );
		$this->view->assign('downloadPid', $this->settings['downloadPid'] );
		
	}
	public function date2unix( $date ){
		    if( empty($date)) return FALSE;
		    $datAt = explode('.' , $date);
		    if( count($datAt)==3 ) return mktime(0,0,0,$datAt[1],$datAt[0],$datAt[2]);
		    return FALSE;
	}
	protected function xls_formattedCells( $row , $rowIdx , $objPHPExcel , $bold = TRUE , $italic = FALSE, $underline = FALSE   ) {
	      $colIdx=0;
	      foreach($row as $fld) {
		  $objRichText = new \PHPExcel_RichText();
		  $objCellTitle = $objRichText->createTextRun( $fld );
		  $objCellTitle->getFont()->setBold( $bold );
		  $objCellTitle->getFont()->setItalic( $italic );
 		  $objCellTitle->getFont()->setUnderline( $underline );
// 		  $objCellTitle->getFont()->setStrikethrough( TRUE );
		  $objPHPExcel->getActiveSheet()->getCellByColumnAndRow($colIdx,$rowIdx)->setValue($objRichText);
		  $objPHPExcel->getActiveSheet()->getColumnDimension( chr(65+$colIdx) )->setAutoSize(true);
		  ++$colIdx;
	      }
	      return;
	}
	protected function download_asXls( $tablecontent , $title  ) {
		if(!count($tablecontent)) return;
		$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->pathToPHPExcel);
		set_include_path($extDir);
		include $extDir.'PHPExcel/IOFactory.php';

		$objPHPExcel = new \PHPExcel();
		$objPHPExcel->getActiveSheet()->setTitle( $title );
		$rowIdx = 1;
		foreach( $tablecontent as $row ){
			$this->xls_formattedCells( array_keys($row) , $rowIdx , $objPHPExcel , TRUE , TRUE , TRUE );
			++$rowIdx;
		    break;
		}
		$testString = '1';
		foreach($tablecontent as $uid=>$row){
		    $colIdx=0;
		    if( empty($testString) ){
			$this->xls_formattedCells( $row , $rowIdx , $objPHPExcel  );
		    }else{
			foreach($row as $fld=>$cellValue) {
			    $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($colIdx,$rowIdx,$cellValue );
			    ++$colIdx;
			}
		    }
		    $testString = implode( '' , $row );
		    ++$rowIdx;
		}
		$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0,$rowIdx, '' );

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="'.$title.'.xlsx"');
		header('Cache-Control: max-age=0');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		
		exit();
	}
	protected function download_asCsv( $tablecontent , $title  ) {
	    $delimiter = $this->settings['csv_options']['delimiter'];
	    $encoding = $this->settings['csv_options']['encoding'];
	    $tq = $this->settings['csv_options']['text_qualifier'];
	    if(!count($tablecontent)) return;
	    $z=0;
	    $delimiter = empty($delimiter) ? ';' : $delimiter;
		$firstRow = array_shift( $tablecontent );
	    if(count($firstRow)) {
				$strOut = $tq . implode( $tq . $delimiter . $tq , $firstRow ) . $tq."\n";
		}
	    foreach( $tablecontent as $idx => $row ){
			$rowArr=array();
			foreach( $firstRow as $rowNr ){
					if(!isset($row[$rowNr])){
						$rowArr[] =  '' ;
					}else{
						$cell = $row[$rowNr];
						if(is_numeric($cell)){
								$rowArr[] =  $cell ;
						}else{
								$rowArr[] = $tq . $cell . $tq;
						}
					}
			}
			$strOut .= implode( $delimiter  , $rowArr) ."\n";
	    }
	    if('utf-8' == strtolower($encoding) || empty($encoding) ){
		$outString = ($strOut);
	    }else{
//		$outString =  utf8_encode( $strOut );
// 		$outString =  iconv( 'utf-8' , $encoding , $strOut);
		$outString = ($strOut);
	    }
	    
           $headers = array(
                'Pragma'                    => 'public', 
                'Expires'                   => 0, 
                'Cache-Control'             => 'must-revalidate, post-check=0, pre-check=0',
                'Cache-Control'             => 'public',
                'Content-Description'       => 'File Transfer',
                'Content-Type'              => 'application/vnd.ms-excel',
                'Content-Disposition'       => 'attachment; filename="'.$title.'.csv"',
                'Content-Transfer-Encoding' => 'binary'        
            );

            foreach($headers as $header => $data) $this->response->setHeader($header, $data); 

            $this->response->sendHeaders();  
            
            echo $outString;
            
            exit;
	}

	public function dwnDocument_fachbereiche() {
		$fachbereiches = $this->fachbereichRepository->findAll();
		$fbTeachers = $this->teacherRelationRepository->findAll();
		// $krzKlasseQuota: GruppeBezeichnung aus Fachbereich
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    $cloudKey = $fb->getCloudKey();
		    if(!empty($cloudKey)) $krzKlasseQuota[$uid] = $cloudKey;
		}
		// $teaEcouser: Fachbereiche der Lehrpersonen
		$teaEcouser = array();
		foreach( $fbTeachers as $tea ){
		    $user = $tea->getTeaEcouser();
		    if( !empty($user) ) {
				$uid = $user->getUid();
				$teaFb = $tea->getFachbereich();
				if(!isset($teaEcouser[$uid]['username'])) {
					$teaEcouser[$uid]['username'] = $user->getUsername();
					$teaEcouser[$uid]['email'] = $user->getEmail();
					$teaEcouser[$uid]['quota'] = $user->getCloudQuota();
				}
				if(!empty($krzKlasseQuota[$teaFb])) $teaEcouser[$uid]['grp'][] = $this->settings['csv_options']['fachbereich_prefix'].$krzKlasseQuota[$teaFb];
		    }
		}
		// $rowCount: Anzahl Gruppen ermitteln
		$rowCount = 0;
		foreach( $teaEcouser as $uid=>$teaRow ){
		    $gidCount = count($teaRow['grp']);
		    if( $gidCount > $rowCount ) $rowCount = $gidCount;
		}
		// $tabelle: Output Lehrpersonen und Fachbereiche zusammenziehen
		$tabelle = array();
		foreach( $teaEcouser as $uid=>$teaRow ){
		    if( !is_array($teaRow['grp']) ) continue;
		    if( strpos( $teaRow['username'] , '.' ) == 0) continue;
		    $tabelle[$uid]['username'] = $teaRow['username'];
// 		    $tabelle[$uid]['email'] = $teaRow['email'];
// 		    $tabelle[$uid]['quota'] = $teaRow['quota'];
		    sort($teaRow['grp']);
		    for( $gid = 0 ; $gid < $rowCount ; ++$gid ){
				$rNr = $gid+1;
				$tabelle[$uid]['grp_'.$rNr] = isset($teaRow['grp'][$gid]) ? $teaRow['grp'][$gid]: '';
		    }
		}
		return $tabelle;
	}

	/**
	* dwnDocument_quotas
	* UNUSED! use \Mff\MffCloud\Utility\IntranetUsersUtility->readIntranetUsersAndCloudgroups() instead
	* teacher quota and groups from Database
	* students groups from File
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function dwnDocument_quotas($now=0) {
		if($now == FALSE ) $now = time();
		$cloudquotas = $this->cloudquotaRepository->findAll();
		$fachbereiches = $this->fachbereichRepository->findAll();
		$ecousers = $this->ecouserRepository->findAll();

		// $cloudQuota: Quotas.Array
		$cloudQuota = array();
		foreach( $cloudquotas as $quota ){
		    $quotaUid = $quota->getUid();
		    $cloudQuota[$quotaUid] = $quota->getSpeicherplatz();
		}
		// creates array $klasseKontingent with Quota per Klasse
		$klasseKontingent = array();
		$today = floor( $now / (3600*24) ) * 3600 * 24;
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    $fbKurzklassen = $fb->getFbKurzklassen();
		    if(empty($fbKurzklassen)) continue;
		    foreach( $fbKurzklassen as $krzKlasse ){
					$quotaUid = $krzKlasse->getKrzCloudquota();
					$klassen = $krzKlasse->getKrzKlassen();
					if(empty($klassen)) continue;
					foreach( $klassen as $klasse ){
						$clsId = $klasse->getUid();
						$clsEnd = $klasse->getKlasseEnde();
						if(!empty($clsId)){
								if($clsEnd >= $today){
									$klasseKontingent[$clsId] = $quotaUid->getUid();
								}else{
									$klasseKontingent[$clsId] = $this->settings['quotaUidZero'];
								}
						}
					}
		    }
		}
		
		// $tabelleKontingente: output Name and Quota
		$tabelleKontingente = array();
		foreach( $ecousers as $user ){
		    $username = $user->getUsername();
		    if( strpos( $username , '.' ) == 0) continue;
		    $tab = array();
		    $tab['username'] = $username;
		    if(empty($tab['username']))continue;
		    $acronym = $user->getEcoAcronym();
		    $ecoKlasse = $user->getEcoKlasse();
		    $persQuota = $user->getCloudQuota();
		    if(!empty($persQuota)) {
				$tab['grp_quota'] = $persQuota;
		    }elseif(!empty($acronym)) {
				$tab['grp_quota'] = $cloudQuota[ $this->settings['quotaUidTeacher'] ];
		    }elseif(!empty($ecoKlasse)){
				$tab['grp_quota'] = $cloudQuota[ $klasseKontingent[$ecoKlasse->getUid()] ];
		    }
		    if(!isset($tab['grp_quota']))continue;
		    $tabelleKontingente[] = $tab;
		}
		return $tabelleKontingente;
	}

	public function dwnDocument_infoLehrpersonen() {
		$fachbereiches = $this->fachbereichRepository->findAll();
		$fbTeachers = $this->teacherRelationRepository->findAll();
		// $fbTeacher: array with fachbereiches and belonging teachers
		$fbTeacher = array();
		foreach( $fbTeachers as $tea ){
		    $user = $tea->getTeaEcouser();
		    if( !empty($user) ) {
			$username = $user->getUsername();
			if( strpos( $username , '.' ) == 0) continue;
			$teaFb = $tea->getFachbereich();
			$fbTeacher[$teaFb][$username]['fullname'] = $user->getName();
			$fbTeacher[$teaFb][$username]['leiter'] = $tea->getLeiter() == 1 ? 'Ja' : '';
		    }
		}
		// $tabelle: create output with teacher and more infos about fachbereiches
		$tabelle = array();
		$tabelle[] = array( 'Fachbereich' => '' , 'ownCloud-Gruppe' => '' , 'Leitung' => '');
		foreach( $fachbereiches as $fb ){
		    $cloudKey = $fb->getCloudKey();
		    if(empty($cloudKey))continue;
		    $uid = $fb->getUid();
		    // head-row with details about Fachbereich
		    $tabelle[] = array(
			'Fachbereich' => $fb->getFachbereichname(),
			'ownCloud-Gruppe' => 'lp-'.$cloudKey,
			'Leitung'=>''
		    );
		    // body with teacher-details
		    ksort($fbTeacher[$uid]);
		    foreach( $fbTeacher[$uid] as $ftUser=>$ftName ){
			$tabelle[] = array(
			    'Fachbereich' => $ftName['fullname'],
			    'ownCloud-Gruppe' => $ftUser,
			    'Leitung' => $ftName['leiter']
			);
		    }
		    //empty trailing row
		    $tabelle[] = array( 'Fachbereich' => '' , 'ownCloud-Gruppe' => '' , 'Leitung' => '');
		}
		return $tabelle;
	}

	public function dwnDocument_infoLernende($now=0) {
		if($now == FALSE ) $now = time();
		$cloudquotas = $this->cloudquotaRepository->findAll();
		$fachbereiches = $this->fachbereichRepository->findAll();
		$ecousers = $this->ecouserRepository->findByPid( $this->userPids['studentPid'] );
		// $classShort: klassen with field 'classhort'
		$classShort = array();
		$classQuota = array();
		$today = floor( $now / (3600*24) ) * 3600 * 24;
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    $fbKurzklassen = $fb->getFbKurzklassen();
		    if(empty($fbKurzklassen)) continue;
		    foreach( $fbKurzklassen as $krzKlasse ){
			if(empty($krzKlasse)) continue;
			$quotaUid = $krzKlasse->getKrzCloudquota()->getUid();
			$klas = $krzKlasse->getKrzKlassen();
			if(empty($klas)) continue;
			foreach( $klas as $klasse ){
			    $clsId = $klasse->getUid();
			    if(!empty($clsId)){
				$classShort[$clsId] = $klasse->getClassShort();
				$clsEnd = $klasse->getKlasseEnde();
				if($clsEnd >= $today){
				    $classQuota[$clsId] = $quotaUid;
				}else{
				    $classQuota[$clsId] = $this->settings['quotaUidZero'];
				}
			    }
			}
		    }
		}
		// $cloudQuota: Quotas.Array
		$cloudQuota = array();
		foreach( $cloudquotas as $quota ){
		    $quotaUid = $quota->getUid();
		    $cloudQuota[$quotaUid] = $quota->getSpeicherplatz();
		}
		// $klassen: array with classname and username as array-names
		$klassen = array();
		foreach( $ecousers as $user ){
		    $tab = array('Klasse'=>'');
		    $ecoKlasse = $user->getEcoKlasse();
		    if(!empty($ecoKlasse)){
				$classUid = $ecoKlasse->getUid();
				$tab['Klasse'] = $classShort[$classUid];
		    }
			if(empty($tab['Klasse'])){
				$tab['Klasse'] = 'keine';
				$tab['Quota'] = $cloudQuota[ $this->settings['quotaUidZero'] ];
			}else{
				$tab['Quota'] = $cloudQuota[ $classQuota[$classUid] ];
			}
		    
		    $tab['Username'] = $user->getUsername();
		    if(empty($tab['Username']))continue;
		    
		    $tab['Name'] = $user->getName();
		    if(empty($tab['Name']))continue;
		    
		    $tab['Email'] = $user->getEmail();
		    if(empty($tab['Email']))continue;
		    
		    $klassen[$tab['Klasse']][$tab['Username']] = $tab;
		}
		// $tabelle: sorted output
		$tabelle = array();
		ksort($klassen);
		foreach( $klassen as $klsId=>$klasse ){
		    foreach( $klasse as $person ){
			$tabelle[] = $person;
		    }
		}
		return $tabelle;
	}

	public function dwnDocument_emailLernende($now=0) {
	      if($now == FALSE ) $now = time();
	      $today = floor( $now / (3600*24) ) * 3600 * 24;
	      $fachbereiches = $this->fachbereichRepository->findAll();
	      $ecousers = $this->ecouserRepository->findAll();
	      // $classShort: klassen mit Feld 'classhort'
	      $classShort = array();
	      foreach( $fachbereiches as $fb ){
		  $uid = $fb->getUid();
		  $fbKurzklassen = $fb->getFbKurzklassen();
		  if(empty($fbKurzklassen)) continue;
		  foreach( $fbKurzklassen as $krzKlasse ){
		      if(empty($krzKlasse)) continue;
		      $klas = $krzKlasse->getKrzKlassen();
		      if(empty($klas)) continue;
		      foreach( $klas as $klasse ){
			  $clsEnd = $klasse->getKlasseEnde();
			  if($clsEnd < $today) continue;
			  $clsId = $klasse->getUid();
			  if(!empty($clsId)) $classShort[$clsId] = array( 'fbId'=>sprintf( '%02s' , $uid ) , 'classShort'=>$klasse->getClassShort() );
		      }
		  }
	      }
	      // students im Array $klassen sammeln mit Format: $klassen[ fbId ][ classShort ][ Email ] = Name <Email>
	      foreach( $ecousers as $user ){
		  $tab = array();
		  $ecoKlasse = $user->getEcoKlasse();
		  if(empty($ecoKlasse))continue;
		  $classUid = $ecoKlasse->getUid();
		  $tab['Klasse'] = $classShort[$classUid]['classShort'];
		  $tab['fbId'] = $classShort[$classUid]['fbId'];
		  if(empty($tab['Klasse']))continue;
		  $tab['Name'] = $user->getName();
		  if(empty($tab['Name']))continue;
		  $tab['Email'] = $user->getEmail();
		  if(empty($tab['Email']))continue;
		  $klassen[ $tab['fbId']  ][ $tab['Klasse'] ][ $tab['Email'] ] = $tab['Name'] . ' <'.$tab['Email'].'>';
	      }
	      // je Klasse eine Zeile mit Fachbereich-Nr im Titel
	      $tabelle = array( array( 'dlist','fileAs','nickname','type' ) );
	      if(count($klassen)) {
				ksort($klassen);
				foreach($klassen as $fbId=>$fbRow){
					ksort($fbRow);
					foreach($fbRow as $idx=>$classRow){
						ksort($classRow);
						$tabelle[$idx]['dlist'] = implode( ',' , $classRow );
						$tabelle[$idx]['fileAs'] = '8:'.$fbId. ' '.$idx. ' ('.count($classRow).')';
						$tabelle[$idx]['nickname'] = $idx;
						$tabelle[$idx]['type'] = 'group';
					}
				}
	      }
	      return $tabelle;
	}

	public function dwnDocument_emailLehrpersonen() {
	      $subtitels = array( 'FB ' , 'nur ABU:' , 'mit ABU:' , 'KlsLp: ' );
	      $teaNams = array();
	      $teaNams[0] = $this->getFachbereicheLehrpersonen();
	      $teaNams[1] = $this->getFachbereicheKlassenKursPlanLehrpersonen();
	      $teaNams[2] = $teaNams[1] ;
	      foreach( $teaNams[1] as $fb=>$abuFbTeachers ){
		  if( !isset($teaNams[0][$fb]) ) continue;
		  foreach( $teaNams[0][$fb] as $tid=>$teacher){
			$teaNams[2][$fb][$tid]=$teacher;
		  }
	      }
	      $teaNams[3] = $this->getFachbereicheKlassenLehrpersonen();
	      $tabelle = array( array( 'dlist','fileAs','nickname','type' ) );
	      foreach( $teaNams as $tableNr=>$tab ){
				if(count($tab)){
						ksort($tab);
						foreach( $tab as $fbUid=>$fbRow ) {
								if(!is_array($fbRow))continue;
								ksort($fbRow);
								$aDlist =array();
								foreach( $fbRow as $teacherID=>$teach ) {
									if(!isset($aDlist['nickname'])) $aDlist['nickname'] = $teach['fachbereich'];
									$aDlist['dlist'][]= $teach['name'] . ' <' . $teach['email'] . '>';
								}
								$description = trim($subtitels[$tableNr].' '.$aDlist['nickname']  );
								$tabelle[$tableNr.'.'.$fbUid]['dlist'] = implode(',',$aDlist['dlist']);
								$tabelle[$tableNr.'.'.$fbUid]['fileAs'] = '8:'.$description. ' (' . count($aDlist['dlist']) .')';
								$tabelle[$tableNr.'.'.$fbUid]['nickname'] = $description;
								$tabelle[$tableNr.'.'.$fbUid]['type'] = 'group';
						}
				}
	      }
	      return $tabelle;
	      
	}

	public function getFachbereicheLehrpersonen() {
		// array with Fachbereich name and teachers of Fachbereich
		// Fachbereich->Kurzklassen->klassen $aKlasseFbId[classUid] = fbUid;
		//$addToIncome = count($teaNams) ? 1 : 0;
		$teaNams = array();
		$tableFachbereiche = $this->fachbereichRepository->findAll();
		foreach($tableFachbereiche as $Fachbereich){
		      $klsFachbereichId = $Fachbereich->getUid();
		      //if( $addToIncome && !is_array( $teaNams[$klsFachbereichId] ) ) continue;
		      $fbFachbereichname = $Fachbereich->getFachbereichname();
		      $fbTeachers = $Fachbereich->getFbTeachers();
		      if(!empty($fbTeachers)){
			  foreach($fbTeachers as $fTeacher){
			      $ecoUser = $fTeacher->getTeaEcouser();
			      if(empty($ecoUser))continue;
			      $teacherID = $ecoUser->getUid();
			      $teacherName = $ecoUser->getUsername();
			      $acronym = $ecoUser->getEcoAcronym();
			      if(empty($acronym))continue;
			      if(empty($teacherName))continue;
			      if( !strpos( $teacherName , '.' ) )continue;
			      $valuesList = array(
				  'id'       => $teacherID , 
				  'username' => $teacherName , 
				  'name'     => $ecoUser->getName(), 
				  'email'    => $ecoUser->getEmail(),
				  'fachbereich'    => $fbFachbereichname 
			      );
			      $teaNams[$klsFachbereichId][$teacherName.$teacherID] = $valuesList;
			  }
		      }
		}
		return $teaNams;
	}

	public function getFachbereicheKlassenLehrpersonen() {
		$ecouserRepository = $this->ecouserRepository->findTeachers();
		foreach( $ecouserRepository as $teacher ){
		    $userUid = $teacher->getEcoKey();
		    if( empty( $userUid )  )continue;
		    $firstName = $teacher->getFirstName();
		    if( empty( $firstName )  )continue;
		    $lastName = $teacher->getLastName();
		    $shownname = substr( $firstName , 0 , 1) . '.' . $lastName;
		    $teachersList[ $userUid ] = array( 'name'=>$shownname , 'email'=>$teacher->getEmail() );
		}
		
		// array with Fachbereich name and classes of Fachbereich
		// Fachbereich->Kurzklassen->klassen $aFbIdKlassenLehrperson[classUid] = fbUid;
		$teaNams = array();
		$aFbIdKlassenLehrperson = array();
		$tableFachbereiche = $this->fachbereichRepository->findAll();
		foreach($tableFachbereiche as $Fachbereich){
		      $klsFachbereichId = $Fachbereich->getUid();
		      $sFachbereichname = $Fachbereich->getFachbereichname();
		      $tableKurzklassen = $Fachbereich->getFbKurzklassen();
		      if(!empty($tableKurzklassen)){
			  foreach($tableKurzklassen as $Kurzklasse){
			      $krzKlassen = $Kurzklasse->getKrzKlassen();
			      if(!empty($krzKlassen)){
				  foreach( $krzKlassen  as $class ) {
				      $classTeacherId = $class->getClassteacherId();
				      if(empty($classTeacherId)) continue;
				      if(empty($teachersList[ $classTeacherId ]['email'])) continue;
				      $classUid = $class->getUid();
				      $classShort = str_replace( ' ' , '-' , $class->getClassShort() );
				      $aFbIdKlassenLehrperson[$klsFachbereichId][$classShort.$classUid] = array(
					  'name' => $classShort.' '.$teachersList[ $classTeacherId ]['name'],
					  'email' => $teachersList[ $classTeacherId ]['email'],
					  'fachbereich' => $sFachbereichname
				      );
				  }
			      }
			  }
		      }
		      if(is_array($aFbIdKlassenLehrperson[$klsFachbereichId]))ksort($aFbIdKlassenLehrperson[$klsFachbereichId]);
		}
		return $aFbIdKlassenLehrperson;
	}

	public function getFachbereicheKlassenKursPlanLehrpersonen() {
		// BK+ABU: Fachbereiche aus unterrichteten Klassen ermitteln.
		
		// array with Fachbereich name and classes of Fachbereich
		// Fachbereich->Kurzklassen->klassen $aKlasseFbId[classUid] = fbUid;
		$teaNams = array();
		$fbFachbereichname = array();
		$aKlasseFbId = array();
		$tableFachbereiche = $this->fachbereichRepository->findAll();
		foreach($tableFachbereiche as $Fachbereich){
		      $klsFachbereichId = $Fachbereich->getUid();
		      $fbFachbereichname[$klsFachbereichId] = $Fachbereich->getFachbereichname();
		      $tableKurzklassen = $Fachbereich->getFbKurzklassen();
		      if(!empty($tableKurzklassen)){
			  foreach($tableKurzklassen as $Kurzklasse){
			      $krzKlassen = $Kurzklasse->getKrzKlassen();
			      if(!empty($krzKlassen)){
				  foreach( $krzKlassen  as $class ) $aKlasseFbId[$class->getUid()] = $klsFachbereichId;
			      }
			  }
		      }
		}
		// create array with fachbereich-ids for courses, get them from classes of course
		//    Fach->Kurse->KurseKlassen $aFachbereicheIds[ courseId ][ fbUid ] = fbUid
		// create array $teaNams with the fachbereichIds from course and teacherId and fieldnames as keys
		//    FOREACH Fach->Kurse->$aFachbereicheIds[ courseId ] AS fbUid
		//    Fach->Kurse->KursPlaene->PlanTeacher ->  $teaNams[ fbUid ][ teacherID ][fld] 
		
		$aFachbereicheIds = array();
		$tableFach = $this->fachRepository->findAll();
		$importExtConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);
		$yearsInPast = empty($importExtConf['daterange_teacher_relations']) ? 1 : $importExtConf['daterange_teacher_relations'];
		$now = time() - (3600*24*365 * $yearsInPast);//now minus x years
		foreach($tableFach as $fach){
		    $kRegeln = $fach->getFachKursregel();
		    if( empty($kRegeln) ) continue;
		    $regelFbUid = $kRegeln->getFachbereich();
		    if( $regelFbUid != $this->settings['abuFbUid'] ) continue;
		    $kurse = $fach->getFachKurse();
		    foreach($kurse as $course){
			$courseId = $course->getCourseId();
			if(empty($courseId))continue;
			$courseClasses = $course->getKurseKlassen();
			if(empty($courseClasses))continue;
			foreach($courseClasses as $class){
			    $classUid = $class->getUid();
			    if( $now > $class->getKlasseEnde() ) continue;
			    if(isset($aKlasseFbId[$classUid]))$aFachbereicheIds[$courseId][$aKlasseFbId[$classUid]] = $aKlasseFbId[$classUid];
			}
			$coursePlaenes = $course->getKursPlaene();
			if(empty($coursePlaenes))continue;
			foreach($coursePlaenes as $plan){
			    $ecoUser = $plan->getPlanTeacher();
			    if(empty($ecoUser))continue;
			    if( $now > $plan->getPlanEnde() ) continue;
			    $teacherID = $ecoUser->getUid();
			    $teacherName = $ecoUser->getUsername();
			    $acronym = $ecoUser->getEcoAcronym();
			    if(empty($acronym))continue;
			    if(empty($teacherName))continue;
			    if( !strpos( $teacherName , '.' ) )continue;
			    $valuesList = array(
				'id'       => $teacherID , 
				'username' => $teacherName , 
				'name'     => $ecoUser->getName(), 
				'email'    => $ecoUser->getEmail() 
			    );
			    if(is_array($aFachbereicheIds[$courseId])){
				foreach( $aFachbereicheIds[$courseId] as $fbUid ){
				    if(!isset($fbFachbereichname[$fbUid]))continue;
				    $teaNams[$fbUid][$teacherName.$teacherID] = $valuesList;
				    $teaNams[$fbUid][$teacherName.$teacherID]['fachbereich'] = $fbFachbereichname[$fbUid];
				}
			    }
			}
		    }
		}
		return $teaNams;
	}

	/**
	 * action show
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fachbereich $fachbereich
	 * @return void
	 */
	public function showAction(\Mff\Mffdb\Domain\Model\Fachbereich $fachbereich) {
		$this->view->assign('fachbereich', $fachbereich);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fachbereich $newFachbereich
	 * @return void
	 */
	public function createAction(\Mff\Mffdb\Domain\Model\Fachbereich $newFachbereich) {
		$this->addFlashMessage('The object was created. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->fachbereichRepository->add($newFachbereich);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fachbereich $fachbereich
	 * @ignorevalidation $fachbereich
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\Fachbereich $fachbereich) {
		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();
		$removeTeacher = 0;
		$hideTeacherNr = 0;
		if( !empty($rawGetArguments['tx_mffdb_fbv']['delteacher']) ) {
		    // remove user
		    $change = array();
		    $removeTeacher = $rawGetArguments['tx_mffdb_fbv']['delteacher'] ;
		    $fbUid = $fachbereich->getUid();
		    $fbTeachers = $this->teacherRelationRepository->findByMother( $fbUid , TRUE );
		    foreach( $fbTeachers as $teacher ){
			$teacherRelationId = $teacher->getUid();
			if( $teacherRelationId == $removeTeacher ){
			    $this->teacherRelationRepository->remove($teacher);
			    $change[] = ' '. $removeTeacher . ' aus Fachbereich entfernt';
			}
		    }
		}
		if( !empty($rawGetArguments['tx_mffdb_fbv']['teacher_hide']) ) { 
		    $bHidden = TRUE;
		    $hideTeacherNr = $rawGetArguments['tx_mffdb_fbv']['teacher_hide'];
		}elseif( !empty($rawGetArguments['tx_mffdb_fbv']['teacher_unhide']) ) {  
		    $bHidden = FALSE; 
		    $hideTeacherNr = $rawGetArguments['tx_mffdb_fbv']['teacher_unhide'];
		}
		if( !empty($hideTeacherNr) ){
		    // hide/unhide user
		    $aStatusText = array( false=>'angezeigt' , true=>'versteckt' );
		    $change = array();
		    $fbUid = $fachbereich->getUid();
		    $fbTeachers = $this->teacherRelationRepository->findByMother( $fbUid , TRUE );
		    foreach( $fbTeachers as $teacher ){
			$teacherRelationId = $teacher->getUid();
			if( $teacherRelationId == $hideTeacherNr ){
			    $teacher->setHidden( $bHidden );
			    $this->teacherRelationRepository->update($teacher);
			    $change[] = ' '. $hideTeacherNr . ' wird fuer Fachbereich ' . $aStatusText[ $bHidden ];
			}
		    }
		}
		if( $removeTeacher || $hideTeacherNr ) {
		    // persist if changed something
		    if(count($change)) {
			$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
			$persistenceManager->persistAll();
			$this->addFlashMessage('&Auml;nderung an den Lehrpersonen des Fachbereichs wurde gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		    }else{
			$this->addFlashMessage('Da ging was schief - &Auml;nderung nicht gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
		
		$rel2kursregel = array();
		$allFachs = $this->fachRepository->findAll();
		foreach( $allFachs as $fach ){
		    $r2kr = $fach->getFachKursregel();
		    if($r2kr) {
			$regelUid = $r2kr->getUid();
			$fachUid = $fach->getFachkurz();
			$rel2kursregel[ $regelUid ][ $fachUid ]['fachkurz'] = $fach->getFachkurz();
			$rel2kursregel[ $regelUid ][ $fachUid ]['fachbezeichnung'] = $fach->getFachbezeichnung();
		    }
		}
		foreach( array_keys($rel2kursregel) as $ix ){ ksort($rel2kursregel[$ix]);}
		
		$fbTeachers = array();
 		$groupOfTeachers = $this->teacherRelationRepository->findByMother( $fachbereich->getUid() , TRUE );
		foreach( $groupOfTeachers as $teacher ){
		    $teaEcouser = $teacher->getTeaEcouser();
		    if( !$teaEcouser ) continue;
		    $leiter = $teacher->getLeiter();
		    $isHidden = $teacher->getHidden();
		    $uid = $isHidden ? 2 : 1;
		    $uid .= ($leiter) ? 1 : 2;
		    $uid .= $teaEcouser->getUsername().$teacher->getUid();
		    $fbTeachers[$uid]['uid'] = $teacher->getUid();
		    $fbTeachers[$uid]['userUid'] = $teaEcouser->getUid();
		    $fbTeachers[$uid]['leiter'] = $leiter;
		    $fbTeachers[$uid]['autoReference'] = $teacher->getAutoReference();
		    $fbTeachers[$uid]['hidden'] = $isHidden;
		    $fbTeachers[$uid]['name'] = $teaEcouser->getName();
		    $fbTeachers[$uid]['ecoAcronym'] = $teaEcouser->getEcoAcronym();
		    $setAsTeacher[ $teaEcouser->getUid() ] = $uid;
		}
		if(count($fbTeachers)) ksort($fbTeachers);
		
		$newTeachersList = array();
		$ecouserRepository = $this->ecouserRepository->findTeachers();
		foreach( $ecouserRepository as $teacher ){
		    $username = $teacher->getUsername();
		    if( !strpos( $username , '.' ) )continue;
		    if( $username == 'abu.abu'   )continue;
		    $fullname = $teacher->getName();
		    if( strpos( $fullname , ' und ' )  )continue;
		    $userUid = $teacher->getUid();
		    if( !isset($setAsTeacher[$userUid]) ) $newTeachersList[ $userUid ] = $fullname;
		}
		$kurzklasse = $this->kurzklasseRepository->findAllOrderByKurzbezeichnung();
		$kursregel = $this->kursregelRepository->findAll();
		// list all recordsets for Paginator
		$fachbereiches = $this->fachbereichRepository->findAll();
		$this->view->assign('allfachbereiches', $fachbereiches);
		$this->view->assign('fachbereich', $fachbereich);
		$this->view->assign('kurzklasse', $kurzklasse);
		$this->view->assign('kursregel', $kursregel);
		$this->view->assign('rel2kursregel', $rel2kursregel);
		$this->view->assign('teachers', array( 'fbteachers'=>$fbTeachers , 'listnewteachers'=>$newTeachersList ));
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fachbereich $fachbereich
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\Fachbereich $fachbereich) {
 		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
		if( isset($rawGetArguments['tx_mffdb_fbv']['abort']) ) {
		    $this->redirect('list');
		    return;
		}
 		if( isset($rawGetArguments['tx_mffdb_fbv']['teacherRelation']['leiter']) ||
 		!empty($rawGetArguments['tx_mffdb_fbv']['teacherRelation']['newteacher']) ) {
		    $fbUid = $fachbereich->getUid();
		    $fbTeachers = $this->teacherRelationRepository->findByMother( $fbUid );
		    $change = array();
		    if( !empty($rawGetArguments['tx_mffdb_fbv']['teacherRelation']['newteacher']) ) {
			// add new user, if affored
			$newTeacher = $rawGetArguments['tx_mffdb_fbv']['teacherRelation']['newteacher'] ;
			$newTeacherUser = $this->ecouserRepository->findByUid($newTeacher);
			if( $newTeacherUser ){
			    $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffdb\Domain\Model\TeacherRelation');
			    $newCode->setFachbereich($fbUid);
			    $newCode->setTeaEcouser( $newTeacherUser );
			    $this->teacherRelationRepository->add($newCode);
			    $change[] = ' "'. $newTeacherUser->getName() . '" zum Fachbereich hinzugef&uuml;gt';
			}
		    }
		    // change leiter, if affored
		    $fachbereichsleiter = array();
		    if(is_array($rawGetArguments['tx_mffdb_fbv']['teacherRelation']['leiter'])) {
			foreach( $rawGetArguments['tx_mffdb_fbv']['teacherRelation']['leiter'] as $id => $teacherRelationId){
			    $fachbereichsleiter[$teacherRelationId]=$teacherRelationId;
			}
		    }
		    foreach( $fbTeachers as $teacher ){
			$teacherRelationId = $teacher->getUid();
			$leiter = $teacher->getLeiter();
			if( 
			    $fachbereichsleiter[ $teacherRelationId ] && empty($leiter )
			){ 
			    $change[$teacherRelationId] = ' ' . $teacherRelationId . ' als LeiterIn markiert ';
			    $teacher->setLeiter( 1 );
			    $this->teacherRelationRepository->update($teacher);
			}elseif(
			    !isset($fachbereichsleiter[ $teacherRelationId ]) && $leiter
			){
			    $change[$teacherRelationId] = ' ' . $teacherRelationId . ' als LeiterIn entfernt ';
			    $teacher->setLeiter( NULL );
			    $this->teacherRelationRepository->update($teacher);
			}
		    }
		    // persist if changed something
		    if(count($change)) {
			$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
			$persistenceManager->persistAll();
			$this->addFlashMessage('&Auml;nderung an den Lehrpersonen des Fachbereichs wurde gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		    }
 		}else{
		    $this->fachbereichRepository->update($fachbereich);
		    $this->addFlashMessage('Fachbereich wurde gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
 		}
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		if( !isset($rawGetArguments['tx_mffdb_fbv']['save_close']) ) {
		    $this->forward('edit', NULL, NULL, array('fachbereich' => $fachbereich));
		}else{
		    $this->redirect('list');
		}
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fachbereich $fachbereich
	 * @return void
	 */
	public function deleteAction(\Mff\Mffdb\Domain\Model\Fachbereich $fachbereich) {
		$this->addFlashMessage('The object was deleted. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->fachbereichRepository->remove($fachbereich);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->redirect('list');
	}

}
