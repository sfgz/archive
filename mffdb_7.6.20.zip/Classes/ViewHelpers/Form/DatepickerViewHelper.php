<?php
namespace Mff\Mffdb\ViewHelpers\Form;

/**
 * View Helper which creates a text field (<input type="text">).
 *
 * = Examples =
 * 
 * on top of template or partial: 
 * {namespace mff = Mff\Mffdb\ViewHelpers}
 * 
 * <code title="Example">
 * <mff:form.datepicker name="myDate" value="16.07.1993" />
 * </code>
 *
 * <output>
 * <input type="text" name="myDate" value="myDateValue" />
 * </output>
 *
 */
 
class DatepickerViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\TextfieldViewHelper {
    
	/**
	 * @var string
	 */
	protected $tagName = 'input';
    
	/**
	 * @var string
	 */
	protected $dateFormat = 'd.m.Y';

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('form','string','als Beispiel kalender',FALSE);
		$this->registerArgument('wrap','string','als Beispiel div',FALSE);
	}
    
	/**
	 * Renders the textfield.
	 *
	 * @param boolean $required If the field is required or not
	 * @param string $type The field type, e.g. "text", "email", "url" etc.
	 * @return string
	 * @api
	 */
	public function render($required = NULL, $type = 'text') {
		$name = $this->getName();
		
		$form = $this->arguments['form'] !== NULL ? $this->arguments['form'] : $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
		
		$css = $this->arguments['class'] !== NULL ? $this->arguments['class'] : '';
		
		$field = $this->arguments['property'] !== NULL ? $this->arguments['property'] : $this->arguments['name'];
		
		$dateValue = $this->getValue();
		if ($dateValue == NULL) $dateValue = $this->renderChildren();
		//if ($dateValue == NULL) $dateValue = date( $this->dateFormat );
		
		if ($required !== NULL) $this->tag->addAttribute('required', 'required');
		if (strlen($dateValue)>=8) {$this->tag->addAttribute('value', $dateValue);}else{
		$this->tag->addAttribute('value', '');
		}
		$this->tag->addAttribute('type', $type);
		$this->tag->addAttribute('name', $name);
		$this->tag->addAttribute( 'id' , $field );
		
		if( $this->arguments['wrap'] == 'div' ){
		      $this->tag->addAttribute( 'class' , 'tx-mffdb' );
		}else{
		      $this->tag->addAttribute( 'class' , trim($css . ' tx-mffdb') );
		}
		
		$this->registerFieldNameForFormTokenGeneration($name);
		
		$this->setErrorClassAttribute();
		
		$jsText = $this->getJavaScript($field,$form);
		
		$renderedTag =  $jsText . $this->tag->render();
		
		if( $this->arguments['wrap'] == 'div'){
		      return '<div class="'.trim($css . ' tx-mffdb').'" style="width:auto;float:left;margin-right:2px;">' . $renderedTag . '</div>'  ;
		}elseif( $this->arguments['wrap'] ){
		      return '<'.$this->arguments['wrap'].' class="'.trim($css . ' tx-mffdb').'">' . $renderedTag . '</'.$this->arguments['wrap'].'>'  ;
		}else{
		      return $renderedTag;
		}
		
	}

	/**
	 * Get the js part
	 *
	 * @param string $field name of the field e.g. datumbeginn
	 * @return mixed
	 */
	protected function getJavaScript($field,$form) {
		
		$jsText = '<div id="tcal'.$field.'" class="tcal"></div>';
		$jsText.= '<script language="JavaScript">';
		$jsText.= "new tcal ({'formname': '".$form."','controlname': '".$field."'});";
		$jsText.= '</script> ';
		return $jsText;
		
		// more possible Variables
		// $formObjectName = $this->viewHelperVariableContainer->get('TYPO3\\CMS\\Fluid\\ViewHelpers\\FormViewHelper', 'formObjectName');
		// $formObjectName_and_field = $this->getNameWithoutPrefix();
	}

}