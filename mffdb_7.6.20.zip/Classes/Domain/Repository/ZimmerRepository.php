<?php
namespace Mff\Mffdb\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Zimmers
 */
class ZimmerRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	 * @var array
	 */
	protected $defaultOrderings = array(
		'haus' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		'zimmer' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);


	  /**
	  *  Find by pattern 'search'
	  * 
	  */
	  public function findByRoom($search , $ignoreEnabled = FALSE ) {
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $pidArr['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields($ignoreEnabled);
	      $querySettings->setRespectStoragePage(TRUE);
	      $querySettings->setStoragePageIds( $pidArr );
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      if( !empty($search) ){
		  $multiFields = explode( ',' , $search );
		  if( count($multiFields) > 1 ){
		      foreach($multiFields as $srcRow){ 
			    $hausZimmer = explode( ' ' , trim($srcRow) );
			    if( count($hausZimmer) == 2 ){
				$lastBuilding = $hausZimmer[0];
			    }
			    $constraints = $this->makeConstraints( $srcRow , $query , $constraints );
		      }
		  }else{
		      $constraints = $this->makeConstraints( $search , $query );
		  }
		  if( $ignoreEnabled ){
		      $query->matching( $query->logicalOr($constraints) );
		  }else{
		      $query->matching(
			  $query->logicalAnd(
			      $query->logicalOr($constraints),
			      $query->logicalNot( $query->equals('ausschliessen', 1) )
			  )
		      );
		  }
	      }
	      $query->setOrderings(
		  array(
		      'haus' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		      'zimmer' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );	  
	      return $query->execute();
	  }
	  private function makeConstraints( $rawSearch , $query , $constraints = array() ) {
		      // possible: Hous* Nr1 Nr2 Str1 str2 st*
		      $search = trim($rawSearch);
		      
		      $hausZimmer = explode( ' ' , $search );
		      
		      if( count($hausZimmer) == 1 ){
			  $pos = strpos( $search , '*' );
			  // if there is a asterisk and its position is not on the tail
			  if( !empty($pos) && strlen($search)-1 != $pos ){
			      // e.g. H*12 -> House 12 + Hall 12
			      $hausZimmer[0] = substr($search , 0 , $pos+1);
			      $hausZimmer[1] = substr($search , $pos);
			  }
		      }
		      
		      if( count($hausZimmer) == 1 ){
			  $constraints[] = $query->like('haus', str_replace( '*' , '%' ,  $hausZimmer[0] ) );
		      }else{
			  foreach( array_slice($hausZimmer , 1) as $zimmerpart){
				$constraints[] = $query->logicalAnd(
				    $query->logicalOr(
					  $query->like('haus', str_replace( '*' , '%' , $hausZimmer[0] ) ),
					  $query->like('haus', str_replace( '*' , '%' , ucFirst($hausZimmer[0]) ) )
				    ),
				    $query->logicalOr(
					  $query->like('zimmer', str_replace( '*' , '%' , $zimmerpart ) ),
					  $query->like('zimmer', str_replace( '*' , '%' , ucFirst($zimmerpart) ) )
				    )
				);
			  }
		      }
		      
		      return $constraints;
	  }

}