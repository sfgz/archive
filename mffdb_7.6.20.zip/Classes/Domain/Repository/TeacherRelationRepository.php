<?php
namespace Mff\Mffdb\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Ecouser
 * used to extend \TYPO3\CMS\Extbase\Persistence\Repository
 */
class TeacherRelationRepository extends \TYPO3\CMS\Extbase\Persistence\Repository{
	  
	/**
	 * $defaultOrderings
	 * 
	 * @var array
	 */
	protected $defaultOrderings = array(
		      'leiter' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING,
		      'auto_reference' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);

	  /**
	  *  Find by parent recordset 'fachbereich-uid'
	  * 
	  */
	  public function findByMother($uid , $ignoreEnabled = FALSE ) {
	      if( $ignoreEnabled ){
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields($ignoreEnabled);
		  $querySettings->setRespectStoragePage(TRUE);
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
	      }
	      $query = $this->createQuery();
	      if( !empty($uid) ){
		  $query->matching(
		      $query->equals('fachbereich', $uid)
		  );
	      }
	      $query->setOrderings(
		  array(
		      'leiter' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING,
		      'auto_reference' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );	  
	      return $query->execute();
	  }

	  /**
	  *  Find by 'uid' IgnoreEnableFields
	  * 
	  */
	  public function findeByUid( $uid ) {
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(TRUE);
	      $querySettings->setRespectStoragePage(FALSE);
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      if( !empty($uid) ){
		  $query->matching(
		      $query->equals('uid', $uid)
		  );
	      }
	      return $query->execute();
	  }
	  
	  public function callSqlStatement( $qryStatement , $ReturnRawQueryResult = TRUE) {
	      $Query = $this->createquery();
// 	      $Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement($qryStatement); 
	      return $Query->execute($ReturnRawQueryResult);
	  }
	  
	  public function getTeachersFachbereich( $relConnection='Klassen' , $passedDays = 180 ) {
	      $proc = 'getTeachersFb_' . $relConnection ;
	      $oldestDate = time() - round( $passedDays * 24 * 60 * 60 );
	      $sqlQuery = '';
	      $data = array();

	      // if there is a method in other Repository then use it, otherwise use actual Repository
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $enableForeignTimetable = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['foreignTimetable'];
	      if ($enableForeignTimetable && is_array($GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['mffdb']['processResponse'])) {
		      foreach($GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['mffdb']['processResponse'] as $className) {
			      $processor = &\TYPO3\CMS\Core\Utility\GeneralUtility::getUserObj($className);
			      $data = $processor->processResponse( $data );
		      }
		      $repositoryName = str_replace( array_keys($data['teacher']) , $data['teacher'] , '##vendor##\\##extension##\\Domain\\Repository\\##repository##Repository');
		      if( $repositoryName != 'Mff\\Mffdb\\Domain\\Repository\\TeacherRepositoryRepository' ){
			    $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			    $teacherRepository = $objectManager->get( $repositoryName );
			    if( method_exists( $teacherRepository , $proc ) ){
				  $sqlQuery = $teacherRepository->$proc( $oldestDate );
			    }
		      }
	      }
	      if( empty($sqlQuery) && method_exists( $this , $proc ) ) $sqlQuery = $this->$proc( $oldestDate );

	      if( empty($sqlQuery) ) return;

	      return $this->callSqlStatement( 'SELECT DISTINCT '.$sqlQuery );
	  }
	  
	  public function getTeachersFb_AllTeachersRelations( $oldestDate=0  ) {
	      return '
	      fe_users.uid AS plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota, fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_teacherrelation.uid AS relationUid,
	      tx_mffdb_domain_model_teacherrelation.hidden,
	      tx_mffdb_domain_model_teacherrelation.leiter,
	      tx_mffdb_domain_model_teacherrelation.auto_reference,
	      "" AS groups
	      FROM fe_users
	        LEFT JOIN tx_mffdb_domain_model_teacherrelation 
		    ON tx_mffdb_domain_model_teacherrelation.tea_ecouser=fe_users.uid
		LEFT JOIN tx_mffdb_domain_model_fachbereich 
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_teacherrelation.fachbereich 
	      WHERE fe_users.eco_acronym > ""
	      ORDER BY fe_users.username
	     ';
	  }
	  public function getTeachersFb_Klassen( $oldestDate=0 ) {
	      // Fachbereich-Lehrpersonen Klassen
	      // verknuepft Lehrpersonen ueber Klassen zu Fachbereichen
	      // wenn deren Faecher keinen Kursregeln entsprechen
	      return '
	      tx_mffdb_domain_model_stundenplan.plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_klasse.class_short AS content
	      FROM tx_mffdb_domain_model_fachbereich
		JOIN tx_mffdb_domain_model_kurzklasse
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kurzklasse.fachbereich 
		JOIN tx_mffdb_domain_model_klasse
		    ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse 
	        JOIN tx_mffdb_kurs_klasse_mm 
		    ON tx_mffdb_domain_model_klasse.uid=tx_mffdb_kurs_klasse_mm.uid_foreign 
	        JOIN tx_mffdb_domain_model_kurs 
		    ON tx_mffdb_kurs_klasse_mm.uid_local=tx_mffdb_domain_model_kurs.uid 
	        JOIN tx_mffdb_domain_model_stundenplan 
		    ON tx_mffdb_domain_model_kurs.uid=tx_mffdb_domain_model_stundenplan.kurs 
	        JOIN fe_users 
		    ON tx_mffdb_domain_model_stundenplan.plan_teacher=fe_users.uid
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffdb_domain_model_fach.uid=tx_mffdb_domain_model_kurs.fach 
	      WHERE tx_mffdb_domain_model_fach.fach_kursregel = 0
	      AND tx_mffdb_domain_model_stundenplan.plan_ende >= '.$oldestDate.'
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffdb_domain_model_stundenplan.plan_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_klasse.class_short
	      ';
	  }
	  public function getTeachersFb_Kurse( $oldestDate=0 ) {
	      // Fachbereich-Lehrpersonen Kursregeln
	      // verknuepft Lehrpersonen ueber Faecher zu Fachbereichen
	      // wenn die Faecher den Kursregeln des Fachebreiches entsprechen
	      return '
	      tx_mffdb_domain_model_stundenplan.plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_fach.fachkurz AS content
	      FROM tx_mffdb_domain_model_fachbereich 
		JOIN tx_mffdb_domain_model_kursregel 
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kursregel.fachbereich 
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffdb_domain_model_kursregel.uid=tx_mffdb_domain_model_fach.fach_kursregel
	        JOIN tx_mffdb_domain_model_kurs 
		    ON tx_mffdb_domain_model_fach.uid=tx_mffdb_domain_model_kurs.fach 
	        JOIN tx_mffdb_domain_model_stundenplan 
		    ON tx_mffdb_domain_model_kurs.uid=tx_mffdb_domain_model_stundenplan.kurs 
	        JOIN fe_users 
		    ON tx_mffdb_domain_model_stundenplan.plan_teacher=fe_users.uid
	      WHERE NOT tx_mffdb_domain_model_fach.fach_kursregel = 0
	      AND tx_mffdb_domain_model_stundenplan.plan_ende >= '.$oldestDate.'
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffdb_domain_model_stundenplan.plan_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_fach.fachkurz
	     ';
	  }
	  public function getTeachersFb_AbuKlassen( $oldestDate=0 ) {
	      // Fachbereich-ABU-Lehrpersonen Kursregeln + Klassen
	      // verknuepft ABU-Lehrpersonen ueber Faecher zu Klassen zu Fachbereichen
	      // wenn die Faecher den Kursregeln des ABU-Fachebreiches entsprechen
	      
	      // Fachbereich-UID von ABU (Allgemeinbildung und Sport) ermitteln
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $abuFbUid = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['abuFbUid'];
	      
	      return '
	      tx_mffdb_domain_model_stundenplan.plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_klasse.class_short AS content
	      FROM tx_mffdb_domain_model_fachbereich
		JOIN tx_mffdb_domain_model_kurzklasse
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kurzklasse.fachbereich 
		JOIN tx_mffdb_domain_model_klasse
		    ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse 
	        JOIN tx_mffdb_kurs_klasse_mm 
		    ON tx_mffdb_domain_model_klasse.uid=tx_mffdb_kurs_klasse_mm.uid_foreign 
	        JOIN tx_mffdb_domain_model_kurs 
		    ON tx_mffdb_kurs_klasse_mm.uid_local=tx_mffdb_domain_model_kurs.uid 
	        JOIN tx_mffdb_domain_model_stundenplan 
		    ON tx_mffdb_domain_model_kurs.uid=tx_mffdb_domain_model_stundenplan.kurs 
	        JOIN fe_users 
		    ON tx_mffdb_domain_model_stundenplan.plan_teacher=fe_users.uid
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffdb_domain_model_fach.uid=tx_mffdb_domain_model_kurs.fach 
		JOIN tx_mffdb_domain_model_kursregel 
		    ON tx_mffdb_domain_model_kursregel.uid=tx_mffdb_domain_model_fach.fach_kursregel
	      WHERE tx_mffdb_domain_model_kursregel.fachbereich = '.$abuFbUid.'
	      AND tx_mffdb_domain_model_stundenplan.plan_ende >= '.$oldestDate.'
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffdb_domain_model_stundenplan.plan_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_klasse.class_short
	      ';
	  }
	  public function getTeachersFb_sortFachbereich( $oldestDate=0 ) { // HACK 6.3.2020 appendet sorting to fieldlist
	      return ' uid, fachbereichname, sorting FROM tx_mffdb_domain_model_fachbereich ORDER BY sorting';
	  }
}
