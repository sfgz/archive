<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Zimmer
 */
class Zimmer extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * zimmer
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $zimmer = '';

	/**
	 * haus
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $haus = '';

	/**
	 * besonderes
	 *
	 * @var string
	 */
	protected $besonderes = '';

	/**
	 * telefon
	 *
	 * @var string
	 */
	protected $telefon = '';

	/**
	 * preise
	 *
	 * @var string
	 */
	protected $preise = '';

	/**
	 * ausschliessen
	 *
	 * @var bool
	 */
	protected $ausschliessen = FALSE;

	/**
	 * locationId
	 *
	 * @var string
	 */
	protected $locationId = '';

	/**
	 * locationKey
	 *
	 * @var string
	 */
	protected $locationKey = '';

	/**
	 * Returns the zimmer
	 *
	 * @return string $zimmer
	 */
	public function getZimmer() {
		return $this->zimmer;
	}

	/**
	 * Sets the zimmer
	 *
	 * @param string $zimmer
	 * @return void
	 */
	public function setZimmer($zimmer) {
		$this->zimmer = $zimmer;
	}

	/**
	 * Returns the haus
	 *
	 * @return string $haus
	 */
	public function getHaus() {
		return $this->haus;
	}

	/**
	 * Sets the haus
	 *
	 * @param string $haus
	 * @return void
	 */
	public function setHaus($haus) {
		$this->haus = $haus;
	}

	/**
	 * Returns the besonderes
	 *
	 * @return string $besonderes
	 */
	public function getBesonderes() {
		return $this->besonderes;
	}

	/**
	 * Sets the besonderes
	 *
	 * @param string $besonderes
	 * @return void
	 */
	public function setBesonderes($besonderes) {
		$this->besonderes = $besonderes;
	}

	/**
	 * Returns the telefon
	 *
	 * @return string $telefon
	 */
	public function getTelefon() {
		return $this->telefon;
	}

	/**
	 * Sets the telefon
	 *
	 * @param string $telefon
	 * @return void
	 */
	public function setTelefon($telefon) {
		$this->telefon = $telefon;
	}

	/**
	 * Returns the preise
	 *
	 * @return string $preise
	 */
	public function getPreise() {
		return $this->preise;
	}

	/**
	 * Sets the preise
	 *
	 * @param string $preise
	 * @return void
	 */
	public function setPreise($preise) {
		$this->preise = $preise;
	}

	/**
	 * Returns the ausschliessen
	 *
	 * @return bool $ausschliessen
	 */
	public function getAusschliessen() {
		return $this->ausschliessen;
	}

	/**
	 * Sets the ausschliessen
	 *
	 * @param bool $ausschliessen
	 * @return void
	 */
	public function setAusschliessen($ausschliessen) {
		$this->ausschliessen = $ausschliessen;
	}

	/**
	 * Returns the boolean state of ausschliessen
	 *
	 * @return bool
	 */
	public function isAusschliessen() {
		return $this->ausschliessen;
	}

	/**
	 * Returns the locationId
	 *
	 * @return string $locationId
	 */
	public function getLocationId() {
		return $this->locationId;
	}

	/**
	 * Sets the locationId
	 *
	 * @param string $locationId
	 * @return void
	 */
	public function setLocationId($locationId) {
		$this->locationId = $locationId;
	}

	/**
	 * Returns the locationKey
	 *
	 * @return string $locationKey
	 */
	public function getLocationKey() {
		return $this->locationKey;
	}

	/**
	 * Sets the locationKey
	 *
	 * @param string $locationKey
	 * @return void
	 */
	public function setLocationKey($locationKey) {
		$this->locationKey = $locationKey;
	}

}