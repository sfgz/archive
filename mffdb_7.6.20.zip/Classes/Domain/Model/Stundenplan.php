<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Stundenplan
 */
class Stundenplan extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * timetableId
	 *
	 * @var string
	 */
	protected $timetableId = '';

	/**
	 * refTimetableId
	 *
	 * @var string
	 */
	protected $refTimetableId = '';

	/**
	 * planStart
	 *
	 * @var int
	 */
	protected $planStart = 0;

	/**
	 * planEnde
	 *
	 * @var int
	 */
	protected $planEnde = 0;

	/**
	 * planTag
	 *
	 * @var int
	 */
	protected $planTag = 0;

	/**
	 * planPeriodizitaet
	 *
	 * @var int
	 */
	protected $planPeriodizitaet = 0;

	/**
	 * zeitAb
	 *
	 * @var string
	 */
	protected $zeitAb = '';

	/**
	 * zeitBis
	 *
	 * @var string
	 */
	protected $zeitBis = '';

	/**
	 * bemerkung
	 *
	 * @var string
	 */
	protected $bemerkung = '';

	/**
	 * planZimmer
	 *
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 */
	protected $planZimmer = NULL;

	/**
	 * planTeacher
	 *
	 * @var \Mff\Mffdb\Domain\Model\Ecouser
	 */
	protected $planTeacher = NULL;


	/**
	 * kurs
	 *
	 * @var int
	 * @validate NotEmpty,Integer
	 */
	protected $kurs = 0;

	/**
	 * some hacks
	 * 
	 */
	public function getKurs(){
	    return $this->kurs;
	}

	/**
	 * Returns the timetableId
	 *
	 * @return string $timetableId
	 */
	public function getTimetableId() {
		return $this->timetableId;
	}

	/**
	 * Sets the timetableId
	 *
	 * @param string $timetableId
	 * @return void
	 */
	public function setTimetableId($timetableId) {
		$this->timetableId = $timetableId;
	}

	/**
	 * Returns the refTimetableId
	 *
	 * @return string $refTimetableId
	 */
	public function getRefTimetableId() {
		return $this->refTimetableId;
	}

	/**
	 * Sets the refTimetableId
	 *
	 * @param string $refTimetableId
	 * @return void
	 */
	public function setRefTimetableId($refTimetableId) {
		$this->refTimetableId = $refTimetableId;
	}

	/**
	 * Returns the planStart
	 *
	 * @return int $planStart
	 */
	public function getPlanStart() {
		return $this->planStart;
	}

	/**
	 * Sets the planStart
	 *
	 * @param int $planStart
	 * @return void
	 */
	public function setPlanStart($planStart) {
		$this->planStart = $planStart;
	}

	/**
	 * Returns the planEnde
	 *
	 * @return int $planEnde
	 */
	public function getPlanEnde() {
		return $this->planEnde;
	}

	/**
	 * Sets the planEnde
	 *
	 * @param int $planEnde
	 * @return void
	 */
	public function setPlanEnde($planEnde) {
		$this->planEnde = $planEnde;
	}

	/**
	 * Returns the planTag
	 *
	 * @return int $planTag
	 */
	public function getPlanTag() {
		return $this->planTag;
	}

	/**
	 * Sets the planTag
	 *
	 * @param int $planTag
	 * @return void
	 */
	public function setPlanTag($planTag) {
		$this->planTag = $planTag;
	}

	/**
	 * Returns the planPeriodizitaet
	 *
	 * @return int $planPeriodizitaet
	 */
	public function getPlanPeriodizitaet() {
		return $this->planPeriodizitaet;
	}

	/**
	 * Sets the planPeriodizitaet
	 *
	 * @param int $planPeriodizitaet
	 * @return void
	 */
	public function setPlanPeriodizitaet($planPeriodizitaet) {
		$this->planPeriodizitaet = $planPeriodizitaet;
	}

	/**
	 * Returns the zeitAb
	 *
	 * @return string $zeitAb
	 */
	public function getZeitAb() {
		return $this->zeitAb;
	}
	/**
	 * Returns the timeFrom
	 * alias for zeitAb
	 * used in table
	 * tx_mffplan_domain_model_timetable
	 *
	 * @return string $zeitAb
	 */
	public function getTimeFrom() {
		return $this->zeitAb;
	}

	/**
	 * Sets the zeitAb
	 *
	 * @param string $zeitAb
	 * @return void
	 */
	public function setZeitAb($zeitAb) {
		$this->zeitAb = $zeitAb;
	}

	/**
	 * Returns the zeitBis
	 *
	 * @return string $zeitBis
	 */
	public function getZeitBis() {
		return $this->zeitBis;
	}
	/**
	 * Returns the timeTo
	 * alias for zeitBis
	 * used in table
	 * tx_mffplan_domain_model_timetable
	 *
	 * @return string $zeitBis
	 */
	public function getTimeTo() {
		return $this->zeitBis;
	}

	/**
	 * Sets the zeitBis
	 *
	 * @param string $zeitBis
	 * @return void
	 */
	public function setZeitBis($zeitBis) {
		$this->zeitBis = $zeitBis;
	}

	/**
	 * Returns the bemerkung
	 *
	 * @return string $bemerkung
	 */
	public function getBemerkung() {
		return $this->bemerkung;
	}

	/**
	 * Sets the bemerkung
	 *
	 * @param string $bemerkung
	 * @return void
	 */
	public function setBemerkung($bemerkung) {
		$this->bemerkung = $bemerkung;
	}

	/**
	 * Returns the planZimmer
	 *
	 * @return \Mff\Mffdb\Domain\Model\Zimmer $planZimmer
	 */
	public function getPlanZimmer() {
		return $this->planZimmer;
	}

	/**
	 * Sets the planZimmer
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $planZimmer
	 * @return void
	 */
	public function setPlanZimmer(\Mff\Mffdb\Domain\Model\Zimmer $planZimmer) {
		$this->planZimmer = $planZimmer;
	}

	/**
	 * Returns the planTeacher
	 *
	 * @return \Mff\Mffdb\Domain\Model\Ecouser $planTeacher
	 */
	public function getPlanTeacher() {
		return $this->planTeacher;
	}

	/**
	 * Returns the relTeacher
	 * alias for planTeacher
	 * used in table
	 * tx_mffplan_domain_model_timetable
	 *
	 * @return \Mff\Mffdb\Domain\Model\Ecouser $planTeacher
	 */
	public function getRelTeacher() {
		return $this->planTeacher;
	}

	/**
	 * Sets the planTeacher
	 *
	 * @param \Mff\Mffdb\Domain\Model\Ecouser $planTeacher
	 * @return void
	 */
	public function setPlanTeacher(\Mff\Mffdb\Domain\Model\Ecouser $planTeacher) {
		$this->planTeacher = $planTeacher;
	}

}