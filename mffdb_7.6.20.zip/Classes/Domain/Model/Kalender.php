<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Kalender
 */
class Kalender extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * ferientext
	 *
	 * @var string
	 */
	protected $ferientext = '';

	/**
	 * beginn
	 *
	 * @var int
	 */
	protected $beginn = 0;

	/**
	 * ende
	 *
	 * @var int
	 */
	protected $ende = 0;

	/**
	 * code
	 *
	 * @var string
	 */
	protected $code = '';

	/**
	 * semestergrenze
	 *
	 * @var bool
	 */
	protected $semestergrenze = FALSE;

	/**
	 * privat
	 *
	 * @var bool
	 */
	protected $privat = FALSE;

	/**
	 * ganztag
	 *
	 * @var bool
	 */
	protected $ganztag = FALSE;

	/**
	 * Returns the ferientext
	 *
	 * @return string $ferientext
	 */
	public function getFerientext() {
		return $this->ferientext;
	}

	/**
	 * Sets the ferientext
	 *
	 * @param string $ferientext
	 * @return void
	 */
	public function setFerientext($ferientext) {
		$this->ferientext = $ferientext;
	}

	/**
	 * Returns the beginn
	 *
	 * @return int $beginn
	 */
	public function getBeginn() {
		return $this->beginn;
	}

	/**
	 * Sets the beginn
	 *
	 * @param int $beginn
	 * @return void
	 */
	public function setBeginn($beginn) {
		$this->beginn = $beginn;
	}

	/**
	 * Returns the ende
	 *
	 * @return int $ende
	 */
	public function getEnde() {
		return $this->ende;
	}

	/**
	 * Sets the ende
	 *
	 * @param int $ende
	 * @return void
	 */
	public function setEnde($ende) {
		$this->ende = $ende;
	}

	/**
	 * Returns the code
	 *
	 * @return string $code
	 */
	public function getCode() {
		return $this->code;
	}

	/**
	 * Sets the code
	 *
	 * @param string $code
	 * @return void
	 */
	public function setCode($code) {
		$this->code = $code;
	}

	/**
	 * Returns the semestergrenze
	 *
	 * @return bool $semestergrenze
	 */
	public function getSemestergrenze() {
		return $this->semestergrenze;
	}

	/**
	 * Sets the semestergrenze
	 *
	 * @param bool $semestergrenze
	 * @return void
	 */
	public function setSemestergrenze($semestergrenze) {
		$this->semestergrenze = $semestergrenze;
	}

	/**
	 * Returns the boolean state of semestergrenze
	 *
	 * @return bool
	 */
	public function isSemestergrenze() {
		return $this->semestergrenze;
	}

	/**
	 * Returns the privat
	 *
	 * @return bool $privat
	 */
	public function getPrivat() {
		return $this->privat;
	}

	/**
	 * Sets the privat
	 *
	 * @param bool $privat
	 * @return void
	 */
	public function setPrivat($privat) {
		$this->privat = $privat;
	}

	/**
	 * Returns the boolean state of privat
	 *
	 * @return bool
	 */
	public function isPrivat() {
		return $this->privat;
	}

	/**
	 * Returns the ganztag
	 *
	 * @return bool $ganztag
	 */
	public function getGanztag() {
		return $this->ganztag;
	}

	/**
	 * Sets the ganztag
	 *
	 * @param bool $ganztag
	 * @return void
	 */
	public function setGanztag($ganztag) {
		$this->ganztag = $ganztag;
	}

	/**
	 * Returns the boolean state of ganztag
	 *
	 * @return bool
	 */
	public function isGanztag() {
		return $this->ganztag;
	}

}