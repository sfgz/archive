<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Fach
 */
class Fach extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * fachbezeichnung
	 *
	 * @var string
	 */
	protected $fachbezeichnung = '';

	/**
	 * fachkurz
	 *
	 * @var string
	 */
	protected $fachkurz = '';

	/**
	 * subjectId
	 *
	 * @var string
	 */
	protected $subjectId = '';

	/**
	 * fachKursregel
	 *
	 * @var \Mff\Mffdb\Domain\Model\Kursregel
	 */
	protected $fachKursregel = NULL;

	/**
	 * fachKurse
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurs>
	 * @cascade remove
	 * @lazy
	 */
	protected $fachKurse = NULL;

	/**
	 * hidden
	 *
	 * @var bool
	 */
	protected $hidden = FALSE;

	/**
	 * cruserId
	 *
	 * @var int
	 */
	protected $cruserId = FALSE;

	/**
	 * ignoreVacation
	 *
	 * @var bool
	 */
	protected $ignoreVacation = FALSE;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->fachKurse = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the fachbezeichnung
	 *
	 * @return string $fachbezeichnung
	 */
	public function getFachbezeichnung() {
		return $this->fachbezeichnung;
	}

	/**
	 * Sets the fachbezeichnung
	 *
	 * @param string $fachbezeichnung
	 * @return void
	 */
	public function setFachbezeichnung($fachbezeichnung) {
		$this->fachbezeichnung = $fachbezeichnung;
	}

	/**
	 * Returns the fachkurz
	 *
	 * @return string $fachkurz
	 */
	public function getFachkurz() {
		return $this->fachkurz;
	}

	/**
	 * Sets the fachkurz
	 *
	 * @param string $fachkurz
	 * @return void
	 */
	public function setFachkurz($fachkurz) {
		$this->fachkurz = $fachkurz;
	}

	/**
	 * Returns the subjectId
	 *
	 * @return string $subjectId
	 */
	public function getSubjectId() {
		return $this->subjectId;
	}

	/**
	 * Sets the subjectId
	 *
	 * @param string $subjectId
	 * @return void
	 */
	public function setSubjectId($subjectId) {
		$this->subjectId = $subjectId;
	}
	
	/**
	 * Returns the ignoreVacation
	 *
	 * @return bool $ignoreVacation
	 */
	public function getIgnoreVacation() {
		return $this->ignoreVacation;
	}

	/**
	 * Sets the ignoreVacation
	 *
	 * @param bool $ignoreVacation
	 * @return void
	 */
	public function setIgnoreVacation($ignoreVacation) {
		$this->ignoreVacation = $ignoreVacation;
	}

	/**
	 * Returns the fachKursregel
	 *
	 * @return \Mff\Mffdb\Domain\Model\Kursregel $fachKursregel
	 */
	public function getFachKursregel() {
		return $this->fachKursregel;
	}

	/**
	 * Sets the fachKursregel
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $fachKursregel
	 * @return void
	 */
	public function setFachKursregel(\Mff\Mffdb\Domain\Model\Kursregel $fachKursregel) {
		$this->fachKursregel = $fachKursregel;
	}

	/**
	 * Adds a Kurs
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurs $fachKurse
	 * @return void
	 */
	public function addFachKurse(\Mff\Mffdb\Domain\Model\Kurs $fachKurse) {
		$this->fachKurse->attach($fachKurse);
	}

	/**
	 * Removes a Kurs
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurs $fachKurseToRemove The Kurs to be removed
	 * @return void
	 */
	public function removeFachKurse(\Mff\Mffdb\Domain\Model\Kurs $fachKurseToRemove) {
		$this->fachKurse->detach($fachKurseToRemove);
	}

	/**
	 * Returns the fachKurse
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurs> $fachKurse
	 */
	public function getFachKurse() {
		return $this->fachKurse;
	}

	/**
	 * Sets the fachKurse
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurs> $fachKurse
	 * @return void
	 */
	public function setFachKurse(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $fachKurse) {
		$this->fachKurse = $fachKurse;
	}

	/**
	 * Returns the hidden
	 *
	 * @return bool $hidden
	 */
	public function getHidden() {
		return $this->hidden;
	}

	/**
	 * Sets the hidden
	 *
	 * @param bool $hidden
	 * @return void
	 */
	public function setHidden($hidden) {
		$this->hidden = $hidden;
	}

	/**
	 * Returns the boolean state of hidden
	 *
	 * @return bool
	 */
	public function isHidden() {
		return $this->hidden;
	}

	/**
	 * Returns the cruserId
	 *
	 * @return string $cruserId
	 */
	public function getCruserId() {
		return $this->cruserId;
	}

	/**
	 * Sets the cruserId
	 *
	 * @param string $cruserId
	 * @return void
	 */
	public function setCruserId($cruserId) {
		$this->cruserId = $cruserId;
	}

}