<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kursregel',
		'label' => 'regelname',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,
		'sortby' => 'sorting',

		'enablecolumns' => array(

		),
		'searchFields' => 'regelname,wert_ab,wert_bis,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_kursregel.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'regelname, wert_ab, wert_bis, sorting',
	),
	'types' => array(
		'1' => array('showitem' => 'regelname, wert_ab, wert_bis, sorting'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'regelname' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kursregel.regelname',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'wert_ab' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kursregel.wert_ab',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'wert_bis' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kursregel.wert_bis',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		
		'fachbereich' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		
		'sorting' => array(
			'exclude' => 0,
			'label' => 'Sorting',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
	),
);