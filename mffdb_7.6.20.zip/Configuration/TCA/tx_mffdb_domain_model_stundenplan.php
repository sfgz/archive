<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan',
		'label' => 'timetable_id',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'timetable_id,ref_timetable_id,ref_teacher_ecokey,plan_start,plan_ende,plan_tag,plan_periodizitaet,zeit_ab,zeit_bis,bemerkung,plan_zimmer,plan_teacher,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_stundenplan.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'timetable_id, ref_timetable_id, ref_teacher_ecokey, plan_start, plan_ende, plan_tag, plan_periodizitaet, zeit_ab, zeit_bis, bemerkung, plan_zimmer, plan_teacher',
	),
	'types' => array(
		'1' => array('showitem' => 'timetable_id, ref_timetable_id, ref_teacher_ecokey, plan_start, plan_ende, plan_tag, plan_periodizitaet, zeit_ab, zeit_bis, bemerkung, plan_zimmer, plan_teacher, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'timetable_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.timetable_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'ref_timetable_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.ref_timetable_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'ref_teacher_ecokey' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.ref_teacher_ecokey',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'plan_start' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_start',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'plan_ende' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_ende',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'plan_tag' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_tag',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'plan_periodizitaet' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_periodizitaet',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'zeit_ab' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.zeit_ab',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'zeit_bis' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.zeit_bis',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'bemerkung' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.bemerkung',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'plan_zimmer' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_zimmer',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'foreign_table_where' => 'AND 1=1 Order by haus ASC,zimmer ASC',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'plan_teacher' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_stundenplan.plan_teacher',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		
		'kurs' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'ref_teacher_ecokey' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);