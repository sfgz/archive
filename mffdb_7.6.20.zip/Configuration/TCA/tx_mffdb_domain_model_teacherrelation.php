<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_teacherrelation',
		'label' => 'tea_ecouser',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(
			'disabled' => 'hidden',
		),
		'searchFields' => 'leiter,auto_reference,tea_ecouser,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_teacherrelation.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'leiter, auto_reference, tea_ecouser, hidden',
	),
	'types' => array(
		'1' => array('showitem' => 'leiter, auto_reference, tea_ecouser, hidden, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'leiter' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_teacherrelation.leiter',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'auto_reference' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_teacherrelation.auto_reference',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'tea_ecouser' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_teacherrelation.tea_ecouser',
			'config' => array(
				'type' => 'select',
				'items' => array( array('keine', 0)),
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		
		'fachbereich' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'hidden' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
			'config' => array(
				'type' => 'check',
			),
		),
	),
);