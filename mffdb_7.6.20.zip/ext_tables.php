<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
// mffdb/ext_tables.php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'Fbv',
	'Fachbereiche verwalten'
);

$pluginSignature = str_replace('_','',$_EXTKEY) . '_fbv';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $_EXTKEY . '/Configuration/FlexForms/flexform_fbv.xml');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'Mff Datenbank');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_fachbereich', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_fachbereich.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_kurzklasse', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_kurzklasse.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_cloudquota', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_cloudquota.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_fach', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_fach.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_kursregel', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_kursregel.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_klasse', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_klasse.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_kurs', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_kurs.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_zimmer', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_zimmer.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_stundenplan', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_stundenplan.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_teacherrelation', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_teacherrelation.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffdb_domain_model_kalender', 'EXT:mffdb/Resources/Private/Language/locallang_csh_tx_mffdb_domain_model_kalender.xlf');
