<?php
namespace Mff\Mffdb\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *  			
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class Mff\Mffdb\Controller\KursregelController.
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class KursregelControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \Mff\Mffdb\Controller\KursregelController
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = $this->getMock('Mff\\Mffdb\\Controller\\KursregelController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllKursregelsFromRepositoryAndAssignsThemToView() {

		$allKursregels = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$kursregelRepository = $this->getMock('', array('findAll'), array(), '', FALSE);
		$kursregelRepository->expects($this->once())->method('findAll')->will($this->returnValue($allKursregels));
		$this->inject($this->subject, 'kursregelRepository', $kursregelRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('kursregels', $allKursregels);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenKursregelToView() {
		$kursregel = new \Mff\Mffdb\Domain\Model\Kursregel();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newKursregel', $kursregel);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($kursregel);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenKursregelToKursregelRepository() {
		$kursregel = new \Mff\Mffdb\Domain\Model\Kursregel();

		$kursregelRepository = $this->getMock('', array('add'), array(), '', FALSE);
		$kursregelRepository->expects($this->once())->method('add')->with($kursregel);
		$this->inject($this->subject, 'kursregelRepository', $kursregelRepository);

		$this->subject->createAction($kursregel);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenKursregelToView() {
		$kursregel = new \Mff\Mffdb\Domain\Model\Kursregel();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('kursregel', $kursregel);

		$this->subject->editAction($kursregel);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenKursregelInKursregelRepository() {
		$kursregel = new \Mff\Mffdb\Domain\Model\Kursregel();

		$kursregelRepository = $this->getMock('', array('update'), array(), '', FALSE);
		$kursregelRepository->expects($this->once())->method('update')->with($kursregel);
		$this->inject($this->subject, 'kursregelRepository', $kursregelRepository);

		$this->subject->updateAction($kursregel);
	}
}
