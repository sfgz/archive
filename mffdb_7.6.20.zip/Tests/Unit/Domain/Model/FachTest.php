<?php

namespace Mff\Mffdb\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Mff\Mffdb\Domain\Model\Fach.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class FachTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \Mff\Mffdb\Domain\Model\Fach
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = new \Mff\Mffdb\Domain\Model\Fach();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getFachbezeichnungReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFachbezeichnung()
		);
	}

	/**
	 * @test
	 */
	public function setFachbezeichnungForStringSetsFachbezeichnung() {
		$this->subject->setFachbezeichnung('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fachbezeichnung',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFachkurzReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFachkurz()
		);
	}

	/**
	 * @test
	 */
	public function setFachkurzForStringSetsFachkurz() {
		$this->subject->setFachkurz('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fachkurz',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getSubjectIdReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getSubjectId()
		);
	}

	/**
	 * @test
	 */
	public function setSubjectIdForStringSetsSubjectId() {
		$this->subject->setSubjectId('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'subjectId',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFachKursregelReturnsInitialValueForKursregel() {
		$this->assertEquals(
			NULL,
			$this->subject->getFachKursregel()
		);
	}

	/**
	 * @test
	 */
	public function setFachKursregelForKursregelSetsFachKursregel() {
		$fachKursregelFixture = new \Mff\Mffdb\Domain\Model\Kursregel();
		$this->subject->setFachKursregel($fachKursregelFixture);

		$this->assertAttributeEquals(
			$fachKursregelFixture,
			'fachKursregel',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFachKurseReturnsInitialValueForKurs() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getFachKurse()
		);
	}

	/**
	 * @test
	 */
	public function setFachKurseForObjectStorageContainingKursSetsFachKurse() {
		$fachKurse = new \Mff\Mffdb\Domain\Model\Kurs();
		$objectStorageHoldingExactlyOneFachKurse = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneFachKurse->attach($fachKurse);
		$this->subject->setFachKurse($objectStorageHoldingExactlyOneFachKurse);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneFachKurse,
			'fachKurse',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addFachKurseToObjectStorageHoldingFachKurse() {
		$fachKurse = new \Mff\Mffdb\Domain\Model\Kurs();
		$fachKurseObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$fachKurseObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($fachKurse));
		$this->inject($this->subject, 'fachKurse', $fachKurseObjectStorageMock);

		$this->subject->addFachKurse($fachKurse);
	}

	/**
	 * @test
	 */
	public function removeFachKurseFromObjectStorageHoldingFachKurse() {
		$fachKurse = new \Mff\Mffdb\Domain\Model\Kurs();
		$fachKurseObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$fachKurseObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($fachKurse));
		$this->inject($this->subject, 'fachKurse', $fachKurseObjectStorageMock);

		$this->subject->removeFachKurse($fachKurse);

	}
}
