<?php

namespace Mff\Mffdb\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Mff\Mffdb\Domain\Model\Klasse.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class KlasseTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \Mff\Mffdb\Domain\Model\Klasse
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = new \Mff\Mffdb\Domain\Model\Klasse();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getClassShortReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getClassShort()
		);
	}

	/**
	 * @test
	 */
	public function setClassShortForStringSetsClassShort() {
		$this->subject->setClassShort('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'classShort',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getKlassennameReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getKlassenname()
		);
	}

	/**
	 * @test
	 */
	public function setKlassennameForStringSetsKlassenname() {
		$this->subject->setKlassenname('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'klassenname',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getKlasseKurzReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getKlasseKurz()
		);
	}

	/**
	 * @test
	 */
	public function setKlasseKurzForStringSetsKlasseKurz() {
		$this->subject->setKlasseKurz('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'klasseKurz',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getKlasseJahrReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setKlasseJahrForIntSetsKlasseJahr() {	}

	/**
	 * @test
	 */
	public function getKlasseZugReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getKlasseZug()
		);
	}

	/**
	 * @test
	 */
	public function setKlasseZugForStringSetsKlasseZug() {
		$this->subject->setKlasseZug('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'klasseZug',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getKlasseStartReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setKlasseStartForIntSetsKlasseStart() {	}

	/**
	 * @test
	 */
	public function getKlasseEndeReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setKlasseEndeForIntSetsKlasseEnde() {	}

	/**
	 * @test
	 */
	public function getDepartmentIdReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setDepartmentIdForIntSetsDepartmentId() {	}

	/**
	 * @test
	 */
	public function getClassteacherIdReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setClassteacherIdForIntSetsClassteacherId() {	}

	/**
	 * @test
	 */
	public function getClassIdReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getClassId()
		);
	}

	/**
	 * @test
	 */
	public function setClassIdForStringSetsClassId() {
		$this->subject->setClassId('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'classId',
			$this->subject
		);
	}
}
