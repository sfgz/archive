<?php
namespace Mff\MffImport\Command;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Dani Rüegg <dani@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class LocationkeyCommandController
 * insserts values into field location_key 
 * in table tx_mffdb_domain_model_zimmer
 * 
 * 
 */
class LocationkeyCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	public function execute(){
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		// instantiate Repository, ignore storage-page uid and hidden/deleted marks
		$zimmerRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setIgnoreEnableFields( TRUE );
		$querySettings->setRespectStoragePage(FALSE);
		$zimmerRepository->setDefaultQuerySettings($querySettings);

		// create Kurzklasse if affored
		$allLocations = $zimmerRepository->findAll();
		foreach($allLocations as $room){
		      $haus = $room->getHaus();
		      $zimmer = $room->getZimmer();
		      $room->setLocationKey( $haus . '.' . $zimmer );
		      $zimmerRepository->update($room);
		      $change[] = 1;
		}
		if(count($change)) {
		    $persistenceManager = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
		    $persistenceManager->persistAll();
		}
		
		return true;
	}
}
