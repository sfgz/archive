<?php
namespace Mff\MffImport\Command;
use \DateTime;

 /** 
 * Class CleartableCommandController
 * 
 * This Controller protects old Data from geting deleted by setting the ecoopen-Keys to empty string
 * If API delivers old Data, it should get excludet in class.tx_mffimport_hooks.
 * - KursRepository  clear Field "course_id" if kurs_ende < time()
 * - KlasseRepository clear Field "class_id" if klasse_ende < time()
 * - Stundenplan via KursRepository -> kurs_plaene clear Field "timetable_id" if plan_ende < time()
 * 
 * Then we delete the real old Data from tables 
 * Kurs, fe_users, Klasse, Stundenplan.
 * 
 * Usage of CleartableCommandController:
 *   run instead of SqldumpCommandController (Backup)
 *   run after restore_from_dump (Restore)
 *   run before tx_externalimport_importer->synchronizeData() (Import)
 * 
 * backup only:
 *    0. dont run the SqldumpCommandController beacuse this is done by Cleartable
 * -> 1. CleartableCommandController
 * 
 * import:
 * -> 1. CleartableCommandController
 *    2. tx_externalimport_importer->synchronizeData()
 * 
 * restore:
 *    1. restore_from_dump
 * -> 2. CleartableCommandController
 */
 
class CleartableCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mff_import';
	    
	protected $extConf = array(); // Extension configuration

	/**
	 * Deletes recordsets wich are expired on a specified date in past.
	 *
	 * Prevents the importroutine on deleting expired recordsets.
	 *    If enddate of recordset is in the past then disable the reference-field 
	 *    by inserting an empty string.
	 * 
	 * returns an array with amount of affected recordsets  
	 *
	 * @return array
	 */
	public function execute(){
		// backup the DB with an sqlDump
		$schedulerTask = new \Mff\MffImport\Command\SqldumpCommandController();
		$schedulerTask->execute();
		
		// get configuration
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $this->getSettings( $objectManager );
		
		// set dateranges
		$actualDate = $this->parseLocalDate( date('Y-m-d') . '23:59:00' );// mktime( 21,59,0, date('m') , date('d') , date('Y') );
		$kursRangeDate = mktime( 0,0,0, 1,1, date('Y')-$this->extConf['daterange_kurs'] );
		$studentsDateDiff =   ( 3600 * 24 * $this->extConf['dayrange_students'] );
// 		$klasseRangeDate = mktime( 0,0,0, 1,1, date('Y')-$this->extConf['daterange_klasse'] );
		$klasseRangeDate = mktime( 0,0,0, date('m'),date('d'), date('Y')-$this->extConf['daterange_klasse'] );
		$planRangeDate = mktime( 0,0,0, 1,1, date('Y')-$this->extConf['daterange_stundenplan'] );

		$counter = array('Kurs-'=>0 , 'Kurs'=>0 , 'Klasse-'=>0 , 'Klasse'=>0 , 'Stundenplan-'=>0 , 'Stundenplan'=>0 , 'User-'=>0 );
		
		// clean KursRepository
		$kursRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KursRepository');
		$kursRepository->setDefaultQuerySettings($querySettings);
		$kursRecordsets = $kursRepository->findeDataToClearOlderThanNow($actualDate);
		foreach( $kursRecordsets as $klsRow ){
		    $kursEnde = $klsRow->getKursEnde();
		    if( $kursRangeDate > $kursEnde ){
					$kursRepository->remove($klsRow);
					++$counter['Kurs-']; 
		    }else{
					$klsRow->setRefCourseId(''); 
					$kursRepository->update($klsRow);
					++$counter['Kurs']; 
		    }
		}

		// clean EcouserRepository (fe_users)
		$klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
		$klasseRepository->setDefaultQuerySettings($querySettings);
		$klasseRecordsets = $klasseRepository->findAll();
		foreach( $klasseRecordsets as $klsRow ){
		    //dont delete this class
		    if( $actualDate <= ($klsRow->getKlasseEnde() + $studentsDateDiff) ) $aClassesToKeep[ $klsRow->getClassId() ] = 'keep';
		}
		
		$userQuerySettings = $this->getSettings( $objectManager );
		$userQuerySettings->setStoragePageIds( array( 'studentPid' => $this->extConf['studentPid']) );
		$userRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
		$userRepository->setDefaultQuerySettings($userQuerySettings);
		$userRecordsets = $userRepository->findByPid( $this->extConf['studentPid'] );
		// remove students from this class x days after end or if class not exists
		foreach( $userRecordsets as $userRow ){
			$userKlasse = $userRow->getEcoKlasse();
			if(empty($userKlasse)){
				$userRepository->remove($userRow);
				++$counter['User-'];
			}else{
				$userClassId = $userKlasse->getRefClassId();
				if( empty($userClassId) || !isset( $aClassesToKeep[$userClassId]) ){
					$userRepository->remove($userRow);
					++$counter['User-'];
				}
			}
		}

		// clean KlasseRepository
		foreach( $klasseRecordsets as $klsRow ){
		    $klsEnde = $klsRow->getKlasseEnde();
		    $origId = $klsRow->getRefClassId();
		    if( $klasseRangeDate > $klsEnde ){
				$klasseRepository->remove($klsRow); 
				++$counter['Klasse-'];
		    }elseif( $actualDate > $klsEnde && !empty($origId) ){ 
				$klsRow->setRefClassId(''); 
				$klasseRepository->update($klsRow);
				++$counter['Klasse']; 
		    }
		}

		// clean StundenplanRepository
		$stundenplanRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\StundenplanRepository');
		$stundenplanRepository->setDefaultQuerySettings($querySettings);
		$planRecordsets = $stundenplanRepository->findeDataToClearOlderThanNow($actualDate);
		foreach( $planRecordsets as $klsRow ){
		    $plnEnde = $klsRow->getPlanEnde();
		    if( $planRangeDate > $plnEnde ){
					$stundenplanRepository->remove($klsRow); 
					++$counter['Stundenplan-'];
		    }else{ 
					$klsRow->setRefTimetableId('');  
					$stundenplanRepository->update($klsRow);
					++$counter['Stundenplan'];
		    }
		}
		
		if( array_sum($counter) ){
		    $persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		    $persistenceManager->persistAll();
 		}
		return $counter;
	}
	
	/**
	 * reads configuration into property extConf , returns querySettings
	 *
	 * @param object $objectManager 
	 * @return object
	 */
	public function getSettings( $objectManager ){
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'][$this->extKey]);

		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->extConf['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
 		$this->extConf['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
// 		$this->extConf['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array($this->extConf['storagePid'],$this->extConf['studentPid']) );
		return $querySettings;
	}
	
	/**
	 * transforms a given datestring to integer value
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseLocalDate($datevalue) {
		$termin = new DateTime( $datevalue );
		$value = $termin->getTimestamp();
		if (!empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['serverTimeZone']) ) {
			$value += $termin->getOffset();
		}
		return $value;
	}
}
