<?php
namespace Mff\MffImport\Command;

/**
 * Class StudClassFromFileCommandController
 * Creates relations between fe_users and tx_mffdb_domain_model_klasse
 * takes relations between students and classes from iConn-export-file
 * 
 */
class StudClassFromFileCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mff_import';

	/**
	 * TCAfieldNr
	 * we take Configuration No.3 [ 0 | 1 | 2 | 3 ]
	 *  The No. 2 is unused since we import students direct from file and not from legicard-api
	 *
	 * @var array
	 */
	public $TCAfieldNr = 3;

	public function execute(){
        if (!$GLOBALS['BE_USER']) return false;
        if (!$GLOBALS['BE_USER']->check('tables_modify', 'fe_users')) return false;
		$pathFilename = ltrim($GLOBALS['TCA']['fe_users']['ctrl']['external'][$this->TCAfieldNr]['parameters']['filename'], '/' );
		$uploadDir = rtrim( PATH_site , '/' ) . '/' .  rtrim(dirname($pathFilename), '/' ) . '/' ;
		$basename = pathinfo($pathFilename , PATHINFO_BASENAME);

		$files = $this->cmpr_getFileList($uploadDir);

		// select joungest file which is not named iconnusers.csv
		$joungest = '';
		foreach($files as $filnam=>$filArr){
		    if($filArr['filename']==$basename) continue;
		    if( empty($joungest) || $filArr['time'] > $files[$joungest]['time'] ) $joungest = $filnam;
		}
		
		// adjust, save and rename the file, delete all other files in dir
		if( isset($files[$joungest]['filename']) ){
			  // if file is taken from IS-II, then evaluate Benutzername and rename fieldname
			  $this->preProcessFields( $uploadDir.$files[$joungest]['filename'] );
		}

		// read first row in file, cut first 3 rows
		$aUsableFileContent = $this->readAndCutLeadingRowsInFile( $uploadDir.$basename );
		// if succesfull 
		if($aUsableFileContent){
			// delete all files in dir
			foreach($files as $filnam=>$filArr) {if( file_exists($uploadDir.$filArr['filename']) ) unlink($uploadDir.$filArr['filename']);}
			// save and rename the file
			file_put_contents( $uploadDir.$basename , $aUsableFileContent );
			
			// run external_import with svconnector_csv
			$importer = new \Cobweb\ExternalImport\Importer;
			
			$importer->synchronizeData( 'fe_users' , $this->TCAfieldNr );
			return true;
		}
		      //return true;
		return file_exists( $uploadDir.$basename );
	}
	
	/**
	 * reads studentPid
	 *
	 * @return int
	 */
	public function getStudentPid(){
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		return $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
	}
	
	/**
	 * readAndCutLeadingRowsInFile
	 *
	 * @param string $pathFilename
	 * @return array
	 */
	public function readAndCutLeadingRowsInFile( $pathFilename ) {
	      if(!file_exists($pathFilename)) return false;
	      $delimiter = $GLOBALS['TCA']['fe_users']['ctrl']['external'][$this->TCAfieldNr]['parameters']['delimiter'];
	      $TCAfields['username']   = $GLOBALS['TCA']['fe_users']['columns']['username']['external'][$this->TCAfieldNr]['field'];
	      $TCAfields['refClassId'] = $GLOBALS['TCA']['fe_users']['columns']['ref_class_id']['external'][$this->TCAfieldNr]['field'];

	      $lines = file($pathFilename);
	      $emptyLines = array();
	      foreach ($lines as $line_num => $line) {
				if( trim($line) == '' ){ $emptyLines[]=$line_num; continue; }
				if( strpos( ' '.$line , $delimiter ) == 0 ){ $emptyLines[]=$line_num; continue; }
				if(isset($headerLineNum)){ $bodyStartNum = $line_num; break; } // table-body starts here
				$lineTestCounter = 0;
				foreach($TCAfields as $fieldname) {
						if( strpos( ' '.$line , $fieldname ) ){++$lineTestCounter;} 
				}
				if($lineTestCounter==count($TCAfields)){ // this is the header-Line
					$headerLineNum = $line_num;
				}
	      }
	      if( isset($headerLineNum) && isset($bodyStartNum) ){
		    foreach($emptyLines as $lineNum){ unset($lines[$lineNum]); }
		    return $lines;
	      }
	      return false;
	}

	/**
	 * preProcessFields 
	 * if field 'Benutzername' is missing, then extract it from 'EMail'
	 * if field 'Klassen' is missing, then try to find field 'Klasse' and rename it.
	 *
	 * @param string $pathFilename
	 * @return array
	 */
	public function preProcessFields( $pathFilename ) {
		if(!file_exists($pathFilename)) return false;
		$aFileRows = file($pathFilename);
		
		$TCA = $GLOBALS['TCA']['fe_users']['ctrl']['external'][$this->TCAfieldNr]['parameters'];
		if( $TCA['skip_rows'] != 1 ) return $aFileRows; // only process if first row contains fieldnames
		$tq = $TCA['text_qualifier'];
		
		$headrow = array_shift($aFileRows);
		$rowFields = explode( $TCA['delimiter'] , trim($headrow) );
		foreach( $rowFields as $fieldIx => $cell ){ $aFieldnames[trim( $cell , $tq)] = $fieldIx ;}
		
		// only process if at least one of specific fieldnames existing
		if( !isset( $aFieldnames['EMail'] ) && !isset( $aFieldnames['Klasse'] ) ) return $aFileRows;
		
		// change Klasse to Klassen
		if( isset( $aFieldnames['Klasse'] ) ) {
				$aFieldnames['Klassen'] = $aFieldnames['Klasse'];
				unset( $aFieldnames['Klasse'] );
				asort( $aFieldnames );
		}
		
		// exit if field EMail is missing
		if( !isset($aFieldnames['EMail']) || isset($aFieldnames['Benutzername']) ){
				$newHeadrow = implode( $TCA['delimiter'] , array_keys($aFieldnames) );
				array_unshift( $aFileRows , $newHeadrow );
				return $aFileRows; 
		}
		
		$aFieldnames['Benutzername'] = count($aFieldnames); // set new field as last field (index+1)
		$newTableContent[] = implode( $TCA['delimiter'] , array_keys($aFieldnames) );
		$classAdjustHelper = new \Mff\MffImport\Utility\AdjustScoolclassUtility();
		foreach($aFileRows as $ix => $line ){
				$row = explode( $TCA['delimiter'] , trim($line) );
				$sMail = trim( $row[$aFieldnames['EMail']] , $tq );
				$aFromMail = explode( '@' , $sMail );
				$row[$aFieldnames['Benutzername']] =  $aFromMail[0];
				$row[$aFieldnames['Klassen']] = $tq . $classAdjustHelper->AdjustScoolclass(trim( $row[$aFieldnames['Klassen']] , $tq )) . $tq;
				$newTableContent[] = implode( $TCA['delimiter'] , $row );
		}
		$defaultFilename = ltrim($GLOBALS['TCA']['fe_users']['ctrl']['external'][$this->TCAfieldNr]['parameters']['filename'], '/' );

		$uploadDir = rtrim( PATH_site , '/' ) . '/' .  $defaultFilename;
 		unlink($pathFilename);
 		file_put_contents( $uploadDir , implode("\n",$newTableContent) );
	}

	/**
	 * create a list of files 
	 * and return the sum of all filesizes
	 *
	 * @param string $uploadDir
	 * @return array
	 */
	public function cmpr_getFileList($uploadDir , $afforedExtension = 'csv') {
		$d = dir( $uploadDir );
		$filelist = array();
		while (false !== ($entry = $d->read())) {
		      $filename = pathinfo($entry , PATHINFO_FILENAME);
		      $extension = pathinfo($entry , PATHINFO_EXTENSION);
		      if( empty($afforedExtension) || $afforedExtension == $extension  ){
			  $filelist[$filename] = array(
				'filename' => $entry ,
				'basename' => pathinfo($entry , PATHINFO_BASENAME) ,
				'size' => round( filesize($uploadDir.$entry) / 1024 , 3 ),
				'time' => filemtime( $uploadDir.$entry )
			  );
		      }
		}
		$d->close();
		krsort($filelist);

		return $filelist;
	}

}
