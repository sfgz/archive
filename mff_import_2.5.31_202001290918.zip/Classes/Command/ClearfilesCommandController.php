<?php
namespace Mff\MffImport\Command;
/**
 * Class ClearfilesCommandController
 */
class ClearfilesCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	
	public function execute(){
		// if younger than 1 week, keep all backups (ca. 3.5 Mb)
		// if younger than 1 month keep 1 backup each day (the last one from each day) 15 Mb
		// if younger than 1 year keep 1 backup each week (52 each year) 25 Mb Max.
		// if younger than 3 year keep 1 backup each month (12 each year) 6 Mb x 3 years = 18 Mb Max
		// if younger than 10 years keep 1 backup each year 0.5 Mb x 7 years = 3.5 Mb Max
		// delete all older than 10 years. Total ca. 65 Mb
		
		$extPath = dirname(dirname(dirname(__FILE__)));
		$dumpPath  = dirname(dirname(dirname($extPath))).'/uploads/tx_mffimport/backups';
		
		$today = mktime( 0,0,0, date('m') , date('d') , date('Y') );
		
		$uxDay = 3600*24;
		$uxWeek = 3600*24*7;
		$uxMonth = 3600*24*30;
		$uxYear = 3600*24*365;
		
		$passedWeek['w'] = $today - ($uxWeek);// innerhalb 7 Tagen alle Dateien behalten
		$passedWeek['m'] = $today - ($uxMonth); // innerhalb 30 Tagen 1 Datei pro Tag behalten
		$passedWeek['y'] = $today - ($uxYear); // innerhalb 1 Jahr 1 Datei pro Woche behalten
		$passedWeek['3y'] = $today - ($uxYear*3); // innerhalb 3 Jahren 1 Datei pro Monat behalten
		$passedWeek['10y'] = $today - ($uxYear*10);  // innerhalb 10 Jahren 1 Datei pro Jahr behalten
		
		$passedMonth = $today - (3600*24*7*4);
		
		$weekFile = array();
		
		$filelist = $this->show_file_list($dumpPath);
		
		// recent file first
		foreach( array_keys($filelist) as $filedate ){
			$fileDateDay = floor($filedate / $uxDay) * $uxDay;
			if ( $fileDateDay >= $passedWeek['w'] ) { // immer behalten: Datei wurde innerhalb der letzten Woche erstellt
			    continue;
			}
			$uxDateDiff = $today - $fileDateDay;
			if ( $filedate >= $passedWeek['m'] ) { // Datei wurde innerhalb des letzten Monats erstellt
			    $daydiff = floor( $uxDateDiff / $uxDay ); // 1 Datei pro Tag behalten
			    if( isset( $weekFile['m'][$daydiff] ) ){
				$this->deleteFile($dumpPath,$filedate);
			    }else{
				$weekFile['m'][$daydiff] = $filedate;
			    }
			}elseif( $filedate >= $passedWeek['y'] ){// Datei wurde innerhalb des letzten Jahres erstellt
			    $daydiff = floor( $uxDateDiff / $uxWeek ); // 1 Datei pro Woche behalten
			    if( isset( $weekFile['y'][$daydiff] ) ) {
				$this->deleteFile($dumpPath,$filedate);
			    }else{
				$weekFile['y'][$daydiff] = $filedate;
			    }
			}elseif( $filedate >= $passedWeek['3y'] ){// Datei wurde innerhalb des letzten 3 Jahre erstellt
			    $daydiff = floor( $uxDateDiff / $uxMonth ); // 1 Datei pro Monat behalten
			    if( isset( $weekFile['3y'][$daydiff] ) ) {
				$this->deleteFile($dumpPath,$filedate);
			    }else{
				$weekFile['3y'][$daydiff] = $filedate;
			    }
			}elseif( $filedate >= $passedWeek['10y'] ){ // Datei wurde innerhalb des letzten 10 Jahre erstellt
			    $daydiff = floor( $uxDateDiff / $uxYear );  // 1 Datei pro Jahr behalten
			    if( isset( $weekFile['10y'][$daydiff] ) ){
				$this->deleteFile($dumpPath,$filedate);
			    }else{
				$weekFile['10y'][$daydiff] = $filedate;
			    }
			}else{
			    $this->deleteFile($dumpPath,$filedate);
			}
		}
		return true;
	}
	
	/**
	 * deleteFile
	 * unlink files
	 *
	 * @param string $dumpPath
	 * @param string $fileBasename
	 * @return array
	 */
	public function deleteFile($dumpPath,$fileBasename) {
		unlink( $dumpPath . '/' . $fileBasename . '.sql' );
	}
	
	/**
	 * show a list of files
	 *
	 * @param string $dumpPath
	 * @return array
	 */
	public function show_file_list($dumpPath) {
		$d = dir( $dumpPath );
		$filelist = array();
		while (false !== ($entry = $d->read())) {
		      $filename = pathinfo($entry , PATHINFO_FILENAME);
		      $extension = pathinfo($entry , PATHINFO_EXTENSION);
		      if( 'sql' == $extension && is_numeric($filename) ){
			  $filelist[$filename]['filename'] = $filename;
			  $filelist[$filename]['size'] = round( filesize($dumpPath.'/'.$entry) / 1024 , 1 );
		      }
		}
		$d->close();
		krsort($filelist);

		return $filelist;
	}
}
