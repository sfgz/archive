<?php
// mff_import/ext_localconf.php

// Register hook for import-routine
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['svconnector_mff']['processResponse'][] = 'EXT:mff_import/class.tx_mffimport_hooks.php:tx_mffimport_hooks';
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['svconnector_csv']['processResponse'][] = 'EXT:mff_import/class.tx_mfficonn_hook.php:tx_mfficonn_hook';

// Register scheduler-Tasks
if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\SqldumpCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\CleartableCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_cleartable',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_cleartable',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\ClearfilesCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_clearfiles',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_clearfiles',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\KursregelCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_kursregel',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_kursregel',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\KurzklasseCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_kurzklasse',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_kurzklasse',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\TeacherrelationsCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_teacherrelations',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_teacherrelations',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\UsergroupsCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_usergroups',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_usergroups',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\LocationkeyCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_locationkey',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_locationkey',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\MffImport\\Command\\FixRelationsCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.title_fixrelations',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.description_fixrelations',
		'additionalFields'	=> ''
	);
}
\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'is2import',
	array(
		'Iconn' => 'upload'
	),
	// non-cacheable actions
	array(
		'Iconn' => 'upload'
	)
);

?>