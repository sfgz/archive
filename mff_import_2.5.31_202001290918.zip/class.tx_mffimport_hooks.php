<?php
/***************************************************************
*  Copyright notice
*
*  (c) 2007-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Hooks for the 'mff_import' extension
 *
 * @author		Daniel Rueegg, Francois Suter (Cobweb) <typo3@cobweb.ch>
 * @package		TYPO3
 * @subpackage	tx_mffimport
 */
class tx_mffimport_hooks implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * extConf
	 *
	 * @var array
	 */
	protected $extConf;

	/**
	 * __construct
	 */
	public function __construct() {
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
 		$this->extConf['hide_if_in_list'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['hide_if_in_list.'];
		$this->extConf['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
		$this->extConf['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		$this->extConf['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		date_default_timezone_set ( 'Europe/Zurich' );
		$this->extConf['timeZoneGMT'] = new \DateTimeZone( 'GMT' );
		$this->extConf['timeZoneLocal'] = new \DateTimeZone( 'Europe/Zurich' );
 		$this->extConf['excludeOldData'] = $this->extConf['importOldData'] ? 0 : 1;
	}

	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 *
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function processResponse($data, $pObj) {
		$hookName = $pObj->parameters['hook'];
		if(!empty($hookName) && $hookName != 'processResponse' && method_exists( $this , $hookName ) ) return $this->$hookName($data, $pObj);
		return false;
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
 		return json_encode($rawData);
	}
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * return only the body-part, not the code (wich is always 200)
	 *
	 * url for the svconnector_json object: [mixed]
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function body_processResponse($data, $pObj) {
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
		$id=0;
		foreach($rawData['body'] as $locRow){
		    ++$id;
		    $locArr[$id]=$locRow;
		    $locArr[$id]['pid'] = $this->extConf['storagePid'];
		}
		return json_encode( $locArr );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out records with empty building-field (which was used for building-description)
	 *
	 * url for the svconnector_json object: .../subject
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function fach_processResponse($data, $pObj) {
		$classArr = array(); // array for hiding courses like 'Lehrgang Malermeister'
		$hideIf = array(); // array for hiding courses like 'Fachklasse' or 'Studiengang'
		// they where added in Ecoopen for secretary purposes
		
		// prepare array for hiding courses with the same name as classes (eg. Lehrgang Malermeister)
		// extConf is coming from mffdb/Configuration/TypoScript/setup.txt. posibly overwritten by template
		// extConf['hide_if_is_ref']['fach'] = SubjectShort:Klasse.ClassShort
		if( 'SubjectShort:Klasse.ClassShort' == $this->extConf['hide_if_is_ref']['fach'] ){
		      $theRepository = $this->getRepository( 'Klasse' );
		      $classes = $theRepository->findAll();
		      foreach($classes as $row){$classArr[$row->getClassShort()] = $row->getClassId();}
		}
		// prepare array for hiding if field = content: Subject:Fachklasse,Subject:Studiengang
		// extConf['hide_if_in_list']['fach'] = Subject:Fachklasse,Subject:Studiengang
		if( !empty($this->extConf['hide_if_in_list']['fach']) ){
		    $pairs = explode( ',' , $this->extConf['hide_if_in_list']['fach'] );
		    foreach($pairs as $pair){ 
				$cmp = explode(':',$pair);
				$hideIf[$cmp[0]][strtolower($cmp[1])] = strtolower($cmp[1]);
		    }
		}
		// end prepare for hiding

		$rawData = json_decode($data, true);
		$aIndex = array();
		$outRow = array();
		foreach($rawData['body'] as $courseRow){
			// translate fieldnames from new course-view to old subject-view
			$locRow = array(
					'pid'=>$this->extConf['storagePid'],
					'ID'=>$courseRow['SubjectID'],
					'SubjectShort'=>$courseRow['CourseShort'],
					'Subject'=>$courseRow['Course'],
			);
			// set recordset to 'hidden' if affored
		    $hide = 0;
		    if( isset($classArr[$locRow['SubjectShort']]) ){
				$hide = 1;
		    }elseif( is_array($hideIf) ){
				foreach( array_keys($hideIf) as $field){
					if(!empty($locRow[$field])){
						$contWords = explode(' ' , $locRow[$field] );
						if(isset( $hideIf[$field][strtolower($contWords[0])] )) {
							$hide = 1;
							break;
						}
					}
				}
		    }
		    // fill the array
		    $locArr[$locRow['ID']]=$locRow;
		    $locArr[$locRow['ID']]['hidden'] = $hide;
		    // create a index for unique recorsets by SubjectShort 
		    // FIXME Take oldest value by !isset. otherwise keys dont match wich existing timetables. is this ok for the future?
		    //if(!isset( $aIndex[$locRow['SubjectShort']] ))
		    $aIndex[$locRow['SubjectShort']] = $locRow['ID'];
		}
		// change index from SubjectShort to numeric index and sort array by key
		foreach($aIndex as $id) $outRow[$id] = $locArr[$id];
		ksort($outRow);

		return json_encode( $outRow );
	}


	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out records with empty building-field (wich was used for building-description)
	 *
	 * url for the svconnector_json object: .../location
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function zimmer_processResponse($data, $pObj) {
		$locArr = array();
		$rawData = json_decode($data, true);
		// delete recordset, if field 'building' is empty
		$id=0;
		foreach($rawData['body'] as $locRow){
		    if( '' == trim($locRow['building']) ) continue;
		    ++$id;
		    $locArr[$id]=$locRow;
		    $aRoom = explode(' ' , $locRow['room'] );
		    if( $aRoom[0] == $locRow['building'] ) $locArr[$id]['room'] = implode( ' ' , array_slice( $aRoom , 1 ) );
		    $locArr[$id]['pid'] = $this->extConf['storagePid'];
		}
 		return json_encode($locArr);
	}
	

	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * it transforms fields for Klasse 
	 *
	 * url for the svconnector_json object: .../class
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function klasse_processResponse($data, $pObj) {
		$krzArr = array();
		$rawData = json_decode($data, true);
		$dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 22:00:00');
		$classAdjustHelper = new \Mff\MffImport\Utility\AdjustScoolclassUtility();
		foreach($rawData['body'] as $klsRow){
		    $id = $klsRow['ID'];
		    // classshort is like 'PBB15 A' but we need the 'PBB' part
		    
		    $stringClassShort = $classAdjustHelper->AdjustScoolclass( trim($klsRow['ClassShort']) );
			$aClassShort = explode( ' ' , $stringClassShort );
 			$classPart = substr( $aClassShort[0] , 0 , strlen($aClassShort[0])-2 );
		    
		    $dateTo = $this->parseLocalDate($klsRow['EndDate']);
 		    if($this->extConf['excludeOldData'] && $dateTo < $dateToNow) continue;
		    
		    $krzArr[$id]=$klsRow;
		    $krzArr[$id]['pid'] = $this->extConf['storagePid'];
		    $krzArr[$id]['ClassShort']=$stringClassShort;
		    $krzArr[$id]['klasse_kurz']=$classPart;
		    $krzArr[$id]['klasse_zug'] = isset($aClassShort[1]) ? $aClassShort[1] : '';
		    // date is like 2015-12-31 00:00:00
		    $krzArr[$id]['klasse_jahr']= substr($klsRow['StartDate'], 2 , 2);
		    $krzArr[$id]['klasse_start']= $this->parseLocalDate($klsRow['StartDate']);
		    $krzArr[$id]['klasse_ende']= $dateTo;
		    $krzArr[$id]['ref_class_id']= $id;
		}
 		return json_encode( $krzArr );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out old records
	 *
	 * url for the svconnector_json object: .../teacher
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function teacher_processResponse($data, $pObj) {
		$teacherArr = array();
		$rawData = json_decode($data, true);
		$genderTransform = array( 'm'=> 0 , 'f'=>1 );
		foreach($rawData['body'] as $teaRow){
 		    if( empty($teaRow['Username']) ) continue;
		    $teacherArr[ $teaRow['ID'] ] = $teaRow;
		    $teacherArr[ $teaRow['ID'] ]['gid'] = $this->extConf['userGroupId'].','.$this->extConf['teacherGroupId'];
		    $teacherArr[ $teaRow['ID'] ]['pid'] = $this->extConf['teacherPid'];
		    $teacherArr[ $teaRow['ID'] ]['name'] =  trim( str_replace( '*' , '' , $teaRow['GivenName'] . ' ' . $teaRow['Lastname'] ) );
		    $teacherArr[ $teaRow['ID'] ]['gender'] = $genderTransform[ $teaRow['Gender'] ];
		    $ID = $teaRow['ID'];
		    $teacherArr[ $teaRow['ID'] ]['Acronym'] = str_replace( 'Ö' , 'OE' , $teaRow['Acronym'] );
		    $namFirst = trim( str_replace( '*' , '' , htmlentities($teaRow['GivenName'] )) );
		    $namLast = trim( str_replace( '*' , '' , htmlentities($teaRow['Lastname'] )) );
		    if( strlen($namLast)>3 ) { $partOne = substr( $namLast , -2  ) ;}else{$partOne =  $namLast;}
		    $partTwo = strlen($namFirst)>2 ? substr( $namFirst , 0 , 2 ) : '';
 		    $teacherArr[ $teaRow['ID'] ]['password'] = $partOne .  $partTwo . '.' . substr( $ID , 0 , 4 ) ;
		}
 		return json_encode($teacherArr);
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * and it filters out old records
	 *
	 * url for the svconnector_json object: .../legicarddata
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function students_processResponse($data, $pObj) {
		$studArr = array();
		$classArr = array();
		// read klassen-records to get outdated classes
		$theRepository = $this->getRepository( 'Klasse' );
		$classes = $theRepository->findAll();
		// create an array for later test
		$classAdjustHelper = new \Mff\MffImport\Utility\AdjustScoolclassUtility();
		foreach($classes as $row){$classArr[$row->getClassId()] = array( 'dateTo'=>$row->getKlasseEnde() , 'classShort'=>$classAdjustHelper->AdjustScoolclass($row->getClassShort()) ) ;}
		// set delay time: exclude record if class is outdated since x days
		$dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 00:00:00');
		// get data in form of an array instead of an object
		$rawData = json_decode($data, true);
		foreach($rawData['body'] as $studRow){
		    $dateTo = $classArr[ $studRow['ClassID'] ]['dateTo'];
 		    if($this->extConf['excludeOldData'] && $dateTo < $dateToNow) continue;
 		    if( empty($studRow['Username']) ) continue;
		    $studArr[ $studRow['PersonID'] ] = $studRow;
		    $studArr[ $studRow['PersonID'] ]['gid'] = $this->extConf['userGroupId'].','.$this->extConf['studentGroupId'];
		    $studArr[ $studRow['PersonID'] ]['pid'] = $this->extConf['studentPid'];
// 		    $studArr[ $studRow['PersonID'] ]['ClassShort'] = $classArr[ $studRow['ClassID'] ]['classShort'];
		    $studArr[ $studRow['PersonID'] ]['name'] =  trim( str_replace( '*' , '' , $studRow['GivenName'] . ' ' . $studRow['Lastname'] ) );
		    $ID = $studRow['PersonID'];
		    $namFirst = trim( str_replace( '*' , '' , htmlentities($studRow['GivenName'] )) );
		    $namLast = trim( str_replace( '*' , '' , htmlentities($studRow['Lastname'] )) );
		    $studArr[ $studRow['PersonID'] ]['password'] =  substr( $namLast , strlen($namLast)-2 ) . substr( $namFirst , 0 , 2 ) . '.' . substr( $ID , 0 , 4 ) ;
		}
 		return json_encode($studArr);
	}

	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the Object to flat array
	 * it transforms fields for Kurs 
	 * with m:m-relation to Klasse 
	 * and n:1 relation to Fach 
	 *
	 * url for the svconnector_json object: .../course
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function kurs_processResponse($data, $pObj) {
		$krzArr = array();
		$rawData = json_decode($data, true);
		$dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 00:00:00');
		foreach($rawData['body'] as $krsRow){
		    // exclude outdated, means older than 7 years.
		    $uxDatumEnd = $this->parseLocalDate($krsRow['EndDate']);
		   if( $this->extConf['excludeOldData'] && $uxDatumEnd < $dateToNow ) continue;
		   if( empty($krsRow['CourseShort']) ) continue;
		    
		    $newRow=$krsRow;
		    $newRow['pid'] = $this->extConf['storagePid'];
		    $newRow['course_id']=$krsRow['ID'];
		    $newRow['subject_id']=$krsRow['SubjectID'];
		    $newRow['department_id']=$krsRow['DepartmentID'];
		    // date is like 2015-12-31 00:00:00
		    $newRow['kurs_start']= $this->parseLocalDate($krsRow['StartDate']);
		    $newRow['kurs_ende']= $uxDatumEnd;
		    $newRow['class_id'] = $krsRow['MainClass'];
		    $newRow['kurs_typ'] = empty($krsRow['MainClass']) ? 2 : 1;
		    
		    $krzArr[$krsRow['ID']] = $newRow;
		}
		if(count($krzArr)) ksort($krzArr);
 		return json_encode( array_slice( $krzArr , 0 , 100000) );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * it is used to create stundenplan
	 * 
	 * url for the svconnector_json object: .../timetable
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function stundenplan_processResponse($data, $pObj) {
	    $courseExists = array();
	    $theRepository = $this->getRepository( 'Kurs' );
	    $Kurses = $theRepository->findAll();
	    foreach($Kurses as $kurs) $courseExists[$kurs->getCourseId()]=1;
	    $outRow = array();
	    $dateToNow = $this->parseLocalDate( date( 'Y-m-d' ).' 00:00:00');
	    $dbData = json_decode( $data, true);
	    $newIx = array();
	    $stundenplanRepository = $this->getRepository( 'Stundenplan' );
	    foreach($dbData['body'] as $row){
		 if( empty($row['TeacherID']) ) continue;
		 if( empty($row['LocationID']) ) continue;
		 if( empty($row['CourseID']) ) continue;
		 if( !isset($courseExists[$row['CourseID']]) ) continue;
		 $newIx[$row['ID']][]=1;
		 $ix = $row['ID'].'.'.( count($newIx[$row['ID']])-1 );
		 $validTo = $this->parseLocalDate($row['ValidTo'].' 23:59:01');
		 if( $this->extConf['excludeOldData'] && $validTo < $dateToNow ) continue;
		  $oldStart = 0;
		  $planRecords = $stundenplanRepository->findByTimetableId($ix);
		  if($planRecords){foreach($planRecords as $rec) {$oldStart = $rec->getPlanStart();break;}}
		  $outRow[$ix]=$row;
		  $outRow[$ix]['ID'] = $ix;
		  $outRow[$ix]['pid'] = $this->extConf['storagePid'];
		  $outRow[$ix]['plan_start']= (!empty($oldStart) && $oldStart < time() ) ? $oldStart : $this->parseLocalDate($row['ValidFrom'].' 00:00:00');
		  $outRow[$ix]['plan_ende']= ( $validTo - 1 ); // 60 Sec * 60 min * 24 h - 1 sec.
	    }
	    return json_encode( array_slice( $outRow , 0 , 100000) );
	}
	
	/**
	 * This method responds to the "processResponse" hook of the svconnector_json class
	 * It is used to transform the iCal-Data to flat array
	 * return only the appt-part
	 *
	 * url for the svconnector_json object: .../calendar
	 * 
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_json object
	 * @return array
	 */
	function kalender_processResponse($data, $pObj) {
		$calDB = array();
		$sortCal = array();
		$keyWords = array();
		$rawData = json_decode($data, true);
		// transform iCal formatted data in flat array
		$conf = array( 'name' , 'class' , 'seq'  , 'allDay'  , 'uid' );
		$matchPrivate = array( 'PUB'=> 0 , 'PRI' =>1 );
		$rawKeywords = explode( ',' , strtolower($this->extConf['periods_keywords']) ); // zb 'Sportferien,Sommerferien'
		foreach($rawKeywords as $rawWord){ $keyWords[trim($rawWord)] = trim($rawWord); }
		foreach($rawData['appt'] as $row){
		      if( $row['inv'][0]['comp'][0]['fba'] != 'F' ) continue;// nur freie Termine, nicht Besetzte
		      $id = $row['uid'];
		      $beginn = $row['inv'][0]['comp'][0]['s'][0]['d'];
		      $ende = $row['inv'][0]['comp'][0]['e'][0]['d'] ;
//		      $beginnUx = $this->parseLocalDate($this->parseCalendarTextdate( $beginn ));
		      $beginnUx = $this->parseLocalDate( $beginn );
		      foreach($conf as $fld) $calDB[$fld] = $row['inv'][0]['comp'][0][$fld];
		      $calDB['bemerkung'] = trim( $calDB['fr'] . ' ' . $calDB['loc'] );
		      $calDB['beginn_localtime'] = $beginnUx;
// 		      $calDB['ende_localtime'] = $this->parseLocalDate($this->parseCalendarTextdate( $ende ));
		      $calDB['ende_localtime'] = $this->parseLocalDate( $ende );
		      $calDB['privat'] = $matchPrivate[ $calDB['class'] ];
		      $calDB['code'] = $row['uid'];
		      $calDB['pid'] = $this->extConf['storagePid'];
		      $calDB['semestergrenze'] = isset( $keyWords[strtolower(trim($calDB['name']))] ) ? 1 : 0;
		      $sortCal[ $beginnUx.'.'.$id  ] = $calDB;
		}
		@ksort($sortCal);
 		return json_encode($sortCal);
	}

	/**
	 * returns the object of a Model like "Klasse" or "Kurs"
	 *
	 * @param string $table The name of table to return
	 * @return void
	 */
	protected function getRepository( $table ) {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		// TODO:storage pid from config
		//$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		//$tsConfig = $configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array($this->extConf['storagePid']) );
		// Repository instanziieren
		$oneRepository = $objectManager->get( str_replace( '##TABLENAME##' , $table , 'Mff\Mffdb\Domain\Repository\##TABLENAME##Repository') );
		$oneRepository->setDefaultQuerySettings($querySettings);
		return $oneRepository;
		//return $oneRepository->findAll();
	}
	
	/**
	 * transforms a given datestring to unix-time
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseCalendarTextdate($datevalue) {
		$aAb = explode( 'T' , $datevalue );
		$date = substr( $aAb[0] , 0 , 4) . '-' . substr( $aAb[0] , 4 , 2) . '-' . substr( $aAb[0] , 6 , 2);
		$time = ( count($aAb) != 2 ) ? '00:00:00' : substr( $aAb[1] , 0 , 2) . ':' . substr( $aAb[1] , 2 , 2) . ':' . substr( $aAb[1] , 4 , 2);
		return  $date . ' ' . $time ;
	}
	
	/**
	 * transforms a given datestring to integer value
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseLocalDate($datevalue) {
		$termin = new \DateTime( $datevalue );
		$termin->setTimeZone($this->extConf['timeZoneLocal']); 
		$value = $termin->getTimestamp();
// 		if (!empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['serverTimeZone']) ) {
 			$value += $termin->getOffset();
// 		}
		return $value;
	}
	/**
	 * transforms a given datestring to unix-time
	 * same as before but with timezone GMT - same result
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseTimestamp($datevalue) {
		$termin = new \DateTime( $datevalue , $this->extConf['timeZoneGMT'] );
		return $termin->getTimestamp();
	}
}
?>
