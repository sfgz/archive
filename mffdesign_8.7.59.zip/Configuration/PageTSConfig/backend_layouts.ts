mod {
	web_layout {
		BackendLayouts {
			1 {
				title = Dreispalter mit Menue und Rand
				config {
					backend_layout {
						colCount = 3
						rowCount = 2
						rows {
							1 {
								columns {
									1 {
										name = Linke Spalte
										colPos = 1
									}
									2 {
										name = Inhalt
										colPos = 0
									}
									3 {
										name = Rechte Spalte
										colPos = 2
									}
								}
							}
							2 {
								columns {
									1 {
										name = Rand unten
										colPos = 3
										colspan = 3
									}
								}
							}
						}
					}
				}
				icon = EXT:mffdesign/Resources/Public/images/backend/layout_3_cols_border.png
			}
			
			2 {
				title = Zweispalter (breiter Inhalt) mit Menue und Rand
				config {
					backend_layout {
						colCount = 2
						rowCount = 3
						rows {
							1 {
								columns {
									1 {
										name = linke Spalte
										colPos = 1
									}
									2 {
										name = Inhalt
										colPos = 0
									}
								}
							}
							2 {
								columns {
									1 {
										name = rechte Spalte (unten Links)
										colspan = 2
										colPos = 2
									}
								}
							}
							3 {
								columns {
									1 {
										name = Rand (unten Mitte)
										colspan = 2
										colPos = 3
									}
								}
							}
						}
					}

				}
				icon = EXT:mffdesign/Resources/Public/images/backend/layout_3on2_cols_border.png
			}
			
			3 {
				title = Nur Inhalt ohne Menue
				config {
					backend_layout {
						colCount = 1
						rowCount = 1
						rows {
							1 {
								columns {
									1 {
										name = Inhalt (ohne Menue)
										colPos = 0
									}
								}
							}
						}
					}
				}
				icon = EXT:mffdesign/Resources/Public/images/backend/layout_1_column.png
			}
			
			4 {
				title = Dreispalter mit Menue, rechts und Rand
				config {
					backend_layout {
						colCount = 3
						rowCount = 2
						rows {
							1 {
								columns {
									1 {
										name = Linke Spalte
										colPos = 1
									}
									2 {
										name = Inhalt
										colPos = 0
									}
									3 {
										name = Rechte Spalte
										colPos = 2
									}
								}
							}
							2 {
								columns {
									1 {
										name = Rand unten
										colPos = 3
										colspan = 3
									}
								}
							}
						}
					}
				}
				icon = EXT:mffdesign/Resources/Public/images/backend/layout_3_cols_border.png
			}
		}
	}
}
