## pagelayout
lib.pagelayout = TEXT
lib.pagelayout.insertData = 1
lib.pagelayout.value = {page:layout}

lib.backendlayout = TEXT
lib.backendlayout.insertData = 1
lib.backendlayout.value = {page:backend_layout}

plugin.tx_mffdesign_pagelayout._CSS_DEFAULT_STYLE (
 .main-layout-pagets__4 DIV.content_box.layout-left-box { float:left;width:60%; }
 .main-layout-pagets__4 DIV.content_box.layout-right-box { float:right;width:38%; }
 
 .main-layout-pagets__4.page-layout-1 DIV.content_box.layout-left-box{ float:left;width:38%; }
 .main-layout-pagets__4.page-layout-1 DIV.content_box.layout-right-box{ float:right;width:60%; }
)
