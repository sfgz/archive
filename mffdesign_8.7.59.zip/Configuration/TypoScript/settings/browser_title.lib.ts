# Seitentitel entfernen
config.noPageTitle = 2

page.headerData.1110 = COA_INT
page.headerData.1110 {
    
    wrap = <title>|</title>
    
    # aktueller Seitentitel aus Tabelle page
    10 = TEXT
    10 {
        field = title
        noTrimWrap = | | &#124; |
    }
    15 = TEXT
    15 {
        value = {$plugin.mffdesign.settings.sitetitle}
        insertData = 1
    }
    
}

