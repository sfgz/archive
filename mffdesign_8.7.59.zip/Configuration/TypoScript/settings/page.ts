#8.7.50
options.clearCache.system = 1
options.clearCache.all = 1
config {
    baseURL = {$plugin.mffdesign.settings.baseURL}
    ## absRefPrefix = /t3_www/
    doctype = html5
    metaCharset = utf-8
    renderCharset = utf-8
    no_cache = 0
    admPanel = 0
    debug = 1

    spamProtectEmailAddresses = 2
    spamProtectEmailAddresses_atSubst = <img src="/typo3conf/ext/mffdesign/Resources//Public/images/at_10.png" alt="[at]" />
    spamProtectEmailAddresses_lastDotSubst = <img src="/typo3conf/ext/mffdesign/Resources//Public/images/dot.png" alt="." />

    simulateStaticDocuments = 0
    tx_extbase.mvc.callDefaultActionIfActionCantBeResolved = 0
    tx_realurl_enable = 1
    typolinkEnableLinksAcrossDomains = 1

    language = de
    locale_all = de_DE.utf8
    htmlTag_langKey = de-CH
    prefixLocalAnchors = all
    
	removeDefaultJS = external
}
# bring back old error-hints in FE instead of 'Oops, an error occured...'
config.contentObjectExceptionHandler = 0

# use swiss Date in Plugin-Header 
lib.stdheader.40.10.strftime = %d.%m.%Y



page = PAGE
page.typeNum = 0
page.shortcutIcon = typo3conf/ext/mffdesign/Resources/Public/images/favicon.ico

page.10 = FLUIDTEMPLATE
page.10 {
    partialRootPath = {$plugin.mffdesign.view.partialRootPaths.10}
    layoutRootPath = {$plugin.mffdesign.view.layoutRootPaths.10}
    variables {
        content_main < styles.content.get
        content_main.select.where = colPos = 0
        content_column_1 < styles.content.get
        content_column_1.select.where = colPos = 1
        content_column_2 < styles.content.get
        content_column_2.select.where = colPos = 2
        content_border < styles.content.get
        content_border.select.where = colPos = 3
    }

    file.stdWrap.cObject = CASE
    file.stdWrap.cObject {

        # Die Backend Layout ID definiert das Frontend Template
        # sliden, falls Backend Layouts auf Unterseiten vererbt wurden.
        key.data = levelfield:-1, backend_layout, slide
        key.override.field = backend_layout

        # Standard Layout
        # Wird verwendet wenn keine spezielles Backend Layout definiert wurde.
        default = TEXT
        default.value = {$plugin.mffdesign.view.templateRootPaths.10}main_3_column_border_with_menu.html

        # Wenn wir Backend Layouts über die Datenbank definieren, dann wird an dieser Stelle die ID des Datensatz stehen.
        # Da wir diese aber ins Page TSConfig auslagern, müssen wir der ID "pagets__" voranstellen.
        # Definition Dreispalter
        pagets__1 = TEXT
        pagets__1.value = {$plugin.mffdesign.view.templateRootPaths.10}main_3_column_border_with_menu.html

        # Definition Zweispalter
        pagets__2 = TEXT
        pagets__2.value = {$plugin.mffdesign.view.templateRootPaths.10}main_3on2_column_border_with_menu.html

        # Definition Popup
        pagets__3 = TEXT
        pagets__3.value = {$plugin.mffdesign.view.templateRootPaths.10}main_1_column_without_menu.html
        
        # Definition Dreispalter
        pagets__4 = TEXT
        pagets__4.value = {$plugin.mffdesign.view.templateRootPaths.10}main_3_column_right_border_with_menu.html

    }
}

page.10.variables.content_main.stdWrap.replacement {
  
  
  5 {
    search = #preauth_daten#
    replace.cObject = USER_INT
    replace.cObject.userFunc = Sfgz\SfgzFeloginrsaauth\Utility\PreauthLinkUtility->preauthLink
    replace.cObject.cssclass = external-link
    replace.cObject.subdomain = https://daten.sfgz.ch
  }

  210 < .5
  210.search = #preauth_intern#
  210.replace.cObject.subdomain = https://intern.sfgz.ch

  220 < .5
  220.search = #preauth_tools#
  220.replace.cObject.subdomain = https://tools.sfgz.ch
  
}

## CSS typo3
page.headerData.10 = CASE
page.headerData.10 {
  stdWrap.wrap = <link rel="stylesheet" type="text/css" href="typo3conf/ext/mffdesign/Resources/Public/css/|" media="all" />
  key.data = levelfield:-1, backend_layout, slide
  key.override.field = backend_layout
  default = TEXT
  default.value = main.css
  pagets__1 = TEXT
  pagets__1.value = main.css
  pagets__2 = TEXT
  pagets__2.value = main3on2.css
  pagets__3 = TEXT
  pagets__3.value = main1column.css
}

[globalVar = GP:type=95]
	page.headerData.11 = TEXT
	page.headerData.11.value = <link rel="stylesheet" type="text/css" href="typo3conf/ext/mffdesign/Resources/Public/css/main1column.css" media="all" />
[global]

# CSS additional
#teaser images
[globalVar = TSFE:id = {$plugin.mffdesign.settings.teaser_uid} ]
	page.headerData.31 = TEXT
	page.headerData.31.value=<style>#container_wrap {min-height:1500px;display:block;}</style>
	
	page.20.20 = FILES
	page.20.20 {
		stdWrap.wrap (
		function getTeaserImages(){ return [ |"background01.svg" ];};
		showFeTeaser();
		)
		folders = 6:teaser/
		renderObj = TEXT
		renderObj {
			stdWrap.data = file:current:name
			stdWrap.wrap = "|",
		}
	}
[global]

# include main css
page.includeCSS.cssfile1 = typo3conf/ext/mffdesign/Resources/Public/css/general.css
page.includeCSS.cssfile3 = typo3conf/ext/mffdesign/Resources/Public/css/decor.css
page.includeCSS.cssfile2 = typo3conf/ext/mffdesign/Resources/Public/css/print.css
page.includeCSS.cssfile2.media = print
## calendar
page.includeCSS.calendar_eu = typo3conf/ext/mffdesign/Resources/Public/css/calendar.css


## include JQuery 
[globalVar = LIT:0<{$plugin.mffdesign.settings.loadjquery}]
	page.includeJS.jquery = https://code.jquery.com/jquery-latest.js
[global]
page.includeJS.jquery_min = https://code.jquery.com/jquery.min.js
page.includeJS.jquery_uimin = https://code.jquery.com/ui/1.11.4/jquery-ui.min.js

## JS 
# give rte-behavor to all elements with class="editor" and class="smalleditor"
page.includeJS.jqte = typo3conf/ext/mffdesign/Resources/Public/script/jquery-te-1.4.0.js
page.includeJS.jqtem = typo3conf/ext/mffdesign/Resources/Public/script/jquery-te-1.4.0.min.js
page.includeJS.jquery_shiftcheckbox = typo3conf/ext/mffdesign/Resources/Public/script/gistfile1.js
page.includeJS.mff_helpers = typo3conf/ext/mffdesign/Resources/Public/script/mff_helpers.js
page.includeJS.sfgz_responsive = typo3conf/ext/mffdesign/Resources/Public/script/sfgz_responsive.js

## calendar
page.includeJS.calendar_eu = typo3conf/ext/mffdesign/Resources/Public/script/calendar_eu.js
# page.includeJS.clipboard = https://cdn.rawgit.com/zenorocha/clipboard.js/v1.7.1/dist/clipboard.min.js

## table sorter
page.includeCSS.pager = typo3conf/ext/mffdesign/Resources/Public/script/tablesorter-master/addons/pager/jquery.tablesorter.pager.css

page.includeJSFooter.tablesorter = typo3conf/ext/mffdesign/Resources/Public/script/tablesorter-master/js/jquery.tablesorter.js
page.includeJSFooter.tablesorter_pager = typo3conf/ext/mffdesign/Resources/Public/script/tablesorter-master/addons/pager/jquery.tablesorter.pager.js
page.includeJSFooter.mff_tablesorter = typo3conf/ext/mffdesign/Resources/Public/script/mff_tablesorter.js

page.includeCSS.cssfile_te = typo3conf/ext/mffdesign/Resources/Public/css/jquery-te-1.4.0.css

# jq editor for own rte in FE
page.jsInline.37 = TEXT
page.jsInline.37.value (
		
// extension mffdesign: jq editor for own rte in FE
	$(document).ready(function(){
		$('.editor').jqte({p: true, br:true});
		$('.smalleditor').jqte({'ol': false,'ul':false,'formats':false,'fsize':false});
	});

)
page.jsInline.37 >

# Meldungen langsam ausblenden, wenn 'hideAlerts' einen Wert größer als 0 (Null) hat
# hide alerts and hints after a while
[globalVar = LIT:0<{$plugin.mffdesign.settings.hideAlerts}]
    page.jsInline.38 = TEXT
    page.jsInline.38.value = {$plugin.mffdesign.settings.hideAlerts} * 1000
    page.jsInline.38.prioriCalc = 1
    page.jsInline.38.wrap (

// extension mffdesign: handle messages and alerts
    function hideAlerts() {
		$('.typo3-messages').css({padding:'3px',border:'2px solid black',background:'#FFFFE0',position: 'fixed', bottom:'10px','z-index':'100'});$('.typo3-messages').fadeOut(|);
    } 
    window.onload = hideAlerts;

)
[global]

# if shown as Popup then use a template without sidebars and border-column
contentonly = PAGE
contentonly < page
contentonly {
      typeNum = 95
      10.file.stdWrap.cObject =<
      10.file.stdWrap.cObject = TEXT
      10.file.stdWrap.cObject.value = {$plugin.mffdesign.view.templateRootPaths.10}main_1_column_without_menu.html
}

[globalVar = GP:cnt!=""]
  tt_content.stdWrap.innerWrap.cObject.default = 
    lib.stdheader >
    contentonly.10 = COA_INT
    contentonly.10 {
      10 = RECORDS
      10 {
	  tables = tt_content
	  source = {GP:cnt}
	  source.insertData = 1
	  source.insertData.intval = 1
      }
    }
[global]


[globalVar = GP:type=100]
tt_content.stdWrap.innerWrap.cObject.default = 
lib.stdheader >
[global]

nurCel = PAGE
nurCel.typeNum = 100
nurCel.config {
   disableAllHeaderCode = 1
   disableCharsetHeader = 1
   disablePrefixComment = 1
}
nurCel.10 = COA_INT
nurCel.10 {
   10 = RECORDS
   10 {
      tables = tt_content
      source = {GP:cnt}
      source.insertData = 1
      source.insertData.intval = 1
   }
}

