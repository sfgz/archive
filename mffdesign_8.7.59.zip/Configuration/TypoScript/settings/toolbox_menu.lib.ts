lib.toolbox_menu = COA
lib.toolbox_menu {
   wrap = <div class="toolbox_menu">|</div>
   10 = COA
   10 {
      wrap = |
      5 = TEXT
      5.wrap = <div>|</div>
      5.value = CONTACT
      5.typolink.parameter = http://sfgz.ch/sfgz.ch/subdomain/beta/Web/schule/kontakt.html
      7 < .5
      7.value = PRINT
      7.typolink.parameter >
      7.typolink.parameter.data = TSFE:id
      7.typolink.ATagParams = onClick="window.print();return false;"
      9 < .5
      9.value = HOME
      9.typolink.parameter = {$plugin.mffdesign.settings.mainpage_uid}
      9.typolink.ATagParams = target="_self"

      11 < .9
      11.value = LOGIN
      11.typolink.parameter = https://intern.sfgz.ch
      
      5.typolink.ATagParams = target="_blank"
   }
}
lib.toolbox_menu.10.5 >
[globalVar = TSFE:fe_user|user|usergroup > 0]
lib.toolbox_menu.10.9.value = Home, Logout
lib.toolbox_menu.10.11 >
#lib.toolbox_menu.10.11.value = zum Logout
#lib.toolbox_menu.10.11.wrap = <div title="zum Logout...">|</div>
#lib.toolbox_menu.10.11.typolink.parameter = {$plugin.mffdesign.settings.loginpage_uid}
[global]
