 
page.config.admPanel = 0