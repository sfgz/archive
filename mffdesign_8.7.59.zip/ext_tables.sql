#
# Table structure for table 'backend_layout'
#
CREATE TABLE backend_layout (

	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,

);
