function fitStyleToWindowSize( breakpoint ) {
		viewportwidth = $(window).width();
		if (viewportwidth > breakpoint ) {
			$('.sidebox').draggable();
			$('.sidebox').draggable( 'destroy' );
			$('.sidebox').css('top','72px');
		}else{
			$('.sidebox').draggable();
		}
}
$(document).ready(function(){
	fitStyleToWindowSize( 788 );
	window.onresize = function(event) { fitStyleToWindowSize( 788 ); }
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 64) { // Wenn 64 Pixel gescrolled wurde
				$('.sidebar_head').addClass('sidebar_head-decoration');
			} else {
				$('.sidebar_head').removeClass('sidebar_head-decoration');
			}
			
			if ($(this).scrollTop() > ( $(window).height() / 1.5 ) ) {
			// Wenn 100 Pixel gescrolled wurde 
 				$('.sidebox').removeClass('sidebox-fix').addClass('sidebox-abs');
 				$('.sidebox-vSpace').css('height', $(window).height() / 1.5 );
				$('.hamburger').addClass('condition-big').addClass('removable');
			} else { // wenn am Anfang der Seite UND grosses Fenster verberge Hamburger
 				$('.sidebox').removeClass('sidebox-abs').addClass('sidebox-fix');
 				$('.sidebox-vSpace').css('height', 0 );
				$('.hamburger').removeClass('condition-big').removeClass('removable');
			}
			
			if ($(this).scrollTop() > 100 ) {
			// Wenn 100 Pixel gescrolled wurde zeige Hamburger
 				$('.scrollview').removeClass('noscroll');
			} else { // wenn am Anfang der Seite verberge Hamburger
				$('.scrollview').addClass('noscroll');
			}
		});
	});
	
	$( '.hamburger' ).click(function(){ 
		$('.clickview').toggleClass('removable');
	})
	
});
function showFeTeaser() {
	var delaytime = 3000;
	var durationtime = 500;
	$('BODY').css('backgroundImage','none');
 	$('#container_wrap').fadeOut(0);
	$('#container').prepend(
		'<div id="teaser_box" style="position:absolute;z-index:99;top:0;top:-10px;left:8;"><img id="teaser_img" src="typo3conf/ext/mffdesign/Resources/Public/images/teaser/' + getFeRandomImage() + '" height="1400px" width="1400px" /></div>'
	);
	setTimeout(function(){
		var div = $('#teaser_box');
		div.fadeOut((durationtime )); 
		$({
			z: 40
		}).animate({
			z: 20
		}, {
			step: function() {
				div.css('zIndex', ~~this.z);
			},
			duration:durationtime
		});		
	}, delaytime);

	setTimeout(function(){ $('#container_wrap').fadeIn( ( delaytime + (durationtime) ) ); }, durationtime );
	setTimeout(function(){
			$('BODY').css('backgroundImage','/typo3conf/ext/mffdesign/Resources/Public/images/design/blackboard_sfgz.jpg');
	}, durationtime );
}
function getFeRandomImage() {
    var imgAr = getTeaserImages();
	var num = Math.floor( Math.random() * imgAr.length );
    var img = imgAr[ num ];
    return img;
}
