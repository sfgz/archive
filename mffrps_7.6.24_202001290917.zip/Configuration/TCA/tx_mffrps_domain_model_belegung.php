<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung',
		'label' => 'belegungstext',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'belegungstext,zusatztext,datum,ab,bis,betrag,status,bel_zimmer,anlass,crdate,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffrps') . 'Resources/Public/Icons/tx_mffrps_domain_model_belegung.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'belegungstext, zusatztext, datum, ab, bis, betrag, status, bel_zimmer,anlass,crdate',
	),
	'types' => array(
		'1' => array('showitem' => 'belegungstext, zusatztext, datum, ab, bis, betrag, status, bel_zimmer,anlass,crdate, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'belegungstext' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.belegungstext',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'zusatztext' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.zusatztext',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 3,
				'eval' => 'trim'
			)
		),
		'datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'required,date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'ab' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.ab',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'bis' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.bis',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'betrag' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.betrag',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'status' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.status',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('definitiv', 1),
					array('provisorisch', 0),
					array('unverschiebbar', 2),
				),
				'size' => 1,
				'maxitems' => 1,
				'eval' => ''
			),
		),
		'editor' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.editor',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array( array('waehlen', 0) ),
			),
		),
		'bel_zimmer' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_belegung.bel_zimmer',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array(
					array('waehlen', 0),
				),
			),
		),
		'crdate' => array(
			'exclude' => 0,
			'label' => 'crdate',
			'config' => array(
				'type' => 'none',
				'format' => 'date',
				'eval' => 'date',
			)
		),
		
		'import_uid' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'anlass' => array(
			'config' => array(
				'type' => 'passthrough',
				'eval' => 'required'
			),
		),
		'tstamp' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);