<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter',
		'label' => 'kurz',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'kurz,anrede,name,strasse_nr,plz_ort,rechnungsadresse,email,telefon,telefax,intern,verstecken,mtr_anlass,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffrps') . 'Resources/Public/Icons/tx_mffrps_domain_model_mieter.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'kurz, anrede, name, strasse_nr, plz_ort, rechnungsadresse, email, telefon, telefax, intern, verstecken, mtr_anlass',
	),
	'types' => array(
		'1' => array('showitem' => 'kurz, anrede, name, strasse_nr, plz_ort, rechnungsadresse, email, telefon, telefax, intern, verstecken, mtr_anlass, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'kurz' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.kurz',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'anrede' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.anrede',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('Firma', 0),
					array('Fr.', 1),
					array('Hr.', 2),
				),
				'size' => 1,
				'maxitems' => 1,
				'eval' => ''
			),
		),
		'name' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.name',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'strasse_nr' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.strasse_nr',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'plz_ort' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.plz_ort',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'rechnungsadresse' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.rechnungsadresse',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 3,
				'eval' => 'trim'
			),
		),
		'email' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.email',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'telefon' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.telefon',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'telefax' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.telefax',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'intern' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.intern',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'verstecken' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.verstecken',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'mtr_anlass' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_mieter.mtr_anlass',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffrps_domain_model_anlass',
				'foreign_field' => 'mieter',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		
		'import_uid' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);