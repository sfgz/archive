<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme',
		'label' => 'timetable',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'timetable,datum,aus_zimmer,zeit_ab,zeit_bis,neu_zimmer,neu_zeit_ab,neu_zeit_bis,info_datum,info_person,ausnahmetext,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffrps') . 'Resources/Public/Icons/tx_mffrps_domain_model_ausnahme.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'timetable,datum, aus_zimmer, zeit_ab, zeit_bis, neu_zimmer, neu_zeit_ab, neu_zeit_bis, info_datum, info_person, ausnahmetext',
	),
	'types' => array(
		'1' => array('showitem' => 'timetable,datum, aus_zimmer, zeit_ab, zeit_bis, neu_zimmer, neu_zeit_ab, neu_zeit_bis, info_datum, info_person, ausnahmetext, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'timetable' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.timetable',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'int,required'
			),
		),
		'datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date,required',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'zeit_ab' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.zeit_ab',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'trim,required'
			),
		),
		'zeit_bis' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.zeit_bis',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'trim,required'
			),
		),
		'aus_zimmer' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.aus_zimmer',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'minitems' => 1,
				'maxitems' => 1,
				'items' => array( array('wählen...', '') ),
				'eval' => 'required'
			),
		),
		'neu_zimmer' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.neu_zimmer',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array( array('kein Ersatz', 0) ),
			),
		),
		'neu_zeit_ab' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.neu_zeit_ab',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'trim'
			),
		),
		'neu_zeit_bis' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.neu_zeit_bis',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'trim'
			),
		),
		'ausnahmetext' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.ausnahmetext',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'info_datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.info_datum',
			'config' => array(
				'dbType' => 'datetime',
				'type' => 'input',
				'size' => 12,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => '0000-00-00 00:00:00'
			),
		),
		'info_person' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_ausnahme.info_person',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array( array('wählen...', 0) ),
			),
		),
		'import_uid' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		
	),
);