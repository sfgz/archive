<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass',
		'label' => 'verwendungszweck',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'verwendungszweck,kontakt_person,kontakt_anrede,kontakt_email,kontakt_telefon,bemerkungen,zuschlag_betrag,zuschlag_text,gesuch_datum,schulleitung_kurz,schulleitung_datum,rechnungs_datum,catering_text,verstecken,anl_belegung,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffrps') . 'Resources/Public/Icons/tx_mffrps_domain_model_anlass.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'verwendungszweck, kontakt_person, kontakt_anrede, kontakt_email, kontakt_telefon, bemerkungen, zuschlag_betrag, zuschlag_text, gesuch_datum, schulleitung_kurz, schulleitung_datum, rechnungs_datum, catering_text, verstecken, anl_belegung',
	),
	'types' => array(
		'1' => array('showitem' => 'verwendungszweck, kontakt_person, kontakt_anrede, kontakt_email, kontakt_telefon, bemerkungen, zuschlag_betrag, zuschlag_text, gesuch_datum, schulleitung_kurz, schulleitung_datum, rechnungs_datum, catering_text, verstecken, anl_belegung, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'verwendungszweck' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.verwendungszweck',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kontakt_person' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.kontakt_person',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kontakt_anrede' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.kontakt_anrede',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kontakt_email' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.kontakt_email',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kontakt_telefon' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.kontakt_telefon',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'bemerkungen' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.bemerkungen',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'zuschlag_betrag' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.zuschlag_betrag',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'trim'
			)
		),
		'zuschlag_text' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.zuschlag_text',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'gesuch_datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.gesuch_datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'schulleitung_kurz' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.schulleitung_kurz',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'schulleitung_datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.schulleitung_datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'rechnungs_datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.rechnungs_datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'catering_text' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.catering_text',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'verstecken' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.verstecken',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'anl_belegung' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_anlass.anl_belegung',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffrps_domain_model_belegung',
				'foreign_field' => 'anlass',
				'foreign_sortby' => 'datum,bel_zimmer,ab',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		
		'crdate' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'import_uid' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'mieter' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		'tstamp' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);