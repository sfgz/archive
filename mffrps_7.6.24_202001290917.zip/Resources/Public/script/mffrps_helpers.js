function belegunlistEdit(  ) {
	$('.editsubject').css('display','none');
	if( $('#editfield').val() >= 1 ){
	    $('.editcheck').css('display','inline');
	    $('.f_' + $('#editfield option:selected').text()).css('display','inline');
	}else{
	    $('.editcheck').css('display','none');
	}
}
function toggleCheck( obj ) {
      $(obj).each(function() {
	if(this.checked==true) {
	  this.checked=false;
	}else{
	  this.checked=true;
	}
      });
}

function sendFromLink(URL , formular){
      location.href= getLinkFromUrl(URL , formular);
}

function getLinkFromUrl(URL , formular){
      var output = '';
      if (formular === undefined) formular = "sysoptions";
      $('#' + formular + ' input[type=text]').each(function(){
	var input = $(this);
	output = output + '&' + input.attr('name') + '=' + input.val();
      });
      $('#' + formular + ' input[type=hidden]').each(function(){
	var input = $(this);
	if(input.attr('class')=='filter' ){
	      output = output + '&' + input.attr('name') + '=' + input.val();
	}
      });
      $('#' + formular + ' select').each(function(){
	var input = $(this);
	output = output + '&' + input.attr('name') + '=' + input.val();
      });
      return URL + output ;
}

function decodeEntities(encodedString) {
    var textArea = document.createElement('textarea');
    textArea.innerHTML = encodedString;
    return textArea.value;
}
  
function askAjax(url, message , parent_id ) {
  question = window.confirm( '«' + message + '» wirklich löschen?...' ); 
  if(question) { return callHtml( url , parent_id ); }
}
function callHtml( URL , parent_id ) {
      $( '#' + parent_id ).addClass('sliced-text');
      $.ajax({
	  url : URL,
	  type : 'GET',
	  cache: false,
	  dataType: "html",
	  success: function(data) {              
	      $( '#' + parent_id ).fadeOut(3000);
	  },
	  error : function(request,error)
	  {
	      alert("Request " + error + ": " + request + " " + URL);
	  }
      });
}
  
  
function callJson( URL , fieldname , obj ) {
      var parent_id = $(obj).parent().attr('id');
      var classname = $(obj).attr('class');
      var val = classname.split('_');
      if( val[1] == 0 ){ var newValue = 1; }else{ var newValue = 0; }
      var arr = parent_id.split('_');
      $.ajax({
	  url : URL,
	  type : 'GET',
	  data : {
	      'table' : arr[0] ,
	      'uid' : arr[1] ,
	      'fieldName' : fieldname ,
	      'newValue' : newValue
	  },
	  dataType:'html',
	  success : function(data) {              
	      if( data == newValue ){
		$(obj).toggleClass( fieldname + '_').toggleClass( fieldname + '_1');
	      }
	  },
	  error : function(request,error)
	  {
	      alert("Request " + error + ": "+JSON.stringify(request));
	  }
      });
}