<!-- JS for tx_mffrps_rpsopt-1477704885-->

window.name='hauptfenster';  

$( tagesansichtBindings );

function tagesansichtBindings() {
    $('.blank').droppable( { drop: handleDropEvent } );
    $('.dc').droppable( { drop: handleDropEvent } );
    
    $('.bel_label').mousedown(function(){ $(this).css('position', 'relative').css('z-index','100'); });
    $('.bel_label').mouseup(function(){ $(this).css('position', 'relative').css('z-index','50'); });
    
    $('.bel_label').css( 'cursor', 'pointer' );
    $('.bel_label').children().css( 'cursor', 'pointer' );
  
    $('DIV.tagesansicht .belZimmer').children().css( 'cursor', 'pointer' );
    $('DIV.tagesansicht .belZimmer').css( 'cursor', 'pointer' ).on('click', function() {
	  var parent_id = $(this).attr('id');
	  var geo = $('#wingeo_zimmer').attr('value').split(',');
	  return popUpRawUrl( parent_id , $('#url_zimmer_view').attr('value') , 'zimmerWinBelegung',geo[0],geo[1],geo[2],geo[3] );
    });
    
    $('DIV.tagesansicht .zmrEdit').hover(
	function(){ $(this).css("color", "#AAA"); }, 
	function(){ $(this).css("color", "#000"); }
    );
    $('DIV.tagesansicht .zmrEdit').children().css( 'cursor', 'pointer' );
    $('DIV.tagesansicht .zmrEdit').css( 'cursor', 'pointer' ).on('click', function() {
	  var parent_id = $(this).attr('id');
	  var splitted = parent_id.split('_');
	  var geo = $('#wingeo_editzimmer').attr('value').split(',');
	  return popUpRawUrl( parent_id, $('#url_zimmer_edit').attr('value'),splitted[0] + 'WinZimmer',geo[0],geo[1],geo[2],geo[3]);
    });
    
    $('DIV.tagesansicht .blank').css( 'cursor', 'pointer' ).on('click', function() {
	  var parent_id = $(this).attr('id');
	  var aTime = $( '#' + parent_id ).attr('title').split('-');
	  var arr = parent_id.split('_');
	  var geo = $('#wingeo_belegung').attr('value').split(',');
	  var url = $('#url_belegung_create').attr('value').replace( '_REP_ZUZMR_' , arr[0] ).replace( '_REP_AB_' , aTime[0] ).replace( '_REP_BIS_' , aTime[1] );
	  return popUp( url , 'belegungWinBelegung',geo[0],geo[1],geo[2],geo[3] );
    });
	  
    $('DIV.tagesansicht .bel.bel_label').draggable().click(function(){
	  if ( $(this).is('.ui-draggable-dragging') ) { return; }
	  var arr = $(this).attr('id').split('_');
	  var geo = $('#wingeo_belegung').attr('value').split(',');
	  var url = $('#url_belegung_open').attr('value').replace( '_REP_UID_' , arr[4] );
	  return popUp( url , 'belegungWinBelegung',geo[0],geo[1],geo[2],geo[3] );
    });
    
    $('DIV.tagesansicht .aus.bel_label').draggable().click(function(){
	  if ( $(this).is('.ui-draggable-dragging') ) {return;}
	  var parent_id = $(this).attr('id');
	  var arr = parent_id.split('_');
	  var geo = $('#wingeo_ausnahme').attr('value').split(',');
	  var url = $('#url_ausnahme_open').attr('value').replace( '_REP_UID_' , arr[4] );
	  return popUp( url , 'ausnahmeWinAusnahme',geo[0],geo[1],geo[2],geo[3] );
    });

    $('DIV.tagesansicht .tt.bel_label').draggable().click(function(){
	    if ( $(this).is('.ui-draggable-dragging') ) {return;}
	    var parent_id = $(this).attr('id');
	    var arr = parent_id.split('_');
	    var geo = $('#wingeo_ausnahme').attr('value').split(',');
	    var url = $('#url_ausnahme_create').attr('value').replace( '_REP_ZUZMR_' , arr[0] ).replace( '_REP_AUSZMR_' , arr[0] ).replace( '_REP_AB_' , arr[1] ).replace( '_REP_BIS_' , arr[2] ).replace( '_REP_UID_' , arr[4] );
	    return popUp( url , 'ausnahmeWinAusnahme',geo[0],geo[1],geo[2],geo[3] );
      });
}



function handleDropEvent( event, ui ) {
	
	var aDrag = ui.draggable.attr('id').split('_');
	var aDrop = $(this).attr('id').split('_');
	
	var typeDrag = aDrag[3];
	var typeDrop = aDrop[3];
	var zmrDrag = aDrag[0];
	var zmrDrop = aDrop[0];
	var startTimeDrag = aDrag[1];
	var endTimeDrag = aDrag[2];
	var dragged_uid = aDrag[4];
	
	if( typeDrop == 'blk'){
	      var aTimeDrop = $( '#' + $(this).attr('id') ).attr('title').split('-');
	      var startTimeDrop = aTimeDrop[0];
	      var endTimeDrop = aTimeDrop[1];
	}else{
	      var startTimeDrop = aDrop[1];
	      var endTimeDrop = aDrop[2];
	}
	
	var startHowerDrag = startTimeDrag.split(':');
	var startHowerDrop = startTimeDrop.split(':');
	
	if( zmrDrag != zmrDrop && startHowerDrag[0] == startHowerDrop[0] ){
	    // target is in same hower as dragged element but not in the same room
	    // assume value from dragged element
	    var timeOptFrom =  startTimeDrag;
	    var timeOptTo =  endTimeDrag;
	}else{
	    // target is in different time and maybe in different room: 
	    // assume start-value from dropped cell
	    // compute endValue from dragged TimeValues
	    var timeOptFrom =  startTimeDrop;
	    var endHowerDrag = endTimeDrag.split(':');
	    var minutenStartDrag = ( parseInt( startHowerDrag[0] * 60 ) + parseInt(startHowerDrag[1]) );
	    var minutenEndDrag = ( parseInt( endHowerDrag[0] * 60 ) + parseInt(endHowerDrag[1]) );
	    var minutenDiff = minutenEndDrag - minutenStartDrag;
	    var minutenStartDrop = parseInt( startHowerDrop[0] * 60 ) + parseInt(startHowerDrop[1]);
	    var minutenEndNewDrop = minutenStartDrop + minutenDiff;
	    var timeOptTo = Math.floor( minutenEndNewDrop / 60 ) + ':' + ( minutenEndNewDrop % 60 ) ;
	}
	
	switch (typeDrag) {
	      case 'bel':
		    var rawUrl = $( '#url_belegung_edit' ).attr('value');
		    var url = rawUrl.replace( '_REP_ZUZMR_' , zmrDrop ).
			replace( '_REP_AB_' , timeOptFrom ).
			replace( '_REP_BIS_' , timeOptTo ).
			replace( '_REP_MINUTES_' , minutenDiff ).
			replace( '_REP_UID_' , dragged_uid );
		    break;
	      case 'aus':
		    var rawUrl = $( '#url_ausnahme_edit' ).attr('value');
		    var url = rawUrl.replace( '_REP_UID_' , dragged_uid ).
			replace( '_REP_ZUZMR_' , zmrDrop );
		    break;
	      case 'tt':
		    var rawUrl = $( '#url_ausnahme_create' ).attr('value');
		    var url = rawUrl.replace( '_REP_ZUZMR_' , zmrDrop ).
			replace( '_REP_AUSZMR_' , zmrDrag ).
			replace( '_REP_UID_' , dragged_uid );
		    break;
	      default:
		    return;
	}
	
	openPopupWindow( url , typeDrag );
	return true;
}

<!-- END JS for tx_mffrps_rpsopt-1477704885 -->
