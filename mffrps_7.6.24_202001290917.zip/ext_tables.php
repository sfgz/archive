<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'Rpsopt',
	'Raumplanung'
);

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'Aushang',
	'Aushang Zimmer'
);

$pluginSignature = str_replace('_','',$_EXTKEY) . '_aushang';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $_EXTKEY . '/Configuration/FlexForms/flexform_aushang.xml');

// $pluginSignature = str_replace('_','',$_EXTKEY) . '_rpsopt';
// $GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
// \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $_EXTKEY . '/Configuration/FlexForms/flexform_rpsopt.xml');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'mff Raumplanung');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_sysoptions', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_sysoptions.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_mieter', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_mieter.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_anlass', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_anlass.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_belegung', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_belegung.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_ausnahme', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_ausnahme.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffrps_domain_model_antrag', 'EXT:mffrps/Resources/Private/Language/locallang_csh_tx_mffrps_domain_model_antrag.xlf');


// Add the external_import information to the ctrl section
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'sql',
		'parameters' => array(
			'driver' => 'mysqli',
			'server' => '193.33.128.207',
			'database' => 'wirker_t3b',
			'user' => 'wirker_daru',
			'password' => '1gdrasil',
			'init' => 'SET NAMES utf8',
			'fetchMode' => '2',
			'query' => 'SELECT * FROM tx_mffrps_domain_model_mieter'
		),
		'data' => 'array',
		'referenceUid' => 'import_uid',
		'pid' => '18',
		'enforcePid' => TRUE,
		'priority' => 2010,
		'description' => 'Importiert Mieter von Live-DB connector:sql'
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['import_uid']['external'] = array(
	0 => array( 'field' => 'uid' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['kurz']['external'] = array(
	0 => array( 'field' => 'kurz' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['anrede']['external'] = array(
	0 => array( 'field' => 'anrede' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['name']['external'] = array(
	0 => array( 'field' => 'name' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['strasse_nr']['external'] = array(
	0 => array( 'field' => 'strasse_nr' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['plz_ort']['external'] = array(
	0 => array( 'field' => 'plz_ort' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['email']['external'] = array(
	0 => array( 'field' => 'email' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['telefon']['external'] = array(
	0 => array( 'field' => 'telefon' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['telefax']['external'] = array(
	0 => array( 'field' => 'telefax' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_mieter']['columns']['rechnungsadresse']['external'] = array(
	0 => array( 'field' => 'rechnungsadresse' )
);


$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'sql',
		'parameters' => array(
			'driver' => 'mysqli',
			'server' => '193.33.128.207',
			'database' => 'wirker_t3b',
			'user' => 'wirker_daru',
			'password' => '1gdrasil',
			'init' => 'SET NAMES utf8',
			'fetchMode' => '2',
			'query' => 'SELECT * FROM tx_mffrps_domain_model_anlass'
		),
		'data' => 'array',
		'referenceUid' => 'import_uid',
		'pid' => '18',
		'enforcePid' => TRUE,
		'priority' => 2020,
		'disabledOperations' => 'delete',
		'description' => 'Importiert Anlass von Live-DB connector:sql'
	)
);

$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['import_uid']['external'] = array(
	0 => array( 'field' => 'uid' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['crdate']['external'] = array(
	0 => array( 'field' => 'crdate' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['tstamp']['external'] = array(
	0 => array( 'field' => 'tstamp' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['verwendungszweck']['external'] = array(
	0 => array( 'field' => 'verwendungszweck' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['kontakt_person']['external'] = array(
	0 => array( 'field' => 'kontakt_person' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['kontakt_email']['external'] = array(
	0 => array( 'field' => 'kontakt_email' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['kontakt_telefon']['external'] = array(
	0 => array( 'field' => 'kontakt_telefon' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['schulleitung_kurz']['external'] = array(
	0 => array( 'field' => 'schulleitung_kurz' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['schulleitung_datum']['external'] = array(
	0 => array( 
	    'field' => 'schulleitung_datum'
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['bemerkungen']['external'] = array(
	0 => array( 'field' => 'bemerkungen' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['rechnungs_datum']['external'] = array(
	0 => array( 'field' => 'rechnungs_datum'
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['catering_text']['external'] = array(
	0 => array( 'field' => 'catering_text' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['zuschlag_betrag']['external'] = array(
	0 => array( 'field' => 'zuschlag_betrag' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['zuschlag_text']['external'] = array(
	0 => array( 'field' => 'zuschlag_text' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_anlass']['columns']['mieter']['external'] = array(
	0 => array(
		'field' => 'mieter',
		'mapping' => array(
			'table' => 'tx_mffrps_domain_model_mieter',
			'reference_field' => 'import_uid'
		)
	)
);

$sqlFields = 'tx_mffrps_domain_model_belegung.uid AS uid,datum,ab,bis,belegungstext,zusatztext,betrag,status,editor,anlass';
$zimmerJoin = ' LEFT JOIN tx_mffdb_domain_model_zimmer ON tx_mffrps_domain_model_belegung.bel_zimmer=tx_mffdb_domain_model_zimmer.uid';
// $userJoin = ' LEFT JOIN fe_users ON tx_mffrps_domain_model_belegung.editor=fe_users.uid';

$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'sql',
		'parameters' => array(
			'driver' => 'mysqli',
			'server' => '193.33.128.207',
			'database' => 'wirker_t3b',
			'user' => 'wirker_daru',
			'password' => '1gdrasil',
			'init' => 'SET NAMES utf8',
			'fetchMode' => '2',
			'query' => 'SELECT tx_mffdb_domain_model_zimmer.location_key AS location_key,'.$sqlFields.' FROM tx_mffrps_domain_model_belegung' . $zimmerJoin
		),
		'data' => 'array',
		'referenceUid' => 'import_uid',
		'pid' => '18',
		'enforcePid' => TRUE,
		'priority' => 2030,
		'disabledOperations' => '',
		'description' => 'Importiert Belegung von Live-DB connector:sql'
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['import_uid']['external'] = array(
	0 => array( 'field' => 'uid' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['datum']['external'] = array(
	0 => array( 'field' => 'datum')
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['ab']['external'] = array(
	0 => array( 'field' => 'ab' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['bis']['external'] = array(
	0 => array( 'field' => 'bis' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['belegungstext']['external'] = array(
	0 => array( 'field' => 'belegungstext' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['zusatztext']['external'] = array(
	0 => array( 'field' => 'zusatztext' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['betrag']['external'] = array(
	0 => array( 'field' => 'betrag' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['status']['external'] = array(
	0 => array( 'field' => 'status' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['anlass']['external'] = array(
	0 => array(
		'field' => 'anlass',
		'mapping' => array(
			'table' => 'tx_mffrps_domain_model_anlass',
			'reference_field' => 'import_uid'
		)
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_belegung']['columns']['bel_zimmer']['external'] = array(
	0 => array(
		'field' => 'location_key',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_zimmer',
			'reference_field' => 'location_key'
		)
	)
);

$selectFields = ' ausnahme.*,fe_users.username AS infoPersonUsername,zmr_aus.location_key AS locationKeyAus, zmr_neu.location_key AS locationKeyNeu';
$selectTable  = ' FROM tx_mffrps_domain_model_ausnahme ausnahme';
$selectJoinAus  = ' LEFT JOIN tx_mffdb_domain_model_zimmer zmr_aus ON ausnahme.aus_zimmer=zmr_aus.uid ';
$selectJoinNeu  = ' LEFT JOIN tx_mffdb_domain_model_zimmer zmr_neu ON ausnahme.neu_zimmer=zmr_neu.uid';
$selectJoinUser = ' LEFT JOIN fe_users ON ausnahme.info_person=fe_users.uid';

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'sql',
		'parameters' => array(
			'driver' => 'mysqli',
			'server' => '193.33.128.207',
			'database' => 'wirker_t3b',
			'user' => 'wirker_daru',
			'password' => '1gdrasil',
			'init' => 'SET NAMES utf8',
			'fetchMode' => '2',
			'query' => 'SELECT ' . $selectFields . $selectTable . $selectJoinAus . $selectJoinNeu . $selectJoinUser
		),
		'data' => 'array',
		'referenceUid' => 'import_uid',
		'pid' => '18',
		'enforcePid' => TRUE,
		'priority' => 2040,
		'disabledOperations' => '',
		'description' => 'Importiert Belegung von Live-DB connector:sql'
	)
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['import_uid']['external'] = array(
	0 => array( 'field' => 'uid' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['datum']['external'] = array(
	0 => array( 'field' => 'datum')
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['zeit_ab']['external'] = array(
	0 => array( 'field' => 'zeit_ab' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['zeit_bis']['external'] = array(
	0 => array( 'field' => 'zeit_bis' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['neu_zeit_ab']['external'] = array(
	0 => array( 'field' => 'neu_zeit_ab' )
);
$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['neu_zeit_bis']['external'] = array(
	0 => array( 'field' => 'neu_zeit_bis' )
);

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['info_datum']['external'] = array(
	0 => array( 'field' => 'info_datum' )
);

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['ausnahmetext']['external'] = array(
	0 => array( 'field' => 'ausnahmetext' )
);

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['info_person']['external'] = array(
	0 => array(
		'field' => 'infoPersonUsername',
		'mapping' => array(
			'table' => 'fe_users',
			'reference_field' => 'username'
		)
	)
);

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['aus_zimmer']['external'] = array(
	0 => array(
		'field' => 'locationKeyAus',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_zimmer',
			'reference_field' => 'location_key'
		)
	)
);

$GLOBALS['TCA']['tx_mffrps_domain_model_ausnahme']['columns']['neu_zimmer']['external'] = array(
	0 => array(
		'field' => 'locationKeyNeu',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_zimmer',
			'reference_field' => 'location_key'
		)
	)
);


