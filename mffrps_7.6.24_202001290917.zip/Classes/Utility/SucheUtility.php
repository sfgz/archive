<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SucheUtility
 */

class SucheUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;


	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->initializeAction();
	}
	
	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
	}

	/**
	* sucheLeereZimmer
	*
	* @param array $aFilteredRooms
	* @param array $aFilter
	* @return array
	*/
	public function sucheLeereZimmer( $aFilteredRooms , $aFilter ) {
	
		if($aFilter['date'] == $aFilter['todate']){
		      $aRoomsData = $this->sucheZimmer( $aFilteredRooms , $aFilter['date'] , $aFilter['date'] , 86400 );
		
		}elseif($aFilter['all_days']){
		      $aRoomsData = $this->sucheZimmer( $aFilteredRooms , $aFilter['date'] , $aFilter['todate'] , 86400 );
		
		}else{
		      $aRoomsData = $this->sucheZimmer( $aFilteredRooms , $aFilter['date'] , $aFilter['todate'] , 7*86400 );
		}
		
		$emptyRoomsData = $this->entferneBelegteZimmer($aRoomsData , $aFilter );
		
		if( $aFilter['same_room'] && count($emptyRoomsData) > 1 ){
		    $emptyRoomsData = $this->entferneEinzelzimmerBeiSerienbelegung($emptyRoomsData , $aFilter );
		}
		
		return $emptyRoomsData;
	}

	/**
	* sucheZimmer
	*
	* @param array $aFilteredRooms
	* @param int $date
	* @param int $todate
	* @return array
	*/
	public function sucheZimmer( $aFilteredRooms , $date , $todate , $iteration ) {
		$aRoomsData = array();
		// search for every day in timerange
		for($loopDay=$date;$loopDay <= $todate; $loopDay+= $iteration){
		      $zmrResObj = $this->dbHelperUtility->mkArrTimetableByRoomAndDate( $aFilteredRooms , $loopDay , array() );
		      $zmrResObj = $this->dbHelperUtility->mkArrAusnahmeByRoomAndDate( $aFilteredRooms , $loopDay , $zmrResObj );
		      $zmrResObj = $this->dbHelperUtility->mkArrBelegungByRoomAndDate( $aFilteredRooms , $loopDay , $zmrResObj );
		      $idx = date('d.m.y' , $loopDay );
		      foreach($aFilteredRooms as $zId=>$zmr){
			  $aRoomsData[$idx][$zId]['zmr']=$zmr->getHaus() . ' ' . $zmr->getZimmer();
			  $aRoomsData[$idx][$zId]['besonderes']=$zmr->getBesonderes();
			  $aRoomsData[$idx][$zId]['date']=$loopDay;
			  if(isset($zmrResObj[$zId]))$aRoomsData[$idx][$zId]['data']=$zmrResObj[$zId];
		      }
		}
		return $aRoomsData;
	}

	/**
	* sucheLeereZimmer
	*
	* @param array $aRoomsData
	* @param array $aFilter
	* @return array
	*/
	public function entferneBelegteZimmer( $aRoomsData , $aFilter ) {
		$calendarObj = $this->dbHelperUtility->mkArrHolidayByDates( $aFilter );
		foreach( $aRoomsData as $dateIdx => $dateRooms ){
		      $holiday = $calendarObj[$dateIdx];
		      foreach( $dateRooms as $roomIdx => $dayRoom ){
			  if( isset($dayRoom['data']) ){
				foreach( $dayRoom['data'] as $occId => $occupation ){
				      if($occupation['status'] == 104 || $occupation['status'] == 103){
					    // timetable status == 104 verschoben(frei) OR ausnahme status == 103 (kein Ersatz)
					    // room is set to free if no bel
					    unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
				      }elseif( $occupation['type'] == 'timetable' ){ 
					    // status == 101 normal(bes) , status == 105 conflict(bes)
					    // raum ist besetzt, dies kann aber annuliert werden 
					    // durch Ferien (wenn nicht ignore_vacation in fach definiert) 
					    // oder durch termin-Grundbildung  (wenn nicht ignore_holiday in fachbereich definiert)
					    
					    $numAb = str_replace( ':' , '.' , $occupation['ab'] );
					    $numBis = str_replace( ':' , '.' , $occupation['bis'] );
					    $istGrundbildungFrei = empty($occupation['ignore_holiday']) &&  $holiday['from'] <= $aFilter['howerFrom'] ? 1 : 0;
					    $istWeiterbildungFrei = !empty($occupation['ignore_holiday']) && $holiday['AllFrom'] <= $aFilter['howerFrom'] ? 1 : 0;
					    $istFreiUndFachIgnoriertDasNicht =  isset($holiday['from']) && empty($occupation['ignore_vacation']) ? 1 : 0;
					    if( ( $istGrundbildungFrei  || $istWeiterbildungFrei ) && $istFreiUndFachIgnoriertDasNicht ){ 
						 unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
					    }else{
						if( $numBis > $aFilter['howerFrom'] && $numAb < $aFilter['howerTo'] ) {
						      unset($aRoomsData[$dateIdx][$roomIdx]);// unset whole room
						      break; 
						}elseif( $numBis <= $aFilter['howerFrom'] ){
						      // if not holiday but timetable before search-time, store for Information
						     $aRoomsData[$dateIdx][$roomIdx]['infoPrologue'][$occId] = $aRoomsData[$dateIdx][$roomIdx]['data'][$occId];
						     unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
						}elseif( $numAb >= $aFilter['howerTo'] ){
						      // if not holiday but timetable after search-time, store for Information
						     $aRoomsData[$dateIdx][$roomIdx]['infoEpilogue'][$occId] = $aRoomsData[$dateIdx][$roomIdx]['data'][$occId];
						     unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
						}
					    }
				      }elseif( $occupation['type'] == 'bel' ){
					    // store for display if option selected
					    $numAb = str_replace( ':' , '.' , $occupation['ab'] );
					    $numBis = str_replace( ':' , '.' , $occupation['bis'] );
					    if( $numBis > $aFilter['howerFrom'] && $numAb < $aFilter['howerTo'] ) $aRoomsData[$dateIdx][$roomIdx]['bel'][$occId] = $occupation;
					    unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
				      }else{ //  $occupation['type'] == 'ausnahme' && $occupation['status'] == 102
					    // room is occupied
					    $numAb = str_replace( ':' , '.' , $occupation['ab'] );
					    $numBis = str_replace( ':' , '.' , $occupation['bis'] );
					    if( $numBis <= $aFilter['howerFrom'] || $numAb >= $aFilter['howerTo'] ) {
						  unset($aRoomsData[$dateIdx][$roomIdx]['data'][$occId]);
					    }else{ // unset whole room
						  unset($aRoomsData[$dateIdx][$roomIdx]);
						  break;
					    }
				      }
				}
				if(!count($aRoomsData[$dateIdx][$roomIdx]['data'])) {
				    unset($aRoomsData[$dateIdx][$roomIdx]['data']);
				}
				// eliminate obsolete timetable info entries
				if( count($aRoomsData[$dateIdx][$roomIdx]['infoPrologue']) > $aFilter['suche_showplan_info_deep'] ){
				    $diff = count($aRoomsData[$dateIdx][$roomIdx]['infoPrologue']) - $aFilter['suche_showplan_info_deep'];
				    $aRoomsData[$dateIdx][$roomIdx]['infoPrologue'] = array_slice( $aRoomsData[$dateIdx][$roomIdx]['infoPrologue'] , $diff , $aFilter['suche_showplan_info_deep'] );
				}
				if( count($aRoomsData[$dateIdx][$roomIdx]['infoEpilogue']) > $aFilter['suche_showplan_info_deep'] ){
				    $aRoomsData[$dateIdx][$roomIdx]['infoEpilogue'] = array_slice( $aRoomsData[$dateIdx][$roomIdx]['infoEpilogue'] , 0 , $aFilter['suche_showplan_info_deep'] );
				}
			  }
		      }
		}
		return $aRoomsData;
	}

	/**
	* entferneEinzelzimmerBeiSerienbelegung
	* bei Zimmertreu nur treue Zimmer
	*
	* @param array $aRoomsData
	* @param array $aFilter
	* @return array
	*/
	public function entferneEinzelzimmerBeiSerienbelegung( $aRoomsData , $aFilter ) {
		$zmrCount = array();
		// same-rooms test
		foreach($aRoomsData as $date=>$dayRow){
		    foreach($dayRow as $zId=>$zmrRow){
			if(!isset($zmrRow['bel'])) $zmrCount[$zId][$date]=1;
		    }
		}
		foreach($zmrCount as $zId=>$zmrDays){
		    if( count($zmrDays) < count($aRoomsData) ) {
			foreach($zmrDays as $date=>$zmrRow) {if(!isset($zmrRow['bel'])) unset($aRoomsData[$date][$zId]);}
		    }
		}
		return $aRoomsData;
	}


}
