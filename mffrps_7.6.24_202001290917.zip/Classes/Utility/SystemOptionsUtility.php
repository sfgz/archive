<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SystemOptionsUtility
 *  get values from settings.optionfields and 
 *  overwrite with values from tx_mffrps_domain_model_sysoptions 
 * 
 */

class SystemOptionsUtility {

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	protected $objectManager ;

	/**
	 * sysOptionsRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\SysOptionsRepository
	 */
	protected $sysOptionsRepository = NULL;

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
//	      $this->typoScriptUtility = new \Mff\Mffrps\Utility\TypoScriptUtility();
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $querySettings = $this->getSettings();
	      $this->sysOptionsRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\SysOptionsRepository');
	      $this->sysOptionsRepository->setDefaultQuerySettings($querySettings);
	      
	}
	
	/**
	 * getSystemOptions
	 * 
	 * @return void
	 */
	public function getSystemOptions() {
	    return $this->getOptions('optionfields');
	}
	
	/**
	 * setSystemOptions
	 * 
	 * @param array $someSettings
	 * @return array
	 */
	public function setSystemOptions( $someSettings ) {
	    if( !is_array($someSettings) )return $this->getOptions('optionfields');
	    foreach($someSettings as $option=>$value){
		  $sysoptionsRecordsets = $this->sysOptionsRepository->findByOptionKey( $option );
		  foreach($sysoptionsRecordsets as $optObj){
			  if( $this->settings['optionfields'][$option]['type'] == 'textarea' ){
			      $optObj->setTextContent( str_replace( '\n' , chr(10) , $value ) );
			  }else{
			      $optObj->setContent( $value );
			  }
			  $this->sysOptionsRepository->update($optObj);
			  ++$counter;
		  }
	    }
	    if($counter){
		$persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		$persistenceManager->persistAll();
	    }
	    return $this->getOptions('optionfields');
	}
	
	/**
	 * resetSystemOptions
	 * 
	 * @param int $category the category to reset or 0 for all SystemOptions
	 * @return void
	 */
	public function resetSystemOptions( $category=0 ) {
		$settingsOptionfields = array();
		foreach( $this->settings['optionfields'] as $sm => $optRow ){
		    $sysoptionsRecordsets = $this->sysOptionsRepository->findByOptionKey( $sm );
		    if( count($sysoptionsRecordsets) ){
			  foreach($sysoptionsRecordsets as $newCode){
			      $key = $newCode->getOptionKey();
			      if( $optRow['type'] == 'textarea' ){
				  $value = $newCode->getTextContent();
			      }else{
				  $value = $newCode->getContent();
			      }
			      break;
			  }
			  if( $optRow['category'] != $category && !empty($category) ) continue;
			  if( $optRow['value'] != $value ) $settingsOptionfields[$key]=$optRow['value'];
		    }
		}
		if(count($settingsOptionfields)) return $this->setSystemOptions($settingsOptionfields);
	}
	
	/**
	 * getUserOptions
	 * 
	 * @return array
	 */
	public function getUserOptions() {
	    $userObj = $GLOBALS['TSFE']->fe_user;
	    if( !$userObj ) return $this->settings['userfields'];
	    
	    $myData = $userObj->getKey('user', 'userfields');
	    if( count($myData) ){
		  foreach(array_keys($this->settings['userfields']) as $ix){
		      if( isset($myData[$ix]) ) $this->settings['userfields'][$ix] = $myData[$ix];
		  }
	    }
	    return $this->settings['userfields'];
	}
	
	/**
	 * resetUserOptions
	 * 
	 * @return array
	 */
	public function resetUserOptions() {
	    $userObj = $GLOBALS['TSFE']->fe_user;
	    if( !$userObj ) return $this->settings['userfields'];
	    
	    $userObj->setKey("user","userfields", '');
	    $userObj->sesData_change = true;
	    $userObj->storeSessionData();
	    return $this->settings['userfields'];
	}
	
	/**
	 * setUserOptions
	 * 
	 * @param array $someSettings
	 * @return array
	 */
	public function setUserOptions( $someSettings ) {
	      foreach(array_keys($this->settings['userfields']) as $ix){
		  if( isset($someSettings[$ix]) ) $this->settings['userfields'][$ix]['value'] = $someSettings[$ix];
	      }
	      $userObj = $GLOBALS['TSFE']->fe_user;
	      if( !$userObj ) return $this->settings['userfields'];
	      
	      $userObj->setKey("user","userfields", $this->settings['userfields']);
	      $userObj->sesData_change = true;
	      $userObj->storeSessionData();
	    return $this->settings['userfields'];
	}
	
	/**
	 * getOptions
	 * 
	 * @param string $optionname 
	 * @return array
	 */
	public function getOptions( $optionname ) {
		if(empty($optionname)) $optionname = 'optionfields';
		foreach( $this->settings[$optionname] as $sm => $optRow ){
		    $sysoptionsRecordsets = $this->sysOptionsRepository->findByOptionKey( $sm );
		    if( count($sysoptionsRecordsets) ){
			  foreach($sysoptionsRecordsets as $newCode){
			      $key = $newCode->getOptionKey();
			      if( $optRow['type'] == 'textarea' ){
				  $value = $newCode->getTextContent();
			      }else{
				  $value = $newCode->getContent();
			      }
			      break;
			  }
		    }else{
			$key = $sm;
			$value = $optRow['value'];
		    }
		    $this->settings[$optionname][$key]['value']=$value;
		}
		return $this->settings[$optionname];
	}
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	public function getSettings( ){
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$settings = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['settings.'];//['optionfields.']
		$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $settings );
		$this->settings['baseURL'] = $fullsettings['config.']['baseURL'];//['optionfields.']
		foreach( $this->settings as $mainparts => $settingFields ){
		      if(!is_array($settingFields)) continue;
		      foreach( $settingFields as $fldName => $userfield ){
			  if(!isset($userfield['anchor'])) continue;
			  $this->settings['anchor2category'][$userfield['anchor']] = $userfield['category'];
		      }
		}

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$this->settings['persistence'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.'];
		$storage['storagePid'] = $this->settings['persistence']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		return $querySettings;
	}
	/**
	 * tsToSettings
	 * translates TS-Variable to Array 
	 * by cutting the point in names
	 * eg. setting[key][name] = setting[key.][name.]
	 *
	 * @param array $settings TypoScript settings like setting[key.][name.]
	 * @return array
	 */
	public function tsToSettings( $settings ){
		$outSet = array();
		if( is_array($settings) ){
		    foreach( $settings as $k0=>$c0 ){
			  if( is_array($c0) ){
			      foreach( $c0 as $k1=>$c1 ){
				    if( is_array($c1) ){
					foreach( $c1 as $k2=>$c2 ){
					      if( is_array($c2) ){
						    foreach( $c2 as $k3=>$c3 ){
							      $outSet[rtrim( $k0 , '.' )][rtrim( $k1 , '.' )][rtrim( $k2 , '.' )][rtrim( $k3 , '.' )] = $c3;
						    }
					      }else{
						  $outSet[rtrim( $k0 , '.' )][rtrim( $k1 , '.' )][rtrim( $k2 , '.' )] = $c2;
					      }
					}
				    }else{
					$outSet[rtrim( $k0 , '.' )][rtrim( $k1 , '.' )] = $c1;
				    }
			      }
			  }else{
			      $outSet[rtrim( $k0 , '.' )] = $c0;
			  }
		    }
		}else{
		    $outSet = $settings;
		}
		return $outSet;
	}
	
	/**
	 * creates sysoptions recordsets/objects if necessary
	 * returns amount of created recordsets
	 * 
	 * @return integer
	 */
	public function lookUpForNewSystemOtions( ) {
		$counter = 0;
		foreach( $this->settings['optionfields'] as $sm => $optRow ){
		    $sysoptionsRecordsets = $this->sysOptionsRepository->findByOptionKey( $sm );
		    if( empty($sysoptionsRecordsets) || !count($sysoptionsRecordsets) ){
			  $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\SysOptions');
			  $newCode->setOptionKey( $sm );
			  if( $optRow['type'] == 'textarea' ){
			      $newCode->setTextContent( str_replace( '\n' , chr(10) , $optRow['value'] ) );
			  }else{
			      $newCode->setContent( $optRow['value'] );
			  }
			  $this->sysOptionsRepository->add($newCode);
			  ++$counter; 
		    }
		}
		return $counter;
	}
	
	/**
	 * selectOptionsHook_
	 * Hook for setSelectOptions
	 * 
	 * Creates the options lists 
	 * for input fields of type 'select'
	 * 
	 * @return void
	 */
	public function selectOptionsHook_filter_tagesplan_timerange_to( ) {
		$settings = $this->getOptions('optionfields');
		return $this->selectOptionsHook_filter_startTimeFrom( 1 , $settings['filter_startTimeFrom']['value'] , $settings['filter_maxHowers']['value'] );
	}
	public function selectOptionsHook_filter_tagesplan_timerange_from( $offset = 0 ) {
		$settings = $this->getOptions('optionfields');
		return $this->selectOptionsHook_filter_startTimeFrom( $offset , $settings['filter_startTimeFrom']['value'] , $settings['filter_maxHowers']['value'] );
	}
	public function selectOptionsHook_filter_startTimeFrom( $offset = 0 , $start = 0 , $max = 22 ) {
		for($z=0;$z<=$max;++$z){
		    $selopt[$z] = sprintf( '%02s' , $offset + $z + $start ) . ':00';
		}
		return $selopt;
	}
	
	/**
	 * setSelectOptions
	 * Creates the options lists 
	 * for input fields of type 'select'
	 * 
	 * @return void
	 */
	public function setSelectOptions() {
	      $fieldVars = array( 'userfields' , 'optionfields' );
	      foreach( $fieldVars as $cat){
		  if( !is_array($this->settings[$cat]) ) continue;
		  foreach( $this->settings[$cat] as $name=>$option){
		      if(!isset($option['type'])) continue;
		      if($option['type']!='select') continue;
		      $dedicatedMethodname = 'selectOptionsHook_' . $name;
		      if( method_exists( $this , $dedicatedMethodname ) ){
			  $this->settings[$cat][$name]['selopt'] = $this->$dedicatedMethodname();
			  continue;
		      }
		      $categories = array();
		      $switched = 0;
		      for($z=0;$z<=999;++$z){
			  $ttxt = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('options.' . $name . '.selopt.'.$z,'mffrps');
			  if( $switched > 3 && empty($ttxt)  ){ break; }
			  if( empty($ttxt)  ){ ++$switched; continue; }
			  $this->settings[$cat][$name]['selopt'][$z] = $ttxt;
		      }
		  }
	      }
	}
	
	/**
	 * create a array of files 
	 *
	 * @param string $path
	 * @param string $suffix
	 * @param string $name
	 * @return int
	 */
	public function readInDir( $path , $suffix='' , $name='' ) {
		$d = dir( $path );
		$filelist = array();
		if(!empty($suffix)){
		     $aSfx = explode( ',' , $suffix);
		     foreach($aSfx as $sfx){ $goodSuffix[ strtolower(trim($sfx)) ] = 1; }
		     while (false !== ($entry = $d->read())) {
			    if( $entry == '.' || $entry == '..' ) continue;
			    $filename = pathinfo($entry , PATHINFO_FILENAME);
			    $extension = strtolower(pathinfo($entry , PATHINFO_EXTENSION));
			    if( isset($goodSuffix[ $extension ]) ){
				$filelist[$entry] = $filename;
			    }
		      }
		}elseif(!empty($name)){
		      while (false !== ($entry = $d->read())) {
			    if( $entry == '.' || $entry == '..' ) continue;
			    $filename = pathinfo($entry , PATHINFO_FILENAME);
			    if( $name == $filename ){
				$filelist[$entry] = $filename;
			    }
		      }
		}else{
		      while (false !== ($entry = $d->read())) {
			    if( $entry == '.' || $entry == '..' ) continue;
			    $filename = pathinfo($entry , PATHINFO_FILENAME);
			    $filelist[$entry] = $filename;
		      }
		}
		$d->close();
		ksort($filelist);
		return $filelist;
	}
	
	/**
	 * handleRequestVars
	 * filter variables
	 *
	 * @param array $inVars expects array(  'filter' => array() , 'variant-sysoptions' => array()  )
	 * @param array $settings array to modify
	 * @return array modified settings
	 */
	public function handleRequestVars( $inVars = array() , $settings ) {
// 		if ( $this->request->hasArgument($settings['formname']) ) {
// 		     $inVars =  $this->request->getArgument($settings['formname']);
// 		}
// 		if ( !count($inVars) &&  $this->request->hasArgument('filter') ) {
// 		     $inVars['filter'] =  $this->request->getArgument('filter');
// 		}
		
		// assign filter-vars, transform them if affored
		$fieldTypes = array( 'date'=>'datefield' , 'todate'=>'datefield' );
		if( 
		    isset($inVars['filter']) &&
		    is_array($inVars['filter']) &&
		    count($inVars['filter'])
		) {
		    foreach($inVars['filter'] as $varName=>$inVarValue){
			  //if(empty($inVarValue))continue;
			  $fType = isset($fieldTypes[$varName]) ? $fieldTypes[$varName] : 'default';
			  switch($fType){
			      case 'datefield':
				    $da = explode( '.' , $inVarValue );
				    if( is_numeric($da[0]) && is_numeric($da[1]) && is_numeric($da[2])  ){
					$settings['filter'][$varName] = mktime( 12,0,0,$da[1],$da[0],$da[2]);
				    }
			      break;
			      default:
				    $settings['filter'][$varName] = $inVarValue;
			      break;
			  }
		    }
		}

		// override filter-vars with userfields or userfields with incoming values.
		foreach( $settings['userfields'] as $nam=>$fld ) {
		    if( isset($fld['overwride_depends_on']) ) {
				$overrideFields[$nam] = $fld['overwride_depends_on'];
			}elseif( !isset($inVars['filter'][$nam]) ){
			//value did not change jet, get values from user-settings. Added on august 2017!
				$settings['filter'][$nam] = $fld['value'];
			}
		}
		// $overrideFields is configured in seutp.txt: array( 'filter_tagesplan_timerange_from'=>'filter_tagesplan_overwride' , 'filter_tagesplan_timerange_to'=>'filter_tagesplan_overwride' );
		if(isset($overrideFields)){
		      foreach($overrideFields as $varName=>$dependingOption){
			    if(isset($inVars['filter'][$varName])) {
				  if( !empty($settings['userfields'][$dependingOption]['value']) ){
					$inVars['userfields'][$varName] = $inVars['filter'][$varName];
				  }
			    }else{
				  if(isset($inVars['userfields'][$varName])) {
					$settings['filter'][$varName] = $inVars['userfields'][$varName];
				  }else{
					if( isset($settings['userfields'][$varName]['value']) ) $settings['filter'][$varName] = $settings['userfields'][$varName]['value'];
				  }
			    }
		      }
		}
		// override userfields with incoming values.
		if(isset($inVars['userfields'])) { 
		    foreach($inVars['userfields'] as $varName=>$inVarValue){
			$settings['userfields'][$varName]['value'] = $inVarValue;
		    }
		    $this->setUserOptions($inVars['userfields']);
		}
		
		// if date filter is empty then create valid date-values
		if(empty($settings['filter']['date'])) $settings['filter']['date'] = time();
		if( 
		    $settings['filter']['todate'] < $settings['filter']['date'] || 
		    empty($settings['filter']['todate'])
		) {
		    $settings['filter']['todate'] = $settings['filter']['date']+(3600*24*$settings['userfields']['display_belegung_dayrange']['value']) ;
		}
		$settings['filter']['dateBack'] = date( 'd.m.Y' , $settings['filter']['date'] - (3600*24) );
		$settings['filter']['dateForward'] = date( 'd.m.Y' , $settings['filter']['date'] + (3600*24) );
		return $settings;
	}

}
