<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
 
$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName('typo3conf/ext/mff_contrib/Resources/Private/PHP/fpdf/');
define( 'FPDF_FONTPATH' , $extDir .  'font/' ); 
set_include_path($extDir);
include $extDir.'PdfRotatePagegroup.php';


/**
 * Class PdfWriterUtility
 * 
 */

class PdfWriterUtility extends \PdfRotatePagegroup {

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();

	/**
	* pageConf
	*
	* @var array
	*/
	Public $pageConf = array(
		'lineWidth'=>array( 0.1 , 0.2  , 0.5 ) , 
		'specchars'=>array( 'laquo'=>171 , 'raquo'=>187 , 'copy'=>169 , 'registered'=>174 , 'at'=>64 ) , 
		'keywords'=>'' , 
		'fontfamily'=>'Helvetica' , 
		'fsize'=>8 , 
		'lfeed'=>4 , 
		'pfeed'=>8 , 
		'zeroY'=>36 , 
		'docuwidth'=>210 , 
		'marginTop'=>15 , 
		'marginRight'=>15 , 
		'marginBottom'=>10 , 
		'marginLeft'=>25 , 
		'firstHeaderFooterNames'=>array(
			'page1'=>1 , 'seite1'=>1 , 1=>1
		) , 
		'dataOptions'=>array( 'lehrerJeZeile'=>6 , 'min_rows'=>18  )
	  );

	/**
	* errors
	*
	* @var array
	*/
	public $errors = array();

	/**
	* data
	*
	* @var array
	*/
	public $data = array( 'main' => array( '##Titel##' => 'testTitel' ) , 'body'=>array() , 'HEADER'=>array() , 'FOOTER'=>array() );
	
	public function initializePdf($pageConf) {
	      $this->pageConf = $pageConf;
		$this->SetTopMargin( $this->pageConf['marginTop'] );
		$this->SetLeftMargin( $this->pageConf['marginLeft'] );
		$this->SetRightMargin( $this->pageConf['marginRight'] );
	 	$this->SetAutoPageBreak( TRUE , $this->pageConf['marginBottom'] );
// 		$this->SetAutoPageBreak( FALSE  );
		$this->SetTextColor(0,0,0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		$this->SetKeywords(  $this->pageConf['keywords'] );
		
	}
	
	function Header() {
		if( !count($this->data['HEADER']) ) {parent::Header();return;}
		$this->replaceMaskedValues();
		
		$isFirstPage = $this->GroupPageNo() == 1 ? 1 : 0;
		foreach($this->data['HEADER'] as $ix => $row){
		  if( $row[0]['section_is_first'] && empty($isFirstPage) )continue;
		  if( $row[0]['section_is_follow'] && $isFirstPage )continue;
		  foreach( $row as $cNr => $cell ){
		      $this->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] );
		  }
		}
	      
	}
	function Footer() {
		
		if( !count($this->data['FOOTER']) ) {parent::Footer();return;}
		$this->replaceMaskedValues();
		
		$this->SetY(-10);
		$isFirstPage = $this->GroupPageNo() == 1 ? 1 : 0;
		
		$xPos = $this->GetX();
		foreach($this->data['FOOTER'] as $ix => $row){
		  if( $row[0]['section_is_first'] && empty($isFirstPage) )continue;
		  if( $row[0]['section_is_follow'] && $isFirstPage )continue;
		  foreach( $row as $cNr => $cell ){
		      $this->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] );
		      $this->SetX($xPos);
		  }
		}
	}
	
	function replaceMaskedValues() {
		$this->data['main']['__PAGE__'] = $this->GroupPageNo();
		$this->data['main']['__PAGES__'] = $this->PageGroupAlias();
		$this->data['main']['__DATE__'] = date( 'd.m.Y' );
		$this->data['main']['__C__'] = chr(169);
	}
      
	public function getCellWidth( $aOptions , $width ){
		if(!count($aOptions)) return;
		
		foreach( $aOptions as $idx=>$aOption){
		      if( 'fieldformat' == $aOption['type'] ){
			    $isItalic = strpos( ' ' . strtolower($aOption['options']) , 'k' ) ? 'I' : '';
			    $isBold = strpos( ' ' . strtolower($aOption['options']) , 'f' ) ? 'B' : '';
 			    unset($aOptions[$idx]);
			    break;
		      }
		}
		$this->SetFont( $this->pageConf['fontfamily'] , $isBold.$isItalic , $this->pageConf['fsize'] );
		
		$cellCollector = array();
		foreach( $aOptions as $idx => $aOption){
		   // if( $aOption['type'] != 'text') continue;
		    // replace placeholders with values from database
		    $dataValue = str_replace( array_keys($this->data['main']) , $this->data['main'] , $aOption['value'] );
		    if($aOption['type'] == 'text'){
			  $cellCollector['stringWidth'][$idx] = trim($dataValue)=='' ? 1:$this->GetStringWidth( $dataValue );
			  if( empty($width) ){
			      $width = !empty($dataValue) ? $cellCollector['stringWidth'][$idx] : 1;
			  }
		    }elseif($aOption['type'] == 'format'){
			  $outString = $this->userdefinedDateFormat( $dataValue , $aOption['options'] );
			  $cellCollector['stringWidth'][$idx] = trim($outString)=='' ? 1 : strlen( $outString );
		    }else{
			  $cellCollector['stringWidth'][$idx] = 1;
		    }
		    if( $cellCollector['stringWidth'][$idx] > $width && !empty($width) ){
			  $wordsInPart = explode( ' ' , $dataValue );
			  $aNewSentence = array();
			  $sCollectWords = '';
			  foreach($wordsInPart as $wix => $longWords){
				$wordWidth = $this->GetStringWidth($longWords);
				if( $wordWidth > $width && !empty($this->pageConf['dataOptions']['cut_overflow']) ){
				      $relation = $wordWidth / $width;
				      $newWordLength = floor( strlen($longWords)/$relation );
				      if( 'split' == $this->pageConf['dataOptions']['cut_overflow'] ){
					  $parts = ceil($relation);
					  for( $rowNr = 0; $rowNr < $parts; ++$rowNr){
						$newWordsInPart[] = substr( $longWords , $rowNr*$newWordLength , $newWordLength );
					  }
				      }else{      
					  $newWordsInPart[] = substr( $longWords , 0 , $newWordLength );
				      }
				}else{
				    $newWordsInPart[] = $longWords;
				}
			  }
			  foreach($newWordsInPart as $wix => $word){
				$testWidth = $this->GetStringWidth( $sCollectWords . ' ' . $word);
				if( $testWidth > $width ){
				      if( $sCollectWords ) {
					  $aNewSentence[] = trim( $sCollectWords );
					  $sCollectWords = $word.' ';
				      }else{
					  $aNewSentence[] = $word;
				      }
				}else{
				      $sCollectWords .= $word.' ';
				}
			  }
			  if(!empty($sCollectWords)) $aNewSentence[] = trim( $sCollectWords );
			  $cellCollector['stringAtoms'][$idx] = $aNewSentence;
		    }else{
			  if(!empty($dataValue)) $cellCollector['stringAtoms'][$idx][] = $dataValue;
		    }
		}
		return $cellCollector;
	}
      
	public function drawCsvCellContents( $aOptions , $width , $align , $ln , $middleRow = false){
		if(!count($aOptions)) return;
		$h = $this->pageConf['lfeed'];
		// define format for the whole cell
		$formatReplace = array( 'b'=>'' , 'f'=>'' , 'k'=>'' , 'l'=>'L' , 'o'=>'T' , 'r'=>'R' , 'u'=>'B' , 'a'=>'1' );
		foreach( $aOptions as $idx=>$aOption){
		      if( 'fieldformat' == $aOption['type'] ){
			    $isItalic = strpos( ' ' . strtolower($aOption['options']) , 'k' ) ? 'I' : '';
			    $isBold = strpos( ' ' . strtolower($aOption['options']) , 'f' ) ? 'B' : '';
			    $isLineBold = strpos( ' ' . strtolower($aOption['options']) , 'b' ) ? 2 : 1;
			    $definedCellBorder = str_replace( array_keys($formatReplace) , $formatReplace , $aOption['options']);
 			    unset($aOptions[$idx]);
			    break;
		      }
		}
		
		$this->SetFont( $this->pageConf['fontfamily'] , $isBold.$isItalic , $this->pageConf['fsize'] );
		
		if( $middleRow && $isLineBold < 2 && strpos( ' ' . $definedCellBorder , 'B' ) ){
		      $this->SetDrawColor(200,200,200);
		      $isLineBold = 0;
		}else{
		      $this->SetDrawColor(0,0,0);
		}
		$this->SetLineWidth( $this->pageConf['lineWidth'][$isLineBold] );
		
		if( $width ) $xPos = $this->GetX();
		
		// define formats for parts of cell and draw them
		$counter = 1;
		$keynumbers = count($aOptions);
		$outString = '' ;
		$fill = 0;
		
		foreach( $aOptions as $idx => $aOption){
		    // replace placeholders with values from database
		    $dataValue = str_replace( array_keys($this->data['main']) , $this->data['main'] , $aOption['value'] );
// 		   if( empty($width) && empty($dataValue) ) $width = 1;
		   switch( $aOption['type'] ){
			  case 'http':
			  case 'mailto':
			      // if there is a string already collected before, then draw it now
			      if($outString){
				  $cellBorder = $this->adjustSideBorder( $definedCellBorder , $counter , $keynumbers  );
				  ++$counter;
				  $this->Cell( $this->GetStringWidth($outString) , $h , $outString , $cellBorder , 0, $align);
				  $outString = '';
			      }
			      $linkAdress = $aOption['type'].':'.$aOption['options'];
			      $cellBorder = $this->adjustSideBorder( $definedCellBorder , $counter , $keynumbers  );
			      ++$counter;
			      $this->Cell( $this->GetStringWidth($dataValue) , $h , $dataValue , $cellBorder , 0 , $align , $fill , $linkAdress );
			  break;
			  case 'format':
			      $outString .= $this->userdefinedDateFormat( $dataValue , $aOption['options'] );
			  break;
			  case 'signatur':
			      if(empty($dataValue)) break;
			      // if there is a string already collected before, then draw it now
			      if($outString){
				  $cellBorder = $this->adjustSideBorder( $definedCellBorder , $counter , $keynumbers  );
				  ++$counter;
				  $this->Cell( $this->GetStringWidth($outString) , $h , $outString , $cellBorder , 0, $align);
				  $outString = '';
			      }
			      $imageOptions = $this->getSignatureImageOptions( $aOption['value'] , $aOption['options'] );
			      $this->Image( $aOption['value'] , $this->getX() , $this->getY()-$imageOptions['yOffset'] , $imageOptions['width']);
			      $this->SetLineWidth( $this->pageConf['lineWidth'][1] );
			      $cellBorder = $this->adjustSideBorder( $definedCellBorder , $counter , $keynumbers  );
			      ++$counter;
			      if($cellBorder){
				    $this->Cell( $imageOptions['width'] , $h , '' , $cellBorder , 0, $align);
			      }else{
				    $this->setX( $this->getX() + $imageOptions['width'] );
			      }
			  break;
			  case 'multicell':
				  $sep = str_replace( '_' , ' ' , $aOption['options']);
				  if(is_array($this->data['main'][$aOption['value']])) {
				      $aFieldValueAsArray = $this->data['main'][$aOption['value']];
				  }else{
				      $aFieldValueAsArray = explode( $sep , trim($dataValue) );
				  }
				  $aNamesRow = array();
				  foreach($aFieldValueAsArray as $teacherName){
					$testString = implode( $sep , $aNamesRow ) . $sep . $teacherName;
					$teaLength = $this->GetStringWidth( $testString );
					if( $teaLength > $width ){
					    $cellBorder = $this->adjustSideBorder( $definedCellBorder , $counter , $keynumbers  );
					    $xPos = $this->GetX(); //++$counter;
					    $this->Cell( $width , $h , implode( $sep , $aNamesRow ) , $cellBorder , 1 , $align);
					    $this->SetX( $xPos );
					    $aNamesRow = array();
					}
					$aNamesRow[] = $teacherName;
				  }
				  $outString = implode( $sep , $aNamesRow ) ;
			  break;
			  case 'text':
			      $outString .= $dataValue;
			  break;
			  default:
			      $outString .= $dataValue;
		    }
		}
		$cellBorder = $this->adjustSideBorder( $definedCellBorder , $keynumbers , $keynumbers  );
		if( $width ){
		    $length = $this->GetX() - $xPos;
		    $newWidth = $width-$length;
		}else{
		    $newWidth = $this->GetStringWidth($outString);
		}
		
		$this->Cell( $newWidth ,$h, $outString , $cellBorder , $ln , $align);
	}
	
	/**
	* adjustSideBorder
	* set border leftonly  for the first element, and set border right only for the last Emlement
	* returns adjusted border-advise
	* 
	* @param string $definedCellBorder
	* @param int $counter number of this element in aeeay
	* @param int $keynumbers total elements in array
	* @return array
	*/
	public function adjustSideBorder( $definedCellBorder , $counter , $keynumbers  ) {
		if( $keynumbers > 1 ){
		      if( $counter == 1 ){ // first
			    $cellBorder = str_replace( 'R' , '' , $definedCellBorder);
		      }elseif( $counter == $keynumbers ){ //last
			    $cellBorder = str_replace( 'L' , '' , $definedCellBorder);
		      }else{ // in middle
			    $cellBorder = str_replace( 'R' , '' , str_replace( 'L' , '' , $definedCellBorder));
		      }
		}else{ // one part only
		      $cellBorder = $definedCellBorder;
		}
		return $cellBorder;
	}
	
	/**
	* userdefinedDateFormat
	* returns date formatted string
	* 
	* @param int $timestamp 
	* @param string $optionString
	* @return array
	*/
	public function userdefinedDateFormat( $timestamp , $optionString ) {
	      if( !is_numeric($timestamp) || empty($timestamp) ) return $timestamp;
	      $encMonthName = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('monthnames.selopt.'.( 0 + date( 'm' , $timestamp ) ),'mffrps');
	      $encWeekDay = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('options.backup_weekinfo_sendday.selopt.'.( 0 + date( 'N' , $timestamp ) ),'mffrps');
	      $monthName = utf8_decode($encMonthName);
	      $weekDay = utf8_decode($encWeekDay);
	      $aReplacing = array(
		  'Monat'=> $monthName,
		  'Mon'=> substr( $monthName , 0 , 3),
		  'M'=> date( 'm' , $timestamp ),
		  'm'=> 0 + date( 'm' , $timestamp ),
		  'W'=> date( 'W' , $timestamp ),
		  'w'=> substr( $weekDay , 0 , 2 ),
		  'N'=> substr( $weekDay , 0 , 2 ),
		  'T'=> date( 'd' , $timestamp ),
		  't'=> 0 + date( 'd' , $timestamp ),
		  'J'=> date( 'Y' , $timestamp ),
		  'j'=> date( 'y' , $timestamp ),
	      );
	      return $this->replaceOnce( $aReplacing , $optionString );
	}
	
	/**
	* replaceOnce
	* similary to str_replace with arrays
	* 
	* but this method replaces every searchword only once, 
	* by deleting it after first replacement.
	* and if a word has changed, it will not be replaced anymore
	* 
	* @param array $aReplacing 
	* @param string $string
	* @return string
	*/
	public function replaceOnce( $aReplacing , $string ) {
	      $outString = '';
	      // jedes Zeichen durchlaufen wenn keine andere Anweisung
	      for( $pos = 0 ; $pos < strlen($string) ; ++$pos){
		    // Austausch Marker auf 0 setzen
		    $replaced = 0;
		    // austausch-Array durchlaufen,
		    foreach( $aReplacing as $s => $r ){
			  $teststring = substr( $string , $pos );
			  $isOnPos0 = strpos( ' ' . $teststring , $s );
			  if( $isOnPos0 == 1 ){
				// wenn Suchbegriff an erster Stelle dann
				// austauschen
				$outString .= $r;
				// loeschen (Suchbegriff nur 1x ersetzen)
				unset($aReplacing[$s]);
				// Zeiger setzen
				$pos+=strlen($s)-1;
				// Austausch markieren
				$replaced = 1;
				break;
			  }
		    }
		    // wenn kein Austausch stattgefunden hat, dann dieses Zeichen an Ausgabe anhaengen
		    if(!$replaced) $outString .= substr( $string , $pos , 1 );
	      }
	      return $outString;
	}
	
	
	/**
	* getSignatureImageOptions
	* returns array with yOffset , width, height
	* 
	* @param string $imagePathname
	* @param string $optionString
	* @return array
	*/
	public function getSignatureImageOptions( $imagePathname , $optionString ) {
		if(empty($imagePathname)) return false;
		
		$opts = explode(' ' , trim($optionString) );
		$width = $opts[0];
		$height = count($opts)>1 ? $opts[1] : 0;
		
		$aImgDim = getimagesize($imagePathname);
		$imgWidth = $aImgDim[0];
		$imgHeight = $aImgDim[1];
		if( $width ){
		    if(empty($height)) $height = $this->pageConf['lfeed'];
		    $faktor = $imgWidth / $width;
		    $newHeight = $faktor ? round( $imgHeight / $faktor ) : $imgHeight;
		    $yOffset = $newHeight > $height ? round( ($newHeight-$height) / 2 ) : 0;
		}else{
		    if(empty($height)) $height = $this->pageConf['pdf_signature_height'];
		    $faktor = $imgHeight / $height;
		    $width = round( $imgWidth / $faktor );
		    $yOffset = $height > $this->pageConf['lfeed'] ? round( ($height-$this->pageConf['lfeed']) / 2 ) : 0;
		    //$yOffset = 0;
		}
		return array( 'yOffset' => $yOffset , 'width' => $width , 'height' => $height );
	}

}