<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PdfDbUtility
 */

class PdfDbUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * mieterRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\MieterRepository
	 */
	protected $mieterRepository = NULL;

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;

	/**
	 * ausnahmeRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AusnahmeRepository
	 */
	protected $ausnahmeRepository = NULL;

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * timetableUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $timetableUtility = NULL;
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		$this->mieterRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\MieterRepository');
		$this->mieterRepository->setDefaultQuerySettings($querySettings);
// 		$this->anlassRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AnlassRepository');
// 		$this->anlassRepository->setDefaultQuerySettings($querySettings);
		$this->belegungRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		$this->ausnahmeRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AusnahmeRepository');
		$this->ausnahmeRepository->setDefaultQuerySettings($querySettings);

		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility($this->settings);
		$this->timetableUtility = new \Mff\Mffrps\Utility\TimetableUtility();
	}
	
	/**
	 * getDataForPdfAnlass
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return array
	 */
	public function getDataForPdfAnlass( $anlass , $type ) {
	      if( $type == 'bewilligung' ) return $this->getAnlassBewilligungForPdf( $anlass );
	      if( $type == 'lehrerinfo' ) return $this->getAnlassLehrerinfoForPdf( $anlass );
	      if( $type == 'lehrpersonen' ) return $this->getAnlassLehrpersonenForPdf( $anlass );
	}
	
	/**
	 * getWochenlisteForPdf
	 *
	 * @param int $datumAb
	 * @return array
	 */
	public function getWochenlisteForPdf( $datumAb = NULL ) {
	      $deelay = $this->settings['optionfields']['info_wochenliste_delay']['value'];//3;
	      $naechsteWoche = $datumAb + (3600 * 24 * (7-$deelay) );
 	      $wochen = $this->getDatumwerteWochen( $naechsteWoche , $this->settings['optionfields']['info_wochenliste_weeks']['value'] );
	      return $this->getWochenlisteByWochenForPdf( $wochen );
	}
	public function getDatumwerteWochen( $eingangDatum , $anzahlWochen ) {
	      $tageNachLetzemMontag = date( 'N' , $eingangDatum )-1; // 1-7
	      $starttag = $eingangDatum - ( $tageNachLetzemMontag * 3600 * 24 );
	      $startzeit = mktime( 5,0,0, date('m',$starttag), date('d',$starttag), date('y',$starttag)  );

	      $wochen = array();
	      for( $addWoche = 0 ; $addWoche < $anzahlWochen ; ++$addWoche ){
		    $wchStartzeit = $startzeit + ( $addWoche  * (3600 * 24 * 7) ) ;
		    $wchEndtag = (3600 * 24 * 6) + $wchStartzeit;
		    $wchEndzeit = mktime( 20,59,59, date('m',$wchEndtag), date('d',$wchEndtag), date('y',$wchEndtag)  );
		    $wochen[date( 'W' , $wchStartzeit )]['date'] = $wchStartzeit;
		    $wochen[date( 'W' , $wchStartzeit )]['todate'] = $wchEndzeit;
	      }
	      return $wochen;
	}
	
	/**
	 * getWochenlisteByWochenForPdf
	 *
	 * @param array $wochen array( $intWocheNr => array( 'date' => uxTimestamp , 'todate' => uxTimestamp ) )
	 * @return array
	 */
	public function getWochenlisteByWochenForPdf( $wochen ) {
	      $data = array();
	      foreach( $wochen as $weekNr => $aDaten ){
		    $objsBelegungen = $this->belegungRepository->findByRoomsAndDates( NULL , $aDaten );
		    $subData = array();
		    foreach($objsBelegungen as $oBelegung){
			  $objDate = $oBelegung->getDatum();
			  if(empty($objDate))continue;
			  $oRoom = $oBelegung->getBelZimmer() ;
			  if(empty($oRoom))continue;
			  $anlassUid = $oBelegung->getAnlass() ;
			  if(empty($anlassUid))continue; 
			  $oAnlass = $this->dbHelperUtility->getAnlassObjByUid( $anlassUid );
			  if(empty($oAnlass))continue;
			  $aAnlass = $this->getAnlassMieterData( $oAnlass );
			  $uxDate = $objDate->format('U');
			  $haus =  utf8_decode($oRoom->getHaus());
			  $zimmer = utf8_decode($oRoom->getZimmer());
			  $belegungstext = utf8_decode($oBelegung->getBelegungstext());
			  $zusatztext = utf8_decode($oBelegung->getZusatztext());
			  $belUid = $oBelegung->getUid();
			  $belAb = $this->dbHelperUtility->cleanTimeString( $oBelegung->getAb() );
			  $belBis = $this->dbHelperUtility->cleanTimeString( $oBelegung->getBis() );
			  
			  $label = array();
			  if(!empty($aAnlass['Verwendungszweck'])) $label[] = $aAnlass['Verwendungszweck'];
			  if(!empty($belegungstext)) $label[] = $belegungstext;
			  if(!empty($zusatztext)) $label[] = $zusatztext;
			  if(!empty($aAnlass['Telefon'])) $label[] = $aAnlass['Telefon'];
			  if(!empty($aAnlass['Email'])) $label[] = $aAnlass['Email'];
			  
			  $index = date( 'ymd' , $uxDate ) . $haus . $belAb . $zimmer . $belUid;
			  
			  $subData[$index] = array(
			      'Uid' => $belUid,
			      'Datum' => $uxDate, 
			      'Zimmer' =>  $haus . ' ' . $zimmer, 
			      'Von' => $belAb , 
			      'Bis' => $belBis , 
			      'Mieter' => $aAnlass['Kurz'] , 
			      'Belegungstext' => $aAnlass['Verwendungszweck'],
			      'Telefon' => $aAnlass['Telefon'] , 
			      'Email' => $aAnlass['Email'], 
			      'Label' => implode( ', ' , $label )
			  );
		    }
		    if(count($subData)){
			  ksort($subData);
			  $data['multiple'][$weekNr] = array(
			    'main' => array(
				      'Filename'=>'info_wochenliste_download_'.date('y-m-d',$aDaten['date']).'.pdf',
				      'Keywords'=>'Wochenliste Raumplanung',
				      'Ab'=>$aDaten['date'],
				      'Bis'=>$aDaten['todate']
			    ),
			    'subdata' => $subData
			  );
		    }
	      }
	      return $data;
	}
	
	/**
	 * getAnlassBewilligungForPdf
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return array
	 */
	public function getAnlassBewilligungForPdf( $anlass ) {
		$type  ='bewilligung';
		
		$aAnlass = $this->getAnlassMieterData( $anlass );
		
		$aAnlass['Filename'] = urlencode(  ucfirst($type).'_'.$aAnlass['Uid'].'-'.$aAnlass['Verwendungszweck'] ) .'.pdf';
		$aAnlass['Keywords'] = utf8_decode( 'Raumplanung '.ucfirst($type).' für Anlass Nr.' ) . $aAnlass['Uid'] . ', '.$aAnlass['Verwendungszweck'].'.';

		//$aAnlass['Titel'] = $aAnlass['Keywords'] ;
		$crdate = $anlass->getCrdate();
		$crYear = date( 'y' , $crdate );
		$aAnlass['BewilligungNr'] = sprintf( "%04s" , $aAnlass['Uid'] ) . '/' . $crYear;
		
		$HaudAdr = $this->settings['optionfields']['info_hauswart_mailadress']['value'];
		$aAnlass['Hausmeisterkopie'] = !empty($HaudAdr) && !empty($this->settings['optionfields']['backup_weekinfo_sendday']['value']) ? 'X' : '';
		$aAnlass['HausdienstEmail'] = $this->settings['optionfields']['info_hauswart_mailshow']['value'] ? $HaudAdr : '';
		
		$lpListe = array();
		$oAnlBelegungen = $anlass->getAnlBelegung();
		if(count($oAnlBelegungen)){
		    $aBelegungTimetable = $this->mkArrBelegungenTimetabApproximation( $oAnlBelegungen ,  $this->settings['optionfields']['info_lp_info_deep']['value'] );
		    if(count($aBelegungTimetable)){
			foreach($aBelegungTimetable as $belUid=>$belTtRecords ){
			      foreach($belTtRecords as $ttRecord ){
				  $lpListe[ $ttRecord['last_name'] ] = ($ttRecord['name']);
			      }
			}
		    }
		}
		ksort($lpListe);
		$aAnlass['Lehrerkopie'] = count($lpListe) ? 'X' : '';
		
		if(!count($lpListe)){
		    $aAnlass['Lehrpersonenliste'] = '';
		}else{
		    if( $this->settings['optionfields']['info_lp_no_details']['value'] ) {
			  $aAnlass['Lehrpersonenliste'] = count($lpListe) . ' Person';
			  if( count($lpListe) >1 ) $aAnlass['Lehrpersonenliste'] .= 'en';
		    }else{
			 // $aAnlass['Lehrpersonenliste'] = implode( ', ' , $lpListe );
			  $aAnlass['Lehrpersonenliste'] = $lpListe ;
		    }
		}
		
		//$oAnlBelegungen = $anlass->getAnlBelegung();
		$anlassSumme = 0;
		
		$aGroupFields = array('Datum','Von','Bis','Zimmerwunsch');
		// expected options: count intsum sum group or a char (,) as separator
		$aConfigFields = array( 
		      'Zimmerzuteilung' => ', ' , 
		      'Zimmerzahl'      => 'count' , 
		      'Zimmerbetrag'    => 'sum' 
		);
		if(count($oAnlBelegungen)){
		    foreach($oAnlBelegungen as $oBelegung ){
			  $belUid = $oBelegung->getUid();
			  $oRoom = $oBelegung->getBelZimmer() ;
			  $strZimmer = ($oRoom) ? utf8_decode($oRoom->getHaus() . ' ' . $oRoom->getZimmer()) : ''; 
			  $Datum = $oBelegung->getDatum();
			  if( !$Datum ) continue;
			  $aBelegung['Datum'] = $Datum->format('U');
			  $aBelegung['Von'] = $this->dbHelperUtility->cleanTimeString( trim( $oBelegung->getAb() ) );
			  $aBelegung['Bis'] = $this->dbHelperUtility->cleanTimeString( trim( $oBelegung->getBis() ) );
			  $aBelegung['Zimmerwunsch'] = utf8_decode($oBelegung->getZusatztext()) ; 
			  $aBelegung['Zimmerzahl'] = 1 ; 
			  $aBelegung['Zimmerbetrag'] = $oBelegung->getBetrag(); 
			  if( !is_numeric($aBelegung['Zimmerbetrag']) ) $aBelegung['Zimmerbetrag'] = 0;
			  $aBelegung['Zimmerzuteilung'] = $strZimmer;
			  $aIdx = array();
			  foreach( $aGroupFields as $fld){ $aIdx[] = $aBelegung[$fld]; }
			  $dateIdx =  implode( '.' , $aIdx );
			  $grpBel[$dateIdx][$belUid] = $aBelegung;
			  $anlassSumme += $aBelegung['Zimmerbetrag'];
		    }
		}
		
		if(count($grpBel)){
		    $data['subdata'] = $this->groupBy( $grpBel , $aGroupFields , $aConfigFields );
		}
		if( !is_numeric($aAnlass['ZuschlagBetrag']) ) $aAnlass['ZuschlagBetrag'] = 0;
		if( !is_numeric($anlassSumme) ) $anlassSumme = 0;
		$aAnlass['Totalbetrag'] = $aAnlass['ZuschlagBetrag'] + $anlassSumme ? sprintf("%01.2f", $aAnlass['ZuschlagBetrag'] + $anlassSumme) : '';
		
		// store data and options in array
		$data['main'] = $aAnlass;
		
		return $data;
	}
	
	/**
	* groupBy
	* 
	* @param array $aThreeDimData data[ sortIdx ][ uid ][ fieldname ] = value
	* @param array $aGroupFields fields[ index ] = Fieldname
	* @param array $aConfigFields fields[ Fieldname ] = array_function [ intsum |sum | count | patternToImplode ]
	* @return array a two dimensional array
	*/
	public function groupBy( $aThreeDimData , $aGroupFields , $aConfigFields ){
	      $fldGrp = array_flip($aGroupFields);
	      $outArr = array();
	      foreach( $aThreeDimData as $grpIdx => $grpdRows){
		  $subRows = array();
		  // collect subrows, without mainrow-fields
		  if(is_array($grpdRows)){foreach( $grpdRows as $uid => $row){
			foreach( $row as $field => $value){
			      if(isset($fldGrp[$field])) continue;
			      $subRows[$field][$uid]= $value;
			}
		  }}
		  // set mainrow fields
		  if(is_array($aGroupFields)){foreach( $aGroupFields as $field ){
			foreach( $grpdRows as $uid => $row){
			      $outArr[$grpIdx][$field] = empty($row[$field]) ? ' ' : $row[$field];
			      break;
			}
		  }}
		  // append subrow values by imploding them into the corresponding fields
		  if(is_array($subRows)){foreach($subRows  as $field => $sRow){
			if( $aConfigFields[$field] == 'count' ){
			      $outArr[$grpIdx][$field] = count( $sRow );
			}elseif( $aConfigFields[$field] == 'intsum' ){
			      $outArr[$grpIdx][$field] = array_sum( $sRow );
			}elseif( $aConfigFields[$field] == 'sum' ){
			      $summ = array_sum( $sRow );
			      $outArr[$grpIdx][$field] = $summ ? sprintf("%01.2f", $summ) : '';
			}else{
			      $teststring = implode( $sRow );
			      if( trim($teststring) == ''){
				    $outArr[$grpIdx][$field] = '';
			      }else{
				    if($aConfigFields[$field] == 'group'){
					  $aGrpd = array();
					  foreach($sRow as $toGroup){
					      if(!empty($toGroup))$aGrpd[$toGroup] = $toGroup;
					  }
					  $outArr[$grpIdx][$field] = implode( ', ' , $aGrpd );
				    }elseif( !empty($aConfigFields[$field]) ){
					  $outArr[$grpIdx][$field] = implode( $aConfigFields[$field] , $sRow );
				    }
			      }
			}
		  }}
	      }
	      return $outArr;
	}
	
	/**
	 * getAnlassLehrerinfoForPdf
	 * get all approximations for all teachers approximating this anlass
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return array
	 */
	public function getAnlassLehrerinfoForPdf( $anlass ) {
		$type  ='Lehrerinfo';
		$iAnlassUid = $anlass->getUid();
		$sVerwendungszweck = utf8_decode($anlass->getVerwendungszweck());
		$Filename = urlencode(  ucfirst($type).'_'.$iAnlassUid.'-'.$sVerwendungszweck ) .'.pdf';
		$Keywords = utf8_decode( 'Lehrerinfo '.ucfirst($type).' aus Anlass Nr.' ) . $iAnlassUid . ', '.$sVerwendungszweck.'.';
		$data = $this->mkArrLehrerinfo( $iAnlassUid );
		if( !is_array($data['multiple']) ) return;
		foreach( array_keys($data['multiple']) as $teaId ){
		    foreach( $data['multiple'][$teaId]['subdata'] as $belId=>$aApprox ){
			  ksort($data['multiple'][$teaId]['subdata']);
			  $data['multiple'][ $teaId ]['main']['LehrpersonInfoTiefe'] = $this->settings['optionfields']['info_lp_info_deep']['value'];
			  $data['multiple'][ $teaId ]['main']['Filename'] = $Filename;
			  $data['multiple'][ $teaId ]['main']['Keywords'] = $Keywords;
			  $data['multiple'][ $teaId ]['main']['Lehrperson'] = $aApprox['name'];
			  break;
		    }
		}
		return $data;
	}
	
	/**
	 * mkArrLehrerinfo
	 * get all belegung-approximations for all teachers
	 *
	 * @param int $iAnlassUid
	 * @return array
	 */
	public function mkArrLehrerinfo( $iAnlassUid = NULL ) {
		$data = array();
		$aBelTea = array();
		$aTeaBel = $this->mkArrTeacherBelegungApproximation( $this->settings['optionfields']['info_lp_info_deep']['value'] );
		foreach( $aTeaBel as $teaId => $aBels ){
		      foreach( $aBels as $belId => $aApprox ){
			  $aBelTea[ $aApprox['AnlassNr'] ][ $teaId ][ $belId ] = $aApprox;
		      }
		}
		
		if( !empty($iAnlassUid) && !isset($aBelTea[ $iAnlassUid ])) return array();
		
		foreach( $aBelTea as $anlUid => $aAnls ){
		      foreach( $aAnls as $teaId => $aBels ){
			    if( !empty($iAnlassUid) && !is_array($aBelTea[ $iAnlassUid ][ $teaId ])) continue;
			    $mainRows = array();
			    foreach( $aBels as $belId => $aApprox ){
				$data['multiple'][ $teaId ]['subdata'][ $belId ] = $aApprox;
			    }
		      }
		}
		return $data;
	}
	
	/**
	 * getAnlassLehrpersonenForPdf
	 * returns array with tangential Belegungen
	 * array[ belegungUid ][ timetableUid ] = before | during | after 
	 * (liefert Stundenplandaten Tag Zeit Person Klasse)
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return array
	 */
	public function getAnlassLehrpersonenForPdf( $anlass ) {
		$type  ='Lehrpersonen';
		
		$aAnlass = $this->getAnlassMieterData( $anlass );
		$aAnlass['Filename'] = urlencode(  ucfirst($type).'_'.$aAnlass['Uid'].'-'.$aAnlass['Verwendungszweck'] ) .'.pdf';
		$aAnlass['Keywords'] = utf8_decode( 'Raumplanung '.ucfirst($type).' für Anlass Nr.' ) . $aAnlass['Uid'] . ', '.$aAnlass['Verwendungszweck'].'.';

		$aAnlass['BewilligungNr'] = $aAnlass['Uid'] ;
		
		$aAnlass['LehrpersonInfoTiefe'] = $this->settings['optionfields']['info_lp_info_deep']['value'];
		
		$oAnlBelegungen = $anlass->getAnlBelegung();
		$aCollectTeatcher = array();
		$approxBelTtRecords = array();
		if(count($oAnlBelegungen)){
		    $aBelegungTimetable = $this->mkArrBelegungenTimetabApproximation( $oAnlBelegungen ,  $this->settings['optionfields']['info_lp_info_deep']['value'] );
		    if(count($aBelegungTimetable)){
			foreach($oAnlBelegungen as $oBelegung ){
			      $belUid = $oBelegung->getUid();
			      if( !isset( $aBelegungTimetable[$belUid] ) ) continue;
			      $oRoom = $oBelegung->getBelZimmer() ;
			      $Datum = $oBelegung->getDatum();
			      if( !$Datum ) continue;
			      $approxBelTtRecords[ $belUid ]['Datum'] = $Datum->format('U');
			      $approxBelTtRecords[ $belUid ]['Von'] = $oBelegung->getAb();
			      $approxBelTtRecords[ $belUid ]['Bis'] = $oBelegung->getBis();
			      $approxBelTtRecords[ $belUid ]['Zimmer'] = $oRoom->getHaus() . ' ' . $oRoom->getZimmer();
			      $approxBelTtRecords[ $belUid ]['PlanVorDatum'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanVorZeit'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanVorLehrperson'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanVorKlasse'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanNachDatum'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanNachZeit'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanNachLehrperson'] = '';
			      $approxBelTtRecords[ $belUid ]['PlanNachKlasse'] = '';
			      foreach($aBelegungTimetable[$belUid] as $ttRecord ){
				  if(!empty($ttRecord['name'])) $aCollectTeatcher[ $ttRecord['last_name'] ] = ($ttRecord['name']);
				  if( 'equal'==$ttRecord['match'] ){
				      if(isset($approxBelTtRecords[ $belUid ]['PlanAm'])){
					    $approxBelTtRecords[ $belUid . '.' . $ttRecord['uid'] ] = $approxBelTtRecords[ $belUid ];
					    $approxBelTtRecords[ $belUid . '.' . $ttRecord['uid'] ]['Ausnahmetext'] = $ttRecord['Ausnahmetext'];
					    $approxBelTtRecords[ $belUid . '.' . $ttRecord['uid'] ]['Ersatzzimmer'] = $ttRecord['Ersatzzimmer'];
					    $approxBelTtRecords[ $belUid . '.' . $ttRecord['uid'] ]['PlanAm'] = ($ttRecord['ab'] . '-' . $ttRecord['bis'] . ' ' . $ttRecord['name'] . ' ' .  $ttRecord['class_short']);
					    $approxBelTtRecords[ $belUid . '.' . $ttRecord['uid'] ]['match'] = $ttRecord['match'];
				      }else{
					    $approxBelTtRecords[ $belUid ]['Ausnahmetext'] = $ttRecord['Ausnahmetext'];
					    $approxBelTtRecords[ $belUid ]['Ersatzzimmer'] = $ttRecord['Ersatzzimmer'];
					    $approxBelTtRecords[ $belUid ]['PlanAm'] = ($ttRecord['ab'] . '-' . $ttRecord['bis'] . ' ' . $ttRecord['name'] . ' ' .  $ttRecord['class_short']);
				      }
				  }else{
				      if(!isset($approxBelTtRecords[ $belUid ]['PlanAm']))$approxBelTtRecords[ $belUid ]['PlanAm'] = '';
				      if('before'==$ttRecord['match']){
					    $approxBelTtRecords[ $belUid ]['PlanVorDatum'] = $ttRecord['date_start'];
					    $approxBelTtRecords[ $belUid ]['PlanVorZeit'] = 'bis '.$ttRecord['bis'];
					    $approxBelTtRecords[ $belUid ]['PlanVorLehrperson'] = ($ttRecord['name']);
					    $approxBelTtRecords[ $belUid ]['PlanVorKlasse'] = ($ttRecord['class_short']);
				      }
				      if('after'==$ttRecord['match']){
					    $approxBelTtRecords[ $belUid ]['PlanNachDatum'] = $ttRecord['date_start'];
					    $approxBelTtRecords[ $belUid ]['PlanNachZeit'] = 'ab '.$ttRecord['ab'];
					    $approxBelTtRecords[ $belUid ]['PlanNachLehrperson'] = ($ttRecord['name']);
					    $approxBelTtRecords[ $belUid ]['PlanNachKlasse'] = ($ttRecord['class_short']);
				      }
				  }
				  $approxBelTtRecords[ $belUid ]['match'] = $ttRecord['match'];
			      }
			}
		    }
		}
		if(is_array($aCollectTeatcher)) ksort($aCollectTeatcher);
		$aAnlass['Lehrperson'] = implode( ', ' , $aCollectTeatcher) ;
		
		$data['main'] = $aAnlass;
		
		$data['subdata'] = $approxBelTtRecords;
		return $data;
	}
	
	/**
	 * mkArrTeacherBelegungApproximation
	 * returns array with timetables approximating to Belegungen
	 *
	 * @param int $infoDepthAllInDay [ 0=only conflicts | 1=if on same day | 2=wholeWeek ]
	 * @return array
	 */
	public function mkArrTeacherBelegungApproximation( $infoDepthAllInDay = 0 ) {
	      $aTeaBel = array();
	      $now = time();
	      $dateNow = mktime( 0,0,0, date('m',$now), date('d',$now), date('y',$now) );
	      $mieterRep = $this->mieterRepository->findAll();
	      foreach($mieterRep as $mieterObj){
		    $objsAnlass = $mieterObj->getMtrAnlass();
		    if(!count($objsAnlass)) continue;
// 		    $aMieter['name'] = utf8_decode($mieterObj->getName());
		    $aMieter['kurz'] = utf8_decode($mieterObj->getKurz());
		    foreach($objsAnlass as $oAnlass){
			  $objsBelegungen = $oAnlass->getAnlBelegung();
			  if(!count($objsBelegungen)) continue;
			  $aAnlass['Uid'] = $oAnlass->getUid();
			  $aAnlass['Verwendungszweck'] = utf8_decode($oAnlass->getVerwendungszweck());
			  $aBelTtApp = $this->mkArrBelegungenTimetabApproximation( $objsBelegungen , $infoDepthAllInDay );
			  if(!count($aBelTtApp)) continue;
			  foreach($objsBelegungen as $oBelegung){
				$Datum = $oBelegung->getDatum();
				if( !$Datum ) continue;
				$uxDate = $Datum->format('U');
				if( $uxDate < $dateNow ) continue;
				$belUid = $oBelegung->getUid();
				$belAb = $oBelegung->getAb();
				$belBis = $oBelegung->getBis();
				if(!isset($aBelTtApp[$belUid])) continue;
				$oRoom = $oBelegung->getBelZimmer() ;
				$iRoomUid = $oRoom->getUid() ;
				foreach( $aBelTtApp[$belUid] as $ttUid => $timetable){
				      $aErsatzZimmerList = array();
				      $newUid = $uxDate.'.'.$belUid.'.'.$timetable['uid'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ] = $timetable;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Match'] = $timetable['match']=='equal' ? 1 : 0;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Startdatum'] = $timetable['date_start'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Datum'] = $uxDate;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Zimmer'] = utf8_decode($oRoom->getHaus() . ' ' . $oRoom->getZimmer());
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['BelAb'] = $belAb;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['BelBis'] = $belBis;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['VonG'] = $timetable['match']!='equal' ? '' : $belAb;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['BisG'] = $timetable['match']!='equal' ? '' : $belBis;
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Von'] = $timetable['ab'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Bis'] = $timetable['bis'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Klasse'] = $timetable['class_short'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Institution'] = $aMieter['kurz'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['Verwendungszweck'] = $aAnlass['Verwendungszweck'];
				      $aTeaBel[ $timetable['teacherId'] ][ $newUid ]['AnlassNr'] = $aAnlass['Uid'];
				}
			  }
		    }
	      }
	      return $aTeaBel;
	}
	public function mkArrBelegungenTimetabApproximation( $objsBelegungen , $infoDepthAllInDay ) {
	      // infoDepthAllInDay [ 0=only conflicts | 1=if on same day | 2=wholeWeek ]
	      $approxBelTtRecords = array();
	      if(count($objsBelegungen)){
		    foreach($objsBelegungen as $oBelegung ){
			  $oRoom = $oBelegung->getBelZimmer() ;
			  if(!$oRoom)continue;
			  $zimmerIdx = $oRoom->getUid();
			  $Datum = $oBelegung->getDatum();
			  if( !$Datum ) continue;
			  $uxDate = $Datum->format('U');
			  $calendarObj = $this->dbHelperUtility->mkArrHolidayByDates( array( 'date'=>$uxDate , 'todate'=>$uxDate ) );
			  $holiday = $calendarObj[ date('d.m.y' , $uxDate ) ];
			  $zmrTtObj = $this->timetableUtility->getArrayByRoomsAndDate( array($zimmerIdx) , $uxDate );
			  $belUid = $oBelegung->getUid();
			  $dBelAb = 0 + str_replace( ':' , '.' , $oBelegung->getAb() );
			  $dBelBis = 0 + str_replace( ':' , '.' , $oBelegung->getBis() );
			  
			  // MATCHING EXACTLY look up for tt-recordset matching with belegung
			  if(count($zmrTtObj)){
				foreach($zmrTtObj as $ttRecord ){
				    if( $this->isTimetableInHoliday( $ttRecord , $holiday ) ) continue;
				    if($ttRecord['numAb'] >= $dBelBis) continue;
				    if($ttRecord['numBis'] <= $dBelAb) continue;
				    foreach($ttRecord as $fld=>$val)$approxBelTtRecords[ $belUid ][ $ttRecord['uid'] ][$fld] = utf8_decode($val);
				    $approxBelTtRecords[ $belUid ][ $ttRecord['uid'] ]['match'] = 'equal';
				    $aErsatzZimmerList = $this->addAusnahmeToArrBelTtApprox( $zimmerIdx , $ttRecord['uid'] , $uxDate );
				    $approxBelTtRecords[ $belUid ][ $ttRecord['uid'] ]['Ersatzzimmer'] = $aErsatzZimmerList['ersatzzimmer'];
				    $approxBelTtRecords[ $belUid ][ $ttRecord['uid'] ]['Ausnahmetext'] = $aErsatzZimmerList['ausnahmetext'];
				}
			  }
			  // stop if there is a exactliy matching tt-recordset for belegung
			  if( isset($approxBelTtRecords[ $belUid ]) )continue;
			  // stop by configuration
			  if( empty($infoDepthAllInDay) )continue;
			  
			  // SAME DAY seek in day pick the nearest before an after this belegung
			  $isNear = array();
			  if(count($zmrTtObj)){
				foreach($zmrTtObj as $ttRecord ){
				    if( $this->isTimetableInHoliday( $ttRecord , $holiday ) ) continue;
				    if( $dBelAb > $ttRecord['numBis'] ){
					$isBefore = 1;
					$diff = $dBelAb - $ttRecord['numBis'];
				    }else{
					$isBefore = 0;
					$diff = $ttRecord['numAb'] - $dBelBis;
				    }
				    $isNear[ $isBefore ][ $diff ] = $ttRecord['uid'];
				}
			  }
			  if( count($isNear) ){
				foreach($isNear as $isBefore => $appTtRecords ){
				    ksort($appTtRecords);
				    $firstTtUid = array_shift( $appTtRecords );
				    foreach($zmrTtObj[$firstTtUid] as $fld=>$val)$approxBelTtRecords[ $belUid ][ $firstTtUid ][$fld] = utf8_decode($val);
				    $approxBelTtRecords[ $belUid ][ $firstTtUid ]['match'] = $isBefore ? 'before' : 'after';
				}
			  }
			  // stop if there are 2 corresponding tt-recordsets for belegung in same day
			  if( count($isNear) == 2 ) continue;
			  // stopped by configuration
			  if( $infoDepthAllInDay < 2 ) continue;
			  
			  // IN WEEK seek in week
			  for( $isBefore = 0 ; $isBefore <= 1 ; ++$isBefore ){
				if( isset($isNear[ $isBefore ]) ) continue;
				$isDayNear[ $isBefore ] = array();
				for( $daysProgr = 1; $daysProgr < 7 ; ++$daysProgr){
				      $dateDiff = $isBefore ? (0-(3600*24))*$daysProgr : (0+(3600*24))*$daysProgr;
				      if( date('w',$uxDate+$dateDiff) > 6 ) continue; // loose sundays
				      $weekZmrTtObj = $this->timetableUtility->getArrayByRoomsAndDate( array($zimmerIdx) , $uxDate+$dateDiff );
				      $weekCalendarObj = $this->dbHelperUtility->mkArrHolidayByDates( array( 'date'=>$uxDate+$dateDiff , 'todate'=>$uxDate+$dateDiff ) );
				      $weekHoliday = $weekCalendarObj[ date('d.m.y' , $uxDate+$dateDiff ) ];
				      foreach($weekZmrTtObj as $ttRecord ){
					    if( $this->isTimetableInHoliday( $ttRecord , $weekHoliday ) ) continue;
					    if($isBefore){
						  $diff = $ttRecord['numBis'];
					    }else{
						  $diff = $ttRecord['numAb'];
					    }
					    $isDayNear[ $isBefore ][ $diff ] = $ttRecord['uid'];
				      }
				      if( count($isDayNear[ $isBefore ]) ){
					    ksort($isDayNear[ $isBefore ]);
					    $firstTtUid = array_shift( $isDayNear[ $isBefore ] );
					    foreach($weekZmrTtObj[$firstTtUid] as $fld=>$val)$approxBelTtRecords[ $belUid ][ $firstTtUid ][$fld] = utf8_decode($val);
					    $approxBelTtRecords[ $belUid ][ $firstTtUid ]['match'] = $isBefore ? 'before' : 'after';
					    $daysProgr = 7;
				      }
				}
			  }
		    }
	      }
	      return $approxBelTtRecords;
	}
	public function addAusnahmeToArrBelTtApprox( $iRoomUid , $ttUid , $uxDate ) {
	      $aErsatzZimmerList = array('ersatzzimmer'=>'Kein Eintrag.' , 'ausnahmetext'=>'');
	      $ttAusnahmen = $this->ausnahmeRepository->findByTimetableAndDate( $ttUid , $uxDate );
	      if(count($ttAusnahmen)){
		  foreach($ttAusnahmen as $aAusnahme){
			$objAusZimmer = $aAusnahme->getAusZimmer();
			if( $iRoomUid == $objAusZimmer->getUid() ){ 
			    $oldRoom = $objAusZimmer->getHaus() . ' ' . $objAusZimmer->getZimmer();
			    $newRoom = utf8_decode($aAusnahme->getNeuZimmer()->getHaus() . ' ' . $aAusnahme->getNeuZimmer()->getZimmer());
			    $displayNewRoom = $newRoom==$oldRoom ? 'Kein Ersatz! ' : $newRoom;
			    $aErsatzZimmerList['ersatzzimmer'] = $displayNewRoom;
			    $aErsatzZimmerList['ausnahmetext'] = utf8_decode($aAusnahme->getAusnahmetext());
			}
		  }
	      }
	      return  $aErsatzZimmerList;
	}

	/**
	 * isTimetableInHoliday
	 *
	 * @param array $ttRecord
	 * @param array $holiday
	 * @return boolean
	 */
	public function isTimetableInHoliday( $ttRecord , $holiday ) {
	      if( isset($holiday['from'])){
		    if( $holiday['allFrom'] != $holiday['from'] ){
			  if( empty($ttRecord['ignore_holiday']) && $holiday['from'] <= $ttRecord['numAb']) return true;
		    }else{
			  if( empty($ttRecord['ignore_vacation']) && $holiday['from'] <= $ttRecord['numAb']) return true;
		    }
	      }
	      return false;
	}
	
	/**
	 * getAnlassMieterData
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return array
	 */
	public function getAnlassMieterData( $anlass ) {
		
		$anlassUid = $anlass->getUid();
		$aMieterinfo = $this->dbHelperUtility->getAnlassMieterInfos( $anlassUid );
		
		$aAnlass = array();
		$aAnlass['Kurz'] = utf8_decode($aMieterinfo['kurz']);
		$aAnlass['Institution'] = utf8_decode($aMieterinfo['name']);
		$aAnlass['Kontaktperson'] = utf8_decode($aMieterinfo['kontakt_person']);
		$aAnlass['Telefax'] = $aMieterinfo['telefax'];
		$aAnlass['Telefon'] = empty($aMieterinfo['kontakt_telefon']) ? $aMieterinfo['telefon'] : $aMieterinfo['kontakt_telefon'];
		$aAnlass['Email'] = empty($aMieterinfo['kontakt_email']) ? $aMieterinfo['email'] : $aMieterinfo['kontakt_email'];
		$aAnlass['StrasseNr'] = utf8_decode($aMieterinfo['strasse_nr']);
		$aAnlass['PlzOrt'] = utf8_decode($aMieterinfo['plz_ort']);
		$aAnlass['ZuschlagBetrag'] = empty($aMieterinfo['zuschlag_betrag']) ? '' : sprintf("%01.2f", $aMieterinfo['zuschlag_betrag'] );
		$aAnlass['ZuschlagText'] = utf8_decode($aMieterinfo['zuschlag_text']);
		
		// get data directly from recordset - in case of no mieter set
		$aAnlass['Uid'] = $anlassUid;
		$aAnlass['Bemerkungen'] = utf8_decode($anlass->getBemerkungen());
		$aAnlass['Signatur'] = utf8_decode($anlass->getSchulleitungKurz());
		$aAnlass['SchulleitungDatum'] = '' == $anlass->getSchulleitungDatum() ? '' : $anlass->getSchulleitungDatum()->format('U');
		$aAnlass['CateringText'] = $anlass->getCateringText();
		$aAnlass['Verwendungszweck'] = utf8_decode($anlass->getVerwendungszweck());
		return $aAnlass;
	}
	
	public function timeFormat( $timeString ){
	    // use dbHelperUtility->cleanTimeString
	    // FIXME this dont work, it produces time like 08:03 instead of 08:30
	    $aT = strpos($timeString,':') ? explode(':' , $timeString ) : explode('.' , $timeString );
	    if( count($aT) != 2 ) return $timeString;
	    return sprintf( '%02s' , $aT[0] ) . ':' . sprintf( '%-02s' , $aT[1] );
	}
}
