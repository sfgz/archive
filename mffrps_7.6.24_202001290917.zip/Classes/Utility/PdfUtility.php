<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
 
// $extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName('typo3conf/ext/contrib/Resources/Private/PHP/fpdf/');
// define( 'FPDF_FONTPATH' , $extDir .  'font/' ); 
// set_include_path($extDir);
// include $extDir.'PdfRotatePagegroup.php';
// 

/**
 * Class PdfUtility
 * 
 */

class PdfUtility {

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();

	/**
	* errors
	*
	* @var array
	*/
	public $errors = array();

	/**
	* data
	*
	* @var array
	*/
	public $data = array();

	/**
	 * pdfService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	Public $pdfService = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	Public $pageConf = array(
		'lineWidth'=>array( 0.1 , 0.2  , 0.5 ) , 
		'specchars'=>array( 'laquo'=>171 , 'raquo'=>187 , 'copy'=>169 , 'registered'=>174 , 'at'=>64 ) , 
		'firstHeaderFooterNames' => array( 'page1'=>1 , 'seite1'=>1 , 1=>1 ) , 
		'keywords'=>'' , 
		'fontfamily'=>'Helvetica' , 
		'fsize'=>8 , 
		'lfeed'=>4 , 
		'pfeed'=>8 , 
		'zeroY'=>36 , 
		'docuwidth'=>210 , 
		'marginTop'=>15 , 
		'marginRight'=>15 , 
		'marginBottom'=>15 , 
		'marginLeft'=>25 , 
		'pdf_signature_height'=>10 , 
		'dataOptions' => array( 'cut_overflow'=>'split' , 'min_rows'=>18  )
	  );
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( $settings ) {
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->pdf = new \Mff\Mffrps\Utility\PdfWriterUtility();
		$this->settings = $settings;
		// if a optionfield in settings compares to a option in pageConf then overwrite pageConf
		foreach( $settings['optionfields'] as $optionname => $setting ){
		      if(isset($setting['value']) && isset($this->pageConf[$optionname]) ) $this->pageConf[$optionname] = $setting['value'];
		}
	}
	
	public function putPdf( $data , $type ) {
		$newData = $this->createPdf( $data , $type );
		if( $this->settings['debug'] ) return $newData;
		return $this->pdf->Output($this->data['main']['##Filename##'], 'I');
	}
	public function putPdfAsString( $data , $type ) {
		$this->createPdf( $data , $type );
		return $this->pdf->Output($this->data['main']['##Filename##'], 'S');
	}
	
	public function createPdf( $data , $type ) {
		// load template-file if available
		$aTemplate = $this->loadTemplate($type.'.csv');
		if(!count($aTemplate)) {
		      $this->errors[] = 'Vorlage '.$type.'.csv nicht gefunden';
		      return false; // catched error
		}
		
		// if multiple set, loop 
		if( !is_array($data['multiple']) ) {
		      $data['multiple'][] = $data;
		}
		//if( $this->settings['debug'] ) return $data;
		
		foreach( $data['multiple'] as $pageNr => $bodyData ){
		      // get data
		      $bodyData['main'] = $this->sortReplaceVariable( $bodyData['main'] , '##' );
		      $this->data = $bodyData;
		      // merge data and template
		      $templateData = $this->mergeDataAndTemplate( $aTemplate );
		      $this->prepareHeaderAndFooter( $templateData );
		      
		      // return data if debug-mode
		      if( $this->settings['debug'] ) $debug[$pageNr] = $this->data;
		      
		      // initialize fpdf
		      $this->pageConf['keywords'] = $this->data['main']['##Keywords##'] ;
		      $this->pdf->initializePdf($this->pageConf);
		      
		      $this->pdf->data = $this->data;
		      
		      $this->pdf->StartPageGroup();
		      $this->pdf->AddPage();
		      
		      $this->drawTemplate( $templateData );
		}
		//if( $this->settings['debug'] ) 
		return array( $type => $debug);
	}

	/**
	* drawTemplate
	* 
	* @param array $templateData
	* @return void
	*/
	public function drawTemplate( $templateData ){
		foreach( $templateData as $ix => $row){
		    if( 'datei' == strtolower($row[0]['contents'][0]['value']) ){
			  $oTmplFilename = trim($row[1]['contents'][0]['value']);
			  $sPagebreak =  $row[2]['contents'][0]['value'] ;
			  $this->drawIncludedTemplate( $oTmplFilename , $sPagebreak );
		    }else{
			$aInfoCell = explode( '_' , $row[0]['section']);
			if( 'HEADER' == $aInfoCell[0] ) continue;
			if( 'FOOTER' == $aInfoCell[0] ) continue;
			if( 'DATA' == $aInfoCell[0] && 'BODY' == $aInfoCell[1] ){
			      $this->drawTemplate_subdata( $row );
			}else{
			      // default: draw a single row from template
			      foreach( $row as $cNr => $cell ){
				  $this->pdf->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] , FALSE );
			      }
			}
		    }
		      
		}
	}

	/**
	* drawIncludedTemplate
	* 
	* @param array $row
	* @return void
	*/
	public function drawIncludedTemplate( $oTmplFilename , $sPagebreak ){
		$oTemplate = $this->loadTemplate( $oTmplFilename );
		if( !count($oTemplate) ) return;
		
		$otherDataTemplate = $this->mergeDataAndTemplate( $oTemplate );
		if( !count($otherDataTemplate) ) return;
		
		$this->prepareHeaderAndFooter( $otherDataTemplate );
		
		if(
		    !strpos( ' ' .strtolower( $sPagebreak ) , 'seitenumbruch' ) ||
		    strpos( strtolower( $sPagebreak ) , 'davor' ) ||
		    strpos( strtolower( $sPagebreak ) , 'before' ) 
		){
		    $this->pdf->AddPage();
		}
		
		$this->drawTemplate( $otherDataTemplate );
		
		if( 
		    strpos( strtolower( $sPagebreak ) , 'danach' ) || 
		    strpos( strtolower( $sPagebreak ) , 'behind' )
		){
		    $this->pdf->AddPage();
		}
	}

	/**
	* drawTemplate_subdata
	* 
	* @param array $row
	* @return int effective rows 
	*/
	public function drawTemplate_subdata( $row ){
// 		$minimalDataRows = $this->settings['optionfields']['pdf_min_rows']['value'];
		$minimalDataRows = $this->pageConf['dataOptions']['min_rows'];
		// draw multiple data-rows
		if( count($this->data['subdata']) ) {
		      $effectiveRows = 0;
		      $groupTagFoot = '';
		      $groupTagHead = '';
		      $countData=0;
		      foreach( $this->data['subdata'] as $belUid => $aBel ){
			    ++$countData;
			    // set sub-data as patterned main-data for each belegung-row
			    if(is_array($aBel)){
				  $this->pdf->data['main'] = $this->sortReplaceVariable( $aBel , '##' , $this->pdf->data['main']);
			    }
			    if( count($row[0]['groupedby']) ){
				  $grpSecInfo = explode( '_' , $row[0]['groupedby']['section'] );
// 				  if($grpSecInfo[count($grpSecInfo)-1]=='HEADER'){
					  $sFirst = $this->pdf->data['main'][ $row[0]['groupedby']['condFirst'] ];
					  if( 'format' == $row[0]['groupedby']['operator'] ){
						$dateFormat = empty($row[0]['groupedby']['arguments']) ? 'd.m.y' : $row[0]['groupedby']['arguments'];
						$weekday = is_numeric($sFirst) ? date( $dateFormat , $sFirst) : $sFirst;
					  }else{
						$weekday = $sFirst;
					  }
					  if(
						$countData == count($this->data['subdata']) ||
					      ( !empty($groupTagHead) && $groupTagHead != $weekday)
					  ) {
					      for( $cellNr = 1; $cellNr < count($row[0]['groupedby']['data']) ; ++$cellNr ){
						  $aOptions = $this->templateCellToArray( $row[0]['groupedby']['data'][$cellNr] );
						  $ln = count($row[0]['groupedby']['data']) == $cellNr + 1 ? 1 : 0 ;
						  $this->pdf->drawCsvCellContents( $aOptions , $row[0]['groupedby']['width'][$cellNr] , $row[0]['groupedby']['align'][$cellNr] , $ln , FALSE );
					      }
					  }
					  $groupTagHead = $weekday;
// 				 }
			    }
			    if( count($row[0]['condition']) ){
			    // hide subrows if affored
				  $condFirst = $this->pdf->data['main'][ $row[0]['condition']['condFirst'] ];
				  $operator = $row[0]['condition']['operator'];
				  $compares = $row[0]['condition']['compares'];
				  $testIfHide = $this->readCondition( $condFirst , $operator , $compares );
				  if($testIfHide) {
				      $maxCellRows[] = $minimalDataRows;
				      continue;
				  }
			    }
			    // loop template-rows and evaluate amount of rows in each cell
			    $maxCellRows[$belUid] = 1;
			    foreach( $row as $cNr => $cell ){
				// only cells with single value of type text
// 				if( $cell['contents'][0]['type'] == 'text' ){
				      $maxRows = 0;
				      $cellCollector[ $cNr ] = $this->pdf->getCellWidth( $cell['contents'] , $cell['width'] );
				      if( array_sum($cellCollector[ $cNr ]['stringWidth']) > $cell['width'] ){
					  if(count($cellCollector[ $cNr ]['stringAtoms'])){
						foreach( $cellCollector[ $cNr ]['stringAtoms'] as $idx => $sentences){
						      if( $maxRows < count($sentences) ) $maxRows = count($sentences);
						}
					  }else{ $maxRows = 0; }
					  $iRowCount[ $cNr ] = $maxRows;
				      }else{
					  $iRowCount[ $cNr ] = 0;
				      }
// 				}else{
// 				      $iRowCount[ $cNr ] = 0;
// 				}
				if( $maxCellRows[$belUid] < $iRowCount[ $cNr ] ) $maxCellRows[$belUid] = $iRowCount[ $cNr ];
			    }
			    // loop template-rows and fill with data from belegung-row
			    if( $maxCellRows[$belUid] > 1){
				  for( $cellRowNr = 0 ; $cellRowNr < $maxCellRows[$belUid] ; ++$cellRowNr ){
				      foreach( $row as $cNr => $cell ){
					    if( $iRowCount[ $cNr ] < $cellRowNr) {
						  foreach( array_keys($cell['contents']) as $ix){
						      $cell['contents'][$ix]['value'] = '';
						  }
					    }else{
						  foreach( array_keys($cell['contents']) as $ix){
							//if( $cell['contents'][$ix]['type'] == 'text' ){
							    $cell['contents'][$ix]['value'] = $cellCollector[ $cNr ]['stringAtoms'][$ix][$cellRowNr];
							//}
						  }
					    }
					    $isMiddleLine = $cellRowNr +1 < $maxCellRows[$belUid] ? TRUE : FALSE;
					    $this->pdf->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] , $isMiddleLine );
				      }
				  }
			    }else{
				  // draw multiple single-rows
				  foreach( $row as $cNr => $cell ){
				      $this->pdf->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] , false );
				  }
			    }
			    
			    if( count($row[0]['groupedby']) ){
				  $grpSecInfo = explode( '_' , $row[0]['groupedby']['section'] );
				  if($grpSecInfo[count($grpSecInfo)-1]=='FOOTER'){
					  if( $countData == count($this->data['subdata'])) {
					      for( $cellNr = 1; $cellNr < count($row[0]['groupedby']['data']) ; ++$cellNr ){
						  $aOptions = $this->templateCellToArray( $row[0]['groupedby']['data'][$cellNr] );
						  $ln = count($row[0]['groupedby']['data']) == $cellNr + 1 ? 1 : 0 ;
						  $this->pdf->drawCsvCellContents( $aOptions , $row[0]['groupedby']['width'][$cellNr] , $row[0]['groupedby']['align'][$cellNr] , $ln , FALSE );
					      }
					}
					$groupTagFoot = $weekday;
				  }
			    }
		      }
		      $effectiveRows = is_array($maxCellRows) ? array_sum($maxCellRows) : 0;
		}else{
		      $effectiveRows = 0;
		}
		// draw empty rows to fill up - if affored
		if( $effectiveRows < $minimalDataRows ){
			for( $x=1; $x <= ($minimalDataRows - $effectiveRows) ; ++$x ){
			    foreach( $row as $cNr => $cell ){
				foreach(array_keys($cell['contents']) as $atomIx) $cell['contents'][$atomIx]['value'] = '';
				$this->pdf->drawCsvCellContents( $cell['contents'] , $cell['width'] , $cell['align'] , $cell['ln'] , FALSE );
			    }
			}
		}
		return $effectiveRows;
	}


	/**
	* prepareHeaderAndFooter
	* 
	* @param array $templateData
	* @return void 
	*/
	public function prepareHeaderAndFooter( $templateData ){
		$this->collectHeaderAndFooterData( $templateData );
		// set flag wether row belongs to a first-header or to a following-header
		$mainSections = array( 'HEADER' , 'FOOTER' );
		$isNext = 0;
		foreach($mainSections as $ms){
		      if( !count($this->data[$ms]) ) continue;
		      foreach($this->data[$ms] as $ix => $row){
			  $aSectNames = explode( '_' , $row[0]['section'] );
			  $isFirst = $row[0]['section']==$ms  || isset( $this->pageConf['firstHeaderFooterNames'][strtolower($aSectNames[1])] ) ? 1 : 0;
			  foreach( $row as $cNr => $cell ){
			      $this->data[$ms][$ix][$cNr]['section_is_first'] = $isFirst ? 1 : 0;
			      $this->data[$ms][$ix][$cNr]['section_is_follow'] = empty($isFirst) ? 1 : 0;
			      $isNext += empty($isFirst) ? 1 : 0;
			  }
		      }
		      // if no header for following pages is defined then copy from first header
		      if( empty($isNext) ){
			    foreach($this->data[$ms] as $ix => $row){
				$newsect = $ms.'_FollowPages';
				$newIdx = count($this->data[$ms]);
				foreach( $row as $cNr => $cell ){
				    $row[$cNr]['section'] = $newsect;
				    $row[$cNr]['section_is_first'] = 0;
				    $row[$cNr]['section_is_follow'] = 1;
				}
				$this->data[$ms][$newIdx] = $row;
			    }
		      }
		}
	}

	/**
	* collectHeaderAndFooterData
	* 
	* @param array $templateData
	* @return void 
	*/
	public function collectHeaderAndFooterData( $templateData ){
		foreach( $templateData as $ix => $row){
		    if( 'datei' == strtolower($row[0]['contents'][0]['value']) ){
			  $oTemplate = $this->loadTemplate( trim($row[1]['contents'][0]['value']) );
			  if( !count($oTemplate) ) continue;
			  $otherDataTemplate = $this->mergeDataAndTemplate( $oTemplate );
			  if( !count($otherDataTemplate) ) continue;
			  $this->collectHeaderAndFooterData( $otherDataTemplate );
		    }else{
			$aInfoCell = explode( '_' , $row[0]['section']);
			if( 'HEADER' == $aInfoCell[0] || 'FOOTER' == $aInfoCell[0] ){
			      $this->data[$aInfoCell[0]][$ix] = $row;
			}
		    }
		}
	}

	/**
	* mergeDataAndTemplate
	* 
	* @param array $aTemplate
	* @return array 
	*/
	public function mergeDataAndTemplate( $aTemplate ) {

		// get csv-row configurations, eg. geometry or conditions
 		foreach($aTemplate as $ix => $tmplRow){
		    if( 'datei' == strtolower($tmplRow[0]) ) continue; // passthru, used in collectHeaderAndFooterData()
		    $aInfoCell = explode( '-' , $tmplRow[0]);
		    $section = $aInfoCell[count($aInfoCell)-1];
		    $act = strtolower($aInfoCell[0]);
		    
		    if( 'geo' == $act ){
			  $cellGeo[$section] = $this->readGeometryRow( $tmplRow );
			  unset($aTemplate[$ix]);
		    }elseif( 'dokument' == $act || 'document' == $act || 'seite' == $act || 'page' == $act ){
			 $this->readDocumentRow( $tmplRow );
			 unset($aTemplate[$ix]);
		    }elseif( 'groupedby' == $act ){
			$cellGeo['DATA_BODY']['group_set'] = array( 'condFirst' => trim($tmplRow[1]) , 'operator'=>trim($tmplRow[2]) , 'arguments'=>trim($tmplRow[3]) ,'section'=>$section );
			$cellGeo[$section]['group_ref'] = 'DATA_BODY';
			unset($aTemplate[$ix]);
		    }elseif( 'bedingung' == $act ){
			  $aCompInfoCell = explode( '_' , $section );
			  if( 'DATA' == $aCompInfoCell[0]  && 'BODY' == $aCompInfoCell[1] ){
				// dont check condition, but store arguments
				$cellGeo[$section]['condition_set'] = array( 'condFirst' => trim($tmplRow[1]) , 'operator'=>trim($tmplRow[2]) , 'compares'=>trim($tmplRow[3]) );
			  }else{
				// check condition and store resulting value ( 1 or 0 )
				$cellGeo[$section]['condition_hide'] = $this->readConditionRow( $tmplRow );
			  }
			  unset($aTemplate[$ix]);
		    }elseif( 'ref' == $act ){
			  $templateFile = trim($tmplRow[1]);
			  $otherTemplate = $this->loadTemplate($templateFile);
			  foreach($otherTemplate as $oIx => $oTmplRow){
			      $otherInfoCell = explode( '-' , $oTmplRow[0]);
			      if( 'geo-'.$section == $oTmplRow[0] ){
				    $cellGeo[$section] = $this->readGeometryRow( $oTmplRow );
			      }elseif($section == $oTmplRow[0]){
				    // add main- and data-rows from other template to this tamplate
				    $addToTemplate[$ix][$oIx] = $oTmplRow;
			      }
			  } // unset the array $aTemplate[$ix] later mandatory
		    }
 		}
 		
 		$newIdx = 0;
 		foreach($aTemplate as $ix => $tmplRow){
		    if(isset($addToTemplate[$ix])){
			foreach($addToTemplate[$ix] as $oTmplRow){
			    $newTemplate[$newIdx] = $oTmplRow;
			    ++$newIdx;
			}
			// mandatory: unset($aTemplate[$ix]);
		    }else{
			$newTemplate[$newIdx] = $tmplRow;
			++$newIdx;
		    }
 		}
 		
 		foreach($newTemplate as $idx => $tmplRow){
		    $aInfoCell = explode( '_' , $tmplRow[0]);
		    if(isset($cellGeo[$tmplRow[0]]['group_ref'])){ 
			  for($c=0;$c<count($cellGeo[$aInfoCell[0]]);++$c){
			      $cellGeo['DATA_BODY']['group_set']['width'][$c+1] = $cellGeo[$aInfoCell[0]][$c]['width'];
			      $cellGeo['DATA_BODY']['group_set']['align'][$c+1] = isset($cellGeo[$aInfoCell[0]][$c]['align']) ? $cellGeo[$aInfoCell[0]][$c]['align'] : 'L';
			  }
			  $cellGeo['DATA_BODY']['group_set']['data'] = $tmplRow;
			  unset($newTemplate[$idx]);
		    }
 		}
 		
 		// merge template rows and draw data-contents 
 		foreach($newTemplate as $idx => $tmplRow){
		    // dont draw row, if row is disabled by condition_hide
		    if(isset($cellGeo[$tmplRow[0]]['condition_hide'])){
			  if(!empty($cellGeo[$tmplRow[0]]['condition_hide']) ) continue;
		    }
		    
		    if(isset($cellGeo[$tmplRow[0]]['condition_set'])){
			  $aRowCondition = $cellGeo[$tmplRow[0]]['condition_set'];
		    }else{
			  $aRowCondition = array();
		    }
		    
		    if(isset($cellGeo[$tmplRow[0]]['group_set'])){
			  $aRowGroup = $cellGeo[$tmplRow[0]]['group_set'];
		    }else{
			  $aRowGroup = array();
		    }
		    
		    // if sectionname is 'datei' then append to array but dont analyze row any further
		    if( 'datei' == strtolower($tmplRow[0]) ) {
			foreach(  $tmplRow as $cellIx => $tmlCell ){
			      $dataCells[$idx][$cellIx] = array( 'section'=>$tmplRow[0] , 'contents'=> array( 0 => array( 'type'=>'text' , 'value'=>$tmplRow[$cellIx]))   );
			}
			continue; 
		    }
		    
// 		    eg geo-DATA defines format for DATA_TITLE, DATA_BODY and DATA_FOOT
		    $aInfoCell = explode( '_' , $tmplRow[0]);
		    $section = $aInfoCell[0];
		    $insertedCell = 0;
		    foreach( array_slice( $tmplRow , 1 ) as $cellNr => $tmlCell ){
			  if(isset($cellGeo[$section][$cellNr]['width'])){
			      $width = $cellGeo[$section][$cellNr]['width'];
			      $align = isset($cellGeo[$section][$cellNr]['align']) ? $cellGeo[$section][$cellNr]['align'] : 'L';
			  }else{
			      if( count($tmplRow) == 1+$cellNr ){ // last cell
				  $width = $cellGeo[$section][ count($cellGeo[$section])-1 ]['width'];
			      }else{
				  $width = 0;
			      }
			  }
			  $string = utf8_decode($tmlCell);
			  $ln = count($tmplRow) == 2 + $cellNr ? 1 : 0;
			  $aOptions = $this->templateCellToArray( $string );
 			  $dataCells[$idx][$cellNr+$insertedCell] = array( 'section'=>$tmplRow[0] , 'condition'=>$aRowCondition , 'groupedby'=>$aRowGroup , 'contents'=>$aOptions , 'width'=>$width , 'align'=>$align , 'ln'=>$ln   );
			  if($cellGeo[$section][$cellNr]['additionalCell']){
				++$insertedCell;
				$aOptions = $this->templateCellToArray( '' );
				$width = $cellGeo[$section][$cellNr]['additionalCell'];
				// dont do this: $ln = count($tmplRow) == 2 + 1 + $cellNr ? 1 : 0;
				$dataCells[$idx][$cellNr+$insertedCell] = array( 'section'=>$tmplRow[0] , 'condition'=>$aRowCondition , 'groupedby'=>$aRowGroup , 'contents'=>$aOptions , 'width'=>$width , 'align'=>$align , 'ln'=>$ln   );
			  }
		    }
 		}
		return $dataCells;
	}
	
	/**
	* templateCellToArray
	* search for advices in double braces and returns them as an array
	* returns a 2-dim array  array[ position ][ fieldname ] = value
	* 
	* Sucht nach Anweisungen in doppelten Klammern 
	* Geht Anweisungen durch, erkennt den typ, setzt entsprechende Optionen, sucht nach voran- und nachgestelltem Text 
	* und gibt alle Werte in einem 2-dimensionalen Array zurueck: array[ position ][ feldname ] = wert 
	* 
	* @param string $cellContent
	* @return array
	*/
	public function templateCellToArray( $cellContent ) {
	      if( empty($cellContent) ) return array( 0 => array( 'type'=>'text' , 'value'=>'') );
	      $newOpt = array();
	      $advice = array();
	      // suche nach Anweisungen in doppelten Klammern und sammle sie in einm array
	      for( $pos = 0 ; $pos < strlen($cellContent) ; ++$pos){
		  $newString = substr( $cellContent , $pos);
		  $firstOpener = strpos( ' ' . $newString , '((' );
		  if(!$firstOpener) { // if there are no advices handle as text
		      $newOpt[$pos] = array( 'type'=>'text' , 'value'=>$newString);
		      break;
		  }
		  $firstOpener +=1;
		  $firstCloser = strpos( $newString , '))' );
		  $advice[$firstOpener+$pos] = ( substr( $newString , $firstOpener , $firstCloser-$firstOpener ) );
		  $pos+=$firstCloser+1;
	      }
	      // gehe Anweisungen durch, 
	      // erkenne den typ, setzte entsprechende Optionen 
	      // suche nach voran- und nachgestelltem Text und sammle alles
	      $lastPos = 0;
	      foreach($advice as $pos=>$opt){
		  $aFieldSplit = explode( ':' , $opt );
		  if( $pos > 0 && count($aFieldSplit) >1 ){
		      $preString = substr($cellContent , $lastPos , $pos-$lastPos-2 );
		      $prePieces = explode( ' ' , $preString );
		      $preWord = $prePieces[ count($prePieces) -1 ];
		      if(count($prePieces) > 1){
			    $unformLeadingString = implode( ' ' , array_slice( $prePieces , 0 , count($prePieces)-1 ));
			    $newOpt[$lastPos] = array( 'type'=>'text' , 'value'=>$unformLeadingString.' ');
		      }
		      $type = $aFieldSplit[0];
		      $nIdx = $pos-strlen($preWord)-2;
		      $wordOptions = implode( ' ' , array_slice($aFieldSplit , 1) );
		      if( 'signatur' == $type ){
			    // if image is available replace with image-path
			    $imagePathname = $this->getSignatureImage_pathname( $this->data['main'][$preWord] );
			    if(empty($imagePathname)){ // handle as text
				$newOpt[$nIdx] = array( 'type'=>'text' , 'value'=>$preWord );
			    }else{ // handle as image
				$newOpt[$nIdx] = array( 'type'=>$type , 'value'=>$imagePathname , 'options'=>$wordOptions );
			    }
		      }else{
			    $newOpt[$nIdx] = array( 'type'=>$type , 'value'=>$preWord , 'options'=>$wordOptions );
		      }
		  }else{
		      $type = count($aFieldSplit) >1 ? $aFieldSplit[0] : 'text';
		      $wordOptions = count($aFieldSplit) >1 ? implode( ' ' , array_slice($aFieldSplit , 1) ) : '';
		      if( count($advice) == 1 ){
			    $newOpt[0] = array( 'type'=>$type , 'value'=>substr( $cellContent , 0 , $pos-2), 'options'=>$wordOptions); 
		      }else{
			    $preString = substr($cellContent , $lastPos , $pos-$lastPos-2 );			
			    $newOpt[$lastPos] = array( 'type'=>$type , 'value'=>$preString , 'options'=>$wordOptions ); 
		      }
		      $newOpt[$pos] = array('type'=>'fieldformat' , 'options'=>$opt);
		  }
		  $lastPos = $pos + strlen($opt)+2 ;
	      }
	      
	      if(count($newOpt)) ksort($newOpt);
	      return $newOpt;
	}
	
	/**
	* readDocumentRow
	* 
	* @param array $tmplRow
	* @return array
	*/
	public function readDocumentRow( $tmplRow ) {
// 	      $aInfoCell = explode( '-' , $tmplRow[0]);
// 	      $act = strtolower($aInfoCell[0]);
	      foreach( $tmplRow as $cx => $cellValue){
		    if( empty($cellValue) ) continue;
		    $aVarValPair = explode( ':' , $cellValue );
		    if( count($aVarValPair) != 2 ) continue;
		    $aNames = explode( '.' , $aVarValPair[0] );
		    if(count($aNames)==1){
			$this->pageConf[ $aNames[0] ] = $aVarValPair[1];
		    }elseif(count($aNames)==2){
			$this->pageConf[ $aNames[0] ][ $aNames[1] ] = $aVarValPair[1];
		    }elseif(count($aNames)==3){
			$this->pageConf[ $aNames[0] ][ $aNames[1] ][ $aNames[2] ] = $aVarValPair[1];
		    }
	      }
	      
	}
	
	/**
	* readConditionRow
	* 
	* @param array $tmplRow
	* @return int
	*/
	public function readConditionRow( $tmplRow ) {
	      $condFirst = $this->data['main'][trim($tmplRow[1])];
	      $operator = $tmplRow[2];
	      $compares = $tmplRow[3];
	      return $this->readCondition( $condFirst , $operator , $compares );
	}
	
	/**
	* readCondition
	* returns $isSwitchSetToOff 
	* true for hide the row, 
	* false for show 
	* 
	* @param string $condFirst
	* @param array $tmplRow
	* @return int
	*/
	public function readCondition( $condFirst , $operator , $compares ) {
	      $isSwitchSetToOff = 0;
	      
	      $condNames = array(
		  'null'=>  array( 'null'     => 1 , 'false'    => 1 , 'falsch' => 1 ),
		  'not'=>   array( 'not'   => 1 , 'ungleich' => 1 , 'nicht'  => 1 ),
		  'equal'=> array( 'equal' => 1 , 'gleich'   => 1 ),
		  'true'=> array( 'true' => 1 , 'wahr' => 1 , 'nichtleer'   => 1 ),
	      );
	      
	      if(
		  isset( $condNames['null'][strtolower($operator)] ) ||
		  empty($compares)
	      ){
		  $isSwitchSetToOff = empty( $condFirst ) ? 1 : 0;
	      }else{
		    $showRow = 0;
		    if(
			  trim($operator) == '=' ||
			  isset( $condNames['equal'][strtolower($operator)] )
		    ){
			  $showRow = ($condFirst == trim($compares) );
		    }elseif(
			  isset( $condNames['true'][strtolower($operator)] )
		    ){
			  $showRow = ( !empty($condFirst) );
		    }elseif(
			  trim($operator) == '!=' || 
			  isset( $condNames['not'][strtolower($operator)] )
		    ){
			  $showRow = ($condFirst != trim($compares) );
		    }elseif(trim($operator) == '>'){
			  $showRow = ($condFirst > trim($compares) );
		    }elseif(trim($operator) == '<'){
			  $showRow = ($condFirst < trim($compares) );
		    }
		    $isSwitchSetToOff = empty($showRow) ? 1 : 0;
	      }
	      return $isSwitchSetToOff;
	}
	
	/**
	* readGeometryRow
	* 
	* @param array $tmplRow
	* @return array
	*/
	public function readGeometryRow( $tmplRow ) {
	      foreach( array_slice( $tmplRow , 1 ) as $cellNr => $tmlCell ){
		    $width = '';
		    $align = '';
		    $nextCellWidth = '';
		    $aParts = explode( '-' , $tmlCell );
		    foreach( $aParts as $opt){
			  $option = trim($opt);
			  if( strtoupper($option) == 'L' || strtoupper($option) == 'C' || strtoupper($option) == 'R' ){
				$align = strtoupper($option);
			  }elseif( strpos( $option , '+' ) ){
				$aIsAssumedCell = explode( '+' , $option );
				$nextCellWidth = $aIsAssumedCell[1];
				$width = $aIsAssumedCell[0];
			  }elseif( is_numeric($option) ){
				$width = $option;
			  }
		    }
		    $cellGeo[$cellNr] = array( 'width' => $width , 'align' => $align , 'additionalCell' => $nextCellWidth);
	      }
	      return $cellGeo;
	}
	
	/**
	* getSignatureImage_pathname
	* returns imagePathname
	* 
	* @param string $username
	* @return string
	*/
	public function getSignatureImage_pathname( $username ) {
		$signatureDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
		$signatureFiles = $this->systemOptionsUtility->readInDir($signatureDir) ;
		$userSignature = array_search( $username , $signatureFiles );
		if(empty($userSignature)) return false;
		return $signatureDir.$userSignature;
	}

	public function loadTemplate( $templatename ) {
		$userTemplatePath = 'uploads/tx_mffrps/templates/';
		$userTemplateDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($userTemplatePath) , '/' ) . '/';
		if( file_exists( $userTemplateDir.$templatename ) ){
		    return $this->readTemplate($userTemplateDir.$templatename);
		}
		$fixTemplatePath = 'typo3conf/ext/mffrps/Resources/Public/templates/';
		$fixTemplateDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($fixTemplatePath) , '/' ) . '/';
		if( file_exists( $fixTemplateDir.$templatename ) ){
		    return $this->readTemplate($fixTemplateDir.$templatename);
		}
		return array();
	}
	
	public function readTemplate( $templatepathname ) {
		$row = 0;
		$outArr = array();
		if (($handle = fopen($templatepathname, "r")) !== FALSE) {
		    while (($aData = fgetcsv($handle, 10000, "," , '"')) !== FALSE) {
			if(strlen(trim($aData[0]))==0){continue;}
			$num = count($aData);
			for ($c=0; $c < $num; $c++) {
			    $outArr[$row][$c] = iconv( 'ISO-8859-15' , 'utf-8' , $aData[$c]);
			    
			}
			$row++;
		    }
		    fclose($handle);
		}
		return $outArr;
	}
	
	
	/**
	 * sortReplaceVariable
	 * same as in class DbHelperUtitlity
	 *
	 * @param array $repVar Fieldnames as array-names, replace as values. 
	 * @param string $pattens mandatory eg. ## for trmplating
	 * @param array $aRpl mandatory array to append Data on 
	 * @return array
	 */
	public function sortReplaceVariable( $repVar , $pattens='' , $aRpl = array() ) {
	      if( !is_array($repVar) ) return $aRpl;
	      $toSortRepl = array();
	      // create array with string-length as value, but keeping the array-keys
	      foreach( array_keys($repVar) as $fieldName ) $toSortRepl[$fieldName]=strlen($fieldName);
	      // sort descendent by keeping assotiations 
	      arsort($toSortRepl);
	      // now only use the array-keys 
	      foreach( array_keys($toSortRepl) as $fieldName ) {
		  $aRpl[$pattens.$fieldName.$pattens] = $repVar[$fieldName] ; 
	      }
	      return $aRpl;
	}
	
	
}
