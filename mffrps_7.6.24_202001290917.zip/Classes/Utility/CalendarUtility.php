<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class CalendarUtility
 */

class CalendarUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * calendarNames
	 *
	 * @var array
	 */
	Public $calendarNames = array() ;
	
	/**
	 * settings
	 *
	 * @var array
	 */
	Public $settings = array() ;
	
	/**
	 * errors
	 *
	 * @var array
	 */
	Public $errors = array() ;

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * calendarService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	Public $calendarService = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
		$this->calendarService = new \Mff\Mffrps\Service\CalendarService( $this->settings );
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();
	}

	/**
	* createEventFromBelegung
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @return void
	*/
	function createEventFromBelegung( \Mff\Mffrps\Domain\Model\Belegung $belegung ) {
	      $objZimmer = $belegung->getBelZimmer();
	      if( !$objZimmer ) return false;
	      $calendarName = $this->getCalendarByRoom( $objZimmer );
	      $eventArr = $this->belegungObj2calendarArr($belegung , $calendarName );
	      if(is_array($eventArr)) $this->calendarService->calendarPutData( $eventArr , $calendarName , 'create_'.microtime(true) );
	      return $calendarName;
	}

	/**
	* refreshEventsFromBelegungen
	* used by scheduler in RefreshCalendarCommandController
	* 
	* Usage of optional param limitation $aLimitDays:
	* 'from' = days in past neagtive values possible
	* 'to' = days in future neagtive values possible
	*
	* @param array $aBelegungen
	* @param array $aLimitDays days offset from/to
	* @return void
	*/
	function refreshEventsFromBelegungen( $aBelegungen , $aLimitDays = array( 'from'=>2 , 'to'=>730 )) {
 	    if( !$aBelegungen ) return FALSE;
 	    $aCalendars = $this->getCalendarsData( 0 );
	    $calArr = $this->calendarNames[ FALSE ];
	    $now = time();
	    $calendarNames = array();
	    $roomIds = array();
	    $belegungCalObj = array();
	    $belCalendarRecords = array();
	    
	    // sample belegung data
	    foreach($aBelegungen as $belegung){
		$objDate = $belegung->getDatum();
		if( !$objDate ) continue;
		
		$belUid = $belegung->getUid();
		$calUid = $this->createCalendarUid( $belUid , $belegung->getCrdate() );
		$belCalendarRecords[$calUid] = $calUid;
		
		$datum = $objDate->format('U');

		// 3+2 years ago 
		// $aLimitDays = array( 'from'=>1095 , 'to'=>-365 )

		// 1 year ago until 1/2 year ago
		// $aLimitDays = array( 'from'=>365 , 'to'=>-182 )

		// past 1/2 year
		// $aLimitDays = array( 'from'=>183 , 'to'=>0 )

		// from the day before yesterday up to 2 years in future
		// $aLimitDays = array( 'from'=>2 , 'to'=>730 )

		if( $datum + (3600 * 24 * $aLimitDays['from']) < $now ) continue;
 		if( $datum > $now + (3600 * 24 * $aLimitDays['to']) ) continue;
		
		$objZimmer = $belegung->getBelZimmer();
		if( !$objZimmer ) continue;
		
		$roomId = $objZimmer->getUid();
 		$belegungCalObj['datum'][$calUid] = $datum;
 		$belegungCalObj['belUid'][$calUid] = $belUid;
 		$belegungCalObj['roomId'][$calUid] = $roomId;
 		$roomIds[$roomId] = $objZimmer;
 		
		if( !isset( $aCalendars[ $calUid ] ) ){ 
		    $belegungCalObj['create'][$calUid] = $belegung;
 		}else{
		    $belegungCalObj['update'][$calUid] = $belegung;
 		}
 		
	    }
	    
	    // sample calendarNames
	    if(is_array($roomIds)){
		  foreach( $roomIds as $roomId => $roomObj ){
		      if( !isset($calendarNames[ $roomId ]) ){
			    if( isset($calArr['Roomcals'][$roomId]) ) {
				$calendarNames[ $roomId ] = $calArr['Roomcals'][$roomId];
			    }else{
				$belHaus = $roomObj->getHaus();
				if( isset($calArr['Housecals'][$belHaus]) ) $calendarNames[ $roomId ] = $calArr['Housecals'][$belHaus];
			    }
		      }
		  }
	    }
	    
	    // prepare array to create calendarEvents
	    if(is_array($belegungCalObj['create'])){
		  foreach( $belegungCalObj['create'] as $calUid => $belegung ){
		      $roomId = $belegungCalObj['roomId'][$calUid];
		      $objZimmer = $roomIds[$roomId];
		      $presetOptions = array(
			    'calendarUid' => $calUid,
			    'belegungUid' => $belegungCalObj['belUid'][$calUid],
			    'datum' => $belegungCalObj['datum'][$calUid],
			    'calendarName' => $calendarNames[ $roomId ],
			    'zimmer' => $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer()
		      );
		      $calendarEventArr[$calendarNames[ $roomId ]][$calUid] = $this->belegungObj2calendarArrPresetOpt($belegung , $presetOptions );
		  }
	    }
	    
	    // prepare array to update calendarEvents
	    if(is_array($belegungCalObj['update'])){
		  foreach( $belegungCalObj['update'] as $calUid => $belegung ){
		      // evaluate sequence
		      // get old calendar name and retrieve calendars data - read every calendar only once
		      $oldCalendarName = $aCalendars[$calUid]['kalender'];
		      if( !isset( $calendarsArr[ $oldCalendarName ] ) ){
			  $calendarsArr[ $oldCalendarName ] = $this->calendarService->calendarReadData( $oldCalendarName , 0 );
		      }
		      $iSequence = 0;
		      // get sequence from old calendar if set
		      if( isset($calendarsArr[ $oldCalendarName ][ $calUid ]['sequence']) ) $iSequence = $calendarsArr[ $oldCalendarName ][ $calUid ]['sequence'];
		      // get sequence from new calendar if set
		      $roomId = $belegungCalObj['roomId'][$calUid];
		      $newCalendarName  = $calendarNames[ $roomId ];
		      if( empty($iSequence) && $newCalendarName != $oldCalendarName ){
			    if(!isset($calendarsArr[ $newCalendarName ])) $calendarsArr[ $newCalendarName ] = $this->calendarService->calendarReadData( $newCalendarName , 0 );
			    if( isset($calendarsArr[ $newCalendarName ][ $calUid ]['sequence']) ) $iSequence = $calendarsArr[ $newCalendarName ][ $calUid ]['sequence'];
		      }
		      // increase sequence
		      $iSequence = empty($iSequence) ? 1 : 1 + $iSequence;
		      
		      // evaluate presetOptions
		      $presetOptions = array(
			    'calendarUid' => $calUid,
			    'belegungUid' => $belegungCalObj['belUid'][$calUid],
			    'datum' => $belegungCalObj['datum'][$calUid],
			    'calendarName' => $newCalendarName,
			    'zimmer' => $roomIds[$roomId]->getHaus() . ' ' . $roomIds[$roomId]->getZimmer()
		      );
		      
		      // create event-array with ingredients $belegung, $iSequence ans $presetOptions
		      $calendarEventArr[$newCalendarName][$calUid] = $this->belegungObj2calendarArrPresetOpt($belegung , $presetOptions , $iSequence );
		      // enrich event-array with status and sequence
		      if(is_array($calendarEventArr[$newCalendarName][$calUid])){
			  $calendarEventArr[$newCalendarName][$calUid]['STATUS'] = 'CONFIRMED';
			  $calendarEventArr[$newCalendarName][$calUid]['SEQUENCE'] = $iSequence;
		      }
		      
		  }
	    }
	    
	    // prepare array to delete orphan calendar-entries
	    if( count($aCalendars) ){
		  foreach($aCalendars as $calUid => $oldCalendarEntry ){
			if(!isset($belCalendarRecords[$calUid])){
			  $calendarEventArr[$oldCalendarEntry['kalender']][$calUid]['UID'] = $calUid;
			  $calendarEventArr[$oldCalendarEntry['kalender']][$calUid]['STATUS'] = 'CANCELLED';
			  $iSequence = $calendarsArr[ $oldCalendarEntry['kalender'] ][ $calUid ]['sequence'] ;
			  $calendarEventArr[$oldCalendarEntry['kalender']][$calUid]['SEQUENCE'] = 1 +$iSequence;
			}
		  }
	    }
	    
	    // run through prepared array and put Data to calendar
	    if(is_array($calendarEventArr)){
		foreach( $calendarEventArr as $calendarName=>$eventArr ){
		    $this->calendarService->calendarPutData( $eventArr , $calendarName , 'create_'.microtime(true) );
		}
	    }
	    return true;
	}

	/**
	* updateEventFromBelegung
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @param string $oldCalendarName
	* @return void
	*/
	function updateEventFromBelegung( \Mff\Mffrps\Domain\Model\Belegung $belegung , $oldCalendarName = '' ) {
	      
	      $belArr = $this->belegungObj2belegungArr($belegung);
	      if( empty($belArr['replace']['_Kalender_']) ) return;
	      
	      $belArr['main']['STATUS'] = 'CONFIRMED';
	      $calendarEventArr[$belArr['replace']['_Kalender_']][$belArr['main']['UID']] = $belArr;
	      
	      if( !empty($oldCalendarName) && $oldCalendarName != $belArr['replace']['_Kalender_'] ){
		    $belArr['main']['STATUS']  = 'CANCELLED';
		    $calendarEventArr[$oldCalendarName][$belArr['main']['UID']] = $belArr;
	      }
	      return $this->appendBelegungDataToUpdateFile($calendarEventArr);
	      
// 	      $iSequence = 0;
// 	      $calendarUid = $this->createCalendarUid( $belegung->getUid() , $belegung->getCrdate() );
// 	      
// 	      if(!empty($oldCalendarName)) {
// 		    // if moved from old calendar, get sequence from there 
// 		    $calendarsArr = $this->calendarService->calendarReadData( $oldCalendarName , 0 );
// 		    if( isset($calendarsArr[ $calendarUid ]['sequence']) ) $iSequence = $calendarsArr[ $calendarUid ]['sequence'];
// 	      }
// 
// 	      // get sequence from new calendar if set
// 	      $objZimmer = $belegung->getBelZimmer();
// 	      if( !$objZimmer ) return false;
// 	      $calendarName = $this->getCalendarByRoom( $objZimmer );
// 	      if( empty($iSequence) && $calendarName != $oldCalendarName ){
// 		    $calendarsArr = $this->calendarService->calendarReadData( $calendarName , 0 );
// 		    if( isset($calendarsArr[ $calendarUid ]['sequence']) ) $iSequence = $calendarsArr[ $calendarUid ]['sequence'];
// 	      }
// 	      $iSequence += 1; //empty($iSequence) ? 1 : 1 + $iSequence;
// 
// 	      $eventArr = $this->belegungObj2calendarArr( $belegung , $calendarName , $iSequence );
// 	      if(is_array($eventArr)){
// 		  $eventArr['STATUS'] = 'CONFIRMED'; // $eventArr['SEQUENCE'] = $iSequence; // done by belegungObj2calendarArr()
// 		  $this->calendarService->calendarPutData( $eventArr , $calendarName , 'update_'.microtime(true) );
// 	      }
	}

	/**
	* appendBelegungDataToUpdateFile
	* expects a 4-dim array[ $calName ][ $calUid ][ 'main' | 'replace' ][ $fieldname ] = value
	*
	* @param array $calendarEventArr 4-dim array
	* @return void
	*/
	function appendBelegungDataToUpdateFile( $calendarEventArr ) {
		// build filename
		$filename = 'deferredCalendars.txt';
		$uploadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
		$uploadedFileName = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $uploadDir.'calendar/'.$filename ) ;
		
		// read file
		$oldDb = !file_exists($uploadedFileName) ? array() : unserialize( file_get_contents($uploadedFileName) );
		
		// append rows to array
		foreach($calendarEventArr as $calname => $calRows){
		    foreach($calRows as $calUid => $persRow){
			  $oldDb[$calname][$calUid] = $persRow;
		    }
		}
		
		// store in file
		file_put_contents( $uploadedFileName , serialize($oldDb) );
		
	    return true;
	}

	/**
	* sendDataFromUpdateFile
	*
	* @return array
	*/
	function sendDataFromUpdateFile() {
	    // build filename
	    $filename = 'deferredCalendars.txt';
	    $uploadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
	    $uploadedFileName = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $uploadDir.'calendar/'.$filename ) ;
	    if( !is_file($uploadedFileName) ) return false;
	    
	    // read file
	    $calendarEventArr = unserialize( file_get_contents($uploadedFileName) );
	    @unlink($uploadedFileName);
	    if( !is_array($calendarEventArr) ) return false;
	    
	    // processing calendars data: insert sequence and str_replace SUMMARY + DESCRIPTION
	    foreach($calendarEventArr as $calname => $calRows){
		// read calendars data to evaluate sequence
		$calendarsArr[ $calname ] = $this->calendarService->calendarReadData( $calname , 0 );
		foreach($calRows as $calUid => $persRow){
		      // sample belegung data and insert sequence
		      $iSequence = 1+$calendarsArr[ $calname ][ $calUid ]['sequence'];
		      $persRow['replace']['_BearbeitungNr_'] = $iSequence;
		      $eventArr = $persRow['main'];
		      $eventArr['INTERN'] = $persRow['replace']['_Intern_'];
		      $eventArr['BELSTS'] = $persRow['replace']['_Status_'];
		      $eventArr['LOCATION'] = $persRow['replace']['_Zimmer_'] ;
		      $eventArr['SEQUENCE'] = $iSequence;
		      $eventArr['SUMMARY'] =  $this->dbHelperUtility->replaceTemplatestring( $persRow['replace'] , $this->settings['optionfields']['backup_exportfields_calendar_subject']['value'] );
		      $eventArr['DESCRIPTION'] =  $this->dbHelperUtility->replaceTemplatestring( $persRow['replace'] , $this->settings['optionfields']['backup_exportfields_calendar_text']['value']);
		      $calendarRow[ $calname ][ $eventArr['STATUS'] ][ $calUid ] = $eventArr;
		}
	    }
	    if( !is_array($calendarRow) ) return false;
	    
	    // build files and send them
	    $aStatusString = array( 'CANCELLED' => 'DELETE', 'CONFIRMED' => 'PUBLISH' );
	    foreach($calendarRow as $calname => $stsRows){
		foreach($stsRows as $STATUS => $eventDB){
			$aCnt = array();
			$aCnt[] = "BEGIN:VCALENDAR";
			$aCnt[] = "PRODID:Zimbra-Calendar-Provider";
			$aCnt[] = "VERSION:2.0";
			$aCnt[] = 'METHOD:' . $aStatusString[$STATUS];
			foreach($eventDB as $aEvent) $aCnt[] = $this->calendarService->mkICS4event($aEvent);
			$aCnt[] = "END:VCALENDAR";
			$content = implode( "\n" , $aCnt) . "\n";
			$filename = 'flushDeferredCalendar_' . $calname . '_' . $STATUS . '.ics';
			$this->calendarService->calendarSendDataFromIcsFile( $filename , $content , $calname );
		}
	    }
	    return true;
	}

	/**
	* belegungObj2belegungArr
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @return array
	*/
	function belegungObj2belegungArr( \Mff\Mffrps\Domain\Model\Belegung $belegung){
	      
	      $objDatum = $belegung->getDatum();
	      if(!$objDatum) return false;
	      
	      $objZimmer = $belegung->getBelZimmer();
	      if( !$objZimmer ) return false;
	      
	      $calendarName = $this->getCalendarByRoom( $objZimmer );

	      $belUid = $belegung->getUid();
	      $UID = $this->createCalendarUid( $belUid , $belegung->getCrdate() );
	      
	      
	      $aMieterInfos = $this->dbHelperUtility->getBelegungMieterInfos();
	      
	      $uxDatum = $objDatum->format('U');
	      $aZtAb = explode(':',$belegung->getAb());
	      $aZtBis = explode(':',$belegung->getBis());
	      
	      $aBelegung = array(
		  'main' => array(
			'UID'        => $UID, 
			'DTSTART'        => mktime( $aZtAb[0] , $aZtAb[1] , 0 ,  date('m',$uxDatum) , date('d',$uxDatum) , date('y',$uxDatum)  ), 
			'DTEND'        => mktime( $aZtBis[0] , $aZtBis[1] , 0 ,  date('m',$uxDatum) , date('d',$uxDatum) , date('y',$uxDatum)  ), 
		  ),
		  'replace' => array(
			'_Text_'        => $belegung->getBelegungstext() , 
			'_Zusatztext_'  => $belegung->getZusatztext()  , 
			'_Betrag_'  => $belegung->getBetrag()  , 
			'_Status_'  => $belegung->getStatus()  , 
			'_BearbeitungNr_'  => 0 ,
			'_Kurzbezeichnung_'  => $aMieterInfos[$belUid]['Kurz']  , 
			'_Verwendungszweck_'  => $aMieterInfos[$belUid]['Verwendungszweck']  , 
			'_Email_'  => $aMieterInfos[$belUid]['Email']  , 
			'_Name_'  => $aMieterInfos[$belUid]['Name']  , 
			'_Telefon_'  => $aMieterInfos[$belUid]['Telefon']  , 
			'_Intern_'  => $aMieterInfos[$belUid]['intern'] ? 1 : 0, 
			'_Kalender_'  => $calendarName , 
			'_Zimmer_'  => $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer()
		  )
	      );
	      
	      return $aBelegung;
	}

	/**
	* deleteEventFromBelegung
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @param string $calendarName
	* @return void
	*/
	function deleteEventFromBelegung( \Mff\Mffrps\Domain\Model\Belegung $belegung , $calendarName = '' ) {
	      if(empty($calendarName)) {
		    $objZimmer = $belegung->getBelZimmer();
		    if( !$objZimmer ) return false;
		    $calendarName = $this->getCalendarByRoom( $objZimmer );
	      }
	      $calendarUid = $this->createCalendarUid( $belegung->getUid() , $belegung->getCrdate() );
	      $this->deleteEventByUid( $calendarName , $calendarUid  );
	}

	/**
	* deleteEvent
	*
 	* @param string $calendarName
 	* @param int $calendarUid events calendar uid
	* @return void
	*/
	function deleteEventByUid( $calendarName , $calendarUid  ) {
	      $calendarsArr = $this->calendarService->calendarReadData( $calendarName , 2 );
	      
	      $eventArr['UID'] = $calendarUid;
	      $eventArr['STATUS'] = 'CANCELLED';
	      if( isset($calendarsArr[ $calendarUid ]['sequence']) ) { $eventArr['SEQUENCE'] =  1 + $calendarsArr[ $calendarUid ]['sequence']; } else{$eventArr['SEQUENCE'] =  1;}
	      return $this->calendarService->calendarPutData( $eventArr , $calendarName , 'delete_'.microtime(true) );
	}

	/**
	* belegungObj2calendarArr
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @param string $calendarName
	* @param int $sequence
	* @return array
	*/
	function belegungObj2calendarArr( \Mff\Mffrps\Domain\Model\Belegung $belegung , $calendarName = '' , $sequence = 1) {
	      $belUid = $belegung->getUid();
	      $objDatum = $belegung->getDatum();
	      if(!$objDatum) return false;
	      $datum = $objDatum->format('U');
	      $objZimmer = $belegung->getBelZimmer();
	      if( !$objZimmer ) return false;
	      if(empty($calendarName)){
		  $calendarName = $this->getCalendarByRoom( $objZimmer );
	      }
	      $UID = $this->createCalendarUid( $belUid , $belegung->getCrdate() );
	      $presetOptions = array(
		    'belegungUid' => $belUid,
		    'calendarUid' => $UID,
		    'datum' => $datum,
		    'calendarName' => $calendarName,
		    'zimmer'  => $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer()
	      );
	      return $this->belegungObj2calendarArrPresetOpt( $belegung , $presetOptions , $sequence );
	}

	/**
	* belegungObj2calendarArrPresetOpt
	*
	* @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	* @param array $presetOptions
	* @param int $sequence
	* @return array
	*/
	function belegungObj2calendarArrPresetOpt( \Mff\Mffrps\Domain\Model\Belegung $belegung , $presetOptions , $sequence = 1) {
	      
	      $aMieterInfos = $this->dbHelperUtility->getBelegungMieterInfos();
	      
	      $belUid = $presetOptions['belegungUid'];
	      $aZtAb = explode(':',$belegung->getAb());
	      $aZtBis = explode(':',$belegung->getBis());
	      $rep = array(
		  '_Text_'        => $belegung->getBelegungstext() , 
		  '_Zusatztext_'  => $belegung->getZusatztext()  , 
		  '_Betrag_'  => $belegung->getBetrag()  , 
		  '_Status_'  => $belegung->getStatus()  , 
		  '_BearbeitungNr_'  => $sequence ,
		  '_Kurzbezeichnung_'  => $aMieterInfos[$belUid]['Kurz']  , 
		  '_Verwendungszweck_'  => $aMieterInfos[$belUid]['Verwendungszweck']  , 
		  '_Email_'  => $aMieterInfos[$belUid]['Email']  , 
		  '_Name_'  => $aMieterInfos[$belUid]['Name']  , 
		  '_Telefon_'  => $aMieterInfos[$belUid]['Telefon']  , 
		  '_Intern_'  => $aMieterInfos[$belUid]['intern'] ? 1 : 0, 
		  '_Kalender_'  => $presetOptions['calendarName'] , 
		  '_Zimmer_'  => $presetOptions['zimmer']
	      );
	      
	      $eventArr = array();
	      $datum = $presetOptions['datum'];
	      $eventArr['UID'] = $presetOptions['calendarUid'];
	      $eventArr['DTSTART'] = mktime( $aZtAb[0] , $aZtAb[1] , 0 ,  date('m',$datum) , date('d',$datum) , date('y',$datum)  );
	      $eventArr['DTEND'] = mktime( $aZtBis[0] , $aZtBis[1] , 0 ,  date('m',$datum) , date('d',$datum) , date('y',$datum)  );
	      $eventArr['INTERN'] = $rep['_Intern_'];
	      $eventArr['BELSTS'] = $rep['_Status_'];
	      $eventArr['SEQUENCE'] = $rep['_BearbeitungNr_'];
	      $eventArr['SUMMARY'] =  $this->dbHelperUtility->replaceTemplatestring( $rep , $this->settings['optionfields']['backup_exportfields_calendar_subject']['value'] );
	      $eventArr['DESCRIPTION'] =  $this->dbHelperUtility->replaceTemplatestring( $rep , $this->settings['optionfields']['backup_exportfields_calendar_text']['value']);
	      $eventArr['LOCATION'] = $rep['_Zimmer_'] ;
	      return $eventArr;
	}
	
	/**
	* getCalendarsData
	* if $excludeAutoGeneratedEvents
	* true:  uid has to match calendar_uid_incredentials pattern from settings
	* false: uid must not match! (2: show all)
	* 
	* @param bool $excludeAutoGeneratedEvents 
	* @return array
	*/
	public function getCalendarsData( $excludeAutoGeneratedEvents = 1 ) {
	    $calDB = array();
	    $sortDB = array();
	    $sortedDb = array();
	    $backupCalendars = $this->getCalendarsNames( $excludeAutoGeneratedEvents );
	    $zimmerRepository = $this->zimmerUtility->getZimmerRepository();
	    foreach( $backupCalendars as $type => $tGroup ){
		foreach( $tGroup as $calId => $kalendername ){
		    $calArr = $this->calendarService->calendarReadData( $kalendername , $excludeAutoGeneratedEvents );
		    if( $calArr == NULL ) continue;
		    if(!is_array($calArr))continue;
		    
		    foreach($calArr as $ix=>$cal){
			  $loc = empty($cal['location']) ? ' Ort:(keiner)' : ' Ort:' .$cal['location'];
			  $strCal = empty($kalendername) ? ' Kalender:(keiner)' : ' Kalender:' .$kalendername;
			  if($type == 'Roomcals'){
				$zimmerUid = $calId;
			  }else{
				$rawLocation = trim( str_replace( '_' , ' ' , trim($cal['location']) ) );
				if(empty($rawLocation)){
				      $zimmerUid = '';
				}else{
				      if($type == 'Housecals'){
					  if( strpos( ' '.$rawLocation , $calId ) == 1 ){
					      $rawLocation = trim( substr( $rawLocation , strlen($calId) ) );
					  }
					  $rawLocation = trim( $calId . ' ' . $rawLocation );
				      }
				      $zimmersObjs = $zimmerRepository->findByRoom( $rawLocation , TRUE );
				      if($zimmersObjs){
					    foreach($zimmersObjs as $zimmerObj){
						  $zimmerUid = $zimmerObj->getUid();
						  break;
					    }
				      }
				}
			  }
			  $calDB[$cal['uid']] = $cal;
			  $calDB[$cal['uid']]['kalender'] = $kalendername;
			  $calDB[$cal['uid']]['zimmer'] = $zimmerUid;
			  $calDB[$cal['uid']]['text'] = trim( $cal['notes'] . $loc . $strCal ) ;
			  // sort by date
			  $sortDB[$cal['uid']] = $cal['datum'];
		    }
		    
		}
	    }
	    // sort by date
	    if(!is_array($sortDB)) return $calDB;
	    asort($sortDB);
	    foreach(array_keys($sortDB) as $idx){ $sortedDb[$idx] = $calDB[$idx];}
	    
	    // return array
	    return $sortedDb;
	}

	/**
	* getCalendarByRoom
	* returns name of calendar corresponding to zimmer of belegung
	*  Zimmerkalender if zimmer-uid compares to a Zimmerkalender-key
	*  Hauskalender if haus compares  to a Hauskalender-key
	*  default is calendar
	*  
	* @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	* @return string
	*/
	function getCalendarByRoom( \Mff\Mffdb\Domain\Model\Zimmer $zimmer ) {
	      $calArr = $this->getCalendarsNames( FALSE );
	      // Zimmerkalender
	       $belRoomId = $zimmer->getUid();
	       if( isset($calArr['Roomcals'][$belRoomId]) ) return $calArr['Roomcals'][$belRoomId];
	      // Hauskalender
	       $belHaus = $zimmer->getHaus();
	       if( isset($calArr['Housecals'][$belHaus]) ) return $calArr['Housecals'][$belHaus];

	      return $this->settings['optionfields']['backup_calendar']['value'];
	}
	
	/**
	* getCalendarsNames
	*
	* @param bool $respectRestrictions
	* @return array
	*/
	public function getCalendarsNames( $respectRestrictions = TRUE ) {
	    if( is_array($this->calendarNames[$respectRestrictions]) ){
		return $this->calendarNames[$respectRestrictions];
	    }
	    
	    $options = $this->settings['optionfields'];
	    $backupCalendars = array( 'Calendar' => array($options['backup_calendar']['value']) );
	    
	    $aImportCals = explode(',' , $options['backup_importcals']['value']);
	    foreach( $aImportCals as $calendars) $backupCalendars['Importcals'][$calendars] = $calendars;
	    
	    if(!$options['backup_importall']['value'] && $respectRestrictions ) {
		  $this->calendarNames[$respectRestrictions] = $backupCalendars;
		  return $backupCalendars;
	    }
	    
	    $calsList['Housecals'] = explode(',' , $options['backup_housecals']['value']);
	    $calsList['Roomcals'] = explode(',' , $options['backup_roomcals']['value']);
	    foreach( $calsList as $type=>$calType){
		foreach( $calType as $calPair){
			$aCal = explode( ':' , trim($calPair) );
			$backupCalendars[$type][$aCal[0]] = $aCal[1];
		}
	    }
	    
	    $this->calendarNames[$respectRestrictions] = $backupCalendars;
	    return $backupCalendars;
	}

	/**
	* createCalendarUid
	*
	* @param string $belUid
	* @param string $createDate
	* @return string
	*/
	function createCalendarUid( $belUid , $createDate ) {
	      $credential = $this->settings['calendar_uid_incredentials'];
	      return  $credential[0]. '-'. $belUid . '-' .$credential[1]. '-' . $createDate . '-'.$credential[2]  ;
	}
	
}
