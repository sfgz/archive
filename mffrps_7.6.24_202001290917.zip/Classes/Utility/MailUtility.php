<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class MailUtility
 */

class MailUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;

	/**
	 * pdfDbUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfDbUtility = NULL;

	/**
	 * pdfUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfUtility = NULL;

	
	protected $objectManager ;

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->settings['baseURL'] = $fullsettings['config.']['baseURL'];

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		$this->belegungRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		$this->pdfDbUtility = new \Mff\Mffrps\Utility\PdfDbUtility( $this->settings );
		$this->pdfUtility = new \Mff\Mffrps\Utility\PdfUtility( $this->settings );
	}
	
	/**
	 * sendNewsletterWochenliste
	 * deelay is set to 3 days - view next week after sunday + deelay
	 * from monday until wednesday we need (old) pdf from this week, 
	 * from thursday to Sunday on we need pdf for next week
	 * e.g. Sunday + 3 days until wednesday / Sunday + 5 days until friday
	 *
	 * @param array $adressList
	 * @return void
	 */
	public function sendNewsletterWochenliste( $adressList = array('dani@verarbeitung.ch') ) {
			$naechsteWoche = time() + (3600 * 24 * (7-$this->settings['optionfields']['info_wochenliste_delay']['value']) );
			
			$wochen = $this->pdfDbUtility->getDatumwerteWochen( $naechsteWoche , $this->settings['optionfields']['info_wochenliste_weeks']['value'] );
			$data = $this->pdfDbUtility->getWochenlisteByWochenForPdf( $wochen );
			$output = $this->pdfUtility->putPdfAsString( $data , 'wochenliste');
	      
			if( count($wochen) <= 2 ){
				$listing=implode( ' und ' , array_keys($wochen) );
			}else{
				$aNamWochen = array_keys($wochen);
				$aHead = array_shift( $aNamWochen );
				$aTail = array_pop( $aNamWochen );
				$listing.= $aHead . ' bis ' . $aTail;
			}
	      
			$wochentext = count($wochen)>1 ? 'Wochen' : 'Woche';
			
			$message ='Im Anhang der Wochenplan mit den Raummieten der ' . $wochentext;
			$message .=' <b>';
			$message .= $listing;
			$message .= '</b>.';
			$message .= '<ul>';
			foreach($wochen as $wNr=>$dates){ 
				if(!isset($subject)) $subject = 'Raumplanung ab '.date( 'd.m.y' , $dates['date']); 
				$message .= '<li>Woche Nr. '.$wNr.' vom '.date('d.m.y',$dates['date']).' bis '.date('d.m.y',$dates['todate']).'.</li>'; 
			}
			$message.='</ul>';
			
			$aFrom = array($this->settings['optionfields']['backup_user']['value'] => 'Raumplanung');
			$dateiname = 'Raummieten_W'. implode( '_' , array_keys($wochen) ).'.pdf';
			
			if(!count($this->pdfUtility->errors)){
				$anzahlWochen = $this->settings['optionfields']['info_wochenliste_weeks']['value']>1 ?  $this->settings['optionfields']['info_wochenliste_weeks']['value'] . ' Wochen' : '1 Woche';
				$footertext = 'Die Anzahl aufgelisteter Wochen wird in der Raumplanung unter <i>Optionen/Systemoptionen/Email</i> festgelegt. Aktueller Wert ist ' . $anzahlWochen.'. <br />';
				$mail = $this->wrapMessageWithHtmlBodyframe( $message , $footertext );
				// Create the attachment with your data
				$attachment = \Swift_Attachment::newInstance($output, $dateiname , 'application/pdf');
				// Attach it to the message
				$mail->attach($attachment);
				$mail->setSubject( $subject );
				$mail->setFrom( $aFrom );
				foreach( $adressList as $emailadress ){
				$mail->setTo( array( $emailadress ) );
				$mail->send();
				}
			}
			return true;
	}
	
	/**
	 * sendWithAttatchment
	 * used by sendmailAction() in AnlassController
	 *
	 * @param array $mailData
	 * @return void
	 */
	public function sendWithAttatchment( $mailData ) {
	      $mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
	      foreach( $mailData['Attatchments'] as $dateiname=> $output){
		    $attachment = \Swift_Attachment::newInstance($output, $dateiname , 'application/pdf');
		    $mail->attach($attachment);
	      }
	      $mail->setBody( $mailData['Body'] , 'text/html' );
	      $mail->setSubject( $mailData['Subject'] );
	      $mail->setFrom( $mailData['From'] );
	      $mail->setTo( $mailData['To'] );
	      if( count($mailData['Cc']) ) $mail->setCc( $mailData['Cc'] );
	      if( count($mailData['Bcc']) ) $mail->setBcc( $mailData['Bcc'] );
	      $mail->send();
	      return true;
	}
	
	/**
	 * mailToAntragsteller
	 * used when created belegung from Antrag
	 * in belegungController createAction() an sucheAction()
	 * swift usage: https://docs.typo3.org/typo3cms/CoreApiReference/ApiOverview/Mail/Index.html#mail-swift
	 *
	 * @param array $arrBelegungObjs array with belegung-objects
	 * @param srtring $emailadress adress to mail 
	 * @return void
	 */
	public function mailToAntragsteller( $arrBelegungObjs , $emailadress ) {

		$subject = 'Raumplanung Antrag bearbeitet';
		
		$aFrom = array($this->settings['optionfields']['backup_user']['value'] => 'Raumplanung');

		// Create the message
		$message = "Der Antrag wurde bearbeitet: \n";
		foreach($arrBelegungObjs as $belegung){
		    $roomObj = $belegung->getBelZimmer();
		    $message .= $belegung->getDatum()->format('d.m.y') . ' ';
		    $message .= $roomObj->getHaus() . ' ' . $roomObj->getZimmer() . ' ';
		    $message .= $belegung->getAb() . '-';
		    $message .= $belegung->getBis() . '. ';
		    $message .= " \n";
		}
		
		$mail = $this->wrapMessageWithHtmlBodyframe( $message );
		$mail->setSubject( $subject );
		$mail->setFrom( $aFrom );
		$mail->setTo( array( $emailadress ) );
		$mail->send();
		return $message;
	}
	
	/**
	 * wrapMessageWithHtmlBodyframe
	 *
	 * @param srtring $message
	 * @param srtring $footertext
	 * @return void
	 */
	public function wrapMessageWithHtmlBodyframe( $message , $footertext = '' ) {
			$imageDir = rtrim($this->settings['baseURL']  , '/' ) . '/';
			$imagePath = $imageDir . 'typo3conf/ext/mffdesign/Resources/Public/images/logo.svg';
			$mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
			$embedImage = $mail->embed(\Swift_Image::fromPath($imagePath));
			$bodyText =  '<div style="color:#222;">';
			$bodyText .= str_replace( "\n" , "<br />" , $message);
			$bodyText .= '</div>';
			$bodyText .= '<div style="font-size:9pt;color:#999;padding-top:10px;">';
			$bodyText .= '<p>' . $footertext;
			$bodyText .= 'Diese Nachricht wurde automatisch generiert.</p>';
			$bodyText .= '<img src="' . $embedImage . '" alt="Image" width="280px;" />';
			$bodyText .= '</div>';
			$mail->setBody( $bodyText , 'text/html' );
			return $mail;
	}

}
