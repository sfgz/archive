<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TimetableUtility
 *  get values from settings.optionfields
 *  returns ZimmerRepository
 * 
 */

class TimetableUtility implements \TYPO3\CMS\Core\SingletonInterface {
	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	* querySettings
	*
	* @var array
	*/
	protected $querySettings = array();
	
	/**
	 * objectManager
	 *
	 * @var \TYPO3\CMS\Extbase\Object\ObjectManager
	 */
	protected $objectManager ;

	/**
	 * timetableRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TimetableRepository
	 */
	protected $timetableRepository = NULL;

	/**
	 * stundenplanRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\StundenplanRepository
	 */
	protected $stundenplanRepository = NULL;

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 */
	protected $fachRepository = NULL;

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * kalenderRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KalenderRepository
	 */
	protected $kalenderRepository = NULL;

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
// 	      $this->typoScriptUtility = new \Mff\Mffrps\Utility\TypoScriptUtility();
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->getSettings();

	      $this->timetableRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\TimetableRepository');
	      $this->timetableRepository->setDefaultQuerySettings($this->querySettings);

	      $this->stundenplanRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\StundenplanRepository');
	      $this->stundenplanRepository->setDefaultQuerySettings($this->querySettings);

	      $this->fachRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
	      $this->fachRepository->setDefaultQuerySettings($this->querySettings);

	      $this->fachbereichRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachbereichRepository');
	      $this->fachbereichRepository->setDefaultQuerySettings($this->querySettings);

	      $this->kalenderRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KalenderRepository');
	      $this->kalenderRepository->setDefaultQuerySettings($this->querySettings);
	}
	
	/**
	 * getKalenderRepository
	 * 
	 * @return void
	 */
	public function getKalenderRepository() {
	    return $this->kalenderRepository;
	}
	
	/**
	 * getTimetableRepository
	 * 
	 * @return void
	 */
	public function getTimetableRepository() {
	    return $this->settings['allowForeignTimetable'] ? $this->timetableRepository : $this->stundenplanRepository;
	}
	
	/**
	 * getArrayByRoomsAndDate
	 * used by extension Mffrps Raumplanung
	 *
	 * @param array  $zimmerArr uids of rooms, or empty
	 * @param integer $datum as unixTimestamp
	 * @return void
	 */
	public function getArrayByRoomsAndDate( $zimmerArr = array() , $datum ){
	      $ttGrouped = array();
	      $ttContent = array();
	      $calendarObj = $this->kalenderRepository->findInTimerange( floor( $datum / 86400) * 86400 );

	      $ttRepos = $this->getTimetableRepository();
	      $zmrTimetable  = $ttRepos->findByRoomsAndDate( $zimmerArr , $datum );

	      foreach( $zmrTimetable as $ttRecord){
		  $ttRecord['time_from'] = substr($ttRecord['time_from'],0,5);
		  $ttRecord['time_to'] = substr($ttRecord['time_to'],0,5);
		  $atDatStart = $this->settings['allowForeignTimetable'] ? explode('-' , $ttRecord['date_start']) : explode('-' , date( 'Y-m-d' , $ttRecord['date_start'] ));
		  $iDiffWeeks = date( 'W' , $datum ) - date( 'W' , mktime( 6,0,0, $atDatStart[1] , $atDatStart[2] , $atDatStart[0] ) );
		  // show only if ( diff between startweek and searchweek ) devided by periodicity has no rest
		  if($ttRecord['periodicity']){if( ( $iDiffWeeks ) % $ttRecord['periodicity'] != 0 ) continue;}
		  $ttGrouped[$ttRecord['uid'].$ttRecord['time_from']]['class'][$ttRecord['class_short']] = $ttRecord['class_short'];
		  $ttGrouped[$ttRecord['uid'].$ttRecord['time_from']]['content'] = $ttRecord;
	      }
	      foreach( $ttGrouped as $uidRecord){
		  $ttRecord = $uidRecord['content'];
		  $ttRecord['class_short'] = implode( '/' , $uidRecord['class'] );
		  $numbHowerFrom = 0 + str_replace( ':' , '.' , $ttRecord['time_from'] );
		  $numbHowerTo = 0 + str_replace( ':' , '.' , $ttRecord['time_to'] );
		  $howerFrom = floor( $numbHowerFrom );
		  $howerTo = floor( $numbHowerTo );
		  $minFrom = round(($numbHowerFrom-$howerFrom)*100); // eg. 5
		  $minTo = round(($numbHowerTo-$howerTo)*100); // eg. 55
		  $nametext = substr($ttRecord['first_name'],0,1) . '. ' . $ttRecord['last_name'];
		  $tFrom = round(($howerFrom * 60) + $minFrom);
		  // ignore Ferien (vacations) as defined in subject (Fach)
		  // Faecher ohne Ferien
		  $ignoreVacationCss = $ttRecord['ignore_vacation'] ? 'vacationShow' : 'vacationHide';

		  // ignore school-happenings like teacher-meetings (holiday) as defined in Fachbereich
		  // ignore_holiday bei Weiterbildung / Grundbildung-Kursen (unechten Feachern) leer, sonst 0 oder 1
		  if( $ttRecord['ignore_holiday'] == '' ) {
		      $fachObjs = $this->fachRepository->findByFachkurz( $ttRecord['fachkurz'] );
		      foreach($fachObjs as $fachObj){ 
			    $objRegel = $fachObj->getFachKursregel();
			    if( !$objRegel ) continue;
			    $fbUid = $objRegel->getFachbereich();
			    $fbObj = $this->fachbereichRepository->findByUid( $fbUid );
			    $ttRecord['ignore_holiday'] = $fbObj->getIgnoreHoliday(); 
			    break;
		      }
		  }
		  $ignoreHolidayCss = $ttRecord['ignore_holiday'] ? 'holidayShow' : 'holidayHide';
		  // Periode,Lehrperson,Fach,Fachlang,Fachbemerkung,Klasse
		  
		  $atDatStart = $this->settings['allowForeignTimetable'] ? explode('-' , $ttRecord['date_start']) : explode('-' , date( 'Y-m-d' , $ttRecord['date_start'] ));
		  $atDatEnd =  $this->settings['allowForeignTimetable'] ? explode('-' , $ttRecord['date_end']) : explode('-' , date( 'Y-m-d' , $ttRecord['date_end'] ));
		  $name = ltrim( substr($ttRecord['first_name'],0,1).'. '.$ttRecord['last_name'] , '.' );
		  $ttContent[  $ttRecord['uid'] ] = array(
			'uid' => $ttRecord['uid'] , 
			'type' => 'timetable', 
			'tiptext' => 'tiptext', 
			'belegungstext' => $name.' '.$ttRecord['class_short'],
			'class_short' => $ttRecord['class_short'], 
			'date_start' => mktime( 6,0,0, $atDatStart[1] , $atDatStart[2] , $atDatStart[0] ), 
			'date_end' => mktime( 6,0,0, $atDatEnd[1] , $atDatEnd[2] , $atDatEnd[0] ), 
			'fachbezeichnung' => $ttRecord['fachbezeichnung'], 
			'fachkurz' => $ttRecord['fachkurz'], 
			'teacherId' => $ttRecord['teacherId'], 
			'last_name' => $ttRecord['last_name'], 
			'name' => $name, 
			'status' => 101, 
			'ignore_vacation' => $ttRecord['ignore_vacation'], 
			'ignore_holiday' => $ttRecord['ignore_holiday'], 
			'holidayCss' => $ignoreVacationCss.' '.$ignoreHolidayCss, 
			'numAb' => $numbHowerFrom, 
			'numBis' => $numbHowerTo, 
			'ab' => sprintf( '%02s' , $howerFrom ) . ':' . sprintf( '%02s' , $minFrom ),
			'bis' => sprintf( '%02s' , $howerTo ) . ':' . sprintf( '%02s' , $minTo )
		  );
	      }
	      return $ttContent;
	}
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	public function getSettings( ){
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$settings = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['settings.'];//['optionfields.']
		$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $settings );

		$this->settings['allowForeignTimetable'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['foreignTimetable'];

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$storage['planStoragePid'] = $fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$storage['foreignStoragePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		return $querySettings;
	}
	
	

}