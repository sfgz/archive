<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TagesansichtUtility
 */

class TagesansichtUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
	}

	/**
	* sortMergedBelegung
	*
	* @param array $rawBelegung
	* @return array
	*/
	public function sortMergedBelegung( $rawBelegung ) {
		$aBelegung = array();
		$z=10000; // keep sort order
		if( is_array($rawBelegung) ){
		      foreach( $rawBelegung as $zimmerIdx=>$zmrBel ){
			    $aSrtBelegung = array();
			    foreach($zmrBel as $itemIdx=>$belegung){
				  $aSrtBelegung[$belegung['ab'].'-'.$z] = $belegung;
				  ++$z;
			    }
			    ksort($aSrtBelegung);
			    // FIXME: how can $belg['uid'] be empty? it happen when we seek in tagesansicht for Building 'lp' and day 1. Jun 2018. 
			    // but no Problems on the same day for all buildings (*) or belegunliste
			    foreach($aSrtBelegung as $belg) if(!empty($belg['uid'])) $aBelegung[$zimmerIdx][$belg['uid']] = $belg;
		      }
		}
		return $aBelegung;
	}

	/**
	* calcTimesInBelegung
	*
	* @param array $rawBelegung
	* @param boolean $disableHook
	* @return void
	*/
	public function calcTimesInBelegung( $rawBelegung , $disableHook = false ) {
		if( is_array($rawBelegung) ){
		      foreach( $rawBelegung as $zimmerIdx=>$zmrBel ){
			    foreach($zmrBel as $itemIdx=>$belegung){
				  $cleanTiemString = $this->dbHelperUtility->cleanTimeString($belegung['ab']);
				  
				  if( empty($cleanTiemString) ){echo ' empty('.$itemIdx.') ';continue;}
				  
				  $numbHowerFrom = 0 + str_replace( ':' , '.' ,  $cleanTiemString);
				  $decHowerTo = str_replace( ':' , '.' , $belegung['bis']);
				  $numbHowerTo = is_numeric($decHowerTo) ? 0 + $decHowerTo:0;
				  $howerFrom = floor( $numbHowerFrom );
				  $howerTo = floor( $numbHowerTo );
				  $minFrom = round(($numbHowerFrom-$howerFrom)*100) ; // eg. 5
				  $minTo = round(($numbHowerTo-$howerTo)*100) ;// eg. 55
				  $aTimeValues = $this->hookCalcTimesInBelegung_timerange( $howerFrom , $minFrom , $howerTo , $minTo , $disableHook );
				  
				  $aBelegung[$zimmerIdx][$itemIdx] = $belegung;
				  $aBelegung[$zimmerIdx][$itemIdx]['uid'] = $itemIdx;
				  $aBelegung[$zimmerIdx][$itemIdx]['otFrom'] = (60 * $howerFrom) + $minFrom;
				  $aBelegung[$zimmerIdx][$itemIdx]['otTo'] = (60 * $howerTo) + $minTo;
				  $aBelegung[$zimmerIdx][$itemIdx]['tFrom'] = (60 * $aTimeValues['howerFrom']) + $aTimeValues['minFrom'];
				  $aBelegung[$zimmerIdx][$itemIdx]['tTo'] = (60 * $aTimeValues['howerTo']) + $aTimeValues['minTo'];
// 				  $aBelegung[$zimmerIdx][$itemIdx]['ab'] = sprintf( '%02s' , $aTimeValues['howerFrom'] ) . ':' . sprintf( '%02s' , $aTimeValues['minFrom'] );
// 				  $aBelegung[$zimmerIdx][$itemIdx]['bis'] = sprintf( '%02s' , $aTimeValues['howerTo'] ) . ':' . sprintf( '%02s' , $aTimeValues['minTo'] );
				  $aBelegung[$zimmerIdx][$itemIdx]['ab'] = $this->dbHelperUtility->cleanTimeString( $belegung['ab'] );
				  $aBelegung[$zimmerIdx][$itemIdx]['bis'] = $this->dbHelperUtility->cleanTimeString( $belegung['bis'] );
				  $aBelegung[$zimmerIdx][$itemIdx]['hFrom'] = $aTimeValues['howerFrom'];
				  $aBelegung[$zimmerIdx][$itemIdx]['mFrom'] = $aTimeValues['minFrom'];
				  $aBelegung[$zimmerIdx][$itemIdx]['hTo'] = $aTimeValues['howerTo'];
				  $aBelegung[$zimmerIdx][$itemIdx]['mTo'] = $aTimeValues['minTo'];
				  $aBelegung[$zimmerIdx][$itemIdx]['css-borderclass'] = count($aTimeValues['aBorderClass']) ? implode( ' ' , $aTimeValues['aBorderClass'] ) : '';
			    }
				  
		      }
		      return $aBelegung;
		}
	}

	/**
	* hookCalcTimesInBelegung_timerange
	* hook for calcTimesInBelegung
	* limitates entries and set css-borders
	* to fit in timeranges
	* by cutting start- or/and end-time
	*
	* @param int $howerFrom
	* @param int $minFrom
	* @param int $howerTo
	* @param int $minTo
	* @param boolean $disabled
	* @return array
	*/
	public function hookCalcTimesInBelegung_timerange( $howerFrom , $minFrom , $howerTo , $minTo , $disabled = false) {
		$aBorderClass = array();
		if( $disabled ) return array( 'howerFrom'=>$howerFrom , 'minFrom'=>$minFrom , 'howerTo'=>$howerTo , 'minTo'=>$minTo ,'aBorderClass'=>$aBorderClass );
		$timeRangeFrom = $this->settings['optionfields']['filter_startTimeFrom']['value'] + $this->settings['filter']['filter_tagesplan_timerange_from'] ;
		$timeRangeTo = 1 + $this->settings['optionfields']['filter_startTimeFrom']['value'] + $this->settings['filter']['filter_tagesplan_timerange_to'] ; 
		if( $howerFrom < $timeRangeTo && $howerTo >= $timeRangeFrom ){
		    if( $howerFrom < $timeRangeFrom ){
			$howerFrom = $timeRangeFrom;
			$minFrom = 0; 
			$aBorderClass[] = 'noborder-left';
		    }
		    if( $howerTo == $timeRangeTo ){
			if( $minTo > 0 ){
			    $aBorderClass[] = 'noborder-right';
			    $minTo = 0;
			}
		    }
		    if( $howerTo > $timeRangeTo ){
			$howerTo = $timeRangeTo;
			$minTo = 0;
			$aBorderClass[] = 'noborder-right';
		    }
		}
	      return array( 'howerFrom'=>$howerFrom , 'minFrom'=>$minFrom , 'howerTo'=>$howerTo , 'minTo'=>$minTo ,'aBorderClass'=>$aBorderClass );
	}
	

	/**
	* evaluateRowNumbers
	*
	* @param array $aBelegung
	* @return array
	*/
	public function evaluateRowNumbers( $aBelegung ) {
		// evaluate amount of rows per zimmer
		$setBlankCell = array();
		$row_belegung = array();
		if( is_array($aBelegung) ){
		      foreach( $aBelegung as $zimmerIdx=>$zmrBel ){
			    foreach($zmrBel as $itemIdx=>$belegung){
				    $z= $this->findNextZimmerRowInTagesansicht( $row_belegung[$zimmerIdx] , 0 , $belegung);
				    $row_belegung[$zimmerIdx][$z][$itemIdx] = $belegung;
			    }
			    // evaluate blank cells
			    $setBlankCell[$zimmerIdx] = $this->calcBlankCellsInTagesansicht( $row_belegung[$zimmerIdx] );
		      }
		}
		return $setBlankCell;
	}
	
	/**
	* findNextZimmerRowInTagesansicht
	*
	* @param array $rowReservation
	* @param int $z
	* @param array $reservation
	* @return int
	*/
	public function findNextZimmerRowInTagesansicht( $rowReservation , $z , $reservation ) {
	      if(!is_array($rowReservation[$z])){
		  return $z;
	      }else{
		  $conflict = 0;
		  foreach($rowReservation[$z] as $setReservation){
		      if( 
			  $setReservation['tFrom'] < $reservation['tTo'] && $setReservation['tTo'] > $reservation['tFrom']
		      ){ $conflict = 1; break; }
		  }
		  if(!$conflict) return $z;
		  return $this->findNextZimmerRowInTagesansicht( $rowReservation , $z+1 , $reservation );
	      }
	}

	/**
	* calcBlankCellsInTagesansicht
	*
	* @param array $aBelegung
	* @return array
	*/
	public function calcBlankCellsInTagesansicht( $aBelegung ) {
		$timeMatrix = array();
		for ( $x = 0 ; $x <= $this->settings['optionfields']['filter_maxHowers']['value'] ; ++$x) $timeMatrix[ $this->settings['optionfields']['filter_startTimeFrom']['value'] + $x ] = $x;
		$loopCount = 0;
		$blankCell = array();
		$setBlankCell = array();
		foreach(array_keys($aBelegung) as $zimmerIdx){
		      $loopCount = 0;
		      foreach($aBelegung[$zimmerIdx] as $itemIdx=>$belegung){
			    $blankCell[$zimmerIdx][$loopCount]['obj'] = $belegung;
			    // set first 'from'-cell
			    if( 0 == $loopCount ){
				$blankCell[$zimmerIdx][$loopCount]['from'] = (60 * $belegung['hFrom']);
				$blankCell[$zimmerIdx][$loopCount]['hFrom'] = $belegung['hFrom'];
			    }
			    $blankCell[$zimmerIdx][$loopCount]['to'] = $belegung['tFrom'];
			    $blankCell[$zimmerIdx][$loopCount]['hTo'] = $belegung['hFrom'];
			    ++$loopCount;
			    $blankCell[$zimmerIdx][$loopCount]['from'] = $belegung['tTo'];
			    $blankCell[$zimmerIdx][$loopCount]['hFrom'] = $belegung['hTo'];
			     // set last cell 'to' - all others get overwritten
			    $blankCell[$zimmerIdx][$loopCount]['to'] = (60 * $belegung['hTo'])+60;
			    $blankCell[$zimmerIdx][$loopCount]['hTo'] = $belegung['hTo'];
		      }
		      
		      foreach($blankCell[$zimmerIdx] as $loopCount=>$cell){
			  if( $cell['hFrom'] == $cell['hTo'] ){
			  // einleitendes blank innerhalb derselben Stunde
			      $timeIdx = $timeMatrix[$cell['hFrom']];
			      $setBlankCell['from'][$zimmerIdx][$timeIdx][$loopCount] = $cell['from'];
			      $setBlankCell['to'][$zimmerIdx][$timeIdx][$loopCount] = $cell['to'];
			      $setBlankCell['obj'][$zimmerIdx][$timeIdx][$loopCount] = $cell['obj'];
			  }else{
			  // einleitendes blank geht ueber mehrere Stunden
			      for( $loopHwr = $cell['hFrom']; $loopHwr <= $cell['hTo']; ++$loopHwr){
				  $timeIdx = $timeMatrix[$loopHwr];
				  $setBlankCell['from'][$zimmerIdx][$timeIdx][$loopCount] = (60 * $loopHwr);
				  $setBlankCell['to'][$zimmerIdx][$timeIdx][$loopCount] = (60 * $loopHwr)+60;
			      }
			      $timeIdx = $timeMatrix[$cell['hFrom']];
			      $setBlankCell['from'][$zimmerIdx][$timeIdx][$loopCount] = $cell['from'];
			      $timeIdx = $timeMatrix[$cell['hTo']];
			      $setBlankCell['to'][$zimmerIdx][$timeIdx][$loopCount] = $cell['to'];
			      $setBlankCell['obj'][$zimmerIdx][$timeIdx][$loopCount] = $cell['obj'];
			  }
			  // datenzelle geht ueber mehrere Stunden, blanks auslassen
			  if($cell['obj']['hFrom'] != $cell['obj']['hTo'] ){
			      for( $loopHwr = $cell['obj']['hFrom']; $loopHwr <= $cell['obj']['hTo']; ++$loopHwr){
				    $setBlankCell['noBlank'][$zimmerIdx][$timeMatrix[$loopHwr]] = array();
			      }
			  }
		      }
		}
		return $setBlankCell;
	}

	/**
	* createObjects
	*
	* @param array $aBelegung
	* @return array
	*/
	public function createObjects( $aBelegung ) {
		// create belegung/timetable objects
		$cellWidth = $this->settings['display_tagesplan_cell_width'];
		$oBelegung = array();
		if( is_array($aBelegung) ){
		      foreach( $aBelegung as $zimmerIdx=>$zmrBel ){
			    foreach($zmrBel as $itemIdx=>$belegung){
				    $oBelSlice = new \stdClass();
				    $oBelSlice->uid = $belegung['uid'];
				    $oBelSlice->type = $belegung['type'];
				    $oBelSlice->timetable = $belegung['timetable'];
				    $oBelSlice->ab = $belegung['ab'];
				    $oBelSlice->bis = $belegung['bis'];
				    $oBelSlice->label = $belegung['belegungstext'];
				    $oBelSlice->title =  $belegung['tiptext'];
				    $oBelSlice->zimmer = $zimmerIdx;
				    $oBelSlice->zimmerinfo = $belegung['zimmerinfo'];
				    $oBelSlice->status = $belegung['status'];
				    $oBelSlice->width = round((( $belegung['tTo']-$belegung['tFrom'] ) *$cellWidth)/ 60 , 2);
				    $oBelSlice->minutes = round( $belegung['otTo']-$belegung['otFrom'] );
				    $oBelSlice->holidayCss = $belegung['holidayCss'];
				    $oBelSlice->css = trim($belegung['css-borderclass']);
				    $oBelegung[$zimmerIdx][$itemIdx] = $oBelSlice;
			    }
		      }
		}
		return $oBelegung;
	}


}
