<?php
namespace \Mff\Mffrps\View\Anlass;


/**
 * Return foo json encoded
 * Action name followed by the format
 *
 * @return string
 */
class DeleteJSON extends \TYPO3\CMS\Extbase\Mvc\View\AbstractView {
// Tx_Foobar_View_Foo_ExportJson extends Tx_Extbase_MVC_View_AbstractView
	/**
	 * Renders the view
	 *
	 * @return string The rendered view
	 */
	public function render() {
		$foo = $this->variables['message'];
		return $foo;
	}

}

?>