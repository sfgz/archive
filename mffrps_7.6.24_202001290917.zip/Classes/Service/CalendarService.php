<?php
namespace Mff\Mffrps\Service;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class CalendarService
 */

class CalendarService implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * settings
	 *
	 * @var array
	 */
	Public $settings = array() ;
	
	/**
	 * errors
	 *
	 * @var array
	 */
	Public $errors = array() ;
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
	}

	/**
	* uploadIcsFile
	* transforms array with event(s) and uploads the result as ics-file to a calendar-url
	* returns an empty string if successed or a error-message if failed
	*
	* @param array $eventDB 1 or 2-dimensioned array for 1 or more events to be stored
	* @param string $calName name of the calendar which should be updated
	* @param string $filSuffix the suffix for the filename is needed if more than one commands are started for the same calendar
	* @return string
	*/
	function calendarPutData($eventDB,$calName,$filSuffix = '0') {

		$filCnt = $this->mkICS4calendar($eventDB);
		
		return $this->calendarSendDataFromIcsFile( $calName.'_'.$filSuffix.'.ics' , $filCnt , $calName );
	}
	
 	function calendarSendDataFromIcsFile( $fileName , $filCnt , $calName ) {
		$uploadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
		$uploadedFileName = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $uploadDir.'calendar/'.$fileName ) ;
		file_put_contents( $uploadedFileName , $filCnt );

		$result = $this->uploadIcsFile($uploadedFileName,$calName);
		if( empty($this->settings['debug_mode']) && file_exists($uploadedFileName) ) @unlink($uploadedFileName);
		
		return true;
 	}

	/**
	* uploadIcsFile
	* uploads a ics-file with event(s) 
	* to a specific calendar-url
	* returns an empty string if successed, or a error-message if failed
	*
	* @param string $uploadedFileName
	* @param string $calName
	* @return string
	*/
	function uploadIcsFile($uploadedFileName,$calName) {
		$baseurl = $this->settings['optionfields']['backup_baseurl']['value'];
		$backupuser = $this->settings['optionfields']['backup_user']['value'];
		$backuppass = $this->settings['optionfields']['backup_pass']['value'];
		$urlName = $baseurl.$backupuser.'/'.$calName.'?fmt=ics';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, ''.$urlName.'');
		curl_setopt($ch, CURLOPT_USERPWD, trim($backupuser).':'.$backuppass);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false); 
		curl_setopt($ch, CURLOPT_PUT, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$fh_res = fopen($uploadedFileName, 'r');
		curl_setopt($ch, CURLOPT_INFILE, $fh_res);
		curl_setopt($ch, CURLOPT_INFILESIZE, filesize($uploadedFileName));
		
		$res = curl_exec($ch);
		
		if($res === false){
		      $content = 'CalendarService uploadIcsFile: error! '.curl_error($ch);
		      $this->errors['uploadIcsFile'][$calName] = $content;
		}else{
		      $content = $res;
		}
		
		fclose($fh_res);
		
		return $content;
	}

	/**
	* mkICS4calendar
	* transforms either a 2-dim array of all events from one calendar
	* or a 1-dim array of one event
	* in ics-formatted string
	*
	* @param array $eventDB
	* @return string
	*/
	function mkICS4calendar($eventDB) {
	  $content = "BEGIN:VCALENDAR\n";
	  $content.= "PRODID:Zimbra-Calendar-Provider\n";
	  $content.= "VERSION:2.0\n";
	  foreach(array_keys($eventDB) as $eid){
		if( is_array($eventDB[$eid]) ){
		      $eventArr = $eventDB[$eid];
		      $is2dimArr = true;
		}else{
		      $eventArr = $eventDB;
		      $is2dimArr = false;
		}
		break;
	  }
	  if( isset($eventArr['STATUS']) && $eventArr['STATUS'] == 'CANCELLED' ){
	      $content.= "METHOD:DELETE\n";
	  }else{
	      $content.= "METHOD:PUBLISH\n";
	  }
	  
	  if( $is2dimArr ) {
		foreach(array_keys($eventDB) as $eid) $content.= $this->mkICS4event($eventDB[$eid]);
	  }else{
		$content.= $this->mkICS4event($eventDB);
	  }
	  
	  $content.= "END:VCALENDAR\n";
	  return $content;
	}

	/**
	* mkICS4event
	* transforms 1-dim array of one event
	* in ics-formatted string
	*
	* @param array $eventArr
	* @return string
	*/
	function mkICS4event($eventArr) {
	  
	  if( $this->settings['optionfields']['belegung_status_aktivieren']['value'] == 2 ){
		// farbgebung aus Status-feld
		$statNr = $this->settings['optionfields']['backup_exportcalendar_mapstatus_'.$eventArr['BELSTS']]['value'];
	  }else{
		// farbgebung aus interner/externer Mieter
		$statusConf = array( $this->settings['optionfields']['backup_exportfields_calendar_status']['value'] , $this->settings['optionfields']['backup_exportfields_calendar_istatus']['value'] );
		$statNr = $statusConf[ $eventArr['INTERN'] ];
	  }
	  
	  // $privConf 1=all public / 2=internal private ext public / 3= internal public ext private / 4=all private 
	  // class 0=public 1=private => $eventArr['INTERN']+2=priv !$eventArr['INTERN']+3=priv 
	  $privConf = $this->settings['optionfields']['backup_exportfields_calendar_private']['value'];
	  $class = ( $eventArr['INTERN'] + $privConf == 3 || $privConf == 4 ) ? 1 :  0;
	  
	  $inExtArr = array(
		'INTENDEDSTATUS' => array( 1 => 'FREE' , 2 => 'TENTATIVE' , 3 => 'BUSY' , 4 => 'OOF' ),
		'CLASS'          => array( 'PUBLIC' , 'PRIVATE' ),
		'TRANSP'         => array( 'OPAQUE' , 'TRANSPARENT' )
	  );
	  
	  $newVal['TRANSPARENCY'] = $inExtArr['TRANSP'][( $statNr < 3 )];
	  $newVal['INTENDEDSTATUS'] = $inExtArr['INTENDEDSTATUS'][$statNr];
	  $newVal['CLASS'] = $inExtArr['CLASS'][$class];
	  $newVal['DTSTAMP'] = date('Ymd\THis\Z');
	  $newVal['LASTMODIFIED'] = ( $eventArr['SEQUENCE'] > 0 ) ? $newVal['DTSTAMP'] : 0;
	  
	  $content.= "BEGIN:VEVENT\n";
	  $content.= "UID:".$eventArr['UID']."\n";
	  $content.= "SUMMARY:".$eventArr['SUMMARY']."\n";
	  $content.= "DESCRIPTION:".$eventArr['DESCRIPTION']."\n";
	  $content.= "LOCATION:".$eventArr['LOCATION']."\n";
	  $content.= "DTSTART;TZID=\"Europe/Berlin\":".date('Ymd\THis',$eventArr['DTSTART'])."\n";
	  $content.= "DTEND;TZID=\"Europe/Berlin\":".date('Ymd\THis',$eventArr['DTEND'])."\n";
	  // delete the event with STATUS = 'CANCELLED'
	  if(!empty($eventArr['STATUS'])) $content.= "STATUS:".$eventArr['STATUS']."\n";
	  $content.= "CLASS:".$newVal['CLASS']."\n";
	  $content.= "X-MICROSOFT-CDO-INTENDEDSTATUS:".$newVal['INTENDEDSTATUS']."\n";
	  $content.= "TRANSP:".$newVal['TRANSPARENCY']."\n";
	  // if adding a new event then dont set last-modified
	  if(!empty($newVal['LASTMODIFIED'])) $content .= "LAST-MODIFIED:".$newVal['LASTMODIFIED']."\n" ;
	  $content.= "DTSTAMP:".$newVal['DTSTAMP']."\n";
	  $content.= "SEQUENCE:".$eventArr['SEQUENCE']."\n";
	  $content.= "END:VEVENT\n";

	  return $content;
	}

	/**
	* calendarReadData
	* reads calendar from url
	* returns flat 2-dimensional array
	* or string with error-message if request failed
	* 
	* if $excludeAutoGeneratedEvents
	* 0 = then uid must not match calendar_uid_incredentials pattern from settings
	* 1 = then uid has to match calendar_uid_incredentials pattern from settings
	* 2 = show all 
	*
	* @param string $calendarName
	* @param int $excludeAutoGeneratedEvents if 1 then uid has to match calendar_uid_incredentials pattern from settings
	* @return void
	*/
	function calendarReadData( $calendarName , $excludeAutoGeneratedEvents = 1 ) {
	      
	      $calendarArray = $this->readAsJson( $calendarName );

	      if( count($calendarArray) ){
		    $aCalendarDB =  $this->calendarJson2Arr( $calendarArray , $excludeAutoGeneratedEvents );
// 		    $uploadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
// 		    $uploadedFileName = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $uploadDir.'calendar/test_'.$calendarName.'.ics' ) ;
// 		    $filCnt = print_r( $calendarArray , TRUE );
// 		    file_put_contents( $uploadedFileName , $filCnt );
		    return $aCalendarDB;
	      }
	      
	      if( isset($this->errors['readAsJson'][$calendarName]) ){
		    return $this->errors['readAsJson'][$calendarName];
	      }
	      
	      return false;
	      
	}

	/**
	* readAsJson
	* reads calendar from url
	* returns json-data as array
	*
	* @param string $calendarName
	* @return array
	*/
	function readAsJson( $calendarName ) {
		$db = array();
		$baseurl = $this->settings['optionfields']['backup_baseurl']['value'];
		$backupuser = $this->settings['optionfields']['backup_user']['value'];
		$backuppass = $this->settings['optionfields']['backup_pass']['value'];
		$urlName = $baseurl.$backupuser.'/'.$calendarName.'?fmt=json';
		
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$urlName);
		curl_setopt($ch, CURLOPT_USERPWD, $backupuser.':'.$backuppass);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		
		if ($result === false) {
		      $this->errors['readAsJson'][$calendarName] = curl_error($ch);
		}else{
		      // format json-data as array
		      $db = json_decode($result, true );
		}
		curl_close($ch);
		
		return $db;
	}
	
	/**
	* calendarJson2Arr
	* translates multi-dimensional clendar-array
	* returns 2-dimensional array with index and Fieldnames as array-keys
	*
	* if $excludeAutoGeneratedEvents
	* 0 = then uid must not match calendar_uid_incredentials pattern from settings
	* 1 = then uid has to match calendar_uid_incredentials pattern from settings
	* 2 = show all 
	*
	* @param array $calendarArray
	* @param int $excludeAutoGeneratedEvents include,exclude,showall if uid match calendar_uid_incredentials pattern from settings
	* @return array
	*/
	function calendarJson2Arr($calendarArray , $excludeAutoGeneratedEvents = 1 ) {
	  $calendar = $calendarArray['appt'];
	  if(!is_array($calendar)) return;
	  
	  $aIncredentials = $this->settings['calendar_uid_incredentials'];
	  $calDB = array();
	  $now = time();
	  foreach($calendar as $calIdx=>$cals){
		if($excludeAutoGeneratedEvents == 1){
		      // exclude auto-generated recordsets with specified searchwords in UID
		      if( strpos( ' ' . $cals['uid'] , $aIncredentials[0] ) == 1 && 
			  strpos( $cals['uid'] , $aIncredentials[1] ) &&
			  strpos( $cals['uid'] , $aIncredentials[2] )
		      ) continue;
		}elseif( empty($excludeAutoGeneratedEvents) ){
		      // exclude manual generated recordsets without specified searchwords in UID
		      if( strpos( ' ' . $cals['uid'] , $aIncredentials[0] ) != 1 || 
			  strpos( $cals['uid'] , $aIncredentials[1] ) == 0 ||
			  strpos( $cals['uid'] , $aIncredentials[2] ) == 0
		      ) continue;
		}
		
		// exclude recordsets with invitations
		$invitations = count( $cals['inv'][0]['comp'][0]['at'] );
		if( $invitations > 0 ) continue;
		
		// exclude recordsets with allDay
		if( $cals['inv'][0]['comp'][0]['allDay'] == TRUE ) continue;
		
		// evaluate Date and Time
		if(!isset($cals['inv'][0]['comp'][0]['s'][0]['u'])){
		      $aDate = explode( 'T' , $cals['inv'][0]['comp'][0]['s'][0]['d']);
		      $Dt = array( substr($aDate[0] , 0 , 4) , substr($aDate[0] , 4 , 2) , substr($aDate[0] , 6 , 2) );
		      $Tm = isset($aDate[1]) ? explode( ':' , $aDate[1] ) : array( 0 , 0 , 0 );
		      $uxStart = mktime( $Tm[0] , $Tm[1] , $Tm[2] , $Dt[1] , $Dt[2] , $Dt[0] );
		      
		      $aDate = explode( 'T' , $cals['inv'][0]['comp'][0]['e'][0]['d']);
		      $Dt = array( substr($aDate[0] , 0 , 4) , substr($aDate[0] , 4 , 2) , substr($aDate[0] , 6 , 2) );
		      $Tm = isset($aDate[1]) ? explode( ':' , $aDate[1] ) : array( 0 , 0 , 0 );
		      $uxEnd =  mktime( $Tm[0] , $Tm[1] , $Tm[2] , $Dt[1] , $Dt[2] , $Dt[0] );
		}else{
		      $uxStart = round($cals['inv'][0]['comp'][0]['s'][0]['u']/1000) ;
		      $uxEnd = round($cals['inv'][0]['comp'][0]['e'][0]['u']/1000) ;
		}
		
		// exclude recordsets with more than 1 day
		if( date('dmy' , $uxStart ) != date('dmy' , $uxEnd ) ) continue;
		
		// exclude recordsets older than 180 days
		if( $now - (3600*24*180) > $uxEnd ) continue;

		$calIndex = $cals['uid'];
 		$calDB[$calIndex]['uid'] = $cals['uid'];
		$calDB[$calIndex]['datum'] =  $this->timeZoneRelatedTimestamp( $uxStart , $cals['inv'][0]['comp'][0]['s'][0]['tz'] ) ;
		$calDB[$calIndex]['zeit_start'] = date('H:i' , $uxStart);
		$calDB[$calIndex]['zeit_ende'] = date('H:i' , $uxEnd);
		$calDB[$calIndex]['mieter'] = !empty($cals['inv'][0]['comp'][0]['or']['sentBy']) ? $cals['inv'][0]['comp'][0]['or']['sentBy'] : $cals['inv'][0]['comp'][0]['or']['url'];
		$calDB[$calIndex]['betreff'] = $cals['inv'][0]['comp'][0]['name'];
		$calDB[$calIndex]['notes'] = $cals['inv'][0]['comp'][0]['fr'];
		$calDB[$calIndex]['location'] = $cals['inv'][0]['comp'][0]['loc'];
		$calDB[$calIndex]['sequence'] = $cals['inv'][0]['comp'][0]['seq'];
		$calDB[$calIndex]['status'] = $cals['inv'][0]['comp'][0]['status'];
		$calDB[$calIndex]['tstamp'] = $cals['inv'][0]['comp'][0]['d']/1000;
		
//   		$calDB[$calIndex]['inv'] = $cals['inv'][0]['comp'][0];
	  }
	  return $calDB;
	}
	
	/**
	* timeZoneRelatedTimestamp
	* unused, returns input-value
	*
	* @param int $unixTimeStamp
	* @param string $strTimeZone
	* @return int
	*/
	function timeZoneRelatedTimestamp( $unixTimeStamp , $strTimeZone = 'Europe/Berlin' ) {
		return $unixTimeStamp;
		$localTimeZone = new \DateTimeZone( $strTimeZone );
		$dateTimeObject = new \DateTime( date( 'Y-m-d H:i:s' ,$unixTimeStamp ) , $localTimeZone );
		return $dateTimeObject->getTimestamp();
	}
	
}