<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * SysOptionsController
 */
class SysOptionsController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * settings
	 *
	 * @var array
	 */
	protected $settings = array();

	/**
	 * sysOptionsRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\SysOptionsRepository
	 * @inject
	 */
	protected $sysOptionsRepository = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * pdfUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfUtility = NULL;

	/**
	 * pdfDbUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfDbUtility = NULL;

	public function initializeAction() {
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['anchor2category'] = $this->systemOptionsUtility->settings['anchor2category'];
	}

	/**
	 * action sysconfig
	 * Configures system-wide options and stores them in the table sysoptions
	 * get filter_section from settings.filterfields
	 * get style, filter_section and values from settings.optionfields and
	 * - if not existent then create records in table tx_mffrps_domain_model_sysoptions
	 * with values from settings
	 * -> [utility lookUpForNewOtions() ]
	 * - overwrite with values from tx_mffrps_domain_model_sysoptions
	 * -> [utility getSystemOptions() ]
	 * - overwrite and store values with inputs from POST-data if present
	 * assign filterfields.filter_section and settings.optionfields
	 *
	 * @return void
	 */
	public function sysconfigAction() {
		$this->systemOptionsUtility->lookUpForNewSystemOtions();
		
		// choose category
		if ($this->request->hasArgument('category')) {
			$category = $this->request->getArgument('category');
		} else {
			if ($this->request->hasArgument('target')) {
				$target = $this->request->getArgument('target');
				$category = $this->settings['anchor2category'][$target];
			} else {
				$category = 1;
			}
		}
		
		$action = $this->evaluateUserAct();
		$save_before_run = empty($action) || 'save_before_run'==$this->settings['optionfields'][$action]['value'] ? 1 : 0;
		
		// choose action
		if ($this->request->hasArgument('reset')) {
			// reset
			$this->systemOptionsUtility->resetSystemOptions( $category );
			$this->addFlashMessage('Grundeinstellung auf dieser Seite wieder hergestellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			
		} elseif ( $save_before_run && $this->request->hasArgument($this->settings['formname'])  ) {
			// store incoming values. not on action or action-button has the value [save_before_run]
			if ( $this->request->hasArgument($this->settings['formname'])  ) {
				$inVars = $this->request->getArgument($this->settings['formname']);
				$this->systemOptionsUtility->setSystemOptions($inVars);
				$this->addFlashMessage('&Auml;nderung wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
			
		} else {
			// first call or action
			// if action-button has not the value [save_before_run]
			$this->systemOptionsUtility->getSystemOptions();
			if(empty($this->systemOptionsUtility->settings['optionfields']['pdf_signature_images']['value'])){
				$setting['pdf_signature_images'] = $GLOBALS['TSFE']->fe_user->user['username'] ;
				$this->systemOptionsUtility->setSystemOptions($setting);
			}
		}
		
		$imageDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
// 		$userTemplatePath = 'uploads/tx_mffrps/templates/';
		$this->settings['template_path_user'] = $this->systemOptionsUtility->settings['template_path_user'];
		$userTemplateDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['template_path_user']) , '/' ) . '/';
// 		$fixTemplatePath = 'typo3conf/ext/mffrps/Resources/Public/templates/';
		$this->settings['template_path_sys'] = $this->systemOptionsUtility->settings['template_path_sys'];
		$fixTemplateDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['template_path_sys']) , '/' ) . '/';

		$base_url = $this->systemOptionsUtility->settings['baseURL'];
		$this->systemOptionsUtility->settings['files'] = array(
			      'base_url'             => $base_url , 
			      'pdf_signature_images' => $this->systemOptionsUtility->readInDir($imageDir , 'jpg,jpeg,gif,png') , 
			      'template_url'         => $base_url.$this->settings['template_path_sys'] , 
			      'fix_templates'        => $this->systemOptionsUtility->readInDir($fixTemplateDir , 'csv'), 
			      'user_template_url'    => $base_url.$this->settings['template_path_user'] , 
			      'user_templates'       => $this->systemOptionsUtility->readInDir($userTemplateDir , 'csv' )
		);
		
		
		$this->executeUserAct( $action );
		
		$this->systemOptionsUtility->setSelectOptions();
		$this->view->assign('settings', $this->systemOptionsUtility->settings);
		
		$this->view->assign('category', $category);
	}

	public function executeUserAct( $action ) {
		$imageDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
		$userTemplateDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['template_path_user']) , '/' ) . '/';
		switch( $action ){
			case 'pdf_signature_images':
				// upload image file 
				$fileName = $_FILES['tx_mffrps_rpsopt']['name']['useraction']['pdf_signature_images'];
				$suffix = pathinfo( $fileName , PATHINFO_EXTENSION );
				if( $suffix != 'csv' ){
				      if( !empty($this->systemOptionsUtility->settings['optionfields']['pdf_signature_images']['value']) ){
					    $baseName = str_replace( '.'.$suffix , '' , $this->systemOptionsUtility->settings['optionfields']['pdf_signature_images']['value']);
					    $fileName = $baseName.'.'.$suffix;
				      }
				      $filesToDelete = $this->systemOptionsUtility->readInDir($imageDir,'',pathinfo( $fileName , PATHINFO_FILENAME ));
				      if(count($filesToDelete)){
					  foreach(array_keys($filesToDelete) as $fil){ if( file_exists($imageDir.$fil) ) @unlink($imageDir.$fil); }
				      }
				      \TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES['tx_mffrps_rpsopt']['tmp_name']['useraction']['pdf_signature_images'] , $imageDir.$fileName );
				      $this->addFlashMessage('Datei hochgeladen ('.$fileName.')' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
				}else{
				      $this->addFlashMessage('Datei NICHT hochgeladen, Dateityp "'.$suffix.'" nicht akzeptiert ('.$fileName.')' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				}
			break;
			case 'pdf_templates':
				  // upload pdf file 
				$fileName = $_FILES['tx_mffrps_rpsopt']['name']['useraction']['pdf_templates'];
				$suffix = pathinfo( $fileName , PATHINFO_EXTENSION );
				if( $suffix == 'csv' ){
				      if( file_exists($userTemplateDir.$fileName) ) @unlink($userTemplateDir.$fileName);
				      \TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES['tx_mffrps_rpsopt']['tmp_name']['useraction']['pdf_templates'] , $userTemplateDir.$fileName );
				      $this->addFlashMessage('Datei hochgeladen ('.$fileName.')' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
				}else{
				      $this->addFlashMessage('Dateityp "'.$suffix.'" nicht akzeptiert ('.$fileName.')' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				}
			break;
			case 'remove':
				if( file_exists($imageDir.$aUseractions['remove']) ) @unlink($imageDir.$aUseractions['remove']);
				$this->addFlashMessage('Datei entfernt ('.$aUseractions['remove'].')', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			break;
			case 'reset':
				if( file_exists($userTemplateDir.$aUseractions['reset']) ) @unlink($userTemplateDir.$aUseractions['reset']);
				$this->addFlashMessage('Datei entfernt ('.$aUseractions['reset'].')', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			break;
			case 'info_wochenliste_download':
				$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
				$this->pdfUtility = new \Mff\Mffrps\Utility\PdfUtility( $this->settings );
				$this->pdfDbUtility = new \Mff\Mffrps\Utility\PdfDbUtility( $this->settings );
				$data = $this->pdfDbUtility->getWochenlisteForPdf( time() );
				$output = $this->pdfUtility->putPdf( $data , 'wochenliste' );
				if(!count($this->pdfUtility->errors)){
				    if( $this->pdfUtility->settings['debug'] ){
						$this->view->assign('aTemplate', $output);
				    }else{
						echo $output;
						die();
				    }
				}else{
				    $this->addFlashMessage('PDF Fehler: '.implode($this->pdfUtility->errors) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				}
				$this->addFlashMessage('info_wochenliste_download', '',\TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			break;
			case 'backup_run':
				$this->backupUtility = new \Mff\Mffrps\Utility\BackupUtility();
				$response = $this->backupUtility->Backup('weekly');
				if($response) {
				      $this->addFlashMessage('Backup ausgefuehrt, Mail gesendet. '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
				  }else{
				      $this->addFlashMessage('Backup nicht ausgefuehrt. ' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				  }
			break;
			case 'find_orphans':
				$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
				$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility($this->settings);
				$anlassUid = $this->settings['optionfields']['find_orphans_anlass_uid']['value'];
				$result = $this->dbHelperUtility->getBelegungRepository()->assignOrphansToAnlass( $anlassUid );
				$this->addFlashMessage('Verwaiste Belegungen gesammelt in Anlass Nr. '. $anlassUid .'. '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			break;
			case 'rebuild_ausnahme':
				// rebuild relations between Timetable (or Stundenplan) and Ausnahme
				$schedulerTask = new \Mff\Mffrps\Command\RebuildAusnahmeCommandController();
				$schedulerTask->execute();
				$this->addFlashMessage('Beziehungen zwischen Ausnahmen und Stundenplan wiederhergestellt. '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			break;
		}
	}

	public function evaluateUserAct() {
		$action = '';
		if ($this->request->hasArgument('useraction') ) {
		
			$aUseractions = $this->request->getArgument('useraction') ;
			
			foreach($aUseractions as $incomeAction => $inVal) if($inVal) break;
			
			if( $incomeAction == 'pdf_signature_images' || $incomeAction == 'pdf_templates' ){
				// upload image file or csv-file  as pdf-template
				if( $_FILES['tx_mffrps_rpsopt']['tmp_name']['useraction'][$incomeAction] ){
				      $action = $incomeAction;
				}
			}elseif( $incomeAction ){
				$action = $incomeAction;
			}
		}
		return $action;
	}

	/**
	 * action useroptions
	 * reads User Options for actual user,
	 *  overwrite them with incomming values
	 *  and stores it in the table sysoptions
	 * get settings.userfields and
	 * - overwrite them with sessionVars if existent
	 * -> [utility getUserOptions() ]
	 * - overwrite and store values with inputs from POST-data if present
	 * ->  [utility setUserOptions( array( key1 => value1 ) ) ]
	 * - or leave values as hardcoded and store them in sessionVars
	 * if clean-vars is choosen
	 * -> [utility resetUserOptions() ]
	 * assign filterfields.filter_section and settings.userfields
	 *
	 * @return void
	 */
	public function useroptionsAction() {
		if ($this->request->hasArgument('category')) {
			$category = $this->request->getArgument('category');
		} else {
			if ($this->request->hasArgument('target')) {
				$target = $this->request->getArgument('target');
				$category = $this->settings['anchor2category'][$target];
			} else {
				$category = 6;
			}
		}
		if ($this->request->hasArgument('reset')) {
			$this->systemOptionsUtility->resetUserOptions();
			$this->addFlashMessage('Grundeinstellung aller Benutzeroptionen wieder hergestellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		} elseif ($this->request->hasArgument($this->settings['formname'] . '_settings')) {
			$inVars = $this->request->getArgument($this->settings['formname'] . '_settings');
			$this->systemOptionsUtility->setUserOptions($inVars);
			$this->addFlashMessage('&Auml;nderung wurde gespeichert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		} else {
			$this->systemOptionsUtility->getUserOptions();
		}
		$this->systemOptionsUtility->setSelectOptions();
		$this->view->assign('settings', $this->systemOptionsUtility->settings);
		$this->view->assign('category', $category);
	}

}
