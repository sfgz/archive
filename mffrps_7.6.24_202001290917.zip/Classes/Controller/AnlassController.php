<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * AnlassController
 */
class AnlassController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * anlassRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
	 * @inject
	 */
	protected $anlassRepository = NULL;

	/**
	 * mieterRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\MieterRepository
	 * @inject
	 */
	protected $mieterRepository = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * pdfDbUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfDbUtility = NULL;

	/**
	 * pdfUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $pdfUtility = NULL;
	
	/**
	 * mailUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['userfields'] = $this->systemOptionsUtility->getUserOptions();
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		}
		$this->settings = $this->systemOptionsUtility->handleRequestVars( $inVars , $this->settings );
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
		$this->pdfUtility = new \Mff\Mffrps\Utility\PdfUtility( $this->settings );
		$this->pdfDbUtility = new \Mff\Mffrps\Utility\PdfDbUtility( $this->settings );
		$this->mailUtility = new \Mff\Mffrps\Utility\MailUtility( $this->settings );

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$cObj = $configurationManager->getContentObject();
		$this->settings['piUid'] = $cObj->data['uid'];
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		
		$anlasses = $this->mieterRepository->findByUidOrKurz($this->settings['filter']['anlass_search_chars']);
		
		if ($this->request->hasArgument('download')) {
			$reqFormat = $this->request->getArgument('download');
			if ($reqFormat == 'xls') {
  				$aAnlass = $this->dbHelperUtility->getAnlassMieterInfos();
  				foreach($anlasses as $anlass){
				    $anlaesseGefilter[] = $aAnlass[ $anlass->getUid() ];
  				}
				$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				$downloader->downloadAsXls( array('AnlaesseGefilter'=>$anlaesseGefilter,'AlleAnlaesse'=>$aAnlass), 'anlaesse_' . date('ymd_Hi') . '.xlsx');
				return;
			}
		}
		
		$this->view->assign('settings', $this->settings);
 		$this->view->assign('anlasses', $anlasses );
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		$this->view->assign( 'allemieter' , $this->dbHelperUtility->mkMieterSelectArray() );
		
		$uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
		$signatureFiles = $this->systemOptionsUtility->readInDir($uploadDir) ;
		$userSignature = array_search( $GLOBALS['TSFE']->fe_user->user['username'] , $signatureFiles );
		$this->view->assign('signatures', array( 'list'=>$signatureFiles , 'usersignature'=>$userSignature ) );

		$acronym = $GLOBALS['TSFE']->fe_user->user['eco_acronym'] ? $GLOBALS['TSFE']->fe_user->user['eco_acronym'] : $GLOBALS['TSFE']->fe_user->user['username'];
		$kuerzel = $userSignature ? $signatureFiles[$userSignature] : $acronym;
		$newAnlass = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\Anlass');
		$newAnlass->setSchulleitungKurz( $kuerzel );
		$newAnlass->setSchulleitungDatum( new \DateTime( date("Y-m-d\TH:i:s") ) );
		$this->view->assign('newAnlass',$newAnlass );
	}

	/**
	 * Initialize  create
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
		$args = $this->arguments['newAnlass']->getPropertyMappingConfiguration();
		if ( $this->request->hasArgument('newAnlass') ) $request = $this->request->getArgument('newAnlass');
		if (strlen($request['schulleitungDatum'])) {
		    $args->forProperty('schulleitungDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		}else{
		    $this->arguments->getArgument('newAnlass')->getPropertyMappingConfiguration()->skipProperties('schulleitungDatum');
		}
		if (strlen($request['rechnungsDatum'])){
		    $args->forProperty('rechnungsDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		}else{
		    $this->arguments->getArgument('newAnlass')->getPropertyMappingConfiguration()->skipProperties('rechnungsDatum');
		}
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $newAnlass
	 * @return void
	 */
	public function createAction(\Mff\Mffrps\Domain\Model\Anlass $newAnlass) {
		$this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		$this->anlassRepository->add($newAnlass);
		$this->persistenceManager->persistAll();
		$this->forward('edit', NULL, NULL, array('anlass' => $newAnlass));
	}

	/**
	 * action sendmail
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return void
	 */
	public function sendmailAction(\Mff\Mffrps\Domain\Model\Anlass $anlass) {
		if ( $this->request->hasArgument('editList') ) {
			$iMieterId = $anlass->getMieter();
			$objMieter = $this->mieterRepository->findByUid($iMieterId);
			$objsAnlass = $objMieter->getMtrAnlass();
			$editList = $this->request->getArgument('editList');
			foreach($objsAnlass as $objAnlass){
			    $aUid = $objAnlass->getUid();
			    $editList['selobj'][$aUid]['checked'] = $editList['sel'][$aUid] ;
			    $editList['selobj'][$aUid]['obj'] =$objAnlass ;
			}

			if( $this->settings['sendmail_mode'] == 1 ){
			    // get user infos for mail_signature
			    $userObj = $GLOBALS['TSFE']->fe_user;
			    $userEmail = '';
			    if($userObj) $userEmail = $userObj->user['email'];
			    if(empty($userEmail)) $userEmail = $this->settings['optionfields']['backup_user']['value'];
			    $rpc = array(
				  '_email_'=>$userEmail , 
				  '_first_name_'=>$userObj->user['first_name'] , 
				  '_last_name_'=>$userObj->user['last_name'] , 
				  '_company_'=>$userObj->user['company'] , 
				  '_telephone_'=>$userObj->user['telephone'] ,
			    );
			    $editList['mail_signature'] = str_replace( array_keys($rpc) , $rpc , $this->settings['optionfields']['mail_signature']['value']);

			    $rawBodyText = $editList['mail_message'] ;
			    $mtrMail['Body']  = str_replace( "\n" , "<br />" , $rawBodyText . $editList['mail_signature'] );
			    $mtrMail['Subject'] = $editList['mail_subject'];
			    $mtrMail['From'] = array( $editList['sender_email'] );
 			    $mtrMail['To'] = array( $editList['sendto_email'] );
			    if($editList['include_cc'] && !empty($editList['cc_mailadresses']) ) $mtrMail['Cc'] = explode( ',' , $editList['cc_mailadresses'] );
			    if( $editList['blincopy_sender'] ) $mtrMail['Bcc'] = $mtrMail['From'] ;
			    
			    foreach( $editList['selobj'] as $aUid=> $aAnlass){
				  if(!$aAnlass['checked']) continue;
				  $data = $this->pdfDbUtility->getDataForPdfAnlass( $aAnlass['obj'] , 'bewilligung' );
				  $output = $this->pdfUtility->putPdfAsString($data , 'bewilligung' );
				  $dateiname = utf8_encode(urldecode( $this->pdfUtility->data['main']['##Filename##'] ));
				  $mtrMail['Attatchments'][$dateiname] = $output;
			    }
			    
			    $emailResult = $this->mailUtility->sendWithAttatchment( $mtrMail );
			    
			    $editList['updated'] = 1;
			    $this->addFlashMessage('Nachricht gesendet an:'.$editList['sendto_email'].' .', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
			    $this->addFlashMessage('Keine Nachricht gesendet.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			}
		}else{
			$editList = array();
		}
		$this->forward('mailform', NULL, NULL, array('anlass' => $anlass,'editList' => $editList));
	}

	/**
	 * action mailform
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return void
	 */
	public function mailformAction(\Mff\Mffrps\Domain\Model\Anlass $anlass) {
		$iMieterId = $anlass->getMieter();
		$objMieter = $this->mieterRepository->findByUid($iMieterId);

		// get user infos for mail-action
		$userObj = $GLOBALS['TSFE']->fe_user;
		$userEmail = '';
		if($userObj) $userEmail = $userObj->user['email'];
		if(empty($userEmail)) $userEmail = $this->settings['optionfields']['backup_user']['value'];

		// evaluate if mail action is triggered 
		// otherwise set default values for message and adress
		if ( $this->request->hasArgument('editList') ) {
			$editList = $this->request->getArgument('editList');
			if(empty($editList['include_cc'])) $editList['cc_mailadresses'] = $this->settings['optionfields']['info_hauswart_mailadress']['value'];
		}else{
			$email = $anlass->getKontaktEmail();
			if(empty($email)) $email = $objMieter->getEmail();
			$editList = array(
			    'mail_message' => $this->settings['optionfields']['info_mieter_mailtext']['value'],
			    'sender_email' => $userEmail,
			    'cc_mailadresses' => $this->settings['optionfields']['info_hauswart_mailadress']['value'],
			    'updated' => 0,
			    'blincopy_sender' => 1,
			    'sendto_email' => $email,
			    'mail_subject' => $this->settings['optionfields']['info_mieter_mailsubject']['value']
			);
			$aUid = $anlass->getUid();
			$editList['sel'][$aUid] = 1;
			$editList['selobj'][$aUid]['checked'] = 1;
			$objsAnlass = $objMieter->getMtrAnlass();
			foreach($objsAnlass as $objAnlass) $editList['selobj'][$objAnlass->getUid()]['obj'] =$objAnlass ;
		}
		// replace placeholders in signature with values from fe_user
		$rpc = array( 
		      '_email_'=>$userEmail , 
		      '_first_name_'=>$userObj->user['first_name'] , 
		      '_last_name_'=>$userObj->user['last_name'] , 
		      '_company_'=>$userObj->user['company'] , 
		      '_telephone_'=>$userObj->user['telephone'] ,
		);
		$editList['mail_signature'] = str_replace( array_keys($rpc) , $rpc , $this->settings['optionfields']['mail_signature']['value']);
		
		// replace placeholders in subject ans message with values from anlass
		$rpc['_verwendungszweck_'] = $anlass->getVerwendungszweck();
		$editList['mail_subject'] = str_replace( array_keys($rpc) , $rpc , $editList['mail_subject']);
		$editList['mail_message'] = str_replace( array_keys($rpc) , $rpc , $editList['mail_message']);

		
		$this->view->assign('anlass', $anlass);
		$this->view->assign('mieter', $objMieter);
		
		// replacing only for view - not for Email
		$editList['mail_signature'] = str_replace( "\n" , "<br />" , $editList['mail_signature']);
		$this->view->assign('editList', $editList);
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @ignorevalidation $anlass
	 * @return void
	 */
	public function editAction(\Mff\Mffrps\Domain\Model\Anlass $anlass = NULL) {
		if( !$anlass ) return;
		$debug = $this->request->hasArgument( 'debug' ) ? $this->request->getArgument( 'debug' ) : 0;
		if ($this->request->hasArgument( 'pdf' ) ){
		    $type = $this->request->getArgument( 'pdf' );
		    $data = $this->pdfDbUtility->getDataForPdfAnlass( $anlass , $type );
		    $this->pdfUtility->settings['debug'] = $debug ;
		    $output = $this->pdfUtility->putPdf($data , $type );
		    if(!count($this->pdfUtility->errors)){
			if( $this->pdfUtility->settings['debug'] ){
			    $this->view->assign('aTemplate', $output);
			}else{
			    echo $output;
			    die();
			}
		    }else{
			$this->addFlashMessage('PDF Fehler: '.implode($this->pdfUtility->errors) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}elseif($this->request->hasArgument( 'xls' )){
		    $subdataCollector = array();
		    $type = $this->request->getArgument( 'xls' );
		    $data = $this->pdfDbUtility->getDataForPdfAnlass( $anlass , $type );
		    if( is_array($data['multiple']) ){
			  foreach($data['multiple'] as $page){
				if( is_array($page['subdata']) ){
				      foreach($page['subdata'] as $ix => $row){
					    $subdataCollector[$ix] = $row;
				      }
				}
				$mainPage = $page['main'];
			  }
		    }else{
			  if( is_array($data['subdata']) ){
				foreach($data['subdata'] as $ix => $row){
				      $subdataCollector[$ix] = $row;
				}
			  }
			  $mainPage = $data['main'];
		    }
		    if(count($subdataCollector)){
			    $aDateFields = array_flip( array('Datum','PlanVorDatum','PlanNachDatum','Startdatum','date_start','date_end') );
			    foreach($subdataCollector as $ix => $row){
				  foreach( array_keys($row) as $setField){
					$allFields[$setField] = $setField;
				  }
			    }
			    foreach($subdataCollector as $ix => $row){
				  foreach($allFields as $setField){
					if( !isset($row[$setField]) ){
					    $aOut[$ix][$setField] = ''; 
					}else{
					    if(isset($aDateFields[$setField]) && !empty($row[$setField])){
						$aOut[$ix][$setField] = date('d.m.y' , $row[$setField] );
					    }else{
						$aOut[$ix][$setField] = utf8_encode( $row[$setField] );
					    }
					}
				  }
			    }
			    $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
			    $Filename = urlencode(  ucfirst($type).'_Nr-'.$mainPage['BewilligungNr'].'-'.date('ymd_Hi') ) .'.xlsx';
			    $downloader->downloadAsXls( array( ucfirst($type) => $aOut ), $Filename);
			    return;
		    }
		}
		$this->view->assign('anlass', $anlass);
		$belMieterInfo = $this->dbHelperUtility->getAnlassMieterInfos( $anlass->getUid() );
		$this->view->assign( 'allemieter' , $this->dbHelperUtility->mkMieterSelectArray($belMieterInfo['verstecken']) );
		$uid = $anlass->getMieter();
		$this->view->assign('derMieter', $this->mieterRepository->findByUid($uid));

		$uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
		$signatureFiles = $this->systemOptionsUtility->readInDir($uploadDir) ;
		$schulleitungKurz = $anlass->getSchulleitungKurz();
		$username = empty($schulleitungKurz) ? $GLOBALS['TSFE']->fe_user->user['username'] : $schulleitungKurz;
		$userSignature = array_search( $username , $signatureFiles );
		if( empty($userSignature) && !empty($schulleitungKurz) ) $userSignature = array_search( $GLOBALS['TSFE']->fe_user->user['username'] , $signatureFiles );
		$this->view->assign('signatures', array( 'list'=>$signatureFiles , 'usersignature'=>$userSignature ) );
	}
	
	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		$args = $this->arguments['anlass']->getPropertyMappingConfiguration();
		if ( $this->request->hasArgument('anlass') )  $request = $this->request->getArgument('anlass');
		if (strlen($request['schulleitungDatum'])) {
		    $args->forProperty('schulleitungDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		}
		if (strlen($request['rechnungsDatum'])){
		      $args->forProperty('rechnungsDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		}else{
		    $this->arguments->getArgument('anlass')->getPropertyMappingConfiguration()->skipProperties('rechnungsDatum');
		}
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return void
	 */
	public function updateAction(\Mff\Mffrps\Domain\Model\Anlass $anlass) {
		$this->addFlashMessage('Anlass '.$anlass->getUid().' was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->anlassRepository->update($anlass);
		$this->persistenceManager->persistAll();
		$this->forward('edit', NULL, NULL, array('anlass' => $anlass));
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $anlass
	 * @return void
	 */
	public function deleteAction(\Mff\Mffrps\Domain\Model\Anlass $anlass) {
// 		$this->view->assign('message', 'Anlass '.$anlass->getUid().' was deleted.');
		$this->addFlashMessage('Anlass '.$anlass->getUid().' was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->anlassRepository->remove($anlass);
		
// 		$this->redirect('list');
	}
	/**
	 * handleRequestVars
	 * filter variables
	 *
	 */
	public function handleRequestVars( ) {
		$inVars = array();
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		}
		
		// assign filter-vars, transform them if affored
		$fieldTypes = array( 'date'=>'datefield' , 'todate'=>'datefield' );
		if(isset($inVars['filter'])) {
			if(is_array($inVars['filter'])) {
			    foreach($inVars['filter'] as $varName=>$inVarValue){
				  //if(empty($inVarValue))continue;
				  $fType = isset($fieldTypes[$varName]) ? $fieldTypes[$varName] : 'default';
				  switch($fType){
				      case 'datefield':
					    $da = explode( '.' , $inVarValue );
					    if( is_numeric($da[0]) && is_numeric($da[1]) && is_numeric($da[2])  ){
						$this->settings['filter'][$varName] = mktime( 12,0,0,$da[1],$da[0],$da[2]);
					    }
				      break;
				      default:
					    $this->settings['filter'][$varName] = $inVarValue;
				      break;
				  }
			    }
			}
		}
		
		// overwrite filter-vars with userfields or userfields with incoming values.
		$overwriteFields = array();
		foreach( $this->settings['userfields'] as $nam=>$fld ) {
		    if( isset($fld['overwride_depends_on']) ) $overwriteFields[$nam] = $fld['overwride_depends_on'];
		}
		// $overwriteFields is configured in seutp.txt: array( 'filter_tagesplan_timerange_from'=>'filter_tagesplan_overwride' , 'filter_tagesplan_timerange_to'=>'filter_tagesplan_overwride' );
		if(count($overwriteFields)){
		      foreach($overwriteFields as $varName=>$dependingOption){
			    if(isset($inVars['filter'][$varName])) {
				  if( !empty($this->settings['userfields'][$dependingOption]['value']) ){
					$inVars['userfields'][$varName] = $inVars['filter'][$varName];
				  }
			    }else{
				  if(isset($inVars['userfields'][$varName])) {
					if($inVars['userfields'][$varName])$this->settings['filter'][$varName] = $inVars['userfields'][$varName];
				  }else{
					if( isset($this->settings['userfields'][$varName]['value']) ) $this->settings['filter'][$varName] = $this->settings['userfields'][$varName]['value'];
				  }
			    }
		      }
		}
		// set default value if not choosen eg. userfields.display_feldliste_favorit.value
		foreach( $this->settings['userfields'] as $nam=>$fld ) {
		    if( !isset($inVars['filter'][$nam]) ) {
			$this->settings['filter'][$nam] = $this->settings['userfields'][$nam]['value'];
		    }elseif( isset($this->settings['userfields'][$nam]['value']) && !isset($inVars['userfields'][$nam]) ){
			$inVars['userfields'][$nam] = $inVars['filter'][$nam];
		    }
		}
		
		// overwrite userfields with incoming values.
		if(isset($inVars['userfields']) && $this->settings['userfields']['filter_tagesplan_overwride']['value']) {
		    foreach($inVars['userfields'] as $varName=>$inVarValue){
			if($inVarValue)$this->settings['userfields'][$varName]['value'] = $inVarValue;
		    }
		    $this->systemOptionsUtility->setUserOptions($inVars['userfields']);
		}
		
		// if date filter is empty then create valid date-values
		if(empty($this->settings['filter']['date'])) $this->settings['filter']['date'] = time();
		if( 
		    $this->settings['filter']['todate'] < $this->settings['filter']['date'] || 
		    empty($this->settings['filter']['todate'])
		) {
		    $this->settings['filter']['todate'] = $this->settings['filter']['date']+(3600*24*$this->settings['userfields']['display_belegung_dayrange']['value']) ;
		}
		$this->settings['filter']['dateBack'] = date( 'd.m.Y' , $this->settings['filter']['date'] - (3600*24) );
		$this->settings['filter']['dateForward'] = date( 'd.m.Y' , $this->settings['filter']['date'] + (3600*24) );

	}

}
