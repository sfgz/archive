<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * AntragController
 */
class AntragController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * antragRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AntragRepository
	 * @inject
	 */
	protected $antragRepository = NULL;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 * @inject
	 */
	protected $frontendUserRepository = NULL;

// 	/**
// 	 * ecouserRepository
// 	 *
// 	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
// 	 */
// 	protected $ecouserRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;
	
	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;
	
	/**
	 * calendarUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $calendarUtility = NULL;

	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		$querySettings->setStoragePageIds( $storage );
// 		$this->ecouserRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
// 		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
		$this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
		$this->frontendUserRepository->setDefaultQuerySettings($querySettings);
	      
		$pQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$pStorage['planStoragePid'] = $fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$pQuerySettings->setStoragePageIds( $pStorage );
		$this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
		$this->periodsRepository->setDefaultQuerySettings($pQuerySettings);
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['userfields'] = $this->systemOptionsUtility->getUserOptions();
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$this->settings['anchor2category'] = $this->systemOptionsUtility->settings['anchor2category'];
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		}
		$this->settings = $this->systemOptionsUtility->handleRequestVars( $inVars , $this->settings );
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		$this->contentObj = $configurationManager->getContentObject();
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$this->calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
		$antrags = $this->antragRepository->findAll();
		$this->view->assign( 'antrages' , $antrags );

		$calendarArr = array();
		if ($this->request->hasArgument('refresh')) {
		      $calendarDate = time();
		      $calendarArr = $this->calendarUtility->getCalendarsData( 1 );
		      $calendarData = array( 'meta'=>array('calendarDate'=>$calendarDate) , 'data'=>$calendarArr );
		      $GLOBALS["TSFE"]->fe_user->setKey("user","calendarData", $calendarData);
		      $GLOBALS["TSFE"]->fe_user->sesData_change = true;
		      $GLOBALS["TSFE"]->fe_user->storeSessionData();
		      $calendars['backup_updated']  = 1;
		}else{
		      $calendarData = $GLOBALS['TSFE']->fe_user->getKey('user', 'calendarData');
		      $calendarArr = $calendarData['data'];
		      $calendarDate = $calendarData['meta']['calendarDate'];
		      $calendars['backup_updated']  = 0;
		}
		$this->view->assign( 'calendarDate' , $calendarDate );
		$this->view->assign( 'calendarDb' , $calendarArr );
		
		$this->settings['antrag']['update_hint'] = 0;
		if( count($calendarData['data']) ) {$this->settings['antrag']['update_hint'] +=1;}
		if( count($antrags) ) {$this->settings['antrag']['update_hint'] +=2;}
		$this->view->assign( 'settings' , $this->settings );
		
		$calendars['backup_calendar'] = $this->settings['optionfields']['backup_calendar']['value'] ;
		$calendars['backup_importcals'] = explode( ',' , $this->settings['optionfields']['backup_importcals']['value'] );
		$calendars['count_backup_housecals'] = count( explode( ',' , $this->settings['optionfields']['backup_housecals']['value'] ) );
		$calendars['count_backup_roomcals'] = count( explode( ',' , $this->settings['optionfields']['backup_roomcals']['value'] ) );
		$minCount = empty($calendars['backup_calendar']) ? 0 : 1;
		$minCount += count($calendars['backup_importcals']) ;
		$calendars['count_backup'] = $this->settings['optionfields']['backup_importall']['value'] ? $calendars['count_backup_housecals']+$calendars['count_backup_roomcals']+$minCount : $minCount;
		$time_to_read = $this->settings['optionfields']['backup_importall']['value'] ? ($calendars['count_backup_housecals'] * 4 ) + ( $calendars['count_backup_roomcals'] * 3 ) + $minCount : $minCount;
		$calendars['time_to_read'] = 5 * round($time_to_read / 5) ;
		$this->view->assign( 'calendars' , $calendars );
	}

	/**
	 * action aushang
	 *
	 * @return void
	 */
	public function aushangAction() {
		// Zimmer beziehen, konfiguriert in Flexconf in tt_content
		$zmrArr = explode( ',' , $this->settings['zimmer'] );
		foreach( $zmrArr as $zmr ){
		      $zmrnamesArr[$zmr] = $this->zimmerUtility->getZimmerRepository()->findByUid($zmr);
		}
		
		// Zeitraum aus input Select beziehen
		$perioden = $this->periodsRepository->findAll();
		$this->view->assign( 'perioden' , $perioden );

		// aktueller Zeitraum und Startdatum ermitteln
		$timeZone = 'Europe/Zurich';
		$zurich = new \DateTimeZone( $timeZone );
		date_default_timezone_set( $timeZone ); 
		if ($this->request->hasArgument('aushang')) {
		    $aushangRequest = $this->request->getArgument('aushang');
		}
		if ( isset($aushangRequest) ) {
		    $aktSemObj = $this->getActualSemester( $perioden, $zurich , $aushangRequest);
		    if( isset($aushangRequest['ab']) && !empty($aushangRequest['ab']) ){
			  $datumStart = new \DateTime( date( 'Y-m-d' , $aushangRequest['ab'] ) . ' 06:00:00' , $zurich);
		    }else{
// 			  $datumStart = $aktSemObj->getDatumAb();
                $diffEndDay = 7-$aktSemObj->getDavorBis()->format('N');
                $diffEndDay +=7;
                if($diffEndDay) $aktSemObj->getDavorBis()->add(new \DateInterval('P'.$diffEndDay.'D')) ;
                $datumStart = $aktSemObj->getDavorBis();
		    }
		}else{
		    $aktSemObj = $this->getActualSemester( $perioden, $zurich );
		    $datumStart = new \DateTime( date( 'Y-m-d' ) . ' 06:00:00' , $zurich);
		}
		
		// Semester-select optionen korrigieren und zuweisen
		$diffEndDay = 7-$aktSemObj->getDatumBis()->format('N');
		if($diffEndDay) $aktSemObj->getDatumBis()->add(new \DateInterval('P'.$diffEndDay.'D')) ;
		$this->view->assign( 'semester' , $aktSemObj );
		
		// aktuelles Startdatum korrigieren und zuweisen
		$diffStartDay = $datumStart->format('N')-1 ;
		if($diffStartDay) $datumStart->sub(new \DateInterval('P'.$diffStartDay.'D')) ;
		$this->view->assign( 'start' , $datumStart );
		
		$aHoliday = $this->dbHelperUtility->mkArrHolidayByDates( array( 'date'=>$datumStart->format('U') , 'todate'=>$aktSemObj->getDatumBis()->format('U') ) );
		// zeitplan ermitteln,  array zusammenstellen
		$dDifferenz = 1+$datumStart->diff( $aktSemObj->getDatumBis() )->format('%a') ;
		$loopTag = new \DateTime( $datumStart->format('Y-m-d 06:00:00') , $zurich );
		$cssClasses = array( false => '' , true => 'urlaub' );
		$aRes = array();
		for( $tag = 0 ; $tag < $dDifferenz ; ++$tag) {
		      foreach( $zmrnamesArr as $zmr => $oZimmer ){
 			  $zmr = $oZimmer->getUid();
 			  $zmrReservationObj = $this->dbHelperUtility->mkArrTimetableByRoomAndDate( array($zmr=>$zmr) , $loopTag->format('U') );
 			  $zmrReservationObj = $this->dbHelperUtility->mkArrBelegungByRoomAndDate( array($zmr=>$zmr) , $loopTag->format('U'), $zmrReservationObj );
			  $zmrReservationObj = $this->dbHelperUtility->mkArrAntragByRoomAndDate( array($zmr=>$zmr) , $loopTag->format('U') , $zmrReservationObj  );
			  if(isset($zmrReservationObj[$zmr])){
				foreach($zmrReservationObj[$zmr] as $bix => $bel ) {
				      $aRes[$zmr][ $bel['ab'] . '.'. $bix] = $bel;
				}
				ksort($aRes[$zmr]);
			  }
			  $semesterplan[$zmr]['raum']=$oZimmer;
			  $semesterplan[$zmr]['daten'][ $loopTag->format('W') ][ $loopTag->format('N') ] = array(
				'datum' => new \DateTime( $loopTag->format('Y-m-d H:i:s') , $zurich ) ,
				'css' => $cssClasses[ isset($aHoliday[$loopTag->format('d.m.y')]) ],
				'urlaub' => isset($aHoliday[$loopTag->format('d.m.y')]) ? $aHoliday[$loopTag->format('d.m.y')]['text'] : '',
				'belegungen' => isset($zmrReservationObj[$zmr]) ? $zmrReservationObj[$zmr] : array()
			  );
		      }
		      $loopTag->add(new \DateInterval('P1D'));
		}
		
		$bearbeiter = $GLOBALS['TSFE']->fe_user->user['uid'];
		$this->view->assign( 'zeitplan' , $semesterplan );
		$this->view->assign( 'bearbeiter' , $bearbeiter );
		$this->view->assign( 'aHoliday' , $aHoliday );
		$this->view->assign('contentUid', $this->contentObj->data['uid'] );
	}

	/**
	 * getActualSemester 
	 * used by action aushang
	 *
	 */
	public function getActualSemester( $perioden , $activeTimeZone , $aushang = array() ) {
		if( !empty($aushang['semester']) ){
		      foreach($perioden as $sem){
			    if( $sem->getUid() == $aushang['semester'] ){
				  $sem->getDatumAb()->setTimezone($activeTimeZone);
				  return $sem; 
				  break;
			    }
		      }
		}else{
		      $now = time();
		      foreach($perioden as $sem){
 			    $sem->getDavorBis()->setTimezone($activeTimeZone);
			    $sem->getDatumBis()->setTimezone($activeTimeZone);
			    if( $sem->getDatumBis()->format('U') >= $now && $sem->getDavorBis()->format('U') <= $now){
				  return $sem;
				  break;
			    }
			    // emergency break
			    $sem->getDatumAb()->setTimezone($activeTimeZone);
			    if( $sem->getDatumAb()->format('U') >= $now){
				  return $sem;
				  break;
			    }
		      }
		}
		return $sem;
	}
	
	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		if ($this->request->hasArgument('newAntrag')) {
		      $newVals =  $this->request->getArgument('newAntrag');
		      if($newVals['zimmer']) {
			    $newAntrag['zimmer'] = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['zimmer']);
		      }
		      if($newVals['datum']) {
			  $timeZone = 'Europe/Zurich';
			  $zurich = new \DateTimeZone( $timeZone );
			  $newAntrag['datum'] = new \DateTime( date('Y-m-d 06:00:00' , $newVals['datum'] ) , $zurich );
		      }
		}
// 		$newAntrag['bearbeiter'] = $this->ecouserRepository->findByUid($GLOBALS['TSFE']->fe_user->user['uid']);
		$newAntrag['bearbeiter'] = $this->frontendUserRepository->findByUid($GLOBALS['TSFE']->fe_user->user['uid']);
		$this->view->assign( 'newAntrag' , $newAntrag );
		$this->view->assign('zimmers', $this->zimmerUtility->mkZimmerSelectObject( 1 ) );
		$this->view->assign( 'bearbeiter' , $this->frontendUserRepository->findAll() );
		if ($this->request->hasArgument('semester')) {
		    $aushangRequest['semester'] = $this->request->getArgument('semester');
		    $this->view->assign('semester', $aushangRequest['semester'] );
		}
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		
		$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
		if($contentUid) $this->view->assign('contentUid', $contentUid );
	}

	/**
	 * Initialize  create
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
		if ($this->request->hasArgument('newAntrag')) {
			$antrReq = $this->request->getArgument('newAntrag');
			$args = $this->arguments['newAntrag']->getPropertyMappingConfiguration();
			$args->forProperty('datum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			if(empty($antrReq['datum'])) {
			      $this->settings['errorMessages'][] = 'Datum leer, nicht gespeichert!';
			      $this->arguments->getArgument('newAntrag')->getPropertyMappingConfiguration()->skipProperties('datum');
			}
		}
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffrps\Domain\Model\Antrag $newAntrag
	 * @return void
	 */
	public function createAction(\Mff\Mffrps\Domain\Model\Antrag $newAntrag) {
		    $originalAb = $newAntrag->getZeitStart();
		    $originalBis = $newAntrag->getZeitEnde();
		    $from = $this->dbHelperUtility->cleanTimeString( $originalAb );
		    $to = $this->dbHelperUtility->cleanTimeString( $originalBis );
		    if( $originalAb != $from ){$newAntrag->setZeitStart($from);}
		    if( $originalBis != $to ){$newAntrag->setZeitEnde($to);}
			$zurich = new \DateTimeZone( 'Europe/Zurich' );
			$neuDatum  = $newAntrag->getDatum()->format('d.m.Y');
			$datArr = explode( '.' , $neuDatum );
			$datum = mktime( 12 , 0 , 0 , $datArr[1] ,$datArr[0] ,$datArr[2]   );
			$objDatum = new \DateTime( date('Y-m-d H:i:s',$datum) , $zurich );
			$newAntrag->setDatum($objDatum);

		    $this->antragRepository->add($newAntrag);
		    $this->persistenceManager->persistAll();
		    $this->addFlashMessage('Neue Antrag erstellt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    $this->settings['forwardingArguments']['antrag'] = $newAntrag;
		if ($this->request->hasArgument('semester')) {
		    $forwardingArguments['semester'] = $this->request->getArgument('semester');
		}
		$forwardingArguments['updated'] = 1;
		$forwardingArguments['pageType'] = '95';
		$forwardingArguments['antrag'] = $newAntrag->getUid();
		$this->forward( 'edit' , NULL, NULL, $forwardingArguments );
	}

	/**
	 * action edit
	 * 
	 * @ignorevalidation $antrag
	 * @param \Mff\Mffrps\Domain\Model\Antrag $antrag
	 * @return void
	 */
	public function editAction(\Mff\Mffrps\Domain\Model\Antrag $antrag = NULL) {
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 1 );
		$this->view->assign('zimmers', $zimmers );

		$this->view->assign('antrag', $antrag);
		$bearbeiter = $this->frontendUserRepository->findAll();
		$this->view->assign( 'bearbeiter' , $bearbeiter );
		
		$oldact = ($this->request->hasArgument('oldact')) ? $this->request->getArgument('oldact') : 'aushang';
		$this->view->assign( 'oldact' , $oldact);
		$updated = ($this->request->hasArgument('updated')) ? $this->request->getArgument('updated') : 0;
		$this->view->assign( 'updated' , $updated);
		
		$this->view->assign('anlaesse', $this->dbHelperUtility->mkAnlassSelectArray() );
		$this->view->assign('mieters', $this->dbHelperUtility->mkMieterSelectArray() );
		if ($this->request->hasArgument('semester')) {
		    $aushangRequest['semester'] = $this->request->getArgument('semester');
		    $this->view->assign('semester', $aushangRequest['semester'] );
		}
		$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
		if($contentUid) $this->view->assign('contentUid', $contentUid );
	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		if ($this->request->hasArgument('antrag')) {
			$bel = $this->request->getArgument('antrag');
			if(empty($bel['datum'])) {
			      $this->settings['errorMessages'][] = 'Datum leer, nicht gespeichert!';
			      $this->arguments->getArgument('antrag')->getPropertyMappingConfiguration()->skipProperties('datum');
			}elseif(!is_numeric($bel['datum'])) {
			      $this->arguments->getArgument('antrag')->getPropertyMappingConfiguration()->skipProperties('datum');
			}
			if(empty($bel['zimmer'])) {
			      $this->settings['errorMessages'][] = 'Zimmer leer, nicht gespeichert!';
			      $this->arguments->getArgument('antrag')->getPropertyMappingConfiguration()->skipProperties('belZimmer');
			}
		}
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffrps\Domain\Model\Antrag $antrag
	 * @return void
	 */
	public function updateAction(\Mff\Mffrps\Domain\Model\Antrag $antrag) {
		if(is_array($this->settings['errorMessages'])){
		    $this->addFlashMessage( implode(', ' , $this->settings['errorMessages'] ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    $updated = 0;
		}else{
		    if ($this->request->hasArgument('antrag')) {
			$timeZone = 'Europe/Zurich';
			$zurich = new \DateTimeZone( $timeZone );
			$bel = $this->request->getArgument('antrag');
			$datArr = explode( '.' , $bel['datum'] );
			$datum = mktime( 12 , 0 , 0 , $datArr[1] ,$datArr[0] ,$datArr[2]   );
			$objDatum = new \DateTime( date('Y-m-d H:i:s',$datum) , $zurich );
			$antrag->setDatum($objDatum);
		    echo date('Y-m-d H:i:s',$datum);
		    }
		    $numbHowerFrom = 0 + str_replace( ':' , '.' , $antrag->getZeitStart());
		    $numbHowerTo = 0 + str_replace( ':' , '.' , $antrag->getZeitEnde());
		    $howerFrom = floor( $numbHowerFrom );
		    $howerTo = floor( $numbHowerTo );
		    $minFrom = round(($numbHowerFrom-$howerFrom)*100); // eg. 5
		    $minTo = round(($numbHowerTo-$howerTo)*100); // eg. 55
		    $from = $this->dbHelperUtility->cleanTimeArray( array( $howerFrom , $minFrom) );
		    $to = $this->dbHelperUtility->cleanTimeArray( array($howerTo , $minTo ) );
		    if( $antrag->getZeitStart() != $from ){$antrag->setZeitStart($from);}
		    if( $antrag->getZeitEnde() != $to ){$antrag->setZeitEnde($to);}
		    $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		    $this->antragRepository->update($antrag);
		    $updated = 1;
// 		    $this->persistenceManager->persistAll();
		}
		if ($this->request->hasArgument('oldact')) $this->settings['forwardingArguments']['oldact'] = $this->request->getArgument('oldact');
		if ($this->request->hasArgument('semester')) {
		    $this->settings['forwardingArguments']['semester'] = $this->request->getArgument('semester');
		}
		$this->settings['forwardingArguments']['updated'] = $updated;
		$this->settings['forwardingArguments']['antrag'] = $antrag;
		$this->settings['forwardingArguments']['pageType'] = '95';
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->forward('edit', NULL, NULL, $this->settings['forwardingArguments']);
	}

	/**
	 * action accept
	 * 
	 * @ignorevalidation $antrag
	 *
	 * @param \Mff\Mffrps\Domain\Model\Antrag $antrag
	 * @return void
	 */
	public function acceptAction(\Mff\Mffrps\Domain\Model\Antrag $antrag = NULL) {
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 1 );
		$bearbeiter = $this->frontendUserRepository->findAll();
		$oldact = ($this->request->hasArgument('oldact')) ? $this->request->getArgument('oldact') : 'aushang';
		$anlaesse = $this->dbHelperUtility->mkAnlassSelectArray();
		$mieters = $this->dbHelperUtility->mkMieterSelectArray();

		if($antrag){
		      $setValue['source'] = '';
		      $setValue['requestEmail'] = $antrag->getBearbeiter()->getEmail();
		      $setValue['deleteAntrag'] =  $antrag->getUid() ;
		      $setValue['belZimmer'] =  $antrag->getZimmer()->getUid() ;
		      $setValue['datum'] =  $antrag->getDatum() ;
		      $setValue['from'] = $this->dbHelperUtility->cleanTimeString( $antrag->getZeitStart() ) ;
		      $setValue['to'] = $this->dbHelperUtility->cleanTimeString( $antrag->getZeitEnde() ) ;
		      $setValue['belegungstext'] =  $antrag->getBearbeiter()->getFirstname() . ' ' . $antrag->getBearbeiter()->getLastname();
		      $setValue['zusatztext'] = 'erfasst:'.$setValue['requestEmail'].' '.trim( trim( $antrag->getBetreff(). "\n" .$antrag->getMieter() , "\n") . "\n" .$antrag->getText() , "\n");
		      $setValue['bearbeiter'] =  $antrag->getBearbeiter();
		}elseif( $this->request->hasArgument('termin')){
		      $termin = $this->request->getArgument('termin');
		      if($termin){
			   // $setValue = $termin;
			    $setValue['source'] = $termin['kalender'];
			    $setValue['requestEmail'] = $termin['mieter'];
			    $setValue['deleteAntrag'] = $termin['uid'];
			    $setValue['belZimmer'] =  $termin['zimmer'] ;
			    $setValue['datum'] =  $termin['datum'] ;
			    $setValue['from'] =  $this->dbHelperUtility->cleanTimeString($termin['zeit_start']) ;
			    $setValue['to'] =  $this->dbHelperUtility->cleanTimeString($termin['zeit_ende']) ;
			    $setValue['belegungstext'] =  $termin['betreff'] ;
			    $setValue['zusatztext'] =  'erfasst:'.$termin['mieter'].' '.$termin['text'] ;
			    $setValue['mieter'] =  $termin['mieter'] ;
		      }
		}
		$this->settings['forwardingArguments']['setValue'] = $setValue;
		$this->settings['forwardingArguments']['zimmers'] = $zimmers;
		$this->settings['forwardingArguments']['oldact'] = $oldact;
		$this->settings['forwardingArguments']['source'] = $setValue['source'];
		$this->settings['forwardingArguments']['deleteAntrag'] = $setValue['deleteAntrag'];
		$this->settings['forwardingArguments']['anlaesse'] = $anlaesse;
		$this->settings['forwardingArguments']['mieters'] = $mieters;
		$this->settings['forwardingArguments']['pageType'] = '95';
		
		$this->forward('new', 'Belegung', NULL , $this->settings['forwardingArguments']);

	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffrps\Domain\Model\Antrag $antrag
	 * @return void
	 */
	public function deleteAction(\Mff\Mffrps\Domain\Model\Antrag $antrag) {
		$this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->antragRepository->remove($antrag);
		if ( $this->request->hasArgument($this->settings['oldact']) ) {
		     $this->settings['forwardingArguments']['oldact'] =  $this->request->getArgument($this->settings['oldact']);
		}
		if ($this->request->hasArgument('semester')) {
		    $this->settings['forwardingArguments']['semester'] = $this->request->getArgument('semester');
		}
		$this->settings['forwardingArguments']['updated'] = 1;
		$this->settings['forwardingArguments']['pageType'] = '95';
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->forward('edit', NULL, NULL, $this->settings['forwardingArguments']);
	}

	/**
	 * handleRequestVars
	 * filter variables
	 *
	 */
	public function handleRequestVars( ) {
		$inVars = array();
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		}
		
		// assign filter-vars, transform them if affored
		$fieldTypes = array( 'date'=>'datefield' , 'todate'=>'datefield' );
		if(is_array($inVars['filter'])) {
		    foreach($inVars['filter'] as $varName=>$inVarValue){
			  //if(empty($inVarValue))continue;
			  $fType = isset($fieldTypes[$varName]) ? $fieldTypes[$varName] : 'default';
			  switch($fType){
			      case 'datefield':
				    $da = explode( '.' , $inVarValue );
				    if( is_numeric($da[0]) && is_numeric($da[1]) && is_numeric($da[2])  ){
					$this->settings['filter'][$varName] = mktime( 12,0,0,$da[1],$da[0],$da[2]);
				    }
			      break;
			      default:
				    $this->settings['filter'][$varName] = $inVarValue;
			      break;
			  }
		    }
		}
		
		// override filter-vars with userfields or userfields with incoming values.
		foreach( $this->settings['userfields'] as $nam=>$fld ) {
		    if( isset($fld['overwride_depends_on']) ) $overrideFields[$nam] = $fld['overwride_depends_on'];
		}
		// $overrideFields is configured in seutp.txt: array( 'filter_tagesplan_timerange_from'=>'filter_tagesplan_overwride' , 'filter_tagesplan_timerange_to'=>'filter_tagesplan_overwride' );
		if(isset($overrideFields)){
		      foreach($overrideFields as $varName=>$dependingOption){
			    if(isset($inVars['filter'][$varName])) {
				  if( !empty($this->settings['userfields'][$dependingOption]['value']) ){
					$inVars['userfields'][$varName] = $inVars['filter'][$varName];
				  }
			    }else{
				  if(isset($inVars['userfields'][$varName])) {
					$this->settings['filter'][$varName] = $inVars['userfields'][$varName];
				  }else{
					if( isset($this->settings['userfields'][$varName]['value']) ) $this->settings['filter'][$varName] = $this->settings['userfields'][$varName]['value'];
				  }
			    }
		      }
		}
	      foreach( $this->settings['userfields'] as $nam=>$fld ) {
		  if( !isset($inVars['filter'][$nam]) ) {
		      $this->settings['filter'][$nam] = $this->settings['userfields'][$nam]['value'];
		  }elseif( isset($this->settings['userfields'][$nam]['value']) && !isset($inVars['userfields'][$nam]) ){
		      $inVars['userfields'][$nam] = $inVars['filter'][$nam];
		  }
	      }
		
		// override userfields with incoming values.
		if(isset($inVars['userfields'])) {
		    foreach($inVars['userfields'] as $varName=>$inVarValue){
			$this->settings['userfields'][$varName]['value'] = $inVarValue;
		    }
		    $this->systemOptionsUtility->setUserOptions($inVars['userfields']);
		}
		
		// if date filter is empty then create valid date-values
		if(empty($this->settings['filter']['date'])) $this->settings['filter']['date'] = time();
		if( 
		    $this->settings['filter']['todate'] < $this->settings['filter']['date'] || 
		    empty($this->settings['filter']['todate'])
		) {
		    $this->settings['filter']['todate'] = $this->settings['filter']['date']+(3600*24*$this->settings['userfields']['display_belegung_dayrange']['value']) ;
		}
		$this->settings['filter']['dateBack'] = date( 'd.m.Y' , $this->settings['filter']['date'] - (3600*24) );
		$this->settings['filter']['dateForward'] = date( 'd.m.Y' , $this->settings['filter']['date'] + (3600*24) );

	}

}
