<?php
namespace Mff\Mffrps\Validation\Validator;

class AnlassValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractValidator {
    /**
    * Object Manager
    * 
    * @var \TYPO3\CMS\Extbase\Object\ObjectManagerInterface
    * @inject
    */
    protected $objectManager;
    
    /**
    * Validates the given value
    * 
    * @param mixed $value
    * @return bool
    */
    protected function isValid($value){
	  $success = FALSE;
	  $anlass = $value->getAnlass();
	  if($anlass>0) $success = TRUE;
	  if( !$success ){
	      $error = $this->objectManager->get(
		    'TYPO3\\CMS\\Extbase\\Validation\\Error',
		    'Anlass fehlt',
		    1482067243
	      );
	      $this->result->forProperty('anlass')->addError($error);
	  }
	  return $success;
    }
}
