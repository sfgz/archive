<?php
namespace Mff\Mffrps\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Belegungs
 */
class BelegungRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	 * @var array
	 */
	protected $defaultOrderings = array(
		'datum' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		'bel_zimmer' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		'ab' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);
	  
	  /**
	  *  Find by pattern 'search'
	  * 
	 * @param string $sAnlasses uids of anlasses
	 * @return void
	  */
	  public function findByAnlassList( $sAnlasses ) {
	      $query = $this->createQuery();
	      
	      $aAnlasses = explode( ',' , $sAnlasses );
	      foreach($aAnlasses as $rAnlassUid){
		      $constraints[] = $query->equals('anlass', trim($rAnlassUid) );
	      }
	      $query->matching(
		      $query->logicalOr($constraints)
	      );
	      $query->setOrderings(
		  array(
		      'datum' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		      'ab' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );
	      return $query->execute();
	  }
	  
	  /**
	  *  Find by pattern 'search'
	  * 
	 * @param array $zimmerArr uids of rooms, or empty 
	 * @param array $dateRangeArr array with one or two values for dateFrom an dateTo
	 * @return void
	  */
	  public function findByRoomsAndDates( $zimmerArr = NULL , $dateRangeArr = array() ) {
	      $constraints = array();
	      $dateFilter = $this->unixDatesToDatestrings($dateRangeArr);
	      $query = $this->createQuery();
	      
	      if( count($zimmerArr) > 0 ){
		  if( count($dateFilter) == 2 ){
		      // Filter by room AND dateFrom AND dateTo
		      foreach($zimmerArr as $zimmerUid){
			    $constraints[] = $query->logicalAnd(
				  $query->equals('bel_zimmer', $zimmerUid ),
				  $query->greaterThanOrEqual('datum', $dateFilter['date'] ),
 				  $query->lessThanOrEqual('datum', $dateFilter['todate'] )
			    );
		      }
		  }elseif( count($dateFilter) == 1 ){
		      // Filter by room AND date
		      foreach($zimmerArr as $zimmerUid){
			    $constraints[] = $query->logicalAnd(
				  $query->equals('bel_zimmer', $zimmerUid ),
				  $query->equals('datum', $dateFilter['date'] )
			    );
		      }
		  }else{
		      // Filter by room
		      foreach($zimmerArr as $zimmerUid){
			    $constraints[] = $query->equals('bel_zimmer', $zimmerUid );
		      }
		  }
		  $query->matching( $query->logicalOr($constraints) );
	      }else{
		  if( count($dateFilter) == 2 ){
		      // Filter by dateFrom AND dateTo
		      $query->matching( $query->logicalAnd(
				$query->greaterThanOrEqual('datum', $dateFilter['date'] ),
				$query->lessThanOrEqual('datum', $dateFilter['todate'] )
				)
		      );
		  }elseif( count($dateFilter) == 1 ){
		      // Filter by date
		      $query->matching( $query->equals('datum', $dateFilter['date'] ) );
		  }
	      }
	      
	      $query->setOrderings(
		  array(
		      'datum' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING,
		      'ab' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );
	      return $query->execute();
	  
	  }
	  
	  /**
	  *  assignOrphansToAnlass
	  * 
	  * @param int $anlassUid
	  * @return void
	  */
	  public function assignOrphansToAnlass( $anlassUid ) {
		  
		  if( empty( $anlassUid ) ) return FALSE;
		  
		  $sql ="UPDATE tx_mffrps_domain_model_belegung f1";
		  $sql .= " LEFT OUTER JOIN tx_mffrps_domain_model_anlass f2";
		  $sql .= " ON f1.anlass = f2.uid AND f1.pid = f2.pid";
		  $sql .= " SET f1.anlass = " . $anlassUid . ", f1.zusatztext = CONCAT_WS(',', f1.zusatztext , f1.anlass )";
		  $sql .= " WHERE f2.uid IS NULL;";
		  
		  $res = $GLOBALS['TYPO3_DB']->sql_query($sql);
		  
		  return $res;
	  }
	  
	  /**
	  *  findOrphans
	  * 
	  * @param boolean $ReturnRawQueryResult if FALSE it returns a object
	  * @return void
	  */
	  public function findOrphans($ReturnRawQueryResult = FALSE) {
		  
		  $sql ="SELECT tx_mffrps_domain_model_belegung.*";
		  $sql .=" FROM tx_mffrps_domain_model_belegung";
		  $sql .=" LEFT JOIN tx_mffrps_domain_model_anlass";
		  $sql .="  ON tx_mffrps_domain_model_belegung.anlass = tx_mffrps_domain_model_anlass.uid";
		  $sql .= " WHERE tx_mffrps_domain_model_anlass.uid IS NULL";
		  
		  $res = $this->callSqlStatement( $sql , $ReturnRawQueryResult );
		  
		  return $res;
	  }
	  
	  /**
	  *  transforms array-values
	  * 
	 * @param array $dateRangeArr array with one or two values for dateFrom an dateTo
	 * @return array
	  */
	  public function unixDatesToDatestrings( $dateRangeArr = array() ) {
	      $dateFilter = array();
	      if( count($dateRangeArr) > 0 ){
		  if( !empty($dateRangeArr['date']) ){
		      $dateFilter['date'] = date('Y-m-d', $dateRangeArr['date'] );
		      if( !empty($dateRangeArr['todate']) ){
			    $dateFilter['todate'] =  date('Y-m-d',$dateRangeArr['todate']);
		      }
		  }
	      }
	      return $dateFilter;
	  }

	  public function callSqlStatement( $qryStatement , $ReturnRawQueryResult = TRUE) {
	      $Query = $this->createquery();
// 	      $Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement($qryStatement); 
	      return $Query->execute($ReturnRawQueryResult);
	  }


	
}