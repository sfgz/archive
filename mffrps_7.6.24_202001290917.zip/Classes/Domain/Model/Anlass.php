<?php
namespace Mff\Mffrps\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Anlass
 */
class Anlass extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * tstamp
	 *
	 * @var int
	 */
	protected $tstamp = 0;
	/**
	 * crdate
	 *
	 * @var int
	 */
	protected $crdate = 0;

	/**
	 * importUid
	 *
	 * @var int
	 */
	protected $importUid = 0;

	/**
	 * mieter
	 *
	 * @var int
	 * @validate NotEmpty
	 */
	protected $mieter = 0;

	/**
	 * verwendungszweck
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $verwendungszweck = '';

	/**
	 * kontaktPerson
	 *
	 * @var string
	 */
	protected $kontaktPerson = '';

	/**
	 * kontaktAnrede
	 *
	 * @var string
	 */
	protected $kontaktAnrede = '';

	/**
	 * kontaktEmail
	 *
	 * @var string
	 */
	protected $kontaktEmail = '';

	/**
	 * kontaktTelefon
	 *
	 * @var string
	 */
	protected $kontaktTelefon = '';

	/**
	 * bemerkungen
	 *
	 * @var string
	 */
	protected $bemerkungen = '';

	/**
	 * zuschlagBetrag
	 *
	 * @var string
	 */
	protected $zuschlagBetrag = 0;

	/**
	 * zuschlagText
	 *
	 * @var string
	 */
	protected $zuschlagText = '';

	/**
	 * gesuchDatum
	 *
	 * @var \DateTime
	 */
	protected $gesuchDatum = NULL;

	/**
	 * schulleitungKurz
	 *
	 * @var string
	 */
	protected $schulleitungKurz = '';

	/**
	 * schulleitungDatum
	 *
	 * @var \DateTime
	 */
	protected $schulleitungDatum = NULL;

	/**
	 * rechnungsDatum
	 *
	 * @var \DateTime
	 */
	protected $rechnungsDatum = NULL;

	/**
	 * cateringText
	 *
	 * @var bool
	 */
	protected $cateringText = FALSE;

	/**
	 * verstecken
	 *
	 * @var bool
	 */
	protected $verstecken = FALSE;

	/**
	 * anlBelegung
	 * @lazy
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Belegung>
	 * @cascade remove
	 */
	protected $anlBelegung = NULL;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->anlBelegung = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the tstamp
	 *
	 * @return int $tstamp
	 */
	public function getTstamp() {
		return $this->tstamp;
	}

	/**
	 * Sets the tstamp
	 *
	 * @param int $tstamp
	 * @return void
	 */
	public function setTstamp($tstamp) {
		$this->tstamp = $tstamp;
	}

	/**
	 * Returns the crdate
	 *
	 * @return int $crdate
	 */
	public function getCrdate() {
		return $this->crdate;
	}

	/**
	 * Sets the crdate
	 *
	 * @param int $crdate
	 * @return void
	 */
	public function setCrdate($crdate) {
		$this->crdate = $crdate;
	}

	/**
	 * Returns the importUid
	 *
	 * @return int $importUid
	 */
	public function getImportUid() {
		return $this->importUid;
	}

	/**
	 * Sets the importUid
	 *
	 * @param int $importUid
	 * @return void
	 */
	public function setImportUid($importUid) {
		$this->importUid = $importUid;
	}

	/**
	 * Returns the mieter
	 *
	 * @return int $mieter
	 */
	public function getMieter() {
		return $this->mieter;
	}

	/**
	 * Sets the mieter
	 *
	 * @param int $mieter
	 * @return void
	 */
	public function setMieter($mieter) {
		$this->mieter = $mieter;
	}

	/**
	 * Returns the verwendungszweck
	 *
	 * @return string $verwendungszweck
	 */
	public function getVerwendungszweck() {
		return $this->verwendungszweck;
	}

	/**
	 * Sets the verwendungszweck
	 *
	 * @param string $verwendungszweck
	 * @return void
	 */
	public function setVerwendungszweck($verwendungszweck) {
		$this->verwendungszweck = $verwendungszweck;
	}

	/**
	 * Returns the kontaktPerson
	 *
	 * @return string $kontaktPerson
	 */
	public function getKontaktPerson() {
		return $this->kontaktPerson;
	}

	/**
	 * Sets the kontaktPerson
	 *
	 * @param string $kontaktPerson
	 * @return void
	 */
	public function setKontaktPerson($kontaktPerson) {
		$this->kontaktPerson = $kontaktPerson;
	}

	/**
	 * Returns the kontaktAnrede
	 *
	 * @return string $kontaktAnrede
	 */
	public function getKontaktAnrede() {
		return $this->kontaktAnrede;
	}

	/**
	 * Sets the kontaktAnrede
	 *
	 * @param string $kontaktAnrede
	 * @return void
	 */
	public function setKontaktAnrede($kontaktAnrede) {
		$this->kontaktAnrede = $kontaktAnrede;
	}

	/**
	 * Returns the kontaktEmail
	 *
	 * @return string $kontaktEmail
	 */
	public function getKontaktEmail() {
		return $this->kontaktEmail;
	}

	/**
	 * Sets the kontaktEmail
	 *
	 * @param string $kontaktEmail
	 * @return void
	 */
	public function setKontaktEmail($kontaktEmail) {
		$this->kontaktEmail = $kontaktEmail;
	}

	/**
	 * Returns the kontaktTelefon
	 *
	 * @return string $kontaktTelefon
	 */
	public function getKontaktTelefon() {
		return $this->kontaktTelefon;
	}

	/**
	 * Sets the kontaktTelefon
	 *
	 * @param string $kontaktTelefon
	 * @return void
	 */
	public function setKontaktTelefon($kontaktTelefon) {
		$this->kontaktTelefon = $kontaktTelefon;
	}

	/**
	 * Returns the bemerkungen
	 *
	 * @return string $bemerkungen
	 */
	public function getBemerkungen() {
		return $this->bemerkungen;
	}

	/**
	 * Sets the bemerkungen
	 *
	 * @param string $bemerkungen
	 * @return void
	 */
	public function setBemerkungen($bemerkungen) {
		$this->bemerkungen = $bemerkungen;
	}

	/**
	 * Returns the zuschlagBetrag
	 *
	 * @return int $zuschlagBetrag
	 */
	public function getZuschlagBetrag() {
		return $this->zuschlagBetrag;
	}

	/**
	 * Sets the zuschlagBetrag
	 *
	 * @param int $zuschlagBetrag
	 * @return void
	 */
	public function setZuschlagBetrag($zuschlagBetrag) {
		$this->zuschlagBetrag = $zuschlagBetrag;
	}

	/**
	 * Returns the zuschlagText
	 *
	 * @return string $zuschlagText
	 */
	public function getZuschlagText() {
		return $this->zuschlagText;
	}

	/**
	 * Sets the zuschlagText
	 *
	 * @param string $zuschlagText
	 * @return void
	 */
	public function setZuschlagText($zuschlagText) {
		$this->zuschlagText = $zuschlagText;
	}

	/**
	 * Returns the gesuchDatum
	 *
	 * @return \DateTime $gesuchDatum
	 */
	public function getGesuchDatum() {
		return $this->gesuchDatum;
	}

	/**
	 * Sets the gesuchDatum
	 *
	 * @param \DateTime $gesuchDatum
	 * @return void
	 */
	public function setGesuchDatum(\DateTime $gesuchDatum = NULL) {
		$this->gesuchDatum = $gesuchDatum;
	}

	/**
	 * Returns the schulleitungKurz
	 *
	 * @return string $schulleitungKurz
	 */
	public function getSchulleitungKurz() {
		return $this->schulleitungKurz;
	}

	/**
	 * Sets the schulleitungKurz
	 *
	 * @param string $schulleitungKurz
	 * @return void
	 */
	public function setSchulleitungKurz($schulleitungKurz) {
		$this->schulleitungKurz = $schulleitungKurz;
	}

	/**
	 * Returns the schulleitungDatum
	 *
	 * @return \DateTime $schulleitungDatum
	 */
	public function getSchulleitungDatum() {
		return $this->schulleitungDatum;
	}

	/**
	 * Sets the schulleitungDatum
	 *
	 * @param \DateTime $schulleitungDatum
	 * @return void
	 */
	public function setSchulleitungDatum(\DateTime $schulleitungDatum = NULL) {
		$this->schulleitungDatum = $schulleitungDatum;
	}

	/**
	 * Returns the rechnungsDatum
	 *
	 * @return \DateTime $rechnungsDatum
	 */
	public function getRechnungsDatum() {
		return $this->rechnungsDatum;
	}

	/**
	 * Sets the rechnungsDatum
	 *
	 * @param \DateTime $rechnungsDatum
	 * @return void
	 */
	public function setRechnungsDatum(\DateTime $rechnungsDatum = NULL) {
		$this->rechnungsDatum = $rechnungsDatum;
	}

	/**
	 * Returns the cateringText
	 *
	 * @return bool $cateringText
	 */
	public function getCateringText() {
		return $this->cateringText;
	}

	/**
	 * Sets the cateringText
	 *
	 * @param bool $cateringText
	 * @return void
	 */
	public function setCateringText($cateringText) {
		$this->cateringText = $cateringText;
	}

	/**
	 * Returns the boolean state of cateringText
	 *
	 * @return bool
	 */
	public function isCateringText() {
		return $this->cateringText;
	}

	/**
	 * Returns the verstecken
	 *
	 * @return bool $verstecken
	 */
	public function getVerstecken() {
		return $this->verstecken;
	}

	/**
	 * Sets the verstecken
	 *
	 * @param bool $verstecken
	 * @return void
	 */
	public function setVerstecken($verstecken) {
		$this->verstecken = $verstecken;
	}

	/**
	 * Returns the boolean state of verstecken
	 *
	 * @return bool
	 */
	public function isVerstecken() {
		return $this->verstecken;
	}

	/**
	 * Adds a Belegung
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $anlBelegung
	 * @return void
	 */
	public function addAnlBelegung(\Mff\Mffrps\Domain\Model\Belegung $anlBelegung) {
		$this->anlBelegung->attach($anlBelegung);
	}

	/**
	 * Removes a Belegung
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $anlBelegungToRemove The Belegung to be removed
	 * @return void
	 */
	public function removeAnlBelegung(\Mff\Mffrps\Domain\Model\Belegung $anlBelegungToRemove) {
		$this->anlBelegung->detach($anlBelegungToRemove);
	}

	/**
	 * Returns the anlBelegung
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Belegung> $anlBelegung
	 */
	public function getAnlBelegung() {
		return $this->anlBelegung;
	}

	/**
	 * Sets the anlBelegung
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Belegung> $anlBelegung
	 * @return void
	 */
	public function setAnlBelegung(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $anlBelegung) {
		$this->anlBelegung = $anlBelegung;
	}

}