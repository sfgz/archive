<?php
namespace Mff\Mffrps\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Mieter
 */
class Mieter extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * import_uid
	 *
	 * @var int
	 */
	protected $import_uid = 0;

	/**
	 * kurz
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $kurz = '';

	/**
	 * anrede
	 *
	 * @var int
	 */
	protected $anrede = 0;

	/**
	 * name
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $name = '';

	/**
	 * strasseNr
	 *
	 * @var string
	 */
	protected $strasseNr = '';

	/**
	 * plzOrt
	 *
	 * @var string
	 */
	protected $plzOrt = '';

	/**
	 * rechnungsadresse
	 *
	 * @var string
	 */
	protected $rechnungsadresse = '';

	/**
	 * email
	 *
	 * @var string
	 */
	protected $email = '';

	/**
	 * telefon
	 *
	 * @var string
	 */
	protected $telefon = '';

	/**
	 * telefax
	 *
	 * @var string
	 */
	protected $telefax = '';

	/**
	 * intern
	 *
	 * @var bool
	 */
	protected $intern = FALSE;

	/**
	 * verstecken
	 *
	 * @var bool
	 */
	protected $verstecken = FALSE;

	/**
	 * mtrAnlass
	 * @lazy
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Anlass>
	 * @cascade remove
	 */
	protected $mtrAnlass = NULL;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->mtrAnlass = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the importUid
	 *
	 * @return int $importUid
	 */
	public function getImportUid() {
		return $this->importUid;
	}

	/**
	 * Sets the importUid
	 *
	 * @param int $importUid
	 * @return void
	 */
	public function setImportUid($importUid) {
		$this->importUid = $importUid;
	}

	/**
	 * Returns the kurz
	 *
	 * @return string $kurz
	 */
	public function getKurz() {
		return $this->kurz;
	}

	/**
	 * Sets the kurz
	 *
	 * @param string $kurz
	 * @return void
	 */
	public function setKurz($kurz) {
		$this->kurz = $kurz;
	}

	/**
	 * Returns the anrede
	 *
	 * @return int $anrede
	 */
	public function getAnrede() {
		return $this->anrede;
	}

	/**
	 * Sets the anrede
	 *
	 * @param int $anrede
	 * @return void
	 */
	public function setAnrede($anrede) {
		$this->anrede = $anrede;
	}

	/**
	 * Returns the name
	 *
	 * @return string $name
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Sets the name
	 *
	 * @param string $name
	 * @return void
	 */
	public function setName($name) {
		$this->name = $name;
	}

	/**
	 * Returns the strasseNr
	 *
	 * @return string $strasseNr
	 */
	public function getStrasseNr() {
		return $this->strasseNr;
	}

	/**
	 * Sets the strasseNr
	 *
	 * @param string $strasseNr
	 * @return void
	 */
	public function setStrasseNr($strasseNr) {
		$this->strasseNr = $strasseNr;
	}

	/**
	 * Returns the plzOrt
	 *
	 * @return string $plzOrt
	 */
	public function getPlzOrt() {
		return $this->plzOrt;
	}

	/**
	 * Sets the plzOrt
	 *
	 * @param string $plzOrt
	 * @return void
	 */
	public function setPlzOrt($plzOrt) {
		$this->plzOrt = $plzOrt;
	}

	/**
	 * Returns the rechnungsadresse
	 *
	 * @return string $rechnungsadresse
	 */
	public function getRechnungsadresse() {
		return $this->rechnungsadresse;
	}

	/**
	 * Sets the rechnungsadresse
	 *
	 * @param string $rechnungsadresse
	 * @return void
	 */
	public function setRechnungsadresse($rechnungsadresse) {
		$this->rechnungsadresse = $rechnungsadresse;
	}

	/**
	 * Returns the email
	 *
	 * @return string $email
	 */
	public function getEmail() {
		return $this->email;
	}

	/**
	 * Sets the email
	 *
	 * @param string $email
	 * @return void
	 */
	public function setEmail($email) {
		$this->email = $email;
	}

	/**
	 * Returns the telefon
	 *
	 * @return string $telefon
	 */
	public function getTelefon() {
		return $this->telefon;
	}

	/**
	 * Sets the telefon
	 *
	 * @param string $telefon
	 * @return void
	 */
	public function setTelefon($telefon) {
		$this->telefon = $telefon;
	}

	/**
	 * Returns the telefax
	 *
	 * @return string $telefax
	 */
	public function getTelefax() {
		return $this->telefax;
	}

	/**
	 * Sets the telefax
	 *
	 * @param string $telefax
	 * @return void
	 */
	public function setTelefax($telefax) {
		$this->telefax = $telefax;
	}

	/**
	 * Returns the intern
	 *
	 * @return bool $intern
	 */
	public function getIntern() {
		return $this->intern;
	}

	/**
	 * Sets the intern
	 *
	 * @param bool $intern
	 * @return void
	 */
	public function setIntern($intern) {
		$this->intern = $intern;
	}

	/**
	 * Returns the boolean state of intern
	 *
	 * @return bool
	 */
	public function isIntern() {
		return $this->intern;
	}

	/**
	 * Returns the verstecken
	 *
	 * @return bool $verstecken
	 */
	public function getVerstecken() {
		return $this->verstecken;
	}

	/**
	 * Sets the verstecken
	 *
	 * @param bool $verstecken
	 * @return void
	 */
	public function setVerstecken($verstecken) {
		$this->verstecken = $verstecken;
	}

	/**
	 * Returns the boolean state of verstecken
	 *
	 * @return bool
	 */
	public function isVerstecken() {
		return $this->verstecken;
	}

	/**
	 * Adds a Anlass
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $mtrAnlass
	 * @return void
	 */
	public function addMtrAnlass(\Mff\Mffrps\Domain\Model\Anlass $mtrAnlass) {
		$this->mtrAnlass->attach($mtrAnlass);
	}

	/**
	 * Removes a Anlass
	 *
	 * @param \Mff\Mffrps\Domain\Model\Anlass $mtrAnlassToRemove The Anlass to be removed
	 * @return void
	 */
	public function removeMtrAnlass(\Mff\Mffrps\Domain\Model\Anlass $mtrAnlassToRemove) {
		$this->mtrAnlass->detach($mtrAnlassToRemove);
	}

	/**
	 * Returns the mtrAnlass
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Anlass> $mtrAnlass
	 */
	public function getMtrAnlass() {
		return $this->mtrAnlass;
	}

	/**
	 * Sets the mtrAnlass
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffrps\Domain\Model\Anlass> $mtrAnlass
	 * @return void
	 */
	public function setMtrAnlass(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $mtrAnlass) {
		$this->mtrAnlass = $mtrAnlass;
	}

}