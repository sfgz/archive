<?php
namespace Mff\Mffrps\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Belegung
 */
class Belegung extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * tstamp
	 *
	 * @var int
	 */
	protected $tstamp = 0;

	/**
	 * import_uid
	 *
	 * @var int
	 */
	protected $import_uid = 0;

	/**
	 * anlass
	 * @lazy
	 * @var int
	 * @validate NotEmpty,Integer
	 */
	protected $anlass = 0;

	/**
	 * belegungstext
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $belegungstext = '';

	/**
	 * zusatztext
	 *
	 * @var string
	 */
	protected $zusatztext = '';

	/**
	 * datum
	 *
	 * @var \DateTime
	 * @validate NotEmpty,DateTime
	 */
	protected $datum = NULL;

	/**
	 * crdate
	 *
	 * @var int
	 */
	protected $crdate = 0;

	/**
	 * ab
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $ab = '';

	/**
	 * bis
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $bis = '';

	/**
	 * betrag
	 *
	 * @var string
	 */
	protected $betrag = 0;

	/**
	 * status
	 *
	 * @var int
	 */
	protected $status = 0;

	/**
	 * editor
	 *
	 * @var int
	 */
	protected $editor = 0;

	/**
	 * belZimmer
	 * 
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 * @validate NotEmpty
	 */
	protected $belZimmer = NULL;

	/**
	 * Returns the tstamp
	 *
	 * @return int $tstamp
	 */
	public function getTstamp() {
		return $this->tstamp;
	}

	/**
	 * Sets the tstamp
	 *
	 * @param int $tstamp
	 * @return void
	 */
	public function setTstamp($tstamp) {
		$this->tstamp = $tstamp;
	}

	/**
	 * Returns the importUid
	 *
	 * @return int $importUid
	 */
	public function getImportUid() {
		return $this->importUid;
	}

	/**
	 * Sets the importUid
	 *
	 * @param int $importUid
	 * @return void
	 */
	public function setImportUid($importUid) {
		$this->importUid = $importUid;
	}

	/**
	 * Returns the anlass
	 *
	 * @return int $anlass
	 */
	public function getAnlass() {
		return $this->anlass;
	}

	/**
	 * Sets the anlass
	 *
	 * @param int $anlass
	 * @return void
	 */
	public function setAnlass($anlass) {
		$this->anlass = $anlass;
	}

	/**
	 * Returns the belegungstext
	 *
	 * @return string $belegungstext
	 */
	public function getBelegungstext() {
		return $this->belegungstext;
	}

	/**
	 * Sets the belegungstext
	 *
	 * @param string $belegungstext
	 * @return void
	 */
	public function setBelegungstext($belegungstext) {
		$this->belegungstext = $belegungstext;
	}

	/**
	 * Returns the zusatztext
	 *
	 * @return string $zusatztext
	 */
	public function getZusatztext() {
		return $this->zusatztext;
	}

	/**
	 * Sets the zusatztext
	 *
	 * @param string $zusatztext
	 * @return void
	 */
	public function setZusatztext($zusatztext) {
		$this->zusatztext = $zusatztext;
	}

	/**
	 * Returns the datum
	 *
	 * @return \DateTime $datum
	 */
	public function getDatum() {
		return $this->datum;
	}

	/**
	 * Sets the datum
	 *
	 * @param \DateTime $datum
	 * @return void
	 */
	public function setDatum(\DateTime $datum) {
		$txttMittagDatum = $datum->format('Y-m-d') . 'T12:00:00';
		$objMittagDatum = new \DateTime( $txttMittagDatum );
		$this->datum = $objMittagDatum;
	}

	/**
	 * Returns the crdate
	 *
	 * @return int $crdate
	 */
	public function getCrdate() {
		return $this->crdate;
	}

	/**
	 * Sets the crdate
	 *
	 * @param int $crdate
	 * @return void
	 */
	public function setCrdate($crdate) {
		$this->crdate = $crdate;
	}

	/**
	 * Returns the ab
	 *
	 * @return string $ab
	 */
	public function getAb() {
		return $this->ab;
	}

	/**
	 * Sets the ab
	 *
	 * @param string $ab
	 * @return void
	 */
	public function setAb($ab) {
		$this->ab = $ab;
	}

	/**
	 * Returns the bis
	 *
	 * @return string $bis
	 */
	public function getBis() {
		return $this->bis;
	}

	/**
	 * Sets the bis
	 *
	 * @param string $bis
	 * @return void
	 */
	public function setBis($bis) {
		$this->bis = $bis;
	}

	/**
	 * Returns the betrag
	 *
	 * @return string $betrag
	 */
	public function getBetrag() {
		return $this->betrag;
	}

	/**
	 * Sets the betrag
	 *
	 * @param string $betrag
	 * @return void
	 */
	public function setBetrag($betrag) {
		$this->betrag = $betrag;
	}

	/**
	 * Returns the status
	 *
	 * @return int $status
	 */
	public function getStatus() {
		return $this->status;
	}

	/**
	 * Sets the status
	 *
	 * @param int $status
	 * @return void
	 */
	public function setStatus($status) {
		$this->status = $status;
	}

	/**
	 * Returns the editor
	 *
	 * @return int $editor
	 */
	public function getEditor() {
		return $this->editor;
	}

	/**
	 * Sets the editor
	 *
	 * @param int $editor
	 * @return void
	 */
	public function setEditor($editor) {
		$this->editor = $editor;
	}

	/**
	 * Returns the belZimmer
	 *
	 * @return \Mff\Mffdb\Domain\Model\Zimmer $belZimmer
	 */
	public function getBelZimmer() {
		return $this->belZimmer;
	}

	/**
	 * Sets the belZimmer
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $belZimmer
	 * @return void
	 */
	public function setBelZimmer(\Mff\Mffdb\Domain\Model\Zimmer $belZimmer) {
		$this->belZimmer = $belZimmer;
	}

}
