<?php
namespace Mff\Mffrps\Command;

 /** 
 * Class RebuildAusnahmeCommandController
 * 
 * This Controller rebuilds 
 * relations to Timetable 
 * after manipualtions on Timetable, 
 * such as the import-action by extension mff_plan
 * 
 */
 
class RebuildAusnahmeCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * ausnahmeRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AusnahmeRepository
	 */
	protected $ausnahmeRepository = NULL;

	/**
	 * timetableUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $timetableUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

	public function execute(){
	    $this->initiate();
	    $result = $this->rebuildOrphanAusnahme();
	    return $result;
	}
	
	/**
	* initiate
	*
	* @return void
	*/
	public function initiate() {
		$this->timetableUtility = new \Mff\Mffrps\Utility\TimetableUtility();
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		$this->ausnahmeRepository = $objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AusnahmeRepository');
		$this->ausnahmeRepository->setDefaultQuerySettings($querySettings);
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
	}
	
	public function rebuildOrphanAusnahme() {
	      $ausnahmen = $this->ausnahmeRepository->findAll();
	      $ttRep = $this->timetableUtility->getTimetableRepository();
	      foreach( $ausnahmen as $aIx => $ausnahme){
			$room = $ausnahme->getAusZimmer()->getUid();
			if( empty($room) ) continue;
			$date = $ausnahme->getDatum()->format('U');
			$timeFrom = substr($ausnahme->getZeitAb(),0,5);
			$timeTo = substr($ausnahme->getZeitBis(),0,5);
			$teacher = $ausnahme->getInfoPerson() ? $ausnahme->getInfoPerson()->getUid() : '';
			$zmrTimetable  = $ttRep->findByRoomsAndDate( array( $room => $room ) , $date );
			foreach($zmrTimetable as $ttRecord){
			      if( 
				    $ttRecord['teacherId'] == $teacher && 
				    substr($ttRecord['time_from'],0,5) == $timeFrom  && 
				    substr($ttRecord['time_to'],0,5) == $timeTo 
			      ){
				    $ausnahme->setTimetable( $ttRecord['uid'] );
				    $this->ausnahmeRepository->update($ausnahme);
			      }
			}
	      }
	      $this->persistenceManager->persistAll();
	      return true;
	}
}
