<?php
namespace Mff\Mffrps\Command;
use \DateTime;

 /** 
 * Class MigrateDbBySqlCommandController
 * 
 * Usage of MigrateDbBySqlCommandController:
 * 
 * 
 */
 
class MigrateDbBySqlCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mffrps';
	public    $plugin = 'rpsopt';
	    
	protected $extConf = array(); // Extension configuration

	public function execute(){
	    $this->getSettings();
	    $result = $this->runSynchronizeData();
	    return $result;
	}

	/**
	 * runSynchronizeData - helper for execute
	 * 
	 * @return array
	 */
	public function runSynchronizeData() {
		$messages = array();
		$importer = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tx_externalimport_importer');
		$aTables = array( 'mieter' , 'anlass' , 'belegung' );
		foreach($aTables as $table){
		    $fullTableName = 'tx_'.$this->extKey.'_domain_model_' . $table ;
		    $GLOBALS['TCA'][$fullTableName]['ctrl']['external'][0]['connector'] = 'sql' ;
		    $GLOBALS['TCA'][$fullTableName]['ctrl']['external'][0]['pid'] = $this->extConf['storagePid'] ;
		    $messages[] = $importer->synchronizeData( $fullTableName , 0 );
		}
		return $messages;
	}
	
	/**
	* getSettings
	*
	* @return void
	*/
	public function getSettings() {
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'][$this->extKey]);
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$typoscript = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$storagePid = $typoscript['plugin.']['tx_'.$this->extKey.'_'.$this->plugin.'.']['persistence.']['storagePid'];
		if( !empty($storagePid) ) $this->extConf['storagePid'] = $storagePid;
	}
}