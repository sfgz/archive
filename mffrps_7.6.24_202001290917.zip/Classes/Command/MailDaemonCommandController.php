<?php
namespace Mff\Mffrps\Command;
use \DateTime;

 /** 
 * Class MailDaemonCommandController
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * 
 */
 
class MailDaemonCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	
	public    $extKey = 'mffrps';
	public    $plugin = 'rpsopt';

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * mailUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailUtility = NULL;

	public function execute(){
	    $this->getSettings();
	    $mailJobs = $this->evaluateMailJobs();
	    $today = date('N');
	    $result = 0;
	    if( is_array($mailJobs[$today]) ){
		$result += $this->mailUtility->sendNewsletterWochenliste( $mailJobs[$today] ) ? 1 : 0;
	    }
	    
	    $message = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
		    $result . ' Email(s) gesendet',
		    'Gesendet', // the header is optional
		    \TYPO3\CMS\Core\Messaging\FlashMessage::INFO, // the severity is optional as well and defaults to \TYPO3\CMS\Core\Messaging\FlashMessage::OK
		    FALSE // optional, whether the message should be stored in the session or only in the \TYPO3\CMS\Core\Messaging\FlashMessageQueue object (default is FALSE)
	    );
	    $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	    $flashMessageService = $objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
	    $messageQueue = $flashMessageService->getMessageQueueByIdentifier();
	    $messageQueue->addMessage($message);
	    return TRUE;
	}
	
	/**
	* evaluateMailJobs
	*
	* @return array
	*/
	public function evaluateMailJobs() {
	    $hauswartMailadress = trim($this->settings['optionfields']['info_hauswart_mailadress']['value']);
	    $infoHauswartDay = $this->settings['optionfields']['backup_weekinfo_sendday']['value'];
	    $infoWochenlisteMailadress = trim($this->settings['optionfields']['info_wochenliste_mailadress']['value']);
	    
	    if( empty($hauswartMailadress) ){
		  $mailJobs = array();
	    }else{
		  $mailJobs = array(
		      $infoHauswartDay => array( $hauswartMailadress => $hauswartMailadress )
		  );
	    }
	    if(empty($infoWochenlisteMailadress)) return $mailJobs;
	    
	    $aWochenlisteAdress = explode( ',' , $infoWochenlisteMailadress );
	    if(!count($aWochenlisteAdress)) return $mailJobs;
	    
	    foreach($aWochenlisteAdress as $mailperson){
		$presonInfos = explode( '-' , $mailperson );
		$persEmail = trim($presonInfos[0]);
		if(empty($persEmail)) continue;
		if(isset($presonInfos[1])){
		      // eg myadress@mylbox.com-51 for saturday (5) and monday (1)
		      for( $zd = 0 ; $zd < strlen($presonInfos[1]) ; ++$zd ){
			  $persDay = substr( $presonInfos[1] , $zd , 1 );
			  $mailJobs[$persDay][$persEmail] = $persEmail;
		      }
		}else{
		    $mailJobs[$infoHauswartDay][$persEmail] = $persEmail;
		}
	    }
	    return $mailJobs;
	}
	
	/**
	* getSettings
	*
	* @return void
	*/
	public function getSettings() {
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings = $this->systemOptionsUtility->settings;
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$this->mailUtility = new \Mff\Mffrps\Utility\MailUtility( $this->settings );
	}
}