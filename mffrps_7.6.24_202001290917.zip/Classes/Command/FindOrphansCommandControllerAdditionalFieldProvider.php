<?php
namespace Mff\Mffrps\Command;

 /** 
 * Class FindOrphansCommandControllerAdditionalFieldProvider
 * 
 * 
 * 
 */
 
class FindOrphansCommandControllerAdditionalFieldProvider implements \TYPO3\CMS\Scheduler\AdditionalFieldProviderInterface {
        public function getAdditionalFields(array &$taskInfo, $task, \TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject) {

		// Initialize extra field value
		if (empty($taskInfo['mffrps_orphansAnlassUid'])) {
			if ($parentObject->CMD == 'add') {
				// In case of new task and if field is empty
				$taskInfo['mffrps_orphansAnlassUid'] = 1;

			} elseif ($parentObject->CMD == 'edit') {
					// In case of edit, and editing a test task, set to internal value if not data was submitted already
				$taskInfo['mffrps_orphansAnlassUid'] = $task->mffrps_orphansAnlassUid;
			} else {
					// Otherwise set value.
				$taskInfo['mffrps_orphansAnlassUid'] = 1;
			}
		}
		
		$additionalFields = array();
		// Write the code for the field
		$fieldID = 'task_mffrps_orphansAnlassUid';
		$fieldCode = '<input type="text" name="tx_scheduler[mffrps_orphansAnlassUid]" id="' . $fieldID . '" value="' . $taskInfo['mffrps_orphansAnlassUid'] . '" size="30" />';
		$additionalFields[$fieldID] = array(
			'code'     => $fieldCode,
			'label'    => 'Anlass Uid'
		);
		return $additionalFields;
        }

	/**
	 * This method checks any additional data that is relevant to the specific task
	 * If the task class is not relevant, the method is expected to return true
	 *
	 * @param	array					$submittedData: reference to the array containing the data submitted by the user
	 * @param	\TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject: reference to the calling object (Scheduler's BE module)
	 * @return	boolean					True if validation was ok (or selected class is not relevant), false otherwise
	 */
        public function validateAdditionalFields(array &$submittedData, \TYPO3\CMS\Scheduler\Controller\SchedulerModuleController $parentObject) {
		$submittedData['mffrps_orphansAnlassUid'] = trim($submittedData['mffrps_orphansAnlassUid']);

		if (empty($submittedData['mffrps_orphansAnlassUid'])) {
			$parentObject->addMessage(  'Anlass Uid ist leer!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);//W ARNING
			$result = false;
		} elseif (!is_numeric($submittedData['mffrps_orphansAnlassUid'])) {
			$parentObject->addMessage(  'Anlass Uid:[' . $submittedData['mffrps_orphansAnlassUid'] . '] muss eine Zahl sein!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);//W ARNING
			$result = false;
		} else {
			//$parentObject->addMessage(  'Gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$result = true;
		}


		return $result;
        }
        public function saveAdditionalFields(array $submittedData, \TYPO3\CMS\Scheduler\Task\AbstractTask $task) {
		$task->mffrps_orphansAnlassUid = $submittedData['mffrps_orphansAnlassUid'];
        }
}
