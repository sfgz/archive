<?php
namespace Mff\Mffrps\Command;

 /** 
 * Class FindOrphansCommandController
 * 
 * 
 */
 
class FindOrphansCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	
	public $mffrps_orphansAnlassUid;
	
	protected    $extKey = 'mffrps';
	
	protected    $plugin = 'rpsopt';
	    
	protected $settings = array(); // Extension settings
	
	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;

	public function execute(){
	    $result = FALSE;
	    
	    if( empty( $this->mffrps_orphansAnlassUid ) ) return $result;
	    
	    $this->getSettings();
	    
	    $result = $this->belegungRepository->assignOrphansToAnlass( $this->mffrps_orphansAnlassUid );
	    $this->persistenceManager->persistAll();

	    return $result;
	}
	
	public function getAdditionalInformation() {
		$meldung = 'Sammelt verwaiste Belegungen in einem Anlass.';
		return $meldung;
	}
	
	/**
	* getSettings
	*
	* @return void
	*/
	public function getSettings() {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$typoscript = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$fullsettings = $typoscript['plugin.']['tx_'.$this->extKey.'_'.$this->plugin.'.'];
		$settings = $fullsettings['settings.'];
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings = $this->systemOptionsUtility->settings;
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		
		$storage['storagePid'] = $fullsettings['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		$this->belegungRepository = $objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
	}
}