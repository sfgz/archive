#
# Table structure for table 'tx_mffrps_domain_model_sysoptions'
#
CREATE TABLE tx_mffrps_domain_model_sysoptions (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	option_key varchar(255) DEFAULT '' NOT NULL,
	content varchar(255) DEFAULT '' NOT NULL,
	text_content text NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY option_key (option_key),

);

#
# Table structure for table 'tx_mffrps_domain_model_mieter'
#
CREATE TABLE tx_mffrps_domain_model_mieter (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kurz varchar(255) DEFAULT '' NOT NULL,
	anrede int(11) DEFAULT '0' NOT NULL,
	name varchar(255) DEFAULT '' NOT NULL,
	strasse_nr varchar(255) DEFAULT '' NOT NULL,
	plz_ort varchar(255) DEFAULT '' NOT NULL,
	rechnungsadresse text NOT NULL,
	email varchar(255) DEFAULT '' NOT NULL,
	telefon varchar(255) DEFAULT '' NOT NULL,
	telefax varchar(255) DEFAULT '' NOT NULL,
	intern tinyint(1) unsigned DEFAULT '0' NOT NULL,
	verstecken tinyint(1) unsigned DEFAULT '0' NOT NULL,
	mtr_anlass int(11) unsigned DEFAULT '0' NOT NULL,
	import_uid int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY import_uid (import_uid),

);

#
# Table structure for table 'tx_mffrps_domain_model_anlass'
#
CREATE TABLE tx_mffrps_domain_model_anlass (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	mieter int(11) unsigned DEFAULT '0' NOT NULL,

	verwendungszweck varchar(255) DEFAULT '' NOT NULL,
	kontakt_person varchar(255) DEFAULT '' NOT NULL,
	kontakt_anrede varchar(255) DEFAULT '' NOT NULL,
	kontakt_email varchar(255) DEFAULT '' NOT NULL,
	kontakt_telefon varchar(255) DEFAULT '' NOT NULL,
	bemerkungen varchar(255) DEFAULT '' NOT NULL,
	zuschlag_betrag varchar(255) DEFAULT '' NOT NULL,
	zuschlag_text varchar(255) DEFAULT '' NOT NULL,
	schulleitung_kurz varchar(255) DEFAULT '' NOT NULL,
	schulleitung_datum date DEFAULT '0000-00-00',
	gesuch_datum date DEFAULT '0000-00-00',
	rechnungs_datum date DEFAULT '0000-00-00',
	catering_text tinyint(1) unsigned DEFAULT '0' NOT NULL,
	verstecken tinyint(1) unsigned DEFAULT '0' NOT NULL,
	anl_belegung int(11) unsigned DEFAULT '0' NOT NULL,
	import_uid int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY mieter (mieter),
	KEY import_uid (import_uid),

);

#
# Table structure for table 'tx_mffrps_domain_model_belegung'
#
CREATE TABLE tx_mffrps_domain_model_belegung (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	anlass int(11) unsigned DEFAULT '0' NOT NULL,

	belegungstext varchar(255) DEFAULT '' NOT NULL,
	zusatztext text NOT NULL,
	datum date DEFAULT '0000-00-00',
	ab varchar(255) DEFAULT '' NOT NULL,
	bis varchar(255) DEFAULT '' NOT NULL,
	betrag varchar(255) DEFAULT '' NOT NULL,
	status int(11) DEFAULT '0' NOT NULL,
	bel_zimmer int(11) unsigned DEFAULT '0',
	import_uid int(11) unsigned DEFAULT '0' NOT NULL,

	editor int(11) unsigned DEFAULT '0',
	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY anlass (anlass),
	KEY datum (datum),
	KEY bel_zimmer (bel_zimmer),
	KEY import_uid (import_uid),

);


#
# Table structure for table 'tx_mffrps_domain_model_ausnahme'
#
CREATE TABLE tx_mffrps_domain_model_ausnahme (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,
	
	timetable int(11) unsigned DEFAULT '0' NOT NULL,

	datum date DEFAULT '0000-00-00',
	zeit_ab varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	aus_zimmer int(11) unsigned DEFAULT '0',
	neu_zimmer int(11) unsigned DEFAULT '0',
	neu_zeit_ab varchar(255) DEFAULT '' NOT NULL,
	neu_zeit_bis varchar(255) DEFAULT '' NOT NULL,
	info_datum datetime DEFAULT '0000-00-00 00:00:00',
	info_person int(11) unsigned DEFAULT '0',
	ausnahmetext varchar(255) DEFAULT '' NOT NULL,
	import_uid int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY timetable (timetable),
	KEY import_uid (import_uid),

);

#
# Table structure for table 'tx_mffrps_domain_model_antrag'
#
CREATE TABLE tx_mffrps_domain_model_antrag (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	datum date DEFAULT '0000-00-00',
	zeit_start varchar(8) DEFAULT '' NOT NULL,
	zeit_ende varchar(8) DEFAULT '' NOT NULL,
	betreff varchar(255) DEFAULT '' NOT NULL,
	text text NOT NULL,
	mieter varchar(255) DEFAULT '' NOT NULL,
	kalender varchar(255) DEFAULT '' NOT NULL,
	anzeige varchar(255) DEFAULT '' NOT NULL,
	zimmer int(11) unsigned DEFAULT '0',
	bearbeiter int(11) unsigned DEFAULT '0',

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);


