$(document).ready(function(){ $('#msg_1').fadeIn(0) });

function jumpToLast( maxElements ){
		oldPage = Number($("#counter").attr("data-active"));
		if( Number( oldPage ) == maxElements ){return false;}; 
		jumpTo( Number(maxElements) - oldPage );
}
function jumpToFirst(  ){
		oldPage = $("#counter").attr("data-active");
		if( Number( oldPage ) <= 1 ){return false;}; 
		jumpTo( ( Number( oldPage )- 1 )*(-1) );
}
function jumpTo( addPage ) {
		var oldPage = Number( $("#counter").attr("data-active") );
		var page = Number(addPage) + oldPage;
		if( $("#msg_" + page).length ){
			$("#msg_" + oldPage).slideUp(400);
			$("#counter").attr("data-active",page);
			$("#counter").html( ' ' + page);
			$("#msg_" + page).slideDown(400);
		}
}
function anfang() {
		$("body,html").animate({
			scrollTop: 0,
			scrollLeft: 0
		}, 550);
}

function toggleByAjax( URL , fieldname , obj ) {
      var parent_id = $(obj).parent().attr('id');
      var classname = $(obj).attr('class');
      var val = classname.split('_');
      if( val[1] == 1 ){ var newValue = 0; }else{ var newValue = 1; }
      var arr = parent_id.split('_');
      $.ajax({
	  url : URL,
	  type : 'GET',
	  data : {
	      'table' : arr[0] ,
	      'uid' : arr[1] ,
	      'fieldName' : fieldname ,
	      'newValue' : newValue
	  },
	  dataType:'json',
	  success : function(data) {
	      if( data[0] == newValue ){
				$(obj).toggleClass( val[0] + '_').toggleClass( val[0] + '_1');
				 if( 1 == newValue ){
					 var antwort = 'Ja';
				 }else{
					 var antwort = 'Nein';
				}
				$(obj).attr( 'title', fieldname + ': ' + antwort + ' (' + data[1] + ' geändert)' );
	      }
	  },
	  error : function(request,error)
	  {
	      alert("Request " + error + ": "+JSON.stringify(request));
	  }
      });
}
