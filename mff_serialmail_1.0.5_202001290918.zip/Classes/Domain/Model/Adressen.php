<?php
namespace Mff\MffSerialmail\Domain\Model;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Adressen
 */
class Adressen extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * serialmail uid of parent
     *
     * @var integer
     * @validate NotEmpty
     */
    protected $serialmail = false;

    /**
     * Versand an diese Adresse aktivieren
     *
     * @var bool
     */
    protected $aktiv = true;

    /**
     * gesendet
     *
     * @var int
     */
    protected $gesendet = 0;

    /**
     * emailadress
     *
     * @var string
     * @validate NotEmpty
     */
    protected $emailadress = '';

    /**
     * Seriendruckfeld
     *
     * @var string
     */
    protected $feld1 = '';

    /**
     * Seriendruckfeld
     *
     * @var string
     */
    protected $feld2 = '';

    /**
     * Seriendruckfeld
     *
     * @var string
     */
    protected $feld3 = '';

    /**
     * Seriendruckfeld
     *
     * @var string
     */
    protected $feld4 = '';

    /**
     * Seriendruckfeld
     *
     * @var string
     */
    protected $feld5 = '';

    /**
     * Returns the serialmail
     *
     * @return bool $serialmail
     */
    public function getSerialmail()
    {
        return $this->serialmail;
    }

    /**
     * Sets the serialmail
     *
     * @param bool $serialmail
     * @return void
     */
    public function setSerialmail($serialmail)
    {
        $this->serialmail = $serialmail;
    }

    /**
     * Returns the aktiv
     *
     * @return bool $aktiv
     */
    public function getAktiv()
    {
        return $this->aktiv;
    }

    /**
     * Sets the aktiv
     *
     * @param bool $aktiv
     * @return void
     */
    public function setAktiv($aktiv)
    {
        $this->aktiv = $aktiv;
    }

    /**
     * Returns the boolean state of aktiv
     *
     * @return bool
     */
    public function isAktiv()
    {
        return $this->aktiv;
    }

    /**
     * Returns the gesendet
     *
     * @return int $gesendet
     */
    public function getGesendet()
    {
        return $this->gesendet;
    }

    /**
     * Sets the gesendet
     *
     * @param int $gesendet
     * @return void
     */
    public function setGesendet($gesendet)
    {
        $this->gesendet = $gesendet;
    }

    /**
     * Returns the emailadress
     *
     * @return string $emailadress
     */
    public function getEmailadress()
    {
        return $this->emailadress;
    }

    /**
     * Sets the emailadress
     *
     * @param string $emailadress
     * @return void
     */
    public function setEmailadress($emailadress)
    {
        $this->emailadress = $emailadress;
    }

    /**
     * Returns the feld1
     *
     * @return string $feld1
     */
    public function getFeld1()
    {
        return $this->feld1;
    }

    /**
     * Sets the feld1
     *
     * @param string $feld1
     * @return void
     */
    public function setFeld1($feld1)
    {
        $this->feld1 = $feld1;
    }

    /**
     * Returns the feld2
     *
     * @return string $feld2
     */
    public function getFeld2()
    {
        return $this->feld2;
    }

    /**
     * Sets the feld2
     *
     * @param string $feld2
     * @return void
     */
    public function setFeld2($feld2)
    {
        $this->feld2 = $feld2;
    }

    /**
     * Returns the feld3
     *
     * @return string $feld3
     */
    public function getFeld3()
    {
        return $this->feld3;
    }

    /**
     * Sets the feld3
     *
     * @param string $feld3
     * @return void
     */
    public function setFeld3($feld3)
    {
        $this->feld3 = $feld3;
    }

    /**
     * Returns the feld4
     *
     * @return string $feld4
     */
    public function getFeld4()
    {
        return $this->feld4;
    }

    /**
     * Sets the feld4
     *
     * @param string $feld4
     * @return void
     */
    public function setFeld4($feld4)
    {
        $this->feld4 = $feld4;
    }

    /**
     * Returns the feld5
     *
     * @return string $feld5
     */
    public function getFeld5()
    {
        return $this->feld5;
    }

    /**
     * Sets the feld5
     *
     * @param string $feld5
     * @return void
     */
    public function setFeld5($feld5)
    {
        $this->feld5 = $feld5;
    }
}
