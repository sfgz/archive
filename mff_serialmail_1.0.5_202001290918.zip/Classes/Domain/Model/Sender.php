<?php
namespace Mff\MffSerialmail\Domain\Model;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Sender
 */
class Sender extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUser
{

	/**
	 * ecoAcronym
	 *
	 * @var string
	 */
	protected $ecoAcronym = '';

	/**
	 * ecoKey
	 *
	 * @var string
	 */
	protected $ecoKey = '';

	/**
	 * Bei Lernenden die Klasse (automatisch)
	 *
	 * @var \Mff\Mffdb\Domain\Model\Klasse
	 */
	protected $ecoKlasse = NULL;

	/**
	 * cloudQuota
	 *
	 * @var string
	 */
	protected $cloudQuota = '';

	/**
	 * disable
	 *
	 * @var bool
	 */
	protected $disable = FALSE;

	/**
	 * deleted
	 *
	 * @var bool
	 */
	protected $deleted = FALSE;

	/**
	 * Returns the ecoAcronym
	 *
	 * @return string $ecoAcronym
	 */
	public function getEcoAcronym() {
		return $this->ecoAcronym;
	}

	/**
	 * Sets the ecoAcronym
	 *
	 * @param string $ecoAcronym
	 * @return void
	 */
	public function setEcoAcronym($ecoAcronym) {
		$this->ecoAcronym = $ecoAcronym;
	}

	/**
	 * Returns the ecoKey
	 *
	 * @return string $ecoKey
	 */
	public function getEcoKey() {
		return $this->ecoKey;
	}

	/**
	 * Sets the ecoKey
	 *
	 * @param string $ecoKey
	 * @return void
	 */
	public function setEcoKey($ecoKey) {
		$this->ecoKey = $ecoKey;
	}

	/**
	 * Returns the cloudQuota
	 *
	 * @return string $cloudQuota
	 */
	public function getCloudQuota() {
		return $this->cloudQuota;
	}

	/**
	 * Sets the cloudQuota
	 *
	 * @param string $cloudQuota
	 * @return void
	 */
	public function setCloudQuota($cloudQuota) {
		$this->cloudQuota = $cloudQuota;
	}

	/**
	 * Returns the ecoKlasse
	 *
	 * @return \Mff\Mffdb\Domain\Model\Klasse $ecoKlasse
	 */
	public function getEcoKlasse() {
		return $this->ecoKlasse;
	}

	/**
	 * Sets the ecoKlasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Klasse $ecoKlasse
	 * @return void
	 */
	public function setEcoKlasse(\Mff\Mffdb\Domain\Model\Klasse $ecoKlasse) {
		$this->ecoKlasse = $ecoKlasse;
	}

	/**
	 * Returns the disable
	 *
	 * @return bool $disable
	 */
	public function getDisable() {
		return $this->disable;
	}

	/**
	 * Sets the disable
	 *
	 * @param bool $disable
	 * @return void
	 */
	public function setDisable($disable) {
		$this->disable = $disable;
	}

	/**
	 * Returns the boolean state of disable
	 *
	 * @return bool
	 */
	public function isDisable() {
		return $this->disable;
	}

	/**
	 * Returns the deleted
	 *
	 * @return bool $deleted
	 */
	public function getDeleted() {
		return $this->deleted;
	}

	/**
	 * Sets the deleted
	 *
	 * @param bool $deleted
	 * @return void
	 */
	public function setDeleted($deleted) {
		$this->deleted = $deleted;
	}

	/**
	 * Returns the boolean state of deleted
	 *
	 * @return bool
	 */
	public function isDeleted() {
		return $this->deleted;
	}
}
