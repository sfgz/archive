<?php
namespace Mff\MffSerialmail\Domain\Model;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Serialmail
 */
class Serialmail extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * Mailversand aktivieren
     *
     * @var bool
     */
    protected $aktiv = false;

    /**
     * startdatum
     *
     * @var int
     * @validate NotEmpty
     */
    protected $startdatum = 0;

    /**
     * antragdatum
     *
     * @var int
     */
    protected $antragdatum = 0;

    /**
     * freigabedatum
     *
     * @var int
     */
    protected $freigabedatum = 0;

    /**
     * betreff
     *
     * @var string
     * @validate NotEmpty
     */
    protected $betreff = '';

    /**
     * mailtext
     *
     * @var string
     * @validate NotEmpty
     */
    protected $mailtext = '';

    /**
     * dateien
     *
     * @var string
     */
    protected $dateien = '';

    /**
     * mailLoguser
     *
     * @var \Mff\MffSerialmail\Domain\Model\Sender
     */
    protected $mailLoguser = null;

    /**
     * Absender
     *
     * @var \Mff\MffSerialmail\Domain\Model\Sender
     */
    protected $mailSender = null;

    /**
     * mailAdr
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffSerialmail\Domain\Model\Adressen>
     * @cascade remove
     * @lazy
     */
    protected $mailAdr = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->mailAdr = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the aktiv
     *
     * @return bool $aktiv
     */
    public function getAktiv()
    {
        return $this->aktiv;
    }

    /**
     * Sets the aktiv
     *
     * @param bool $aktiv
     * @return void
     */
    public function setAktiv($aktiv)
    {
        $this->aktiv = $aktiv;
    }

    /**
     * Returns the boolean state of aktiv
     *
     * @return bool
     */
    public function isAktiv()
    {
        return $this->aktiv;
    }

    /**
     * Returns the startdatum
     *
     * @return int $startdatum
     */
    public function getStartdatum()
    {
        return $this->startdatum;
    }

    /**
     * Sets the startdatum
     *
     * @param int $startdatum
     * @return void
     */
    public function setStartdatum($startdatum)
    {
        $this->startdatum = $startdatum;
    }

    /**
     * Returns the antragdatum
     *
     * @return int $antragdatum
     */
    public function getAntragdatum()
    {
        return $this->antragdatum;
    }

    /**
     * Sets the antragdatum
     *
     * @param int $antragdatum
     * @return void
     */
    public function setAntragdatum($antragdatum)
    {
        $this->antragdatum = $antragdatum;
    }

    /**
     * Returns the freigabedatum
     *
     * @return int $freigabedatum
     */
    public function getFreigabedatum()
    {
        return $this->freigabedatum;
    }

    /**
     * Sets the freigabedatum
     *
     * @param int $freigabedatum
     * @return void
     */
    public function setFreigabedatum($freigabedatum)
    {
        $this->freigabedatum = $freigabedatum;
    }

    /**
     * Returns the betreff
     *
     * @return string $betreff
     */
    public function getBetreff()
    {
        return $this->betreff;
    }

    /**
     * Sets the betreff
     *
     * @param string $betreff
     * @return void
     */
    public function setBetreff($betreff)
    {
        $this->betreff = $betreff;
    }

    /**
     * Returns the mailtext
     *
     * @return string $mailtext
     */
    public function getMailtext()
    {
        return $this->mailtext;
    }

    /**
     * Sets the mailtext
     *
     * @param string $mailtext
     * @return void
     */
    public function setMailtext($mailtext)
    {
        $this->mailtext = $mailtext;
    }

    /**
     * Returns the dateien
     *
     * @return string $dateien
     */
    public function getDateien()
    {
        return $this->dateien;
    }

    /**
     * Sets the dateien
     *
     * @param string $dateien
     * @return void
     */
    public function setDateien($dateien)
    {
        $this->dateien = $dateien;
    }

    /**
     * Returns the mailLoguser
     *
     * @return \Mff\MffSerialmail\Domain\Model\Sender $mailLoguser
     */
    public function getMailLoguser()
    {
        return $this->mailLoguser;
    }

    /**
     * Sets the mailLoguser
     *
     * @param \Mff\MffSerialmail\Domain\Model\Sender $mailLoguser
     * @return void
     */
    public function setMailLoguser(\Mff\MffSerialmail\Domain\Model\Sender $mailLoguser)
    {
        $this->mailLoguser = $mailLoguser;
    }

    /**
     * Returns the mailSender
     *
     * @return \Mff\MffSerialmail\Domain\Model\Sender $mailSender
     */
    public function getMailSender()
    {
        return $this->mailSender;
    }

    /**
     * Sets the mailSender
     *
     * @param \Mff\MffSerialmail\Domain\Model\Sender $mailSender
     * @return void
     */
    public function setMailSender(\Mff\MffSerialmail\Domain\Model\Sender $mailSender)
    {
        $this->mailSender = $mailSender;
    }

    /**
     * Adds a Adressen
     *
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $mailAdr
     * @return void
     */
    public function addMailAdr(\Mff\MffSerialmail\Domain\Model\Adressen $mailAdr)
    {
        $this->mailAdr->attach($mailAdr);
    }

    /**
     * Removes a Adressen
     *
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $mailAdrToRemove The Adressen to be removed
     * @return void
     */
    public function removeMailAdr(\Mff\MffSerialmail\Domain\Model\Adressen $mailAdrToRemove)
    {
        $this->mailAdr->detach($mailAdrToRemove);
    }

    /**
     * Returns the mailAdr
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffSerialmail\Domain\Model\Adressen> $mailAdr
     */
    public function getMailAdr()
    {
        return $this->mailAdr;
    }

    /**
     * Sets the mailAdr
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffSerialmail\Domain\Model\Adressen> $mailAdr
     * @return void
     */
    public function setMailAdr(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $mailAdr)
    {
        $this->mailAdr = $mailAdr;
    }
}
