<?php
namespace Mff\MffSerialmail\Domain\Repository;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Serialmails
 */
class SerialmailRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

 	  /**
	  *  Find data from Serialmail 
	  *  
	  * @param integer $logUser
	  * 
	  */
	  public function findeByMailLoguserOrMailSender( $logUser ) {
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields( TRUE );
 	      $querySettings->setRespectStoragePage( FALSE );
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      
	      $query->matching(
		    $query->logicalOr(
			    $query->equals('mail_loguser', $logUser ),
			    $query->equals('mail_sender', $logUser )
		    )
	      );
	      return $query->execute();
	  }

 	  /**
	  *  Find data from Serialmail 
	  *  
	  * @param integer $dateNow
	  * @param boolean $ReturnRawQueryResult
	  * 
	  */
	  public function findeAktiveByStartdate( $dateNow , $ReturnRawQueryResult = FALSE ) {
			$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
			$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
			$storage['storagePid'] =  $fullsettings['plugin.']['tx_mffserialmail_mailer.']['persistence.']['storagePid'];

			$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
			$querySettings->setIgnoreEnableFields( FALSE );
			$querySettings->setRespectStoragePage( TRUE );
			$querySettings->setStoragePageIds( $storage );
			$this->setDefaultQuerySettings($querySettings);
			$query = $this->createQuery();
			
			$query->matching(
				$query->logicalAnd(
					$query->lessThanOrEqual('startdatum', $dateNow ),
					$query->equals('aktiv', 1 )
				)
			);
			return $query->execute($ReturnRawQueryResult);
	  }

 	  /**
	  *  Find data from Serialmail 
	  *  
	  * @param integer $dateNow
	  * @param boolean $ReturnRawQueryResult
	  * 
	  */
	  public function findLessThanOrEqualStartdatum( $dateNow , $ReturnRawQueryResult = FALSE ) {
			$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
			$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
			$storage['storagePid'] =  $fullsettings['plugin.']['tx_mffserialmail_mailer.']['persistence.']['storagePid'];

			$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
			$querySettings->setIgnoreEnableFields( FALSE );
			$querySettings->setRespectStoragePage( TRUE );
			$querySettings->setStoragePageIds( $storage );
			$this->setDefaultQuerySettings($querySettings);
			$query = $this->createQuery();
			
			$query->matching(
					$query->lessThanOrEqual('startdatum', $dateNow )
			);
			return $query->execute($ReturnRawQueryResult);
	  }
	  
}
