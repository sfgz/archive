<?php
namespace Mff\MffSerialmail\Domain\Repository;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Adressens
 */
class AdressenRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {
	/**
	* @var array
	*/
	protected $defaultOrderings = array(
	    'uid' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);

}
