<?php
namespace Mff\MffSerialmail\Domain\Repository;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * The repository for Mails
 */
class SenderRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
{
	/**
	* @var array
	*/
	protected $defaultOrderings = array(
	    'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);

	  /**
	  *  findTeachers
	  *  Find by user-field tx_extbase_type e.g. 'Tx_Mffdb_Ecouser'
	  *  
	  * 
      * @param boolean $ReturnRawQueryResult
	  */
	  public function findTeachers( $ReturnRawQueryResult = FALSE , $filter = array( 'username'=>1 ,'eco_acronym'=>1 ,'notdeleted'=>1 ,'notdisable'=>0 ,'extbase_type'=>'Tx_Mffdb_Ecouser' )  ) {
		  
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields( TRUE );
		  $querySettings->setRespectStoragePage(TRUE);
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();

	      $conditions = array();
	      if( !empty( $filter['username'] ) ) $conditions['eco_key'] = $query->greaterThan('username', '');
	      if( !empty( $filter['eco_key'] ) ) $conditions['eco_key'] = $query->greaterThan('eco_key', '');
	      if( !empty( $filter['email'] ) ) $conditions['email'] = $query->greaterThan('email', '');
		  if( !empty( $filter['extbase_type'] ) ) $conditions['tx_extbase_type'] = $query->equals('tx_extbase_type', $filter['extbase_type'] );
	      if( !empty( $filter['notdeleted'] ) ) $conditions['deleted'] = $query->equals('deleted', 0);
	      if( !empty( $filter['notdisable'] ) ) $conditions['disable'] = $query->equals('disable', 0);
	      $query->matching(
			$query->logicalAnd( $conditions )
	      );

	      $query->setOrderings(
		  array(
		      'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );	  
	      return $query->execute($ReturnRawQueryResult);
	  }

	  /**
	  *  findStudents
	  *  Find by user-field tx_extbase_type e.g. 'Tx_Mffdb_Ecouser'
	  * 
	  */
	  public function findStudents( $ReturnRawQueryResult = TRUE ) {
		  $filter = array( 'username'=>1 ,'eco_key'=>1 ,'notdeleted'=>1 ,'notdisable'=>1 ,'extbase_type'=>'Tx_Mffdb_Ecouser' ) ;
		  
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $searchInDisabled = ( $filter['deleted'] && $filter['disable'] ) ? FALSE : TRUE ;
		  $querySettings->setIgnoreEnableFields( $searchInDisabled ); // unclude disabled and deleted records in search (if one of both is not set)
		  $querySettings->setRespectStoragePage( TRUE ); // include only students, there are on page studentPid
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();

	      $conditions = array();
	      if( !empty( $filter['username'] ) ) $conditions['username'] = $query->greaterThan('username', '');
	      if( !empty( $filter['eco_key'] ) ) $conditions['eco_key'] = $query->greaterThan('eco_key', '');
	      if( !empty( $filter['email'] ) ) $conditions['email'] = $query->greaterThan('email', '');
		  if( !empty( $filter['extbase_type'] ) ) $conditions['tx_extbase_type'] = $query->equals('tx_extbase_type', $filter['extbase_type'] );
	      if( !empty( $filter['notdeleted'] ) ) $conditions['deleted'] = $query->equals('deleted', 0);
	      if( !empty( $filter['notdisable'] ) ) $conditions['disable'] = $query->equals('disable', 0);
	      $query->matching(
			$query->logicalAnd( $conditions )
	      );

	      $query->setOrderings(
			array(
				'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
			)
	      );	  
	      return $query->execute($ReturnRawQueryResult);
	  }

}
