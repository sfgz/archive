<?php
namespace Mff\MffSerialmail\Controller;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * AdressenController
 */
class AdressenController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

    /**
     * adressenRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\AdressenRepository
     * @inject
     */
    protected $adressenRepository = null;

    /**
     * serialmailRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\SerialmailRepository
     * @inject
     */
    protected $serialmailRepository = null;

    /**
     * senderRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\SenderRepository
     * @inject
     */
    protected $senderRepository = null;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\TeacherRelationRepository
	 * @inject
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 * @inject
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * classesArray
	 *
	 * @var array
	 */
	protected $classesArray = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;
	
	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
	    $this->fachbereichRepository->setDefaultQuerySettings($querySettings);
	}

    /**
     * action edit
     *
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $adressen
     * @ignorevalidation $adressen
     * @return void
     */
    public function editAction(\Mff\MffSerialmail\Domain\Model\Adressen $adressen) {
        
        $this->view->assign('adressen', $adressen);
        
        $serialMailNbr = $adressen->getSerialmail();
        if( !$serialMailNbr ) return; // an error occurred

        $serialmailObj = $this->serialmailRepository->findByUid($serialMailNbr);
        
		$this->settings['linesPerPage'] = $this->request->hasArgument('pagesize') ? $this->request->getArgument('pagesize') : 30;
		
		$this->view->assign('serialmail', $serialmailObj );
		$this->view->assign('settings', $this->settings );
        
        // pager: go to page
        $z=0;
        $checkboxStart=0;
        $mailAdr = $serialmailObj->getMailAdr();
        foreach( $mailAdr as $objAdr ){
			if( $adressen->getUid() == $objAdr->getUid() ){
                  $this->view->assign( 'gotoPage' , floor($z/$this->settings['linesPerPage']) );
                  $checkboxStart = $z + 1;
                  break;
			}
			$z += 1;
        }
        if( count($mailAdr) > $this->settings['checkboxesPerForm'] ){
			$remainingOnTail = count($mailAdr) - $checkboxStart ;
			if( $this->settings['checkboxesPerForm'] > $remainingOnTail ) $checkboxStart -= ($this->settings['checkboxesPerForm']-$remainingOnTail);
        }else{
			$checkboxStart = 1;
        }
        $checkboxes = array( 'start'=> $checkboxStart , 'end'=>$checkboxStart + $this->settings['checkboxesPerForm'] );
        
        $this->view->assign( 'checkboxes' , $checkboxes );
        
    }

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
        if ( $this->request->hasArgument('adressen') ) {
			$adressen = $this->request->getArgument('adressen');
			if(!is_numeric($adressen['gesendet'])) {
			      $this->arguments->getArgument('adressen')->getPropertyMappingConfiguration()->skipProperties('gesendet');
			}
        }
    }

    /**
     * action update
     *
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $adressen
     * @ignorevalidation $adressen
     * @return void
     */
    public function updateAction(\Mff\MffSerialmail\Domain\Model\Adressen $adressen) {
		$pagesize = GeneralUtility::_POST('pagesize');
		if( $pagesize ){
			$this->settings['linesPerPage'] =  $pagesize;
		}
        if ( $this->request->hasArgument('delete_adresse') ) {
			$edFields = $this->request->getArgument('delete_adresse');
			if($this->request->hasArgument('delete') && is_array($edFields) ) {
				$deletedMarkedAdress = 0;
				foreach( $edFields as $ix => $val ){
						if($val) {
							if( $adressen->getUid() === $ix) $deletedMarkedAdress = $adressen->getSerialmail();
							$delAdress = $this->adressenRepository->findByUid($ix);
							$this->adressenRepository->remove($delAdress);
						}
				}
				$this->persistenceManager->persistAll();
				if( !empty($deletedMarkedAdress) ) {
						$this->redirect('edit', 'Serialmail', NULL, array('serialmail' => $deletedMarkedAdress  ));
				}else{
					$this->redirect('edit', NULL, NULL, array('adressen' => $adressen ,'pagesize'=>$this->settings['linesPerPage'] ));
				}
			}        
       } 
        
        if( $adressen ) {
			if($this->request->hasArgument('abort')) {
				$this->redirect('edit', 'Serialmail' , NULL, array('serialmail' => $adressen->getSerialmail() , 'adressen' => $adressen->getUid() ) );
			}
			$edFields = $this->request->getArgument('adressen');
			$timeField = $this->request->getArgument('startzeit');
			if( empty($edFields['gesendet']) ){
				$adressen->setGesendet( 0 );
			}else{
				$helperObj = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Controller\\SerialmailController');
// 				$helperObj = new \Mff\MffSerialmail\Controller\SerialmailController();
				$gesendet = $helperObj->dateTime2timestamp( $edFields['gesendet'] , $timeField , -5);
				$adressen->setGesendet( $gesendet );
			}
			$this->addFlashMessage('Adresse gespeichert.', 'Adresse speichern', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$this->adressenRepository->update($adressen);

			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);

			if($this->request->hasArgument('saveclose')) {
				$this->redirect('edit', 'Serialmail' , NULL, array('serialmail' => $adressen->getSerialmail() , 'adressen' => $adressen->getUid() ) );
			}else{
				$this->redirect('edit', NULL, NULL, array('adressen' => $adressen,'pagesize'=>$this->settings['linesPerPage']));
 			}
 			
        }else{
            $this->redirect('list');
        }
    }

    /**
     * action delete
     *
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $adressen
     * @return void
     */
    public function deleteAction(\Mff\MffSerialmail\Domain\Model\Adressen $adressen) {
        $serialmail = $adressen->getSerialmail();
        $this->addFlashMessage('Adresse entfernt.', 'Adresse löschen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->adressenRepository->remove($adressen);
 		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		if($serialmail) $this->redirect('edit', 'Serialmail' , NULL, array('serialmail' => $serialmail));
		// should not happen:
        $this->redirect('list', 'Serialmail');
    }

    /**
     * action insert
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @return void
     */
    public function insertAction(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail ) {
		
		$insert = $this->request->hasArgument('insert') ? $this->request->getArgument('insert') : array('adresslistBut'=>1);
		$insert['result'] = array();
        
		if($this->request->hasArgument('abort')) {
			$this->redirect('edit', 'Serialmail' , NULL, array('serialmail' => $serialmail));
			return true;
		}
		
		if( isset( $insert['uploadBut'] ) ) {
			// detect if a file was uploaded
// 			$this->attachmentUtility = new \Mff\MffSerialmail\Utility\AttachmentUtility( array( 'uploadFolder' => 'adressesFolder' ) );
			$this->attachmentUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\AttachmentUtility' , array( 'uploadFolder' => 'adressesFolder' ) );
			$uploadFile = $this->attachmentUtility->uploadFile( $serialmail->getUid() );
			$isFileInvalid = empty($uploadFile) || !file_exists($uploadFile) || !is_file($uploadFile) ? 1 : 0;
			// detect lastUploadfile if no file was uploaded
			if( $isFileInvalid && isset( $insert['lastUploadfile'] ) && !empty( $insert['lastUploadfile'] ) ) {
				$uploadFile = rtrim(PATH_site, '/') . $this->attachmentUtility->adressesFolder . $serialmail->getUid().'/'.$insert['lastUploadfile'];
			}
			if( file_exists($uploadFile) ) {
				$objImport = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\ImportUtility');
// 				$objImport = new \Mff\MffSerialmail\Utility\ImportUtility();
				$insert['result'] = $objImport->GetAnalysedFileAsArray($uploadFile);
				$this->addFlashMessage('Datei hochgeladen zu adressen/'.$serialmail->getUid().'/ ' . basename( $uploadFile ) . ' + ' . $objImport->fileDescription['charset'] , 'Adressen hochladen' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				// create adresses from file, delete the file and redirect
				if( empty($insert['previewupload']) && count($insert['result']) ){
					$newAdressen = $this->createAdressesFromArray( $serialmail , $insert['result'] );
					@unlink( $uploadFile );
					if( $newAdressen ) $this->redirect('edit', NULL , NULL, array( 'serialmail' => $serialmail , 'adressen' => $newAdressen ) );
					$this->redirect('edit', 'Serialmail' , NULL, array( 'serialmail' => $serialmail ) );
				}
				// store filename as lastUploadfile if only preview without creating adresses
				$this->view->assign( 'lastUploadfile' , basename($uploadFile) );
			}
		}
		
		if( isset( $insert['adresslistBut'] ) && isset( $insert['adresslist'] ) && !empty( $insert['adresslist'] )){
			$objImport = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\ImportUtility');
// 			$objImport = new \Mff\MffSerialmail\Utility\ImportUtility();
			$insert['result'] = $objImport->GetAnalysedContentsAsArray($insert['adresslist']);
			// create adresses from textarea and redirect
			if(  empty($insert['previewadresslist']) && count($insert['result']) ){
				$newAdressen = $this->createAdressesFromArray( $serialmail , $insert['result'] );
				if( $newAdressen ) $this->redirect('edit', NULL , NULL, array( 'serialmail' => $serialmail , 'adressen' => $newAdressen ) );
			}
		}
			
		if(isset( $insert['newadressBut'] ) && $this->request->hasArgument('adressen')) {
			$edFields = $this->request->getArgument('adressen');
			// create adress from formFields and redirect
			if( !empty($edFields['emailadress']) ) {
					$exisitingMail = $this->getRegisteredEmailAdresses($serialmail);
					if( isset($exisitingMail[$edFields['emailadress']]) ){
						$this->addFlashMessage( 'Die Adresse '.$edFields['emailadress'].' wurde bereits erfasst.' , 'Adressen erfassen' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
						$this->redirect('edit', NULL , NULL, array( 'serialmail' => $serialmail , 'adressen' => $exisitingMail[$edFields['emailadress']] ) );
					}else{
						$aAdress = $edFields;
						$aAdress['serialmail'] = $serialmail->getUid();
						$aAdress['startzeit'] = $this->request->getArgument('startzeit');
						$newAdressen = $this->createAdressFromInputfields( $aAdress );
						if( $newAdressen ) $this->redirect('edit', NULL , NULL, array( 'serialmail' => $serialmail , 'adressen' => $newAdressen ) );
					}
			}
		}
			
		$aAdressBook = $this->getMaillinglistTeacher();
		$studAdressBook = $this->getMaillinglistStudents();
		if( ( isset( $insert['addTeachersBut'] ) || isset( $insert['addStudentsBut'] ) )  && $this->request->hasArgument('adressbooks') ) {
			$reqAdressbooks = $this->request->getArgument('adressbooks');
			foreach($studAdressBook as $fbUid => $fbRow){
					foreach($fbRow['classes'] as $strSortclass => $shortclassRow){
							foreach($shortclassRow as $classUid => $classRow){
									if(isset( $reqAdressbooks['classes'][$classUid] ) ){
											foreach($classRow['user'] as $email => $objUser){
													$addToAddressList[$email][0] = $email;
											}
									}
							}
					}
			}
			foreach($aAdressBook as $listType => $listRow){
					if( $listType == 'classteacher' ){
						foreach($listRow as $fbUid => $fbRow) {
							foreach($fbRow['user'] as $teacherEmail => $fbRow) if(isset( $reqAdressbooks[$listType][$teacherEmail] ) )$addToAddressList[$teacherEmail][0] = $teacherEmail;
						}
					}else{
						foreach($listRow as $fbUid => $fbRow) {
							if(!isset( $reqAdressbooks[$listType][$fbUid] ) ) continue;
							foreach($fbRow['user'] as $teacherEmail=>$userRow) {
								$addToAddressList[$teacherEmail][0] = $teacherEmail;
							}
						}
					}
			}
			$newAdressen = $this->createAdressesFromArray( $serialmail , $addToAddressList );
			if( $newAdressen ) $this->redirect('edit', 'Serialmail' , NULL, array( 'serialmail' => $serialmail , 'adressen' => $newAdressen ) );
		}
		$aAdressBook['students'] = $studAdressBook;
        $this->view->assign( 'adressbooks' , $aAdressBook );
		
		// else, if no redirect until here:
		// new adress-object for adressfields
		$newAdress = GeneralUtility::makeInstance('Mff\MffSerialmail\Domain\Model\Adressen');
		$newAdress->setSerialmail( $serialmail->getUid() );
		$this->view->assign('newAdressen', $newAdress );
		
        $this->view->assign( 'serialmail' , $serialmail );
		$this->view->assign( 'settings', $this->settings );
        $this->view->assign( 'insert' , $insert );
        
    }

    /**
     * getMaillinglistStudents
     *
     * @return array 2-dim [ (int) fachbereich ][ (int) klasse ] = (int) amount-of-adresses
     */
    Private function getMaillinglistStudents(){
			$ecousers = $this->senderRepository->findStudents( true );
			
			$aUsers = array();
			foreach( $ecousers as $objUser ){
				if( empty($objUser['eco_klasse']) || empty($objUser['email']) ) continue;
				$aUsers[ $objUser['eco_klasse'] ][ $objUser['email'] ] = $objUser;
			}
			
			$classes = $this->getClasses();
			
			foreach( array_keys($classes) as $fbUid ){
					if( !isset($classes[$fbUid]['classes']) ) continue;
					asort($classes[$fbUid]['classes']);
					foreach( $classes[$fbUid]['classes'] as $shortclass => $classTrain ){
						foreach( $classTrain as $classUid => $classRow ){
							if( count($aUsers[ $classUid ]) ) $fbStudents[$fbUid]['classes'][$shortclass][$classUid] = array( 'classshort'=>$classRow['classname'] , 'user'=>$aUsers[ $classUid ] );
						}
					}
					if( isset($fbStudents[$fbUid]['classes']) ) $fbStudents[$fbUid]['fachbereich'] = $classes[$fbUid]['fachbereich'];
			}
			return $fbStudents;
		
    }

    /**
     * getMaillinglistTeacher
     *
     * @return array 3-5-dim [ (string) listType ][ (int) fachbereich ][ 'fachbereich' OR 'users' ] ...
     */
    Private function getMaillinglistTeacher(){
		$teacherRelation = array();
		$sortFachbereich = $this->teacherRelationRepository->getTeachersFachbereich( 'sortFachbereich'  );
		$teaRelRepository['alleFachbereiche'] = $this->teacherRelationRepository->getTeachersFachbereich( 'AllTeachersRelations'  );
		$teaRelRepository['abuNachFachbereich'] = $this->teacherRelationRepository->getTeachersFachbereich( 'AbuKlassen'  );
		foreach( $sortFachbereich as $fbRow ){
			foreach($teaRelRepository as $listType => $listRow) {
				foreach($listRow as $row) {
					if($row['fachbereichNr'] != $fbRow['uid']) continue;
					$teacherRelation[$listType][$fbRow['uid']]['user'][$row['email']] = $row;
				}
				if( count( $teacherRelation[$listType][$fbRow['uid']]['user'] ) ) $teacherRelation[$listType][$fbRow['uid']]['fachbereich'] = $fbRow['fachbereichname'];
			}
		}
		
		$ecousers = $this->senderRepository->findTeachers( true );
		foreach($ecousers as $teacherObj){
			$aTeachers[ $teacherObj['eco_key'] ] = $teacherObj['email'];
		}
		$classes = $this->getClasses();
		foreach( array_keys($classes) as $fbUid ){
				if( !isset($classes[$fbUid]['classes']) ) continue;
				asort($classes[$fbUid]['classes']);
				foreach( $classes[$fbUid]['classes'] as $shortclass => $classTrain ){
					foreach( $classTrain as $classUid => $classRow ){
							if( empty($classRow['classteacher']) ) continue;
							if( !isset( $aTeachers[ $classRow['classteacher'] ] ) ) continue;
							$teacherEmail =   $aTeachers[ $classRow['classteacher'] ] ; 
							$teacherRelation['classteacher'][$fbUid]['user'][ $teacherEmail ][ $classUid ] = $classRow['classname'];
					}
				}
				if( isset($teacherRelation['classteacher'][$fbUid]['user']) ) $teacherRelation['classteacher'][$fbUid]['fachbereich'] = $classes[$fbUid]['fachbereich'];
		}
		
		
        return $teacherRelation;
    }

    /**
     * getClasses
     *
     * @return array 
     */
    Private function getClasses(){
			if( count( $this->classesArray ) ) return $this->classesArray;
			
			$fachbereiches = $this->fachbereichRepository->findAll(); 
			$today = time();
			foreach( $fachbereiches as $fb ){
					$fbUid = $fb->getUid();
					$this->classesArray[$fbUid]['fachbereich'] = $fb->getFachbereichname();
					$fbKurzklassen = $fb->getFbKurzklassen();
					if(empty($fbKurzklassen)) continue;
					foreach( $fbKurzklassen as $krzKlasse ){
							if(empty($krzKlasse)) continue;
							$klas = $krzKlasse->getKrzKlassen();
							$shortclass = $krzKlasse->getKurzbezeichnung();
							if(empty($klas)) continue;
							foreach( $klas as $klasse ){
									$clsEnd = $klasse->getKlasseEnde();
									if($clsEnd < $today) continue;
									$classUid = $klasse->getUid();
									$classname = $klasse->getClassShort();
									$classTeacher = $klasse->getClassteacherId();
									$this->classesArray[$fbUid]['classes'][$shortclass][$classUid] = array( 'classteacher'=> $classTeacher, 'classname'=> $classname );
							}
					}
			}
			return $this->classesArray;
    }

    /**
     * getRegisteredEmailAdresses
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @return array
     */
    Private function getRegisteredEmailAdresses(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail ){
			$exisitingMail = array();
			$mailAdr = $serialmail->getMailAdr();
			if( $mailAdr ){
				foreach( $mailAdr as $mlAdr ){
					$email = $mlAdr->getEmailadress();
					$exisitingMail[$email] = $mlAdr;
				}
			}
			return $exisitingMail;
    }

    /**
     * createAdressFromInputfields
     *
     * @param array $aAdress
     * @return void
     */
    Private function createAdressFromInputfields( $aAdress ){
				$isExisting = $this->adressenRepository->findByEmailadress($aAdress['emailadress']);
				// if( $isExisting ) return false;
				$newAdressen = GeneralUtility::makeInstance('Mff\MffSerialmail\Domain\Model\Adressen');
				$newAdressen->setSerialmail( $aAdress['serialmail'] );
				$newAdressen->setEmailadress( $aAdress['emailadress'] );
				if( empty($aAdress['gesendet']) ){
					$newAdressen->setGesendet( 0 );
				}else{
					$helperObj = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Controller\\SerialmailController');
// 					$helperObj = new \Mff\MffSerialmail\Controller\SerialmailController();
					$gesendet = $helperObj->dateTime2timestamp( $aAdress['gesendet'] , $aAdress['startzeit'] , -5);
					$newAdressen->setGesendet( $gesendet );
				}
				for( $fld = 1; $fld < 10 ; ++ $fld ){
					$method = 'setFeld'.$fld ;
					if( method_exists( $newAdressen , $method )  && isset( $aAdress['feld' . $fld] ) ) $newAdressen->$method( $aAdress['feld' . $fld] );
				}
				$this->adressenRepository->add($newAdressen);
				$this->persistenceManager->persistAll();
				$this->addFlashMessage('Adresse erstellt: ' . $newAdressen->getUid() , 'Adresse erstellen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);

				return $newAdressen;
    }

    /**
     * createAdressesFromArray
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @param array $aAdresses 2-dim array expects emailadress in row[x][0] and appends all other fields row[x][1]-row[x][9] to feld1 ... feld9
     * @return void
     */
    Private function createAdressesFromArray(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail  , $aAdresses ){
			$serialMailUid = $serialmail->getUid();
			if( empty($serialMailUid)  ) return FALSE;
			// delete existing adresses from creating-list
			$exisitingMail = $this->getRegisteredEmailAdresses($serialmail);
			foreach( $aAdresses as $ix => $row ){
				if( isset( $exisitingMail[ $row[0]] ) ) unset($aAdresses[$ix]);
			}
			// if there are no more adresses then stop the script
			if( !count($aAdresses) ) {
				$this->addFlashMessage( 'Keine neuen Adressen zu erfassen.' , 'Adressen erfassen' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				return FALSE;
			}
			// run through adresslist and create new adresses for the mail
			foreach( $aAdresses as $ix => $row ){
				$newAdressen = GeneralUtility::makeInstance('Mff\MffSerialmail\Domain\Model\Adressen');
				$newAdressen->setAktiv(1);
				$newAdressen->setSerialmail( $serialMailUid );
				$newAdressen->setEmailadress( $row[0] );
				for( $fld = 1; $fld < count($row) ; ++ $fld ){
					$method = 'setFeld'.$fld ;
					if( method_exists( $newAdressen , $method ) ) $newAdressen->$method( $row[$fld] );
				}
				$this->adressenRepository->add($newAdressen);
			}
			
			$this->persistenceManager->persistAll();
			$this->addFlashMessage(''.count($aAdresses).' Adressen hinzugefgügt.', 'Adressen hinzufügen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			return $newAdressen;
    }

}
