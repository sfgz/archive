<?php
namespace Mff\MffSerialmail\Controller;

/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

    /**
     * @var string
     */
    protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';

	/**
	* @var \TYPO3\CMS\Extbase\Persistence\Repository
	*/
	protected $resourceRepository;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
 	      $this->querySettings = $this->getSettings();
	      $this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
 	      
	}
    
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	Private function getSettings( ){
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storage['storagePid'] =  $fullsettings['plugin.']['tx_mffserialmail_mailer.']['persistence.']['storagePid'];
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );
		return $querySettings;
	}

    /**
     * Action List
     *
     * @return void
     */
    public function updateAction()
    {
		$fieldName = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('fieldName');
		$newValue = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('newValue');
		$table = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('table');
		$uid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('uid');
		if ( $table ) {
		      $repName  = str_replace( '##TABLENAME##' , ucFirst($table) , 'Mff\\MffSerialmail\\Domain\\Repository\\##TABLENAME##Repository' );
		      $this->resourceRepository = $this->objectManager->get( $repName );
		      $this->resourceRepository->setDefaultQuerySettings( $this->querySettings );
		      $res = $this->resourceRepository->findByUid( $uid );
		      $method = 'set' . ucFirst( $fieldName );;
		      if( method_exists($res,$method) ) $res->$method( $newValue );
		      $this->resourceRepository->update( $res );
		      $this->persistenceManager->persistAll();
		      return json_encode( array( 0 => $newValue , 1 => $table ) );
		}
    }
}
