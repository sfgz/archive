<?php
namespace Mff\MffSerialmail\Controller;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/***
 *
 * This file is part of the "Serial Mailer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * SerialmailController
 */
class SerialmailController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * serialmailRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\SerialmailRepository
     * @inject
     */
    protected $serialmailRepository = null;

    /**
     * senderRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\SenderRepository
     * @inject
     */
    protected $senderRepository = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;


	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
			date_default_timezone_set ( 'Europe/Zurich' );
		
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
	    $this->senderRepository->setDefaultQuerySettings($querySettings);
	    
		$this->attachmentUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\AttachmentUtility');
		
	    $action = $this->request->getControllerActionName();
	    if( !$GLOBALS['TSFE']->fe_user->user['uid'] && $action != 'list' ) $this->redirect('list');
	}

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $serialmails = $GLOBALS['TSFE']->fe_user->user['uid'] ? $this->serialmailRepository->findeByMailLoguserOrMailSender( $GLOBALS['TSFE']->fe_user->user['uid'] ) : array();
        $this->view->assign('serialmails', $serialmails);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {
		$uid = $GLOBALS['TSFE']->fe_user->user['uid'];
		
// 		$newSerialmail = new \Mff\MffSerialmail\Domain\Model\Serialmail();
		$newSerialmail = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Domain\\Model\\Serialmail');
		
		$startdatum = $this->dateTime2timestamp( '' , '' );
		$newSerialmail->setStartdatum( $startdatum );
		
		$senderObj = $this->senderRepository->findByUid($uid);
		$newSerialmail->setMailSender( $senderObj );
		
		$userObj = $this->senderRepository->findByUid($uid);
		$newSerialmail->setMailLoguser( $userObj );
		
        $this->view->assign('serialmail', $newSerialmail );
        
 		$senderlist = $this->senderRepository->findTeachers( true , array( 'username'=>1 ,'email'=>1 ,'notdeleted'=>1 ,'notdisable'=>1 ) );
		
        $this->view->assign('senderlist', array('options' => $senderlist, 'selected' => $uid) );
		$this->view->assign('loguserlist', array('options' => $senderlist, 'selected' => $uid) );
    }

	/**
	 * Initialize  create
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
        if ( $this->request->hasArgument('newSerialmail') ) {
			$serialmail = $this->request->getArgument('newSerialmail');
			if(!is_numeric($serialmail['startdatum'])) {
			      $this->arguments->getArgument('newSerialmail')->getPropertyMappingConfiguration()->skipProperties('startdatum');
			}
			if( $this->request->hasArgument('abort') ) {
				$this->redirect('list');
			}
        }
    }

    /**
     * action create
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $newSerialmail
     * @return void
     */
    public function createAction(\Mff\MffSerialmail\Domain\Model\Serialmail $newSerialmail) {
		if($this->request->hasArgument('abort')) {
			$this->addFlashMessage('Der Vorgang create Serialmail wurde abgebrochen.', 'Abbrechen', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
			$this->redirect('list');
			return;
        }
        if ( $this->request->hasArgument('newSerialmail') ) {

			$objLoguser = $newSerialmail->getMailLoguser() ;
			if( !$objLoguser){
				$userUid = $GLOBALS['TSFE']->fe_user->user['uid'];
				$userRepository = $this->senderRepository->findByUid($userUid);
				$newSerialmail->setMailLoguser($userRepository);
			}
			
			$edFields = $this->request->getArgument('newSerialmail');
			$timeField = $this->request->getArgument('startzeit');
			$startdatum = $this->dateTime2timestamp( $edFields['startdatum'] , $timeField );
			$newSerialmail->setStartdatum( $startdatum );
        }
        $this->addFlashMessage('Das Serien-Email wurde erstellt. ', 'Email erstellen', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->serialmailRepository->add($newSerialmail);
		$this->persistenceManager->persistAll();
        
		$this->redirect('edit', NULL, NULL, array('serialmail' => $newSerialmail));
 		//$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        //$this->redirect('list');
    }

	/**
	 * attachment Action
	 *
	 * @return void
	 */
	public function attachmentAction() {
        if ( $this->request->hasArgument('serialmail') ) {
			
			$serialmailNr = $this->request->getArgument('serialmail');
            if( $this->request->hasArgument('delete_attachment') ){
				$attachedFile =  $this->request->getArgument('delete_attachment');
				$this->attachmentUtility->deleteAttachment( $serialmailNr , $attachedFile );
				$this->addFlashMessage( 'Anhang ' . $attachedFile . '  entfernt. Mail Nr.' . $serialmailNr , 'Anhang entfernen' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
			
            if( $this->request->hasArgument('download_attachment') ){
// 				$downloadUtility = new \Mff\MffSerialmail\Utility\FileDownloaderUtility();
				$downloadUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\FileDownloaderUtility');
				$subDirectory = trim( $serialmailNr , '/' ) . '/';
				$uploadDir =  $this->attachmentUtility->attachmentFolder . $subDirectory;
				$attachedFile =  $this->request->getArgument('download_attachment');
				$downloadUtility->download($uploadDir.$attachedFile);
 				exit;
			}

			$this->redirect('edit', NULL, NULL, array('serialmail' => $serialmailNr));
		}

        $this->redirect('list');
    }

	/**
	 * Initialize  edit
	 *
	 * @return void
	 */
	public function initializeEditAction() {
        if ( $this->request->hasArgument('serialmail') ) {
			$serialmail = $this->request->getArgument('serialmail');
			if(isset($serialmail['startdatum']) && !is_numeric($serialmail['startdatum'])) {
			      $this->arguments->getArgument('serialmail')->getPropertyMappingConfiguration()->skipProperties('startdatum');
			}
        }
    }

    /**
     * action edit
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @ignorevalidation $serialmail
     * @return void
     */
    public function editAction(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail) {
		$objSender = $serialmail->getMailSender() ;
		$tUid = $objSender ? $objSender->getUid() : $GLOBALS['TSFE']->fe_user->user['uid'];
        $objLoguser = $serialmail->getMailLoguser() ;
		$lUid = $objLoguser ? $objLoguser->getUid() : $GLOBALS['TSFE']->fe_user->user['uid'];
		
		$isCientmode = $this->settings['clientmode'] && $tUid != $lUid ;
		$isAutostart = $this->settings['clearanceTimeHowers'] > 0;
		$plannedStartDate = $serialmail->getStartdatum();
		$lastRequestDate = $serialmail->getAntragdatum();
		$isClearedOnDate = $serialmail->getFreigabedatum();
		
        // client-mode state:
        // done ; sending ; will_send/will_autosend ; waiting_request/will_autosend ; will_ask/will_autosend ; disabled 
        // no client-mode: send if starttime
        // client-mode AND antragsdatum = 0: send link (will_autosend)
        // client-mode AND antragsdatum > 0 AND clearanceHowsers = 0: wait for clearance (will_autosend)
        // client-mode AND antragsdatum > 0 AND clearanceHowsers > 0: wait for clearance (autostart in x minutes)
        // client-mode AND antragsdatum+clearanceHowsers <= now: autostarted
        
        if( $this->request->hasArgument('edit') ){
				$edit = $this->request->getArgument('edit');
				if( $edit == 'sendrequest' ){
					$now = time();
					$timeout = $this->settings['clearanceTimeSecondsBetweenUnlockRequests'];
					$lastRequest = $serialmail->getAntragdatum();
					if( $lastRequest + $timeout > $now ){
							$this->addFlashMessage('Kein Email versendet, bitte noch ' . ($lastRequest + $timeout - $now ). ' Sekunden warten. ' , 'Email senden', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
					}else{
							$serialmail->setAntragdatum( $now );
							if( $this->settings['clearanceTimeHowers'] > 0 ) {
								$serialmail->setFreigabedatum( time() );
								$serialmail->setAktiv( 1 );
							}
							$this->serialmailRepository->update($serialmail);
							$this->mailDaemonUtility = GeneralUtility::makeInstance(\Mff\MffSerialmail\Utility\MailDaemonUtility::class);
							$this->mailDaemonUtility->sendUnlockRequestToHostAdress( $serialmail );
							$this->addFlashMessage('Email mit Antrag versendet: ' . date( 'd.m.y H:i' , $now ) , 'Email senden', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
					}
				}
        }

        $this->view->assign('serialmail',$serialmail );
		
		$senderlist = $this->senderRepository->findTeachers( true , array( 'username'=>1 ,'email'=>1 ,'notdeleted'=>1 ,'notdisable'=>1 ,'extbase_type'=>'' ) );
		
		$this->view->assign('senderlist', array('options' => $senderlist, 'selected' => $tUid) );
		$this->view->assign('loguserlist', array('options' => $senderlist, 'selected' => $lUid) );

		$objSignature = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\SignatureUtility' , $this->settings );
		$this->view->assign('signature', $objSignature->getSignature( $tUid ) );

        $this->view->assign('attachments', $this->attachmentUtility->getAttachments( $serialmail ) );

		$this->view->assign('settings', $this->settings );

        // pager: go to page
        $mailAdr = $serialmail->getMailAdr();
        if( $this->request->hasArgument('adressen') ){
			$activeAdressNr = $this->request->getArgument('adressen');
			$this->view->assign( 'adressen' , $activeAdressNr ); // mark row as selected
			$z=0;
			foreach( $mailAdr as $objAdr ){
				if( $activeAdressNr == $objAdr->getUid() ){
					$this->view->assign( 'gotoPage' , floor($z/$this->settings['linesPerPage']) );
					break;
				}
				$z += 1;
			}
		}else{
//			$this->view->assign( 'gotoPage' , floor((count($mailAdr)-1)/$this->settings['linesPerPage']) ); // go to last page
			$this->view->assign( 'gotoPage' , 0 ); // go to first page
        }
		
         
	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		if($this->request->hasArgument('abort')) {
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$this->redirect('list');
		}
		
		if($this->request->hasArgument('new')) $this->redirect('new');
		
        if ( $this->request->hasArgument('serialmail') ) {
			$serialmail = $this->request->getArgument('serialmail');
			$propertyMapConfig = $this->arguments->getArgument('serialmail')->getPropertyMappingConfiguration();
			if(!is_numeric($serialmail['startdatum'])) $propertyMapConfig->skipProperties('startdatum');
        }
        
    }

    /**
     * action update
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @return void
     */
    public function updateAction(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail) {
		$additionalFlashMessage = array();
		// get attachment-restrictions
		$aRestrictions = $this->request->hasArgument('restriction') ? $this->request->getArgument('restriction') : array() ;
		// handle attachment file upload+rud-actions
		$uploadFile = $this->attachmentUtility->updateAttachments( $serialmail , $aRestrictions );
		if( $uploadFile ) $this->addFlashMessage('Hochgeladen: ' . $uploadFile , 'Hochladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);

		// set logged user as editor
		$userUid = $GLOBALS['TSFE']->fe_user->user['uid'];
		$userRepository = $this->senderRepository->findByUid($userUid);
		$serialmail->setMailLoguser($userRepository);
		
		$objLoguser = $serialmail->getMailLoguser() ;
		$objSender = $serialmail->getMailSender() ;
		
// 		if( $this->settings['clientmode'] > 0 && $objLoguser->getUid() != $objSender->getUid() ){
// 			$clearingDate = $serialmail->getFreigabedatum();
// 			if( empty($clearingDate) && $serialmail->getAntragdatum() ){
// 				$serialmail->setAntragdatum('');
// 				$additionalFlashMessage[] = 'Antragdatum gelöscht' ;
// 			}
// 		}
		
		// sanitize time and date
		$edFields = $this->request->getArgument('serialmail');
		$timeField = $this->request->getArgument('startzeit');
		$startdatum = $this->dateTime2timestamp( $edFields['startdatum'] , $timeField );
		$serialmail->setStartdatum( $startdatum );
		
		// update serialmail
		$this->addFlashMessage('Serien-Email gespeichert. Startdatum:' . date( 'd.m.y H:i' , $startdatum ) . "\n" . implode( "\n" , $additionalFlashMessage ) , 'Speichern', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->serialmailRepository->update($serialmail);
        
        // redirect or output in own view
		if($this->request->hasArgument('saveclose')) {
 			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
			$this->redirect('list');
        }else{
			$this->redirect('edit', NULL, NULL, array('serialmail' => $serialmail));
        }
    }

    /**
     * action delete
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @return void
     */
    public function deleteAction(\Mff\MffSerialmail\Domain\Model\Serialmail $serialmail)
    {
		$this->attachmentUtility->deleteUploadFolders( $serialmail->getUid() );
        $this->serialmailRepository->remove($serialmail);
 		$GLOBALS['TSFE']->clearPageCacheContent_pidList( $GLOBALS['TSFE']->id );
        $this->addFlashMessage('Serien-Email wurde entfernt.', 'Email löschen', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
        $this->redirect('list');
    }

    /**
     * getUserlist
     *
     * @return void
     */
    public function getUserlist() {
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$senderlist = $this->senderRepository->findByPid($settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid']);
		return $senderlist;
    }

    /**
     * dateTime2timestamp
     *
     * @param string $sDate in format d.m.Y optional
     * @param string $sTime in format H:i optional
     * @param string $minOffset defult is 5 minutes
     * @return void
     */
    public function dateTime2timestamp( $sDate = '' , $sTime = '' , $minOffset = 5 ) {
			$in5minutes = (300 * ceil(time()/300)) + ( $minOffset * 60 ) ;
			if( empty($sDate) ){
				$sDate = date( 'd.m.Y' , $in5minutes );
			}elseif(
				( (string) (int) $sDate === $sDate) && 
				($sDate <= PHP_INT_MAX) && 
				($sDate >= ~PHP_INT_MAX)
			){	// string is already a timestamp
				return $sDate;
			}
			
			if( empty($sTime) ){
				$sTime = date( 'H:i' , $in5minutes);
			}
			$aD = explode( '.' , $sDate);
			$aZ = explode( ':' , $sTime);
			$unixTimestamp = mktime($aZ[0],$aZ[1],0,$aD[1], $aD[0], $aD[2] );
			return $unixTimestamp;
    }
}
