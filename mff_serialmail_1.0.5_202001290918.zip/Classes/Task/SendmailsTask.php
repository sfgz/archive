<?php
namespace Mff\MffSerialmail\Task;

 /** 
 * Class MailTask
 * look up if a mail job is open
 * sends the Email if trigger is on
 * 
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */
 
use Mff\MffSerialmail\Utility\MailDaemonUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
/**
 * SendmailsTask class for the Scheduler
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 * @package TYPO3
 * @subpackage tx_mff_serialmail
 */
class SendmailsTask extends AbstractTask {

    /**
     * @var integer Emails per job
     */
    public $mails_per_job;

	/**
	 * mailDaemonUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailDaemonUtility = NULL;
	
	/**
	* initiate
	*
	* @return void
	*/
	public function initiate() {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			$this->mailDaemonUtility = GeneralUtility::makeInstance(MailDaemonUtility::class);
	}

	public function execute(){
	    $this->initiate();
	    $success = FALSE;
	    $result = 0;
 	    $mailJobMsgs = $this->mailDaemonUtility->evaluateMailJobs( $this->mails_per_job );
	    foreach( $mailJobMsgs as $ix => $msg ){
			// create flashMessage
			$type = is_numeric($ix) ? \TYPO3\CMS\Core\Messaging\FlashMessage::INFO : \TYPO3\CMS\Core\Messaging\FlashMessage::WARNING;
			$message = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
				$msg ,
				'Serienmail Nr. '.$ix, 
				$type
			);
			$this->messageQueue->addMessage($message);
	    }
	    
	    $success = TRUE;
	    return $success;
	}

    /**
     * This method returns the synchronized service and index as additional information
     *
     * @return    string    Information to display
     */
    public function getAdditionalInformation()
    {
        $info = $GLOBALS['LANG']->sL('LLL:EXT:mff_serialmail/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.description');
        return $info;
    }
	

}
