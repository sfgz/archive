<?php
namespace Mff\MffSerialmail\Utility;
use \DateTime;
use TYPO3\CMS\Core\Utility\GeneralUtility;

 /** 
 * Class MailDaemonUtility
 * Looks up if a mail job is open and fills the array 'validJobs' with serialmails.
 * Delays the delivery if editor is not the same person as the sender.
 * Finally loops through the defined amount of adresses and
 * sends the Email if trigger is on, regardless if the sent-on-date is set
 * 
 * 
 */
 
class MailDaemonUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* serialmailRepository
	*
	* @var \Mff\MffSerialmail\Domain\Repository\SerialmailRepository
	*/
	protected $serialmailRepository = null;

    /**
     * adressenRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\AdressenRepository
     * @inject
     */
    protected $adressenRepository = null;

    /**
     * attachmentUtility
     *
     * @var \Mff\MffSerialmail\Utility\AttachmentUtility
     * @inject
     */
    Public $attachmentUtility = null;

	/**
	 * validJobs
	 *
	 * @var array
	 */
	protected $validJobs = NULL;

	/**
	 * hasToPersist
	 *
	 * @var boolean
	 */
	protected $hasToPersist = FALSE;

	/**
	 * activeMailjob
	 *
	 * @var array
	 */
	Public $activeMailjob = NULL;

	/**
	* settings
	* 
	* @var array
	*/
	protected $settings = array();
	
	/**
	* __construct
	*
	* @return void
	*/
	Public function __construct(  ) {
			date_default_timezone_set ( 'Europe/Zurich' );
			$this->timeZone = new \DateTimeZone('Europe/Zurich');
			
			$this->init_setSettings();

			$this->querySettings->setRespectStoragePage( TRUE );
			
			$this->serialmailRepository = $this->objectManager->get('Mff\\MffSerialmail\\Domain\\Repository\\SerialmailRepository');
			$this->serialmailRepository->setDefaultQuerySettings( $this->querySettings );

			$this->adressenRepository = $this->objectManager->get('Mff\\MffSerialmail\\Domain\\Repository\\AdressenRepository');
			$this->adressenRepository->setDefaultQuerySettings( $this->querySettings );
			
			$this->attachmentUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\AttachmentUtility');
			$this->signatureUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\SignatureUtility' , $this->settings );
			
	}
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	Private function init_setSettings( ){
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storage['storagePid'] =  $fullsettings['plugin.']['tx_mffserialmail_mailer.']['persistence.']['storagePid'];
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );
		$this->querySettings = $querySettings;
		
		$this->typoScriptService = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
		$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mffserialmail_mailer.']['settings.']);
		$this->settings['config'] = $fullsettings['config.'];

		$this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
	}
	
	/**
	* init_sanitizeMailJobs
	*
	* @param bool $onlyActiveJobs optional, default is true
	* @return bool
	*/
	Private function init_sanitizeMailJobs( $onlyActiveJobs = TRUE ) {
		$toPersist = 0;
		$startTime = time();

		if($onlyActiveJobs){
			$mailObjs = $this->serialmailRepository->findeAktiveByStartdate( $startTime );
		}else{
//			$mailObjs = $this->serialmailRepository->findLessThanOrEqualStartdatum( $startTime );
			$mailObjs = $this->serialmailRepository->findAll(  );
		}
 		
		if( !$mailObjs || !count($mailObjs) ) return false;

		foreach($mailObjs as $serialmail) {
			$oSender = $serialmail->getMailSender();
			$oEditor = $serialmail->getMailLoguser();
			$validAdresses = $this->init_getValidActiveAdresses( $serialmail );
			if( !count($validAdresses) || empty($oSender) || empty($oEditor) ){
				$serialmail->setAktiv( FALSE );
				$this->serialmailRepository->update( $serialmail );
				++$toPersist;
			}else{
				$this->validJobs[$serialmail->getUid()] = array( 'serialmail'=>$serialmail , 'adresses'=>$validAdresses );
			}
		}
		if( $toPersist ) $this->persistenceManager->persistAll();
		return true;

    }
	
	/**
	* init_getValidActiveAdresses
	*
    * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
	* @return array
	*/
	Private function init_getValidActiveAdresses( \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail ) {
			
			$objAdr = $serialmail->getMailAdr();
			if( !$objAdr || !count($objAdr) ) return false;
			
			$validAdresses = array();
			foreach( $objAdr as $oAdress ){
				if( false == $oAdress ) continue;
				if( false == $oAdress->getAktiv() ) continue;
				$adressToExamine = $oAdress->getEmailadress();
				if( false == filter_var( $adressToExamine , FILTER_VALIDATE_EMAIL ) ) continue;
				$validAdresses[$adressToExamine] = $oAdress;
			}
			if( !count($validAdresses) ) return false;
			
			return $validAdresses;
	}
	
	/**
	* previewMailJobs
	*
	* @param int $serialmailUid
	* @return int
	*/
	Public function previewMailJobs( $serialmailUid ) {
			$this->init_sanitizeMailJobs( FALSE );
			if( !is_array( $this->validJobs[$serialmailUid]['adresses'] ) || !count( $this->validJobs[$serialmailUid]['adresses'] ) ) return FALSE;
			$objSerialmail = $this->serialmailRepository->findByUid( $serialmailUid );
			if( !$objSerialmail ) return FALSE;
			$oSender = $objSerialmail->getMailSender();
			$this->activeMailjob = array( 'from' => $oSender->getEmail() );
			$this->signatureUtility->setSenderinfo( $oSender->getUid() );
			$this->activeMailjob['signature'] = $this->signatureUtility->glueSignature();
			$this->activeMailjob['validAdressesToDispatch'] = $this->validJobs[$serialmailUid]['adresses'];
			
			return $this->activeMailjob;
	}
	
	/**
	* evaluateMailJobs
	*
	* @param int $mails_per_job
	* @return int
	*/
	Public function evaluateMailJobs( $mails_per_job ) {
		$this->init_sanitizeMailJobs( TRUE );
		$mailJobMsgs = array();
		if( count($this->validJobs) ) {
			foreach( array_keys($this->validJobs) as $jobNr ) {
					$hasWork = $this->dispatchMailJob( $jobNr , $mails_per_job );
					if($hasWork) $mailJobMsgs[ $jobNr ] = $hasWork;
			}
			if( $this->hasToPersist ) $this->persistenceManager->persistAll();
		}
		if( !count($mailJobMsgs) ) return array('keine'=>'Es wurden keine Emails gesendet. ');
		return $mailJobMsgs ;
	}
	
	/**
	* dispatchMailJob
	*
	* @param int $jobNr
	* @param int $mails_per_job
	* @return string message
	*/
	Private function dispatchMailJob( $jobNr , $mails_per_job ) {
			
			$serialmail = $this->validJobs[$jobNr]['serialmail'];

			// if no adresses then inactivate this serialmail
			$validAdressesToDispatch = $this->validJobs[$jobNr]['adresses'];
			if( !is_array($validAdressesToDispatch) || !count($validAdressesToDispatch) )  {
					$serialmail->setAktiv( FALSE );
					$this->serialmailRepository->update($serialmail);
					$this->hasToPersist = true;
					return false;
			}
			
			// detect if sender and editor are the same
			// if sender and editor are NOT the same
			$isJobLockedByHostAdress = $this->isJobLockedByHostAdress( $serialmail );
			if( $isJobLockedByHostAdress ) return $isJobLockedByHostAdress;
			
			$oSender = $serialmail->getMailSender();
			
			
			// initialize and fill activeMailjob
			$this->activeMailjob = array( 'from' => $oSender->getEmail() );
			$this->setImagesForActiveMailjob();
			$this->setSignatureForActiveMailjob( $oSender->getUid() );
			
			$aAttachments = $this->attachmentUtility->getAttachments( $serialmail );
			
			$dispatchedAdress =array();
			foreach( $validAdressesToDispatch as $emailadress => $oAdress ){
					if( $mails_per_job < 1 ) break;
					// detect if there is a file to attach
					$this->setAttachmentsForAdressedJob( $aAttachments , $oAdress );
					// create individual subject and mailtext: replace variables with values in templateTextes
					$this->setTextesForAdressedJob( $serialmail , $oAdress );
					$this->activeMailjob['mailtext'] .= $this->activeMailjob['signature'];
					// send the mail and set it do inactive
					if( $this->sendMailToAdress( $serialmail , $oAdress ) ) $dispatchedAdress[$emailadress] = $emailadress;
					// refresh counter an array containing valid adresses to dispatch
					unset($validAdressesToDispatch[$emailadress]);
					$mails_per_job -=1;
			}
			// if no more adresses then inactivate this serialmail
			if( !count($validAdressesToDispatch) )  {
					$serialmail->setAktiv( FALSE );
					$this->serialmailRepository->update($serialmail);
					$this->hasToPersist = true;
			}
			// if no mails sent return here without message
			if( !count($dispatchedAdress) ) return false;
			
			// return message
			$remainingText = count($validAdressesToDispatch).' verbleibende Adressen.';
			if( count( $dispatchedAdress ) >1 ) return 'Es wurden '.count( $dispatchedAdress ).' Emails gesendet. ' . $remainingText;
			return 'Es wurde 1 Email gesendet. ' . $remainingText;
	}
	
	/**
	* getClearanceTimeString
	*
	* @param int $timespan
	* @return boolean
	*/
	Public function getClearanceTimeString( $timespan = '' ) {
		if( !strlen($timespan) ) $timespan = $this->settings['clearanceTimeHowers'];
		return $timespan >= 1 ? round($timespan ,1) . ' Std.' : round($timespan * 60 ,1) . ' Min.' ;
	}
	
	/**
	* sendUnlockRequestToHostAdress
	*
    * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
	* @return boolean
	*/
	Public function sendUnlockRequestToHostAdress( $serialmail ) {
			$oSender = $serialmail->getMailSender();
			$oEditor = $serialmail->getMailLoguser();
			
					$mail = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');

					$signatureLogoPath = GeneralUtility::getFileAbsFileName( $this->settings['signatureLogo']['path'] );
					$embedImg = '<img src="' . $mail->embed(\Swift_Image::fromPath($signatureLogoPath)) . '" alt="logo" />';
					
					$sr = array( 
						'_LOGO_' => $embedImg , 
						'_COUNTDOWN_' => $this->getClearanceTimeString() , 
						'_EDITOR_NAME_' =>  $oEditor->getFirstname().' '.$oEditor->getLastname(), 
						'_EDITOR_EMAIL_' => $oEditor->getEmail(), 
						'_SENDER_NAME_' =>  $oSender->getFirstname().' '.$oSender->getLastname(), 
						'_SENDER_EMAIL_' => $oSender->getEmail(), 
						'_SERIALMAIL_UID_' => $serialmail->getUid() 
					);

					$textTemplate = $this->getUnlockMailTemplateText( $serialmail->getUid() );
					$subject = $this->settings['clearanceTimeHowers'] > 0 ? 'Ansage' : 'Anfrage';

					$mail->setBody( str_replace( array_keys($sr) , $sr , $textTemplate ) , 'text/html' );
					$mail->setSubject( $subject . ' Serien-Emailversand' );
					$mail->setFrom( $oEditor->getEmail() );
					$mail->setTo( $oSender->getEmail() );
// 					$mail->setTo( 'job@verarbeitung.ch' ); // $oSender->getEmail()
					$mail->send();
					return true;
	}
	
	/**
	* isJobLockedByHostAdress
	*
    * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
	* @return boolean
	*/
	Private function isJobLockedByHostAdress( $serialmail ) {
			// detect if sender and editor are the same
			$oSender = $serialmail->getMailSender();
			$oEditor = $serialmail->getMailLoguser();
			if(  ( $oSender->getUid() == $oEditor->getUid() ) ) return false;
			
			// if sender and editor are NOT the same...
			$iAntragdatum = $serialmail->getAntragdatum();
			if( empty($iAntragdatum) ) {
			// delay step 1.
					$clearanceTimeString = $this->getClearanceTimeString();
					// send email to sender
					$this->sendUnlockRequestToHostAdress( $serialmail );
					// set freigabedatum to now
					if( $this->settings['clearanceTimeHowers'] > 0 ){
							$freigabedatum =  time() + ( $this->settings['clearanceTimeHowers'] * 3600 );
							$serialmail->setFreigabedatum( $freigabedatum );
							$timeLeft = 'in ' . $clearanceTimeString;
					}else{
							$timeLeft = 'nach Freigabe';
					}
					$serialmail->setAntragdatum( time() );
					$this->serialmailRepository->update($serialmail);
					$this->hasToPersist = true;
					
					//  return a message (used if startet out of task-manager)
					return 'Die Absenderadresse entspricht nicht der Adresse des Bearbeiters. Jetzt wurde eine Nachricht an die Absenderadresse gesendet, die Serienmails werden '.$timeLeft.' versendet. Total Adressen: ' . count($this->validJobs[$serialmail->getUid()]['adresses']);

			}
			
			// antragsdatum is set, but perhaps we have another call of script 
			$iFreigabedatum = $serialmail->getFreigabedatum();
			if( empty($iFreigabedatum) ){
					$timeLeft =  'Der Job muss erst frei gegeben werden bevor ' ;
					$timeLeft .= 'die Serienmails versendet werden, weil die Absenderadresse nicht der Adresse des Bearbeiters entspricht. ' ;
					$timeLeft .= 'Die Nachricht wurde am '.date('d.m.y H:i' , $serialmail->getAntragdatum() ).' gesendet. ' ;
					$timeLeft .= ' Total Adressen: ' . count($this->validJobs[$serialmail->getUid()]['adresses']) ;
					return $timeLeft;
					
			}elseif( ($this->settings['clearanceTimeHowers'] * 3600) + $iFreigabedatum > time() ){
			// delay step 2. and further steps until time is reached to send
					if( $this->settings['clearanceTimeHowers'] > 0 ){
						$diffSec = ((($this->settings['clearanceTimeHowers'] * 3600) + $iFreigabedatum) - time() ) / 3600;
						$timeLeft = 'Es dauert noch '. $this->getClearanceTimeString($diffSec) . ' bis ' ;
					}else{
						$timeLeft = 'Der Job muss erst frei gegeben werden bevor ' ;
					}
					$timeLeft .= 'die Serienmails versendet werden, ';
					$timeLeft .= 'weil die Absenderadresse nicht der Adresse des Bearbeiters entspricht. ';
					$timeLeft .= 'Die Nachricht wurde am '.date('d.m.y H:i' , $serialmail->getAntragdatum() ).' gesendet. ';
					$timeLeft .= 'Total Adressen: ' . count($this->validJobs[$serialmail->getUid()]['adresses']);
					return $timeLeft;
			}
			return false;
	}
	
	/**
	* getUrlForEmailText
	*
     * @param string $outputAction
     * @param string $serialmailUid
	* @return string
	*/
	Public function getUrlForEmailText( $outputAction , $serialmailUid ) {
		$urlPart['base'] = $this->settings['config']['baseURL'].'?type=1522010450';
		$urlPart['serialmail'] = $this->settings['previewExtKey'].'[serialmail]='.$serialmailUid;
		if( !empty($outputAction) ) $urlPart['action'] = $this->settings['previewExtKey'].'[action]=' . $outputAction;
		$urlPart['bHash'] = 'bHash=' . $this->create_bHash( $serialmailUid );
		return implode(  '&' , $urlPart );
	}
	
	/**
	* create_bHash
	* 
	* @param integer $serialmailUid
	* @return void
	*/
	public function create_bHash( $serialmailUid ) {
			return md5( 'serialmailer-' . $serialmailUid );
	}
	
	/**
	* getUnlockMailTemplateText
	*
    * @param string $serialmailUid
	* @return string
	*/
	Private function getUnlockMailTemplateText( $serialmailUid = '_SERIALMAIL_UID_' ) {
		$textTemplate = 'Hallo _SENDER_NAME_';
		$textTemplate .= "\n<br />";
		$textTemplate .= '_EDITOR_NAME_ (_EDITOR_EMAIL_) möchte im Namen der Absenderaresse &laquo;_SENDER_EMAIL_&raquo; einen';
		$textTemplate .= ' Serien-Emailversand durchführen.';
		$textTemplate .= "\n<br />";
		
		if( $this->settings['clearanceTimeHowers'] > 0 ){
			$textTemplate .= 'Dieser wird in _COUNTDOWN_ gestartet.';
			$textTemplate .= "\n<br />";
			$textTemplate .= "\n<br />";
			$textTemplate .= 'Hier klicken, um den Start zu verhindern: <a href="'. $this->getUrlForEmailText( 'stop' , $serialmailUid ).'">Stop!</a>';
			$textTemplate .= "\n<br />";
		}else{
			$textTemplate .= "\n<br />";
			$textTemplate .= '<b>Bitte freigeben</b>, sonst wird der Versand <b>nicht gestartet</b>.';
			$textTemplate .= "\n<br />";
			$textTemplate .= 'Hier klicken, um den Versand zu starten: <a href="' . $this->getUrlForEmailText( 'go' , $serialmailUid ) . '">Start!</a>';
			$textTemplate .= "\n<br />";
		}
		
// 		$textTemplate .= 'Hier einloggen, um die Nachricht anzuschauen: <a href="'.$this->settings['config']['baseURL'].'loginlogout/">Login</a>';
		$textTemplate .= "\n<br />\n<br />".'<i style="font-size:80%">Diese Nachricht wurde vom Serien-Mailer auf &laquo;'.$this->settings['config']['baseURL'].'&raquo; automatisch gesendet.</i>';
		$textTemplate .= "\n<br />_LOGO_\n<br />";
		return $textTemplate;
	}
	
	/**
	 * setImagesForActiveMailjob
	 *
	 * @return void
	 */
	Private function setImagesForActiveMailjob() {
			if( isset( $this->settings['imagesToReplaceInMails'] ) ){
				foreach( $this->settings['imagesToReplaceInMails'] as $aImg ){
						$shortname = pathinfo( $aImg['path'] , PATHINFO_BASENAME );
						$this->activeMailjob['images'][ $shortname ] = $aImg; 
				}
			}
	}
	
	/**
	 * setSignatureForActiveMailjob
	 *
     * @param string $senderUid
	 * @return void
	 */
	Private function setSignatureForActiveMailjob($senderUid) {
			$this->signatureUtility->setSenderinfo( $senderUid );
			$this->signatureUtility->senderInfo['logo'] = basename($this->settings['signatureLogo']['path']);
			$this->activeMailjob['signature'] = $this->signatureUtility->glueSignature();
	}

	/**
	 * setAttachmentsForAdressedJob
	 *
     * @param array $aAttachments
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $adresse
	 * @return string
	 */
	Public function setAttachmentsForAdressedJob( $aAttachments , $adresse ) {
			$this->activeMailjob['attachments'] = array();
			if( !count($aAttachments) ) return false;
			
			if( $this->settings['attachmentFieldRestriction'] == 'equalsFilename' ){
				$sr = array( '/' , ';' , ' '  , ',,,'  , ',,' );
				foreach( $aAttachments as $fileInfo ){
					if( empty($fileInfo['restriction']) ){
							$this->activeMailjob['attachments'][ $fileInfo['filename'] ] = $fileInfo['path'];
					}else{
						$method = 'getFeld'.trim($fileInfo['restriction']);
						if( method_exists( $adresse , $method ) ){
							$fieldContent = $adresse->$method();
							$clrCont = str_replace( $sr , ',' , trim($fieldContent) );
							$aFilenames = explode( ',' , $clrCont );
							foreach( $aFilenames as $fileInField ){
									if(  pathinfo( $fileInField , PATHINFO_FILENAME ) == pathinfo( $fileInfo['filename'] , PATHINFO_FILENAME ) ){
											$this->activeMailjob['attachments'][ $fileInfo['filename'] ] = $fileInfo['path'];
									}
							}
						}
					}
				}
				
			}elseif( $this->settings['attachmentFieldRestriction'] == 'notEmpty' ){
				foreach( $aAttachments as $fileInfo ){
					if( empty($fileInfo['restriction']) ){
							$this->activeMailjob['attachments'][ $fileInfo['filename'] ] = $fileInfo['path'];
					}else{
						$method = 'getFeld'.trim($fileInfo['restriction']);
						if( method_exists( $adresse , $method ) ){
							if( $adresse->$method() ) $this->activeMailjob['attachments'][ $fileInfo['filename'] ] = $fileInfo['path'];
						}
					}
				}
					
			}else{ // attachmentFieldRestriction == none
				foreach( $aAttachments as $fileInfo ){
					$this->activeMailjob['attachments'][ $fileInfo['filename'] ] = $fileInfo['path'];
				}
					
			}
	}

	/**
	 * setTextesForAdressedJob
	 *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @param \Mff\MffSerialmail\Domain\Model\Adressen $adresse
	 * @return string
	 */
	Public function setTextesForAdressedJob( $serialmail , $adresse ) {
			$adressField[ '_Feld' ] = '_feld';
			$adressField[ '_FELD' ] = '_feld';
			for( $fieldNr = 1 , $fieldPrefix = 'Feld' ; $fieldNr <= 5 ; ++$fieldNr ) {
				$method = 'get' . $fieldPrefix.$fieldNr;
				$adressField[ '__' . strtolower($fieldPrefix.$fieldNr) . '__' ] = '_' . strtolower($fieldPrefix.$fieldNr) . '_';
				$adressField[ '_' . strtolower($fieldPrefix.$fieldNr) . '_' ] = method_exists( $adresse , $method ) ? $adresse->$method() : '';
			}
			
			$subject = str_replace( array_keys($adressField) , $adressField , $serialmail->getBetreff() );
			$mailtext = str_replace( array_keys($adressField) , $adressField , $serialmail->getMailtext() );
			
			$this->activeMailjob['subject'] = $subject;
			$this->activeMailjob['mailtext'] = $mailtext;
	}

	/**
	* sendMailToAdress
	*
    * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
    * @param \Mff\MffSerialmail\Domain\Model\Adressen $adresse
	* @return void
	*/
	Private function sendMailToAdress( \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail , \Mff\MffSerialmail\Domain\Model\Adressen $adresse ) {
 			// deactivate adress
 			$adresse->setAktiv( FALSE );
			$this->adressenRepository->update($adresse);
			$this->hasToPersist = true;
			
			// send mail to adress
			$this->activeMailjob['to'] = $adresse->getEmailadress();
			$this->sendWithAttatchment();
			
			// set sendt-date for adress
			$adresse->setGesendet( time() );
			$this->adressenRepository->update($adresse);

			return true;
	}
	
	/**
	 * sendWithAttatchment
	 *
	 * @return void
	 */
	Private function sendWithAttatchment( ) {
	      $mail = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
	      
	      if( is_array($this->activeMailjob['images']) ){
				$imageDir = rtrim($this->settings['baseUrl']  , '/' ) . '/';
				$embedImage = array();
				foreach( $this->activeMailjob['images'] as $dateiname => $aImageInfo ){
					$absPath = GeneralUtility::getFileAbsFileName( $aImageInfo['path'] );
					if( strpos( ' ' . strtolower($this->activeMailjob['mailtext']) , strtolower($dateiname) ) ){
						$embedImage[$dateiname] = '<img src="' . $mail->embed(\Swift_Image::fromPath($absPath)) . '" alt="' . $aImageInfo['alt'] . '" />';
					}
				}
				if( count($embedImage) ){
					$this->activeMailjob['mailtext'] = str_replace( array_keys($embedImage) , $embedImage , $this->activeMailjob['mailtext'] );
				}
	      }
	      
	      if( isset($this->activeMailjob['attachments']) && is_array($this->activeMailjob['attachments']) && count($this->activeMailjob['attachments']) ){
				foreach( $this->activeMailjob['attachments'] as $dateiname => $fullpathname){
					if( file_exists($fullpathname) && is_readable($fullpathname) ){
						$output = file_get_contents( $fullpathname );
						$attachment = \Swift_Attachment::newInstance($output, $dateiname  );
						$mail->attach($attachment);
					}
				}
	      }
	      
	      $mail->setBody( $this->activeMailjob['mailtext'] , 'text/html' );
	      $mail->setSubject( $this->activeMailjob['subject'] );
	      $mail->setFrom( $this->activeMailjob['from'] );
	      $mail->setTo( 'dani@verarbeitung.ch' ); // $this->activeMailjob['to']
	      
	      if( isset($this->activeMailjob['ReturnPath']) && !empty($this->activeMailjob['ReturnPath']) && filter_var($this->activeMailjob['ReturnPath'], FILTER_VALIDATE_EMAIL)) $mail->setReturnPath( $this->activeMailjob['ReturnPath'] );
	      if( isset($this->activeMailjob['ReplyTo']) && !empty($this->activeMailjob['ReplyTo']) && filter_var($this->activeMailjob['ReplyTo'], FILTER_VALIDATE_EMAIL)) $mail->setReplyTo( $this->activeMailjob['ReplyTo'] );
	      if( isset($this->activeMailjob['Cc']) && !empty($this->activeMailjob['Cc']) && filter_var($this->activeMailjob['Cc'], FILTER_VALIDATE_EMAIL)) $mail->setCc( $this->activeMailjob['Cc'] );
	      if( isset($this->activeMailjob['Bcc']) && !empty($this->activeMailjob['Bcc']) && filter_var($this->activeMailjob['Bcc'], FILTER_VALIDATE_EMAIL)) $mail->setBcc( $this->activeMailjob['Bcc'] );

	      $mail->send();
	      
	      return true;
	}
	
}
