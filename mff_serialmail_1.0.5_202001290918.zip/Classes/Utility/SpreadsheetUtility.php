<?php
namespace Mff\MffSerialmail\Utility;
 
	use Box\Spout\Reader\ReaderFactory;
	use Box\Spout\Writer\WriterFactory;
	use Box\Spout\Common\Type;
	
 /** 
 * Class SpreadsheetUtility
 * 
 * 
 */
 
class SpreadsheetUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property config
	 *
	 * @var array
	 */
	Public $config = array(
		'spoutFilpath' => 'typo3conf/ext/mff_contrib/Resources/Private/PHP/Spout/',
		'excelReaderFile' => 'typo3conf/ext/mff_contrib/Resources/Private/PHP/excel_reader/excel_reader27.php',
	);

	/**
	 * __construct
	 *
     * @param array $config
	 * @return void
	 */
	public function __construct( $config = array() ){
			if( count($config) ) {
				foreach( $config as $key => $var ) if( isset($this->config[$key]) ) $this->config[$key] = $var;
			}
			$this->config['excelReaderFile'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->config['excelReaderFile'] );

			$this->config['spoutFilpath'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->config['spoutFilpath'] );
			if( file_exists($this->config['spoutFilpath'].'Autoloader/autoload.php') ) require_once( $this->config['spoutFilpath'].'Autoloader/autoload.php' ); 
	}
	
	
	/**
	* arrayToSpreadSheet
	* 
	* @param array $spoutRs
	* @param string $filePathname 
	* @return void
	*/
	public function arraysToSpreadSheet( $spoutRs, $filePathname ) {
			if( !file_exists($this->config['spoutFilpath']) ) return false;
			$type = pathinfo( $filePathname , PATHINFO_EXTENSION );
			
			switch( $type ){
				case 'ods' : $writer = WriterFactory::create(Type::ODS); break;
				case 'xlsx' : $writer = WriterFactory::create(Type::XLSX); break;
				default : return false; break;
			}
			$writer->setShouldCreateNewSheetsAutomatically(false);

			$writer->openToBrowser( pathinfo( $filePathname , PATHINFO_FILENAME ).'.'. $type); // stream data directly to the browser
			
			if( !is_array($spoutRs) ) return false;
			$testTab = $spoutRs;
			$testRow = array_shift($testTab);
			if( !is_array($testRow) ) return false;
			$testField = array_shift($testRow);
			if( is_array($testField) ){
				foreach( $spoutRs as $sheet => $shtRs ){
					$writer->addRows( $shtRs ); // add multiple rows at a time
					$writer->getCurrentSheet()->setName( $sheet );
					$writer->addNewSheetAndMakeItCurrent();
				}
			}else{
				$writer->addRows( $spoutRs ); // add multiple rows at a time
				$writer->getCurrentSheet()->setName(pathinfo( $filePathname , PATHINFO_FILENAME ));
			}
			
			$writer->close();
			exit();
	}
	
	/**
	* spreasheetToArray
	* 
	* @param string $filePathName
	* @param boolean $prependHeadrow
	* @return array
	*/
	public function spreadsheetToArrays( $filePathName , $prependHeadrow = FALSE ) {
			if( !file_exists($this->config['spoutFilpath']) ) return false;

			$uploadedFileExtension = strtolower( pathinfo( $filePathName , PATHINFO_EXTENSION ) );
			switch( $uploadedFileExtension ){
				case 'ods' : $reader = ReaderFactory::create(Type::ODS); break;
				case 'xlsx' : $reader = ReaderFactory::create(Type::XLSX); break;
				case 'xls' : return $this->xlsFile2Arrays( $filePathName , $prependHeadrow ); break;
				default : return false; break;
			}
			
			$spoutRs = array();
			$reader->open($filePathName);
			foreach ($reader->getSheetIterator() as $sNr => $sheet) {
				$sheetname = urlencode( str_replace( '.csv' , '' , $sheet->getName() ) );
				foreach ($sheet->getRowIterator() as $rNr => $row) {
					if( !isset($fieldnames[$sNr]) ) {$fieldnames[$sNr] = $row; if(!$prependHeadrow) continue;}
					foreach($fieldnames[$sNr] as $fix=>$fld) $spoutRs[$sheetname][$rNr][$fld] = $row[$fix];
				}
			}
			$reader->close();
			return $spoutRs;
	}
	
	/**
	 * xlsFile2Arrays
	 * 
	 * @param string $filePathName
	 * @param boolean $prependHeadrow
	 * @return array
	 */
	public function xlsFile2Arrays( $filePathName , $prependHeadrow = FALSE ) {
	
			if( !file_exists( $this->config['excelReaderFile'] ) ) return false;
			require_once( $this->config['excelReaderFile'] );
			$data = new \Spreadsheet_Excel_Reader($filePathName);
			
			$excelReaderRs = array();
			foreach( $data->sheets as $sNr => $objSheet){
				$sheetname = urlencode( str_replace( '.csv' , '' , $data->boundsheets[$sNr]['name'] ) );
				foreach( $objSheet['cells'] as $rNr => $row){
					if( !isset($fieldnames[$sNr]) ) {// first row (titles)
						$fieldnames[$sNr] = $row;
						if( count($row) < $objSheet['numCols'] ){
							for( $emptyCols = count($row) ; $emptyCols <= $objSheet['numCols'] ; ++$emptyCols) { 
									$name = strtolower(( (($emptyCols-1)/26>=1)?chr(($emptyCols-1)/26+64):'') . chr(($emptyCols-1)%26+65));
									$fieldnames[$sNr][$emptyCols . '_' . $name] = $name; 
							}
						}
						 // default is not to insert the first row with the column-headers. But until here we need this row to get fieldnames
						if(!$prependHeadrow) continue;
					}
					foreach($fieldnames[$sNr] as $fix=>$fld) $excelReaderRs[$sheetname][$rNr][$fld] = isset($row[$fix]) ? utf8_encode($row[$fix]) : '';
				}
			}
			return $excelReaderRs;
	}
}
