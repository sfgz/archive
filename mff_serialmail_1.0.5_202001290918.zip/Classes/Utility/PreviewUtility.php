<?php
namespace Mff\MffSerialmail\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, sfgz formerly called medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
	
 /** 
 * Class PreviewUtility
 * 
 * 
 */
 
class PreviewUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property piVars
	 *
	 * @var array
	 */
	protected $piVars = NULL;

	/**
	 * Property settings
	 *
	 * @var array
	 */
	protected $settings = NULL;

	/**
	* serialmailRepository
	*
	* @var \Mff\MffSerialmail\Domain\Repository\SerialmailRepository
	*/
	protected $serialmailRepository = null;

	/**
	* activeMailjob
	*
	* @var array
	*/
	protected $activeMailjob = null;

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct(){
		date_default_timezone_set ( 'Europe/Zurich' );
		$this->timeZone = new \DateTimeZone('Europe/Zurich');
			
		$objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$typoScriptService = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
		$this->settings = $typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mffserialmail_mailer.']['settings.']);

		$storage['storagePid'] =  $fullsettings['plugin.']['tx_mffserialmail_mailer.']['persistence.']['storagePid'];
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );
		$querySettings->setRespectStoragePage( TRUE );
		
		$this->serialmailRepository = $objectManager->get('Mff\\MffSerialmail\\Domain\\Repository\\SerialmailRepository');
		$this->serialmailRepository->setDefaultQuerySettings( $querySettings );
		
		$this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
	    $this->mailUtility = GeneralUtility::makeInstance('Mff\\MffSerialmail\\Utility\\MailDaemonUtility');

	    $this->piVars = GeneralUtility::_GET( $this->settings['previewExtKey'] );
	    $bHash = GeneralUtility::_GET( 'bHash' );
	    
	    if( $this->piVars['serialmail'] && $bHash == $this->mailUtility->create_bHash( $this->piVars['serialmail'] ) ){
			$this->serialmailObject = $this->serialmailRepository->findByUid( $this->piVars['serialmail'] ); 
			$this->activeMailjob = $this->mailUtility->previewMailJobs($this->piVars['serialmail']);
		}
	}
	
	/**
	* showObjectTitle
	* 
	* @return void
	*/
	public function showObjectTitle() {
	    if( !$this->piVars['serialmail'] || !$this->serialmailObject || !$this->activeMailjob ) return 'Serialmailer: no data';
		
		if($this->serialmailObject) return ' daten.sfgz.ch | ' . $this->serialmailObject->getBetreff();
		
		return 'Serialmailer: no data';
	}
	
	/**
	* showObjectData
	* 
	* @return void
	*/
	public function showObjectData() {
		$username = $GLOBALS['TSFE']->fe_user->user['username'];
		
		// no data
	    if( !$this->piVars['serialmail'] || !$this->serialmailObject || !$this->activeMailjob ) {
			$aErrorString =  '<i>Fehler in Serialmailer/PreviewUtility/showObjectData</i> <hr /> <h5>Keine Daten!</h5>';
			if( empty($this->piVars['serialmail']) || empty($username) ){
				$aErrorString .= 'Kann (oder darf) die gesuchte Serien-Email nicht ausweisen.';
				return $aErrorString;
			}else{
				$aErrorString .=  '<p>Vielleicht wurden bereits alle Emails versendet, oder der <i>bHash</i> stimmt nicht. </p><p><a title="Versuche neu zu laden" class="black" href="'.$this->getUrl(array('action'=>'' , 'serialmail' => $this->piVars['serialmail'] )).'" style="font-weight:bold;padding:0.5em 0;" >Neu laden ...</a></p>';
				return $aErrorString;
			}
	    }
	    
		$oLoguser = $this->serialmailObject->getMailLoguser();
		$oSender = $this->serialmailObject->getMailSender();
		$clientMode = $oLoguser->getUid() != $oSender->getUid();
		
		$isAktiv = $this->serialmailObject->getAktiv();
		$iStartdatum = $this->serialmailObject->getStartdatum();
		$iFreigabedatum = $this->serialmailObject->getFreigabedatum();
		$iAntragdatum = $this->serialmailObject->getAntragdatum();
		
		$now = time();
		
		$toPersist = 0;
		if( $clientMode ){
			// clientMode: set setAktiv + setFreigabedatum to 1+1 or setFreigabedatum to 0
			$timeleftMin = $iAntragdatum ? ( ($iAntragdatum+($this->settings['clearanceTimeHowers']*3600)) - $now) / 60 : 0;
			if( isset($this->piVars['action']) ){
				if(  $this->piVars['action'] == 'go'  ){
					$iFreigabedatum = $now;
					$isAktiv = 1 ;
					$this->serialmailObject->setAktiv( $isAktiv );
					$isUnlockedOrRunning = 1 ;
				}elseif($this->piVars['action'] == 'stop' ){
					$iFreigabedatum = 0;
					$isUnlockedOrRunning = 0 ;
					$isAktiv = 0;
					if( $this->settings['clearanceTimeHowers'] ) $this->serialmailObject->setAktiv( $isAktiv );
				}
				$this->serialmailObject->setFreigabedatum( $iFreigabedatum );
				$toPersist = 1;
			}else{
				$isUnlockedOrRunning = $isAktiv && ($iFreigabedatum || ( $isAutostart && $timeleftMin < 0 ) ) ? 1 : 0 ;
			}
			// choose higher value
			$versandAb = $iStartdatum > $iFreigabedatum ? $iStartdatum : $iFreigabedatum;
		}else{
			// no clientMode: set setAktiv + setStartdatum to 1+1 or setAktiv to 0
			$isUnlockedOrRunning = $isAktiv && $iStartdatum <= $now  ? 1 : 0 ;
			if( isset($this->piVars['action']) ){
				if(  $this->piVars['action'] == 'go'  ){
					if( empty($iStartdatum) || $iStartdatum > $now ) {
							$iStartdatum = $now;
							$this->serialmailObject->setStartdatum( $iStartdatum );
					}
					$isUnlockedOrRunning = 1 ;
					$isAktiv = 1;
					$this->serialmailObject->setAktiv( $isAktiv );
					$toPersist = 1;
				}elseif($this->piVars['action'] == 'stop' ){
					$this->serialmailObject->setAktiv( 0 );
					$isUnlockedOrRunning = 0 ;
					$toPersist = 1;
					$isAktiv = 0;
				}
			}
			$versandAb = $iStartdatum;
			$timeleftMin = ( ( $versandAb - $now ) /60 );
		}
		if( $toPersist ){
			$this->serialmailRepository->update($this->serialmailObject); 
			$this->persistenceManager->persistAll();
		}
		
		$outputAction = $isUnlockedOrRunning ? 'stop' : 'go';
		
		$dateString = '';
		if( !$clientMode || $iFreigabedatum ){ // no clientMode OR cleared
					if( (!$clientMode && $outputAction == 'go') ) {
						$dateString .= '  <span class="info" > Versand nicht gestartet.</span> <br />';
						
					}elseif( (!$clientMode && $outputAction == 'stop') || ($clientMode && $iFreigabedatum) ){
						$dateString .= '  <span class="info" > '.( $versandAb > $now ? 'Versand wird automatisch gestartet ab' : 'Versand wurde gestartet' ).': '.date( 'd.m.y H:i' , $versandAb  ).'</span> <br />';
					}
					
		}elseif( $iAntragdatum && $this->settings['clearanceTimeHowers'] ){ // request is sendt (waiting for unlock) and autostart is on (trigger will start)
				if( $timeleftMin > 0 ){
					$leftMin = $timeleftMin % 60;
					$stdLeft = floor( $timeleftMin / 60 );
					$secLeft = round( ($timeleftMin - floor( $timeleftMin ) ) * 60 );
					$dateString .= '<span class="info" title="Der automatische Versand ist eingeschaltet.">';
					$dateString .= ' Benachrichigt am: ' . date( 'd.m.y H:i' , $iAntragdatum ) . ' ';
					if( $isAktiv ){
						$dateString .= '<br />Automatische Freigabe: ';
						$dateString .= '' . date( 'd.m.y H:i' , $iAntragdatum+($this->settings['clearanceTimeHowers']*3600) ) . '';
						$dateString .= ' (in ' . $stdLeft . ':' . sprintf('%02d',floor($timeleftMin) ) . ':' . sprintf('%02d',$secLeft).' Std.)';
						$dateString .= '<br /> ';
					}else{
						$dateString .= '<br /><i>Dieses Serien-Email ist nicht aktiviert, es kann aber <a class="black" href="'.$this->getUrl(array('action'=>$outputAction , 'serialmail' => $this->serialmailObject->getUid() )).'" title="Serienmail Versand starten!" ><b>hier aktiviert</b> (und gestartet)</a> werden </i>';
					}
					$dateString .= '</span>';
				}else{
					$timepastMin = $timeleftMin * (-1);
					$dateString .= '<span class="info" title="Der automatische Versand ist eingeschaltet."> ';
					$dateString .= 'Benachrichigt am: ' . date( 'd.m.y H:i' , $iAntragdatum ) . ' ';
					$dateString .= 'Freigabefrist abgelaufen vor: ';
					$dateString .= $timepastMin < 60 ? round( $timepastMin ,1 ).' Min.' : round( $timepastMin / 60  ,1 ).' Std.' ;
					$dateString .= '<br />';
					$dateString .= '</span>';
				}
		}else{
			$dateString .= '<span class="info" title="Noch kein Freigabedatum festgelegt.">';
			$dateString .= '  Wartet auf Freigabe. ';
			$dateString .= $iAntragdatum ? ' Benachrichigt am '.date("d.m.y \u\m H:i" , $iAntragdatum ).'.' : ' Noch nicht benachrichtigt. ';
			$dateString .= '<br />';
			if( $isAutostart ) $dateString .= 'Automatische Freigabe: ' . date( 'd.m.y H:i' , $iAntragdatum+($this->settings['clearanceTimeHowers']*3600) ) ;
			$dateString .= '</span>';
		}
		
		// class "send"    = black enabled  (button:stopNow)  outputAction=='stop'
		// class "send_30" = white disabled (button:startNow) outputAction=='go'
		
		$mailHead = array();
		$mailHead[] = 	'<div class="tx-mff-serialmail" id="serialmail_'.$this->serialmailObject->getUid().'" style="border:thin solid #999;margin:5px 0;"><!-- start mailHead -->';
		$mailHead[] = 	' <div style="padding:0 10px;">';
		$mailHead[] = 		'Serianmail Uid: <b>'.$this->serialmailObject->getUid().'</b><br />';
		$mailHead[] = 		'Betreff: <b>'.$this->serialmailObject->getBetreff().'</b>';
		$mailHead[] = 	' </div>';
		$mailHead[] = 	' <div class="widget" style="border:thin solid #999;border-radius:5px;margin:5px 10px;padding:5px 10px;float:left;width:auto;">';
		$mailHead[] = '<a class="'.( $outputAction=='stop'?'send':'send_30').'" href="'.$this->getUrl(array('action'=>$outputAction , 'serialmail' => $this->serialmailObject->getUid() )).'" style="padding:0.5em 0;display:block;white-space:nowrap;" >';
		$mailHead[] = ' Serienmail Versand '.( $outputAction=='stop'?( $versandAb > $now ? 'nicht starten.' : 'anhalten!' ):'starten!').'<br />';
		$mailHead[] = '</a>';
		$mailHead[] = '</div>';
		$mailHead[] = '<div style="padding:0 10px;clear:left;">' ;
		$mailHead[] = 	$dateString . '';
		$mailHead[] = '</div>';
		$mailHead[] = 	'</div><!-- end mailHead -->';
		
		$mailBody  = array();
		if( isset( $this->activeMailjob['validAdressesToDispatch'] ) && is_array( $this->activeMailjob['validAdressesToDispatch'] ) ) {
			$msgNr = 0;
			$anhangSingPlural = array( false=>'Anh&auml;nge' , true=>'Anhang' );
			$aAttachments = $this->mailUtility->attachmentUtility->getAttachments( $this->serialmailObject );
			foreach($this->activeMailjob['validAdressesToDispatch'] as $email => $adresse){
				$this->mailUtility->setAttachmentsForAdressedJob( $aAttachments , $adresse );
				$this->mailUtility->setTextesForAdressedJob( $this->serialmailObject , $adresse );
				++$msgNr;
				$mailBody[] = '<div id="msg_'.$msgNr.'" class="msgs">';
				$mailBody[] = '	<i>An:</i> <b>' . $email.'</b><br /><i>Betreff:</i> <b>' . $this->mailUtility->activeMailjob['subject'] . '</b><br />';
				$mailBody[] = '	<div class="content_box">' . $this->mailUtility->activeMailjob['mailtext'] . '</div>';
				$mailBody[] = count($this->mailUtility->activeMailjob['attachments']) ? "\t" . '<div><i>'.$anhangSingPlural[count($this->mailUtility->activeMailjob['attachments'])==1].'</i><b>: '.implode( ', ' , array_keys($this->mailUtility->activeMailjob['attachments'])) . '.</b></div>' : "\t" . '<div><i>kein Anhang</i></div>';
				$mailBody[] = '</div>' ; 
			}
		}
		
		$sOutput = array();
		$sOutput[] = '<div class="content_box"><!-- start content_box-->';
		$sOutput[] = implode( "\n" , $mailHead );
		$sOutput[] = '	<div style="border:thin solid #999;margin:5px 0;"><!-- start mail-box-->';
		$sOutput[] = "\t<div><!-- start Paginator -->\n\t" . ''.count($this->activeMailjob['validAdressesToDispatch']).' verbleibende Adressen. <b>Vorschau: </b>' . $this->jsPaginatorElement( count($this->activeMailjob['validAdressesToDispatch']) ). "\n\t</div><!-- end Paginator -->";
		$sOutput[] = '		<div style="border:2px inset #bbb;border-radius:5px;margin:5px 0 0 0;padding:5px 0 0 0;"><!-- start mailBody-->';
		$sOutput[] = "\t\t\t".implode( "\n\t\t\t" , $mailBody ) ;
		$sOutput[] = '		</div><!-- end mailBody-->';
		$sOutput[] = '		<div style="margin-top:5px;padding:0 5px;border-top:0 solid #DDD;"><!-- start signature-->'. $this->activeMailjob['signature'].'		</div><!-- end signature-->';
		$sOutput[] = '	</div><!-- end mail-box-->';
		$sOutput[] = '</div><!-- end content_box-->';
		$sOutput[] = '<span style="cursor:pointer;" onclick="anfang();">&uarr; top </span>';
		$sOutput[] = 	$username  ? '<span style="font-size:90%;"> Eingeloggt als &laquo;'. $username .'&raquo;.</span>' : '<span style="font-size:90%;">  Nicht eingeloggt &rarr; <a href="?id='.$this->settings['loginpage_uid'].'" target="_blank">Login</a>.</span>';
		
		return "\n" .implode( "\n" , $sOutput );

	}
	
	/**
	* jsPaginatorElement
	* 
	* @param integer $maxElements
	* @return void
	*/
	public function jsPaginatorElement( $maxElements = 1 ) {
			$js = '<span style="cursor:pointer;" onclick="jumpToFirst();" title="zum Anfang"> &lArr; </span>';
			$js.= '<span style="cursor:pointer;" onclick="jumpTo(\'-1\');" title="zurück"> &larr; </span>';
			$js.= '[<span id="counter" data-active="1" style="font-weight:bold"> 1</span>/' . $maxElements . ' ]';
			$js.= '<span style="cursor:pointer;" onclick="jumpTo(\'+1\');" title="vor"> &rarr; </span>';
			$js.= '<span style="cursor:pointer;" onclick="jumpToLast(\''.$maxElements.'\');" title="zum Ende"> &rArr; </span>';
			return $js ;
	}

	/**
	* setUrl
	* 
	* @param array $changingValues
	* @return void
	*/
	public function getUrl( $changingValues = array() ) {
		return $this->mailUtility->getUrlForEmailText( $changingValues['action'] , $changingValues['serialmail'] );
		$aQuery = array();
		
		// get existing values from REQUEST URL
		$splittedFullPath = explode( '?' , $_SERVER['REQUEST_URI'] );
		if( count($splittedFullPath) == 2 ){
				$queryPart = array_pop( $splittedFullPath );
				$cleanQueryPart = str_replace( '&amp;' , '&' , $queryPart );
				$splittedQuery = explode( '&' , $cleanQueryPart );
				foreach( $splittedQuery as $qrys){
					$aOpt = explode( '=' ,  $qrys);
					$aQuery[ $aOpt[0] ] = $aOpt[0] . '=' . $aOpt[1];
				}
		}
		
		// overwrite existing query-values with changingValues set for this script
		foreach($changingValues as $fld => $val) {
			// prepend the extension key to querys if not done in changingValues
			if( substr( $fld , 0 , strlen($this->settings['previewExtKey']) ) != $this->settings['previewExtKey'] && strpos( $fld , '[' ) == false ){
				if( isset($aQuery[$fld]) ) unset( $aQuery[$fld] );
				$fld = $this->settings['previewExtKey'] . '['.$fld.']';
			}
			$aQuery[$fld] = $fld . '=' . $val;
		}
		
		// rebuild url
		$host = $this->getBaseUrl( $_SERVER );
		$path = $splittedFullPath[0];
		$query = count( $aQuery ) ? '?' . implode( '&' , $aQuery ) : '';
		return $host.$path.$query;
	}
	
	private function getBaseUrl( $s ) {
		$ssl      = ( ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on' );
		$sp       = strtolower( $s['SERVER_PROTOCOL'] );
		$protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
		$port     = $s['SERVER_PORT'];
		$port     = ( ( ! $ssl && $port=='80' ) || ( $ssl && $port=='443' ) ) ? '' : ':'.$port;
		$host     = isset( $s['HTTP_HOST'] ) ? $s['HTTP_HOST'] : $s['SERVER_NAME'] . $port ;
		return $protocol . '://' . $host;
	}
	
}
