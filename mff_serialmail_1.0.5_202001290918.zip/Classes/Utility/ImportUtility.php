<?php
namespace Mff\MffSerialmail\Utility;

 /** 
 * Class ImportUtility
 *  imports adresses
 * 
 */
 
class ImportUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property fileDescription
	 *
	 * @var array
	 */
	Public $fileDescription = NULL;

	/**
	 * Property contents
	 *
	 * @var string
	 */
	Private $contents = NULL;

	/**
	 * Property analyseConf
	 *
	 * @var array
	 */
	Public $analyseConf = array(
		'delimiters' => array(
			'comma'     => ',' ,
			'semicolon' => ';' ,
			'tab'         => "\t" ,
			'pipe'         => '|' ,
			'colon'     => ':'
		),
		'linebreaks' => array(
			'rn'         => "\r\n" ,
			'n'         => "\n" ,
			'r'         => "\r" ,
			'nr'         => "\n\r"
		),
		'charsetlist' => array(
			"utf-8",
			"iso-8859-15",
			"iso-8859-1",
			"windows-1251",
			"utf-16"
		)
	);

	/**
	 * __construct constructor
	 *
	 * @param string $analyseConf 
	 * @return void
	 */
	Public function __construct( $analyseConf = array() ){
			if( !count($analyseConf) ) return;
			foreach( $analyseConf as $key => $var ) if( isset($this->analyseConf[$key]) ) $this->analyseConf[$key] = $var;
	}

	/**
	* AnalyseCsvFile
	* 
	* script analyse_file + analyse_contents from Ashley, http://php.net/manual/de/function.fgetcsv.php
	* 
	* Example Usage:
    * $Array = AnalyseCsvFile('/www/files/file.csv', 10);
    *
    * example usable parts of output (fileDescription):
    * $Array['charset']['value'] => ISO-8859-15
    * $Array['delimiter']['value'] => ,
    * $Array['linebreak']['value'] => \r\n
    * 
	* @param string $file 
	* @param integer $capture_limit_in_kb optional
	* @return array 
	*/
	Public function AnalyseCsvFile($file, $capture_limit_in_kb = 10) {
		// capture starting memory usage
		$memory_start = memory_get_peak_usage(true);
	
		// read in file
		$fh = fopen($file, 'r');
		$contents = fread($fh, ($capture_limit_in_kb * 1024)); // in KB
		fclose($fh);
		
		$output = $this->analyse_contents($contents);
		
		$output['peak_mem']['start'] = $memory_start;
		// log the limit how much of the file was sampled (in Kb)
		$output['read_kb'] = $capture_limit_in_kb;
		// capture ending memory usage
		$output['peak_mem']['end'] = memory_get_peak_usage(true);
		return $output;
	}

	/**
	* analyse_contents 
	* This is the main part of 
	* analyse_file from Ashley, http://php.net/manual/de/function.fgetcsv.php
    * 
	* @param string $contents
	* @return array 
	*/
	Private function analyse_contents( $contents ) {
		
		$output = array();
		
		// detect LINEBRAKS AND LINES
		// loop and count each line ending instance
		foreach ($this->analyseConf['linebreaks'] as $key => $value) {
			$line_result[$key] = substr_count($contents, $value);
		}
	
		// sort by largest array value
		asort($line_result);
	
		// log to output array
		$output['linebreak']['results'] = $line_result;
		$output['linebreak']['count'] = end($line_result);
		$output['linebreak']['key'] = key($line_result);
		$output['linebreak']['value'] = $this->analyseConf['linebreaks'][$output['linebreak']['key']];
		
		// lines statistic count + total length
		$lines = explode($output['linebreak']['value'], $contents);
		
		// remove last line of array, as this maybe incomplete?
		if( count($lines) > 1 ) array_pop($lines);
	
		// create a string from the legal lines
		$complete_lines = implode(' ', $lines);
	
		// log statistics to output array
		$output['lines']['count'] = count($lines);
		$output['lines']['length'] = strlen($complete_lines);
		
		// detect DELIMITER
		// loop and count each delimiter instance
		foreach ($this->analyseConf['delimiters'] as $delimiter_key => $delimiter) {
			$delimiter_result[$delimiter_key] = substr_count($complete_lines, $delimiter);
		}
	
		// sort by largest array value
		asort($delimiter_result);
	
		// log statistics to output array with largest counts as the value
		$output['delimiter']['results'] = $delimiter_result;
		$output['delimiter']['count'] = end($delimiter_result);
		$output['delimiter']['key'] = key($delimiter_result);
		$output['delimiter']['value'] = $this->analyseConf['delimiters'][$output['delimiter']['key']];

		// detect CHARSET (does not work 100% beacuse foreign chars may appear later than the test-string shows up )
		foreach ($this->analyseConf['charsetlist'] as $charset) {
			if( strtolower(mb_detect_encoding( $complete_lines , $charset , true)) == strtolower($charset) ){ // first test ok
				$sample = iconv($charset, $charset, $complete_lines);
				if (md5($sample) == md5($complete_lines)) { // second test ok
					$output['charset']['value'] =  $charset;
					break;
				}
			}
		}
		
		$this->fileDescription = array( 
				'charset'	=>	$output['charset']['value'] , 
				'delimiter'	=>	$output['delimiter']['value'] , 
				'linebreak'	=>	$output['linebreak']['value'] 
		);
		return $output;
	}

	/**
	* AnalyseCsvContent
	* this is NOT part of the original ** analyse_file ** 
	* from Ashley, http://php.net/manual/de/function.fgetcsv.php
    * 
	* @param string $contents
	* @param integer $capture_limit_in_kb optional
	* @return array 
	*/
	Public function AnalyseCsvContent( $contents , $capture_limit_in_kb = 10 ) {
		
		// catch the full content for further usage in other methods
		$this->contents = $contents;
		
		// cut test-string if longer than affored
		$testStringLength = ($capture_limit_in_kb * 1024);
		$testContents =  strlen($contents) > $testStringLength ? substr( $contents , 0 , $testStringLength ) : $contents;
		
		$output = $this->analyse_contents($testContents);
		
		// Blank as delimiter: We produce unexcpected results if blank is set as delimiter like array( 'blank' => ' ' )
		// So, if blank is the delimiter and no other delimiter is found then try following as last possibility
		if( $output['delimiter']['count'] == 0) {
			$this->analyseConf['delimiters']['blank'] = ' ';
			$output = $this->analyse_contents( $testContents );
		}
		
		// add more analyse-info: texttype and field-number of emailadress-field
		$output = $this->analyse_structure( $testContents , $output );
		if( $this->fileDescription['texttype'] == 'table' ) $output = $this->analyse_detect_emailadress( $testContents , $output );
		return $output;
	}

	/**
	* analyse_structure
	*  detects wether a string represents 
	*   - a csv-table, 
	*   - a group like in angulated emailadresses, 
	*   - or a list with single emailadresses
	*  
	*  appends the type to the information-array $output
	* 
	* Copyright hint: 
	*  This is NOT part of the original ** analyse_file ** from Ashley, http://php.net/manual/de/function.fgetcsv.php
    * 
	* @param string $contents
	* @param array $output
	* @return array 
	*/
	Private function analyse_structure( $contents , $output ) {
			
			$aTextTypes = array( 'single' =>1 , 'groups'=>2 , 'table'=>3 );
			
			$texttype = 'single';
			$reason['single'] = $output['lines']['count'] <= 1 ? 'less than 2 lines' : 'only fields with email@dresses detected';
			
			$countAngulatedValues = substr_count($contents, '<');
			if( $countAngulatedValues >= $output['lines']['count'] ){
				// One or more amount of <angulated-v@lues> per line
				// Firstname Lastname <email@adress.org> ; Nextfirstname Secondname <second@name.net> ; ...
				$texttype = 'groups';
				$reason['groups'] = 'angular quotes detected';
				
			}elseif( $output['lines']['count'] >= 1 ){
				// to find out if the content is a table we must count the amount of fields per row.
				$splitByLb = explode( $output['linebreak']['value'] , $contents );
				if( count($splitByLb) > 1 ) {
					// if more than 1 row it could be a table
					// remove last line of array, as this maybe incomplete?
					array_pop($splitByLb);
					foreach($splitByLb as $rIx => $row ){
						// remove trailing delimiter
						$lastDelimiterCleanedRow = rtrim( trim( $row ) , $output['delimiter']['value'] ) ;
						if( empty($lastDelimiterCleanedRow) ) continue;
						$fieldsPerRow = substr_count( $lastDelimiterCleanedRow, $output['delimiter']['value'] ) +1;// or +0 if trailing delimiter would not have been removed above
						if( !isset( $output['texttype']['fieldcount'][  $fieldsPerRow ] ) ) $output['texttype']['fieldcount'][ $fieldsPerRow ] = 0;
						$output['texttype']['fieldcount'][  $fieldsPerRow ] += 1;
						// if in every field is a emailadress then it is not a table
						$countEmailValues = substr_count($row, '@');
						if( $fieldsPerRow-1 <= $countEmailValues ){
							// detect other text than email: a@b ; c@d ; e@f.gh
							$aRow = explode( $output['delimiter']['value'] , $lastDelimiterCleanedRow );
							foreach( $aRow as $field ){
								$aElementsInFld = explode( ' ' , trim($field) ); 
								if( count($aElementsInFld) >1 && substr_count($field, '@') ){
									$output['texttype']['typecount']['groups'] += (1/$fieldsPerRow);
									$reason['groups'] = 'field with email@dress AND other values detected';
								}elseif(substr_count($field, '@')){
									$output['texttype']['typecount']['single'] += (1/$fieldsPerRow);
									$reason['single'] = 'field with single email@dress detected';
								}else{
									$output['texttype']['typecount']['table'] += (1/$fieldsPerRow)+0.1;
									$reason['table'] = 'less email@dresses than fields per row';
								}
							}
						}else{
							$reason['table'] = 'less email@dresses than fields per row';
							$output['texttype']['typecount']['table'] += 1;
						}
						// if in every field is a emailadress AND more stuff then it is a group
					}
					arsort($output['texttype']['fieldcount']);
					arsort($output['texttype']['typecount']);
					$texttype = key($output['texttype']['typecount']);
					if( $output['texttype']['typecount']['groups'] && 'table' != $texttype ) $texttype = 'groups';
				}
			}
			$output['texttype']['value'] = $aTextTypes[$texttype];
			$output['texttype']['key'] = $texttype;
			$output['texttype']['reason'] = $reason[$texttype];
			
			$this->fileDescription['texttype'] = $output['texttype']['key'];
			return $output;
	}

	/**
	* analyse_detect_emailadress
    * 
	* @param string $contents
	* @param array $output
	* @return array 
	*/
	Private function analyse_detect_emailadress( $contents , $output = array() ) {
				$db = explode( $this->fileDescription['linebreak'] , $this->remove_angular_braces($contents) );
				foreach( $db as $ix => $row) {
					$aLine = str_getcsv( $row , $this->fileDescription['delimiter'] );
					foreach( $aLine as $fldNr => $cell ) {
						$hasEmail[ $fldNr ] += filter_var($cell,FILTER_VALIDATE_EMAIL) == false ? 0 : 1;
					}
				}
				arsort($hasEmail);
				$keys = array_keys($hasEmail);
				$this->fileDescription['emailfield'] = array_shift($keys);;
// 				$output['emailfield']['key'] = array_shift($keys);
// 				$output['emailfield']['fieldcount'] = $hasEmail;
// 				$this->fileDescription['emailfield'] = $output['emailfield']['key'];
			return $output;
	}

	/**
	* GetSpreadsheetsAsArray
    * 
	* @param string $file
	* @param integer $capture_limit_in_kb optional
	* @return array 
	*/
	Public function GetSpreadsheetsAsArray( $file , $capture_limit_in_kb = 10  ) {
			$spreadsheetUtility = new \Mff\MffSerialmail\Utility\SpreadsheetUtility();
			$db = $spreadsheetUtility->spreadsheetToArrays($file);
			// detect cell with emailadress
			$capture_limit = $capture_limit_in_kb * 1024;
			$this->fileDescription['linebreak'] = "\n";
			$this->fileDescription['delimiter'] = ';';
			$resultDB = array();
			$key = 0;
			foreach( $db as $sheetName => $aTable ){
				$rawDB = array();
				$analyseString = '';
				foreach( $aTable as $ix => $aRow ) {
					// the row has assotiative fieldnames, we need integer values.
					// Therefore implode the array to a string and explode it again
					$firstCell = array_shift($aRow);
					if(!$firstCell) continue;;
					$strRow = $firstCell . $this->fileDescription['delimiter'] . implode( $this->fileDescription['delimiter'] , $aRow );
					$rawDB[] = explode( $this->fileDescription['delimiter'] , $strRow);
					// append row to analyseString until its length reached capture_limit_in_kb
					if( strlen($analyseString) < $capture_limit ) $analyseString .= $strRow . $this->fileDescription['linebreak'];
				}
				// detect fieldNumber of field with emailadress
				$this->analyse_detect_emailadress( $analyseString );
				// rebuild array with new structure: first filed emailadress
				foreach( $rawDB as $ix => $aLine ) {
					// if no emailadress detected then skip line
					$cln = $this->remove_angular_braces($aLine[ $this->fileDescription['emailfield'] ]);
					if( filter_var($cln,FILTER_VALIDATE_EMAIL) == false ) continue;
					$key += 1;
					// insert the emailadress in first field of new line
					$resultDB[$key][] = $cln;
					// remove emailadress from array and copy array to new line
					unset($aLine[ $this->fileDescription['emailfield'] ]);
					$resultDB[$key] = array_merge( $resultDB[$key] , $aLine );
				}
			}
			return $resultDB;
	}

	/**
	* GetAnalysedFileAsArray
    * 
	* @param string $file
	* @param integer $capture_limit_in_kb optional
	* @return array 
	*/
	Public function GetAnalysedFileAsArray( $file , $capture_limit_in_kb = 10 ) {
				
			$uploadedFileExtension = strtolower( pathinfo( $file , PATHINFO_EXTENSION ) );
			if( $uploadedFileExtension == 'xls' || $uploadedFileExtension == 'xlsx' || $uploadedFileExtension == 'ods' ){
				return $this->GetSpreadsheetsAsArray( $file , $capture_limit_in_kb );
			}
			
			// read the whole file
			$fh = fopen($file, 'r');
			$contents = fread($fh, filesize($file));
			fclose($fh);
			
			return $this->GetAnalysedContentsAsArray( $contents , $capture_limit_in_kb);
	}

	/**
	* GetAnalysedContentsAsArray
    * 
	* @param string $contents
	* @param integer $capture_limit_in_kb optional
	* @return array 
	*/
	Public function GetAnalysedContentsAsArray( $contents , $capture_limit_in_kb = 10 ) {
			$this->AnalyseCsvContent( $contents , $capture_limit_in_kb );
			return $this->getContentsAsArray();
	}

	/**
	* getContentsAsArray
    * 
	* @return array 
	*/
	Private function getContentsAsArray() {
			$contents = (mb_detect_encoding($this->contents) != 'UTF-8') ? utf8_encode($this->contents) : $this->contents; 
			$db = explode( $this->fileDescription['linebreak'] ,  $contents  );
			// table with emailadresses
			if( $this->fileDescription['texttype'] == 'table' ){
				foreach( $db as $ix => $row) {
					$aLine = str_getcsv( $row , $this->fileDescription['delimiter'] );
					$key = $ix+1;
					// if no emailadress detected then skip line
					$cln = $this->remove_angular_braces($aLine[ $this->fileDescription['emailfield'] ]);
					if( filter_var($cln,FILTER_VALIDATE_EMAIL) == false ) continue;
					// insert the emailadress in first field of new line
					$newLine[$key][] = $cln;
					// remove emailadress from array and copy array to new line
					unset($aLine[ $this->fileDescription['emailfield'] ]);
					$newLine[$key] = array_merge( $newLine[$key] , $aLine );
				}
				return $this->remove_empty_columns( $newLine );
			}
			
			// groups or 'single' emailadress
			foreach( $db as $ix => $row) {
				$aLine = explode( $this->fileDescription['delimiter'] , $row );
				foreach( $aLine as $fldNr => $cellvalue) {
					$key = ($ix+1) . '.' . ($fldNr+1);
					$aCell = explode( ' ' , str_replace('"','',$cellvalue) );
					$assemble = array();
					foreach( $aCell as $x => $cellFracture ) $assemble[FALSE != filter_var($this->remove_angular_braces($cellFracture), FILTER_VALIDATE_EMAIL)][] = $cellFracture;
// 					foreach( $aCell as $x => $cellFracture ) $assemble[ strpos( ' ' . $cellFracture,'@') > 0 ][] = $cellFracture;
					if( !isset($assemble[true][0]) ) continue;
					$newLine[$key][] = $this->remove_angular_braces( $assemble[true][0] );
					if(isset($assemble[false]) ) $newLine[$key][] = $this->remove_angular_braces( implode( ' ' , $assemble[false] ) );
				}
			}
			return $this->remove_empty_columns( $newLine );
	}

	/**
	* remove_angular_braces
    * 
	* @param string $fieldcontent 
	* @return string 
	*/
	Private function remove_angular_braces($fieldcontent) {
			return trim( str_replace( '>' , '' , str_replace( '<' , '' , str_replace( '"' , '' , $fieldcontent ) ) ) );
	}

	/**
	* remove_empty_columns
    * 
	* @param array $table
	* @return array 
	*/
	Private function remove_empty_columns( $table ) {
			// detect not-empty (valid) and empty cells
			if( !count($table) ) return $table;
			foreach( $table as $ix => $row ){
				foreach( $row as $fld => $cnt ){
					$validCell[$fld] += trim($cnt) == '' ? 0 : 1;
				}
			}
			// remove valid cells from list
			foreach( $validCell as $fld => $amount ){
				if( $amount ) unset($validCell[$fld]);
			}
			// if there are no invalid cells then return input-table
			if( !count($validCell) ) return $table;
			
			// remove invalid cells and sort field-index by field-order
			$sortTable = array();
			foreach( $table as $ix => $row ){
				// remove invalid cells
				foreach( array_keys($validCell) as $fld ){
					unset($table[$ix][$fld]);
				}
				// reset field-index
				foreach( $table[$ix] as $fld => $cnt ){
					$sortTable[$ix][] = $cnt;
				}
			}
			return $sortTable;
	}
	
}
