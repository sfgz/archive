<?php
namespace Mff\MffSerialmail\Utility;

 /** 
 * Class AttachmentUtility
 * 
 * 
 */
 
class AttachmentUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * serialmailRepository
     *
     * @var \Mff\MffSerialmail\Domain\Repository\SerialmailRepository
     * @inject
     */
    protected $serialmailRepository = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

    /**
     * attachmentFolder
     *
     * @var string
     */
    Public $attachmentFolder = '/uploads/tx_mffserialmail/attachments/';

    /**
     * adressesFolder
     *
     * @var string
     */
    Public $adressesFolder = '/uploads/tx_mffserialmail/adresses/';

    /**
     * pluginKey
     *
     * @var string
     */
    protected $pluginKey = 'tx_mffserialmail_mailer';

    /**
     * attachments
     *
     * @var array
     */
    protected $attachments = NULL;

    /**
     * fileFieldname
     *
     * @var string
     */
    protected $fileFieldname = 'dateiname';

	/**
	 * construct
	 *
     * @param array $conf optional
	 * @return void
	 */
	public function __construct( $conf = array() ){
	
		if( isset($conf['uploadFolder']) && !empty($conf['uploadFolder']) ) $this->attachmentFolder = $this->$conf['uploadFolder'];
		if( isset($conf['pluginKey']) && !empty($conf['pluginKey']) ) $this->pluginKey = $conf['pluginKey'];
		if( isset($conf['fileFieldname']) && !empty($conf['fileFieldname']) ) $this->fileFieldname = $conf['fileFieldname'];
	
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		$this->serialmailRepository = $objectManager->get('Mff\\MffSerialmail\\Domain\\Repository\\SerialmailRepository');
	    $this->serialmailRepository->setDefaultQuerySettings($querySettings);
	    
	    $this->attachmentFolder = rtrim(PATH_site, '/') . $this->attachmentFolder ;
	}
	
    /**
     * getAttachments
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @return void
     */
    public function getAttachments( \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail ) {
		$mailUid = $serialmail->getUid();
		$dirinfo = $this->getFileList( $mailUid );
		$fileInfo = json_decode( $serialmail->getDateien() , TRUE );
		$outArr = array();
		if( count($dirinfo) ){
			foreach($dirinfo as $fullFilename => $aFile ){
					$outArr[] = array(
						'uid' => $aFile['shortfilename'] . '_' . $aFile['extension'] , 
						'restriction' => ( isset($fileInfo[$fullFilename]) ? $fileInfo[$fullFilename] : 0 ) , 
						'path' => $this->attachmentFolder . $mailUid.'/'.$fullFilename , 
						'filename' => $fullFilename , 
						'size' => $aFile['size'], 
						'extension' => $aFile['extension']
					);
			}
		}
		return $outArr;
    }

	/**
	 * updateAttachments
	 * upload file, 
	 * read attachment-field, read directory, 
	 * compare and adjust attachment-field, 
	 * write  attachment-field 
	 * persist
	 * and returns the filename of uploaded file - if exists
	 *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @param array $aRestricitons
	 * @return string
	 */
	public function updateAttachments( \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail , $aRestricitons ) {
			// upload a file if there is one
			$uploadFile = $this->uploadFile( $serialmail->getUid() );
			
			// get the attachments from existing files
			$aAttachmentsRestrictions = $this->getAttachmentsRestriction( $serialmail );
			
			// merge with incoming values
			if( count($aAttachmentsRestrictions) && count($aRestricitons) ) {
				foreach( array_keys($aAttachmentsRestrictions) as $ix ) {
					if( isset($aRestricitons[$ix]) ) $aAttachmentsRestrictions[ $ix ] = $aRestricitons[$ix];
				}
			}
			
			// update attachment-field
			$this->setAttachmentsRestriction( $serialmail , $aAttachmentsRestrictions );
			
			// return uploaded file if exists
			return !empty($uploadFile) ? basename( $uploadFile ) : false;
    }

	/**
	 * deleteAttachment
	 *
	 * @param string $subDir
	 * @param string $filename
	 * @return string
	 */
	Public function deleteAttachment( $subDir , $filename ) {
	
		// make shure we dived in the subdirectory and the filename is not empty or /
		$subDirectory = trim( $subDir , '/' ) . '/';
		if( $subDirectory == '/' ) return false;
		$filename = trim( $filename , '/' ) ;
		if( empty($filename) ) return false;
		
		// delete the file
		$uploadDir =  $this->attachmentFolder . $subDirectory;
		if( file_exists( $uploadDir . $filename ) ) @unlink( $uploadDir . $filename );
		// get restrictions of existing files
		$objSerialmail = $this->serialmailRepository->findByUid( trim( $subDir , '/' ) );
		$fileInfo = $this->getAttachmentsRestriction( $objSerialmail );
		
		// delete directory if its empty now
		if( !count($fileInfo) ) @rmdir( $uploadDir );
		
		// update attachment-field
		$this->setAttachmentsRestriction( $objSerialmail , $fileInfo );
		
	}

	/**
	 * deleteUploadFolders
	 *
	 * @param string $subDir
	 * @return string
	 */
	Public function deleteUploadFolders( $subDir ) {
		$subDirectory = trim( $subDir , '/' ) . '/';
		if( $subDirectory == '/' ) return false;
		
		$attachmentsDir =  $this->attachmentFolder . $subDirectory;
		$this->clearFolder( $attachmentsDir );
		
		$adressesDir =  $this->adressesFolder . $subDirectory;
		$this->clearFolder( $adressesDir );
    }

	/**
	 * clearFolder
	 *
	 * @param string $uploadDir
	 * @return void
	 */
	Protected function clearFolder( $uploadDir ) {
		if( !file_exists( $uploadDir ) || !is_dir( $uploadDir ) ) return false;
		$d = dir($uploadDir);
		while ( false !== ( $fullFilename = $d->read() ) ) {
			if( $fullFilename === '.' || $fullFilename === '..' ) continue;
			@unlink( $uploadDir . $fullFilename );
		}
		$d->close();
		@rmdir( $uploadDir );
    }

	/**
	 * getAttachmentsRestriction
	 * returns an array with all existing files and its attachments
	 *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
	 * @return array
	 */
	Private function getAttachmentsRestriction( $serialmail ) {
		// get existing files from folder
		$filesInDir = $this->getFileList( $serialmail->getUid() );
		// get the attachments from field 'dateien'
		$fileInfo = json_decode( $serialmail->getDateien() , TRUE );
		// set attachments for existing files
		$aAttachmentsRestrictions = array();
		if( count($filesInDir) ){
			foreach($filesInDir as $fullFilename => $aFile ){
					$aAttachmentsRestrictions[$fullFilename] = isset($fileInfo[$fullFilename]) ? $fileInfo[$fullFilename] : 0 ;
			}
		}
		// return existing files with restrictions as attachments
		return $aAttachmentsRestrictions;
    }

    /**
     * setAttachmentsRestriction
     *
     * @param \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail
     * @param array $aRestricitons
     * @return void
     */
    Private function setAttachmentsRestriction( \Mff\MffSerialmail\Domain\Model\Serialmail $serialmail , $aRestricitons ) {
		$serialmail->setDateien( json_encode( $aRestricitons ) );
		$this->serialmailRepository->update($serialmail);
		$this->persistenceManager->persistAll();
    }

	/**
	 * uploadFile
	 *
	 * @param string $subDir
	 * @return string
	 */
	Public function uploadFile( $subDir ) {
		$subDirectory = trim( $subDir , '/' ) . '/';
		if( $subDirectory == '/' ) return false;
		if ($_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname]) {
			$uploadDir =  $this->attachmentFolder . $subDirectory;
			// if folder dont exists then make directory. Writable for all (0777) , Recursive if parent folder not exist (TRUE) 
			if( !file_exists($uploadDir) ) @mkdir( $uploadDir ,  0777, TRUE );
			// UPLOAD
			$fileName = $_FILES[$this->pluginKey]['name'][$this->fileFieldname];
			if( file_exists( $uploadDir . $fileName ) ) @unlink( $uploadDir . $fileName );
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$this->pluginKey]['tmp_name'][$this->fileFieldname] , $uploadDir . $fileName );
			return $uploadDir . $fileName;
		}
		return false;
	}

	/**
	 * helper getFileList
	 * create a list of files
	 *
	 * @param string $subDir
	 * @return array 
	 */
	Private function getFileList( $subDir ) {
		$filelist = array();
		$subDirectory = trim( $subDir , '/' ) . '/';
		if( $subDirectory == '/' ) return $filelist;
		$uploadDir = $this->attachmentFolder . $subDirectory;
		if( !file_exists( $uploadDir ) || !is_dir( $uploadDir ) ) return $filelist;
		$d = dir($uploadDir);
		$fileSizeSum = 0;
		while ( false !== ( $fullFilename = $d->read() ) ) {
			if( $fullFilename === '.' || $fullFilename === '..' ) continue;
			$pathFilename = $uploadDir . $fullFilename;
			$fileSize = filesize($pathFilename);
			$filelist[$fullFilename]['filename'] = $fullFilename;
			$filelist[$fullFilename]['extension'] = pathinfo( $fullFilename , PATHINFO_EXTENSION );
			$filelist[$fullFilename]['size'] = round( $fileSize / 1024, 3 );
			$filelist[$fullFilename]['time'] = filemtime( $pathFilename );
			$filelist[$fullFilename]['shortfilename'] = pathinfo( $fullFilename , PATHINFO_FILENAME );
			$fileSizeSum += $fileSize;
		}
		$d->close();
		ksort($filelist);
		return $filelist;
	}
	
}
