# customsubcategory=rendering=Display
# customsubcategory=attachment=Attachment behavior
# customsubcategory=sender=Host mode
# customsubcategory=persistence=Persistence

plugin.tx_mffserialmail_mailer {
  view {
    # cat=plugin.tx_mffserialmail_mailer/file; type=string; label=Path to template root (FE)
    templateRootPaths.10 = EXT:mff_serialmail/Resources/Private/Templates/
    # cat=plugin.tx_mffserialmail_mailer/file; type=string; label=Path to template partials (FE)
    partialRootPaths.10 = EXT:mffdesign/Resources/Private/Partials/
	# cat=plugin.tx_mffserialmail_mailer/file; type=string; label=Design template partials (FE)
	partialRootPaths.20 = EXT:mffdb/Resources/Private/Partials/
    # cat=plugin.tx_mffserialmail_mailer/file; type=string; label=Path to template layouts (FE)
    layoutRootPaths.10 = EXT:mff_serialmail/Resources/Private/Layouts/
  }
  persistence {
    # cat=plugin.tx_mffserialmail_mailer/persistence; type=string; label=Default storage PID
    storagePid =
  }
  settings {
		# cat=plugin.tx_mffserialmail_mailer/rendering/lists; type=options[5,10,20,30,40,50,80,100]; label=Lines per page:Amount of lines displayed in paging-lists.
		linesPerPage = 5
		# cat=plugin.tx_mffserialmail_mailer/rendering/forms; type=integer; label=Maximal checkboxes:Maximum amount of checkboxes per form (deleting adresses works only until 1'000).
		checkboxesPerForm = 1000
		# cat=plugin.tx_mffserialmail_mailer/rendering/preview; type=integer; label=Lines in import-preview:Amount of lines displayed in preview-lists.
		linesInPreview = 1000
		# cat=plugin.tx_mffserialmail_mailer/attachment/restriction; type=options[none,notEmpty,equalsFilename]; label=Attachment restricitons:Restrict attachment depending on a specified field-content.
		attachmentFieldRestriction = notEmpty
		# cat=plugin.tx_mffserialmail_mailer/sender/client/1; type=boolean; label=enable clientmode, Mandantenmodus:Allows changing sender-adress. Ermoeglicht das Aendern der Absenderadresse.
		clientmode = true
		# cat=plugin.tx_mffserialmail_mailer/sender/client/2; type=integer; label=Clearance time in howers:Used when sender and editor are not the same, time for sender to react.
		clearanceTimeHowers = 1
  }
}
