plugin.tx_mffserialmail_mailer = USER_INT
plugin.tx_mffserialmail_mailer {
  view {
    templateRootPaths.0 = EXT:mff_serialmail/Resources/Private/Templates/
    templateRootPaths.1 = {$plugin.tx_mffserialmail_mailer.view.templateRootPaths.10}
    partialRootPaths.10 = EXT:mff_serialmail/Resources/Private/Partials/
    partialRootPaths.11 = {$plugin.tx_mffserialmail_mailer.view.partialRootPaths.10}
    partialRootPaths.12 = {$plugin.tx_mffserialmail_mailer.view.partialRootPaths.20}
    layoutRootPaths.0 = EXT:mff_serialmail/Resources/Private/Layouts/
    layoutRootPaths.1 = {$plugin.tx_mffserialmail_mailer.view.layoutRootPaths.10}
  }
  persistence {
    storagePid = {$plugin.tx_mffserialmail_mailer.persistence.storagePid}
  }
  settings {
		loginpage_uid = {$plugin.mffdesign.settings.loginpage_uid}
		pluginPrefix = tx_mffserialmail_mailer
		previewExtKey = mffserialmail
		clearanceTimeSecondsBetweenUnlockRequests = 120
		linesInPreview = {$plugin.tx_mffserialmail_mailer.settings.linesInPreview}
		linesPerPage = {$plugin.tx_mffserialmail_mailer.settings.linesPerPage}
		checkboxesPerForm = {$plugin.tx_mffserialmail_mailer.settings.checkboxesPerForm}
		#  [ none | notEmpty | equalsFilename  ]
		attachmentFieldRestriction = {$plugin.tx_mffserialmail_mailer.settings.attachmentFieldRestriction}
		clearanceTimeHowers = {$plugin.tx_mffserialmail_mailer.settings.clearanceTimeHowers}
		imagesToReplaceInMails.1.path = typo3conf/ext/mffdesign/Resources/Public/images/logo/sfgz_sw_xxs.png
		imagesToReplaceInMails.1.width = 250
		imagesToReplaceInMails.1.height = 45
		imagesToReplaceInMails.1.alt = Schule für Gestaltung Zürich
		imagesToReplaceInMails.1.url = http://www.sfgz.ch
		clientmode = {$plugin.tx_mffserialmail_mailer.settings.clientmode}
		imagesToReplaceInMails.2.path = typo3conf/ext/mffdesign/Resources/Public/images/logo/sfgz_logo_weiss.png
		imagesToReplaceInMails.2.width = 250
		imagesToReplaceInMails.2.height = 45
		imagesToReplaceInMails.2.alt = Schule für Gestaltung Zürich
		imagesToReplaceInMails.2.url = http://www.sfgz.ch
		imagesToReplaceInMails.3.path = typo3conf/ext/mffdesign/Resources/Public/images/logo/sfgz_logo_transparent.png
		imagesToReplaceInMails.3.width = 250
		imagesToReplaceInMails.3.height = 45
		imagesToReplaceInMails.3.alt = Schule für Gestaltung Zürich
		imagesToReplaceInMails.3.url = http://www.sfgz.ch
		signatureLogo < plugin.tx_mffserialmail_mailer.settings.imagesToReplaceInMails.1
  }
}

json_view = PAGE
json_view {
  config {
    disableAllHeaderCode = 1
    debug = 0
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1489891402
  10 < tt_content.list.20.mffserialmail_mailer
}

preview = PAGE
preview {
	headerData.1522 = COA_INT
	headerData.1522 {
		wrap = <title>|</title>
			10 = USER_INT
			10 {
				userFunc = Mff\MffSerialmail\Utility\PreviewUtility->showObjectTitle
			}
	}
	shortcutIcon = typo3conf/ext/mff_serialmail/Resources/Public/Icons/serialmail.ico
	config {
		debug = 0
		no_cache = 1
	}
	typeNum = 1522010450
	5 = COA_INT
	5.wrap = <div id="container">|</div>
	
	5.10 = COA_INT
	5.10.wrap (
		<div id="container_header" style="width:65%;text-align:left;padding-bottom:1px;">
			<div id="header_top" style="padding-bottom:5px;">
				<div id="header_top_left" style="text-align:left;">
				| <h1>Serienweise Emails versenden</h1>
				</div>
			</div>
		</div><!-- /container_header -->
	)
	5.10.10 = IMAGE
	5.10.10 {
		file =typo3conf/ext/mffdesign/Resources/Public/images/logo.svg
		params = alt="sfgz-logo" style="width:auto;vertical-align:middle;margin-right:5px;"
	}
	
	5.20 = COA_INT
	5.20.wrap (
		<div id="container_content" style="width:65%;text-align:left;">
			<div id="content">
				<div id="content_main" style="padding-top:5px;">
				|
				</div>
			</div>
		</div><!-- /container_content -->
	)
	5.20.10 = USER_INT
	5.20.10 {
		userFunc = Mff\MffSerialmail\Utility\PreviewUtility->showObjectData
	}
   
	includeCSS.cssfile1 = typo3conf/ext/mffdesign/Resources/Public/css/general.css
	includeCSS.cssfile3 = typo3conf/ext/mffdesign/Resources/Public/css/decor.css
	includeCSS.cssfile2 = typo3conf/ext/mffdesign/Resources/Public/css/print.css
	includeCSS.cssfile2.media = print
	
	includeJS.jquery_min = https://code.jquery.com/jquery.min.js
	includeJS.jquery_uimin = https://code.jquery.com/ui/1.11.4/jquery-ui.min.js
	includeJS.jquery_shiftcheckbox = typo3conf/ext/mffdesign/Resources/Public/script/gistfile1.js
	includeJS.mff_helpers = typo3conf/ext/mffdesign/Resources/Public/script/mff_helpers.js
	includeJS.sfgz_responsive = typo3conf/ext/mffdesign/Resources/Public/script/sfgz_responsive.js
	includeJS.serialmail_preview = typo3conf/ext/mff_serialmail/Resources/Public/Script/serialmail.js
}
	
plugin.tx_mffserialmail_mailer._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .tx-mff-serialmail table {
        border-collapse:collapse;
        border-spacing:1px;
    }

    .tx-mff-serialmail table th {
        font-weight:bold;
    }

    .tx-mff-serialmail table td {
        vertical-align:top;
    }

    .tx-mff-serialmail .typo3-messages  {
        position:fixed;
        right:10px;
        bottom:10px;
    }
    .typo3-messages .message-error {
        color:red;
    }
    .no-typo3-messages .alert-error {
        color: red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
    .typo3-messages .alert-danger {
        color:#A00;
    }
    .typo3-messages .alert-error {
        color:red;
    }
    .typo3-messages .alert-success {
        color:green;
    }
    
    .tx-mff-serialmail div.table H3 {font-size:10.5pt;padding:3px 5px;margin:}
    
    div.table { 
      display: table; 
      border-collapse:collapse; 
      margin:5px 0; 
      background:#fff;
    }
    
    div.tr { 
      display:table-row; 
    }
    
    div.td { 
      display:table-cell; 
      border:thin solid #DDD; 
      border-bottom:1px solid #B0B0B0; 
      border-left:1px solid #BFBFBF; 
      padding:5px 8px; 
      vertical-align:top;
    }
    
    div.border_red { 
      border:2px solid #A00; 
      padding:5px; 
    }
    
    TABLE.tx_mffserialmail.tx_mffdb TR.selected TD {font-weight:normal;font-style:italic;}
    
    .tinytext[type=text] {width:4em;}
    
    .timetext[type=text] {width:4.5em;}
    
    .datetext[type=text] {width:8em;}
    
    .largetext[type=text] {width:24em;}
    
    .hugetext[type=text] {width:32em;}
    
	.fileUpload {
		position: relative;
		overflow: hidden;
		margin: 0px;
	}
	.fileUpload label { cursor: pointer; }
	.fileUpload input.upload {
		position: absolute;
		top: 0;
		right: 0;
		margin: 0;
		padding: 0;
		cursor: pointer;
		font-size: 20px;
		opacity: 0;
		filter: alpha(opacity=0);
	}   
	table.tx_mffserialmail.tablesorter.tx_mffdb TD {white-space:nowrap;}
	#uploadFile {color:#000;}
	.tx-mff-serialmail .widget { }
	.tx-mff-serialmail .border-bottom { border-bottom:thin solid #DDD; }
	.tx-mff-serialmail .widget:hover { box-shadow:0 0 10px #00BDFF; border-radius:4px;}
	.msgs {display:none;padding:5px;}
	.msgs DIV {padding:0;margin:0;}
	.msgs .content_box {padding:5px;margin:5px 5px;}
)
