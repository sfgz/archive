<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen',
        'label' => 'emailadress',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'aktiv,gesendet,emailadress,feld1,feld2,feld3,feld4,feld5',
        'iconfile' => 'EXT:mff_serialmail/Resources/Public/Icons/tx_mffserialmail_domain_model_adressen.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'aktiv, gesendet, emailadress, feld1, feld2, feld3, feld4, feld5',
    ],
    'types' => [
		'1' => ['showitem' => 'aktiv, gesendet, emailadress, feld1, feld2, feld3, feld4, feld5'],
    ],
    'columns' => [
        'aktiv' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.aktiv',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 1
			]
	    ],
	    'gesendet' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.gesendet',
	        'config' => [
			    'type' => 'input',
			    'size' => 13,
			    'eval' => 'datetime'
			]
	    ],
	    'emailadress' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.emailadress',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
			],
	    ],
	    'feld1' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.feld1',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'feld2' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.feld2',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'feld3' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.feld3',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'feld4' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.feld4',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'feld5' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_adressen.feld5',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'serialmail' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
