<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail',
        'label' => 'betreff',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'aktiv,startdatum,antragdatum,freigabedatum,betreff,mailtext,dateien,mail_loguser,mail_sender,mail_adr',
        'iconfile' => 'EXT:mff_serialmail/Resources/Public/Icons/tx_mffserialmail_domain_model_serialmail.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'aktiv, startdatum, antragdatum,freigabedatum, betreff, mailtext, dateien, mail_loguser, mail_sender, mail_adr',
    ],
    'types' => [
		'1' => ['showitem' => 'aktiv, startdatum, antragdatum,freigabedatum, betreff, mailtext, dateien, mail_loguser, mail_sender, mail_adr'],
    ],
    'columns' => [
        'aktiv' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.aktiv',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	    ],
	    'startdatum' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.startdatum',
	        'config' => [
			    'type' => 'input',
			    'size' => 13,
			    'eval' => 'datetime'
			]
	    ],
	    'antragdatum' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.antragdatum',
	        'config' => [
			    'type' => 'input',
			    'size' => 13,
			    'eval' => 'datetime'
			]
	    ],
	    'freigabedatum' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.freigabedatum',
	        'config' => [
			    'type' => 'input',
			    'size' => 13,
			    'eval' => 'datetime'
			]
	    ],
	    'betreff' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.betreff',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
			],
	    ],
	    'mailtext' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.mailtext',
	        'config' => [
			    'type' => 'text',
			    'cols' => 40,
			    'rows' => 15,
			    'eval' => 'trim,required',
			],
	        'defaultExtras' => 'richtext:rte_transform[mode=ts_css]'
	    ],
	    'dateien' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.dateien',
	        'config' => [
			    'type' => 'text',
			    'cols' => 40,
			    'rows' => 5,
			    'eval' => 'trim,required',
			],
	    ],
	    'mail_loguser' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.mail_loguser',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'foreign_table' => 'fe_users',
			    'minitems' => 0,
			    'maxitems' => 1,
			],
	    ],
	    'mail_sender' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.mail_sender',
	        'config' => [
			    'type' => 'select',
			    'renderType' => 'selectSingle',
			    'foreign_table' => 'fe_users',
			    'minitems' => 0,
			    'maxitems' => 1,
			],
	    ],
	    'mail_adr' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mffserialmail_domain_model_serialmail.mail_adr',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_mffserialmail_domain_model_adressen',
			    'foreign_field' => 'serialmail',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 1,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
    ],
];
