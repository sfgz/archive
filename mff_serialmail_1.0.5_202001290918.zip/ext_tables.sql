#
# Table structure for table 'tx_mffserialmail_domain_model_serialmail'
#
CREATE TABLE tx_mffserialmail_domain_model_serialmail (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	aktiv tinyint(1) unsigned DEFAULT '0' NOT NULL,
	startdatum int(11) DEFAULT '0' NOT NULL,
	antragdatum int(11) DEFAULT '0' NOT NULL,
	freigabedatum int(11) DEFAULT '0' NOT NULL,
	betreff varchar(255) DEFAULT '' NOT NULL,
	mailtext text NOT NULL,
	dateien text NOT NULL,
	mail_loguser int(11) unsigned DEFAULT '0',
	mail_sender int(11) unsigned DEFAULT '0',
	mail_adr int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (

	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,

);

#
# Table structure for table 'tx_mffserialmail_domain_model_adressen'
#
CREATE TABLE tx_mffserialmail_domain_model_adressen (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	serialmail int(11) unsigned DEFAULT '0' NOT NULL,

	aktiv tinyint(1) unsigned DEFAULT '1' NOT NULL,
	gesendet int(11) DEFAULT '0' NOT NULL,
	emailadress varchar(255) DEFAULT '' NOT NULL,
	feld1 varchar(255) DEFAULT '' NOT NULL,
	feld2 varchar(255) DEFAULT '' NOT NULL,
	feld3 varchar(255) DEFAULT '' NOT NULL,
	feld4 varchar(255) DEFAULT '' NOT NULL,
	feld5 varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (

	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,

);

#
# Table structure for table 'tx_mffserialmail_domain_model_adressen'
#
CREATE TABLE tx_mffserialmail_domain_model_adressen (

	serialmail int(11) unsigned DEFAULT '0' NOT NULL,

);
