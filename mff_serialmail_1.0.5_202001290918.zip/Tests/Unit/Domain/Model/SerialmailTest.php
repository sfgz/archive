<?php
namespace Mff\MffSerialmail\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class SerialmailTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Domain\Model\Serialmail
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffSerialmail\Domain\Model\Serialmail();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getAktivReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getAktiv()
        );

    }

    /**
     * @test
     */
    public function setAktivForBoolSetsAktiv()
    {
        $this->subject->setAktiv(true);

        self::assertAttributeEquals(
            true,
            'aktiv',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getStartdatumReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setStartdatumForIntSetsStartdatum()
    {
    }

    /**
     * @test
     */
    public function getBetreffReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getBetreff()
        );

    }

    /**
     * @test
     */
    public function setBetreffForStringSetsBetreff()
    {
        $this->subject->setBetreff('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'betreff',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getMailtextReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getMailtext()
        );

    }

    /**
     * @test
     */
    public function setMailtextForStringSetsMailtext()
    {
        $this->subject->setMailtext('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'mailtext',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getMailLoguserReturnsInitialValueForLoguser()
    {
        self::assertEquals(
            null,
            $this->subject->getMailLoguser()
        );

    }

    /**
     * @test
     */
    public function setMailLoguserForLoguserSetsMailLoguser()
    {
        $mailLoguserFixture = new \Mff\MffSerialmail\Domain\Model\Loguser();
        $this->subject->setMailLoguser($mailLoguserFixture);

        self::assertAttributeEquals(
            $mailLoguserFixture,
            'mailLoguser',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getMailSenderReturnsInitialValueForSender()
    {
        self::assertEquals(
            null,
            $this->subject->getMailSender()
        );

    }

    /**
     * @test
     */
    public function setMailSenderForSenderSetsMailSender()
    {
        $mailSenderFixture = new \Mff\MffSerialmail\Domain\Model\Sender();
        $this->subject->setMailSender($mailSenderFixture);

        self::assertAttributeEquals(
            $mailSenderFixture,
            'mailSender',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getMailAdrReturnsInitialValueForAdressen()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getMailAdr()
        );

    }

    /**
     * @test
     */
    public function setMailAdrForObjectStorageContainingAdressenSetsMailAdr()
    {
        $mailAdr = new \Mff\MffSerialmail\Domain\Model\Adressen();
        $objectStorageHoldingExactlyOneMailAdr = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneMailAdr->attach($mailAdr);
        $this->subject->setMailAdr($objectStorageHoldingExactlyOneMailAdr);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneMailAdr,
            'mailAdr',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function addMailAdrToObjectStorageHoldingMailAdr()
    {
        $mailAdr = new \Mff\MffSerialmail\Domain\Model\Adressen();
        $mailAdrObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $mailAdrObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($mailAdr));
        $this->inject($this->subject, 'mailAdr', $mailAdrObjectStorageMock);

        $this->subject->addMailAdr($mailAdr);
    }

    /**
     * @test
     */
    public function removeMailAdrFromObjectStorageHoldingMailAdr()
    {
        $mailAdr = new \Mff\MffSerialmail\Domain\Model\Adressen();
        $mailAdrObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $mailAdrObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($mailAdr));
        $this->inject($this->subject, 'mailAdr', $mailAdrObjectStorageMock);

        $this->subject->removeMailAdr($mailAdr);

    }
}
