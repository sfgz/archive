<?php
namespace Mff\MffSerialmail\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class AdressTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Domain\Model\Adress
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffSerialmail\Domain\Model\Adress();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getAktivReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getAktiv()
        );

    }

    /**
     * @test
     */
    public function setAktivForBoolSetsAktiv()
    {
        $this->subject->setAktiv(true);

        self::assertAttributeEquals(
            true,
            'aktiv',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getGesendetReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setGesendetForIntSetsGesendet()
    {
    }

    /**
     * @test
     */
    public function getEmailReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getEmail()
        );

    }

    /**
     * @test
     */
    public function setEmailForStringSetsEmail()
    {
        $this->subject->setEmail('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'email',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getFeld1ReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFeld1()
        );

    }

    /**
     * @test
     */
    public function setFeld1ForStringSetsFeld1()
    {
        $this->subject->setFeld1('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'feld1',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getFeld2ReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFeld2()
        );

    }

    /**
     * @test
     */
    public function setFeld2ForStringSetsFeld2()
    {
        $this->subject->setFeld2('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'feld2',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getFeld3ReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFeld3()
        );

    }

    /**
     * @test
     */
    public function setFeld3ForStringSetsFeld3()
    {
        $this->subject->setFeld3('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'feld3',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getFeld4ReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFeld4()
        );

    }

    /**
     * @test
     */
    public function setFeld4ForStringSetsFeld4()
    {
        $this->subject->setFeld4('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'feld4',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getFeld5ReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getFeld5()
        );

    }

    /**
     * @test
     */
    public function setFeld5ForStringSetsFeld5()
    {
        $this->subject->setFeld5('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'feld5',
            $this->subject
        );

    }
}
