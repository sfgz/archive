<?php
namespace Mff\MffSerialmail\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class EmailControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Controller\EmailController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffSerialmail\Controller\EmailController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllEmailsFromRepositoryAndAssignsThemToView()
    {

        $allEmails = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $emailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\EmailRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $emailRepository->expects(self::once())->method('findAll')->will(self::returnValue($allEmails));
        $this->inject($this->subject, 'emailRepository', $emailRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('emails', $allEmails);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenEmailToEmailRepository()
    {
        $email = new \Mff\MffSerialmail\Domain\Model\Email();

        $emailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\EmailRepository::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $emailRepository->expects(self::once())->method('add')->with($email);
        $this->inject($this->subject, 'emailRepository', $emailRepository);

        $this->subject->createAction($email);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenEmailToView()
    {
        $email = new \Mff\MffSerialmail\Domain\Model\Email();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('email', $email);

        $this->subject->editAction($email);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenEmailInEmailRepository()
    {
        $email = new \Mff\MffSerialmail\Domain\Model\Email();

        $emailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\EmailRepository::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $emailRepository->expects(self::once())->method('update')->with($email);
        $this->inject($this->subject, 'emailRepository', $emailRepository);

        $this->subject->updateAction($email);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenEmailFromEmailRepository()
    {
        $email = new \Mff\MffSerialmail\Domain\Model\Email();

        $emailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\EmailRepository::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $emailRepository->expects(self::once())->method('remove')->with($email);
        $this->inject($this->subject, 'emailRepository', $emailRepository);

        $this->subject->deleteAction($email);
    }
}
