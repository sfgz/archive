<?php
namespace Mff\MffSerialmail\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class AdressenControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Controller\AdressenController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffSerialmail\Controller\AdressenController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllAdressensFromRepositoryAndAssignsThemToView()
    {

        $allAdressens = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $adressenRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $adressenRepository->expects(self::once())->method('findAll')->will(self::returnValue($allAdressens));
        $this->inject($this->subject, 'adressenRepository', $adressenRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('adressens', $allAdressens);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenAdressenToAdressenRepository()
    {
        $adressen = new \Mff\MffSerialmail\Domain\Model\Adressen();

        $adressenRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressenRepository->expects(self::once())->method('add')->with($adressen);
        $this->inject($this->subject, 'adressenRepository', $adressenRepository);

        $this->subject->createAction($adressen);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenAdressenToView()
    {
        $adressen = new \Mff\MffSerialmail\Domain\Model\Adressen();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('adressen', $adressen);

        $this->subject->editAction($adressen);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenAdressenInAdressenRepository()
    {
        $adressen = new \Mff\MffSerialmail\Domain\Model\Adressen();

        $adressenRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressenRepository->expects(self::once())->method('update')->with($adressen);
        $this->inject($this->subject, 'adressenRepository', $adressenRepository);

        $this->subject->updateAction($adressen);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenAdressenFromAdressenRepository()
    {
        $adressen = new \Mff\MffSerialmail\Domain\Model\Adressen();

        $adressenRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressenRepository->expects(self::once())->method('remove')->with($adressen);
        $this->inject($this->subject, 'adressenRepository', $adressenRepository);

        $this->subject->deleteAction($adressen);
    }
}
