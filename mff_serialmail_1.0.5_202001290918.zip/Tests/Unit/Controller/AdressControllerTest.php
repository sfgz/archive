<?php
namespace Mff\MffSerialmail\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class AdressControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Controller\AdressController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffSerialmail\Controller\AdressController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllAdressesFromRepositoryAndAssignsThemToView()
    {

        $allAdresses = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $adressRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $adressRepository->expects(self::once())->method('findAll')->will(self::returnValue($allAdresses));
        $this->inject($this->subject, 'adressRepository', $adressRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('adresses', $allAdresses);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenAdressToAdressRepository()
    {
        $adress = new \Mff\MffSerialmail\Domain\Model\Adress();

        $adressRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressRepository->expects(self::once())->method('add')->with($adress);
        $this->inject($this->subject, 'adressRepository', $adressRepository);

        $this->subject->createAction($adress);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenAdressToView()
    {
        $adress = new \Mff\MffSerialmail\Domain\Model\Adress();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('adress', $adress);

        $this->subject->editAction($adress);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenAdressInAdressRepository()
    {
        $adress = new \Mff\MffSerialmail\Domain\Model\Adress();

        $adressRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressRepository->expects(self::once())->method('update')->with($adress);
        $this->inject($this->subject, 'adressRepository', $adressRepository);

        $this->subject->updateAction($adress);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenAdressFromAdressRepository()
    {
        $adress = new \Mff\MffSerialmail\Domain\Model\Adress();

        $adressRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $adressRepository->expects(self::once())->method('remove')->with($adress);
        $this->inject($this->subject, 'adressRepository', $adressRepository);

        $this->subject->deleteAction($adress);
    }
}
