<?php
namespace Mff\MffSerialmail\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class SerialmailControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffSerialmail\Controller\SerialmailController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffSerialmail\Controller\SerialmailController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllSerialmailsFromRepositoryAndAssignsThemToView()
    {

        $allSerialmails = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $serialmailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\SerialmailRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $serialmailRepository->expects(self::once())->method('findAll')->will(self::returnValue($allSerialmails));
        $this->inject($this->subject, 'serialmailRepository', $serialmailRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('serialmails', $allSerialmails);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenSerialmailToSerialmailRepository()
    {
        $serialmail = new \Mff\MffSerialmail\Domain\Model\Serialmail();

        $serialmailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\SerialmailRepository::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $serialmailRepository->expects(self::once())->method('add')->with($serialmail);
        $this->inject($this->subject, 'serialmailRepository', $serialmailRepository);

        $this->subject->createAction($serialmail);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenSerialmailToView()
    {
        $serialmail = new \Mff\MffSerialmail\Domain\Model\Serialmail();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('serialmail', $serialmail);

        $this->subject->editAction($serialmail);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenSerialmailInSerialmailRepository()
    {
        $serialmail = new \Mff\MffSerialmail\Domain\Model\Serialmail();

        $serialmailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\SerialmailRepository::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $serialmailRepository->expects(self::once())->method('update')->with($serialmail);
        $this->inject($this->subject, 'serialmailRepository', $serialmailRepository);

        $this->subject->updateAction($serialmail);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenSerialmailFromSerialmailRepository()
    {
        $serialmail = new \Mff\MffSerialmail\Domain\Model\Serialmail();

        $serialmailRepository = $this->getMockBuilder(\Mff\MffSerialmail\Domain\Repository\SerialmailRepository::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $serialmailRepository->expects(self::once())->method('remove')->with($serialmail);
        $this->inject($this->subject, 'serialmailRepository', $serialmailRepository);

        $this->subject->deleteAction($serialmail);
    }
}
