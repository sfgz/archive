<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffSerialmail',
            'Mailer',
            'Mailer'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($extKey, 'Configuration/TypoScript', 'Serial Mailer');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffserialmail_domain_model_serialmail', 'EXT:mff_serialmail/Resources/Private/Language/locallang_csh_tx_mffserialmail_domain_model_serialmail.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffserialmail_domain_model_serialmail');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffserialmail_domain_model_adressen', 'EXT:mff_serialmail/Resources/Private/Language/locallang_csh_tx_mffserialmail_domain_model_adressen.xlf');
//         \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffserialmail_domain_model_adressen');

    },
    $_EXTKEY
);
