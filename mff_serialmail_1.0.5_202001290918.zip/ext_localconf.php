<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
	{

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Mff.MffSerialmail',
            'Mailer',
            [
                'Serialmail' => 'list, new, create, edit, update, delete, attachment',
                'Adressen' => 'edit, update, delete, insert',
                'Json' => 'update'
            ],
            // non-cacheable actions
            [
                'Serialmail' => 'create, edit, update, delete, attachment',
                'Adressen' => 'edit, update, delete, insert',
                'Json' => 'update'
            ]
        );

	// wizards
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
		'mod {
			wizards.newContentElement.wizardItems.plugins {
				elements {
					mailer {
						icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($extKey) . 'Resources/Public/Icons/user_plugin_mailer.svg
						title = LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mff_serialmail_domain_model_mailer
						description = LLL:EXT:mff_serialmail/Resources/Private/Language/locallang_db.xlf:tx_mff_serialmail_domain_model_mailer.description
						tt_content_defValues {
							CType = list
							list_type = mffserialmail_mailer
						}
					}
				}
				show = *
			}
	   }'
	);
		// Register scheduler-Tasks
		if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
			$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\Mff\MffSerialmail\Task\SendmailsTask::class] = array(
				'extension'			=> $extKey,
				'title'				=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.title',
				'description'		=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.description',
				'additionalFields'	=> \Mff\MffSerialmail\Task\SendmailsAdditionalFieldProvider::class
			);
		};
    },
    $_EXTKEY
);
