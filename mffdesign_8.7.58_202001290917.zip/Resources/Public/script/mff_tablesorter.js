$(document).ready(function(){

    $(".sortTable").tablesorter({
    dateFormat: "ddmmyyyy", 
    debug:false, 
    headers : {
      ".dateFormat-ddmmyyyy" : { sorter: "shortDate", dateFormat: "ddmmyyyy" },
    }
    });
    
    if( $("#sortPagerTableSize").length ){
	var pagerOptions = {container: $(".pager") , size:$("#sortPagerTableSize").val() };
    }else{
	var pagerOptions = {container: $(".pager") , size:30 };
    }
    $("#sortPagerTable").tablesorter({
    dateFormat: "ddmmyyyy", 
    debug:false, 
    }).bind('pagerChange pagerComplete pagerInitialized pageMoved', function(e, c){
      var msg = '"</span> event triggered, ' + (e.type === 'pagerChange' ? 'going to' : 'now on') +
        ' page <span class="typ">' + (c.page + 1) + '/' + c.totalPages + '</span>';
      $('#display')
        .append('<li><span class="str">"' + e.type + msg + '</li>')
        .find('li:first').remove();
    }).tablesorterPager(pagerOptions);

});

