//  gistfile1.js
//  https://gist.github.com/DelvarWorld/3784055
$.fn.shiftSelectable = function() {
    var lastChecked,
        $boxes = this;

    $boxes.click(function(evt) {
        if(!lastChecked) {
            lastChecked = this;
            return;
        }

        if(evt.shiftKey) {
            var start = $boxes.index(this),
                end = $boxes.index(lastChecked);
            $boxes.slice(Math.min(start, end), Math.max(start, end) + 1)
                .prop('checked', lastChecked.checked).trigger('change');
        }

        lastChecked = this;
    });
};


$.fn.shiftSelectable_general = function() {
    var lastChecked, $boxes = this;
    $boxes.click(function(evt) {
			if(!lastChecked) { lastChecked = this; return; }
			if(evt.shiftKey) {
				var start = $boxes.index(this), end = $boxes.index(lastChecked), actionUri = editConfigUrl( 'update' );
				$boxes.slice(Math.min(start, end), Math.max(start, end) + 1).each(function(){
						$(this).prop('checked', lastChecked.checked);
						jsUpdateFromObject( actionUri , 'importSelection' , $( this ) );
				});
			}
			lastChecked = this;
    });
};

