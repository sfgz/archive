function slideImages( wechseldauer ){
      // set variable to the li-element with classname "active"
      var active = jQuery('#slideheader li.active'); 
      // change pointer to last Element, if it is not set (although this is not possible)
      if (active.length == 0){ active = jQuery('#slideheader li:last'); } 
      // if there is next Element, set pointer "next" to this - otherwise to the first li-element
      var next = active.next().length ? active.next() : jQuery('#slideheader li:first'); 
      // add class last-active to the pointed li-element, so it gets the z-index 2
      active.addClass('last-active');
      // if its the last element, fade out and then remove class "last-active" so z-index falls back to 1
      if( active.hasClass('end') ) active.animate({ opacity: 0 }, wechseldauer , function(){ active.removeClass('active last-active');} );
      // then to "active" and fade it in, then remove class "last-active" so z-index falls back to 1
      next.css({ opacity: 0 }).addClass('active').animate({ opacity: 1 }, wechseldauer , function(){ active.removeClass('active last-active'); });
}
function startSlideImages( wechseldauer , slideshowdauer ){
    jQuery(function(){ 
	  if( wechseldauer +500 > slideshowdauer ) slideshowdauer = wechseldauer + 500;
	  if( 1 >= jQuery('#slideheader li').length ) {
	      // if there ist only one image in list dont start slideshow but show first image - in case its hidden
	      jQuery('#slideheader li:first').show();
	      return;
	  } else {
	      // wait for the defined time (slideshowdauer),  then start changing slide (wechseldauer)
	      setInterval( 'slideImages(' + wechseldauer + ')', slideshowdauer );
	  }
    });
}