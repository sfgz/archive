// ask bevore delete-behavor
function ask(url, message) {
  question = window.confirm( '«' + message + '» wirklich löschen?' ); 
  if(question) document.location.href = url; 
}
function popUpRawUrl( id_string , raw_url, win , w , h , t , l ) {
      return popUp( rawUrl2url( id_string , raw_url ), win , w , h , t , l );
}
function popUp( url, win , w , h , t , l ) {
      vHWin=window.open(
	    url,
	    win,
	    'width=' + w + ',height=' + h + ',top=' + t + ',left=' + l + ',scrollbars=1,resizable=1,status=0,menubar=0,toolbar=0'
      );
      vHWin.focus();
      return false;
}
function rawUrl2url( id_string , raw_url ) {
      var arr = id_string.split('_');
      var url = raw_url.replace( '_REP_VALUE_' , arr[1] ).replace( '_REP_NAME_' , arr[0] );
      return url;
}

function anfang() {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
}

function ende() {
	$("body,html").animate({
		scrollTop: $(document).height() + $(window).height(),
		scrollLeft: 8
	}, 550);
}
