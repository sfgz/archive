## lib.permacontent_right
## dont show permacontent_right  on login-page
    lib.permacontent_right = COA
    lib.permacontent_right {
      10 = RECORDS
      10 {
	  tables = tt_content
	  source = {$plugin.mffdesign.settings.permacontent_right}
      }
    }
[globalVar = TSFE:id == {$plugin.mffdesign.settings.loginpage_uid}]
    lib.permacontent_right >
[global]
