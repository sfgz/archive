## alle Bilder aus dem Medienfeld des aktuellen Datensatzes

# Die Files-Liste mit dem keyword ###SPLITTER### zusammenfuehren
# Sie wird spaeter wieder getrennt, aber auch
# als Bedingung wiederverwendet, leicht abgeaendert (begin = 2)
temp.contentToSplit = COA
temp.contentToSplit {
    10 = FILES
    10 {
        references{
            treatIdAsReference = 1
            data =  levelmedia:-1, slide
        }
        renderObj = COA
        renderObj {
            10 = IMAGE
            10.file.import.data = file:current:originalUid // file:current:uid
            10.file.width = {$plugin.mffdesign.settings.imgwidth}
            10.file.height = {$plugin.mffdesign.settings.imgheight}
            10.titleText.data = file:current:title
            10.altText.data = file:current:name
            10.stdWrap.typolink.parameter.data = file:current:link
            stdWrap.outerWrap = |###SPLITTER###
        }
    }
}

[globalVar = LIT:1 != {$plugin.mffdesign.settings.inherit_images}]
temp.contentToSplit {
    10 {
        references{
            treatIdAsReference = 1
	    table = pages
	    uid.data = page:uid
	    fieldName = media
	    data <
      }
    }
}
[global]


temp.mffmediaslides_objects {
    headline_image = COA
    headline_image {
	10 = COA
	10 {
	    stdWrap {
		required = 1
		wrap.cObject = COA
		wrap.cObject {
		    wrap = <div>|</div>
		    15 = TEXT
		    15.value = <div id="slideheader">
		    
		    # spacer, provides surounding div to keep height 
		    16 = IMAGE
		    16.file =typo3conf/ext/mffdesign/Resources/Public/images/design/transp_bg.png
            16.file.width = {$plugin.mffdesign.settings.imgwidth}
            16.file.height = {$plugin.mffdesign.settings.imgheight}
            
		    20 = TEXT
		    20.value = <ul>|</ul>
		    
		    30 = TEXT
		    30.data = TSFE:page|title
		    30.wrap = <div id="imagelabel">|</div>
		    
		    35 = TEXT
		    35.value = </div>
		}
	    }

	    10 < temp.contentToSplit

	    # last element is always empty 
	    # because we added a split-char after each element of list
	    stdWrap.split {
		token = ###SPLITTER###
		cObjNum = 1 |*| 2 |*| 3 || 4
		1.current = 1
		1.wrap = <li class="active">|</li>
		2.current = 1
		2.wrap = <li class="middle">|</li>
		3.current = 1
		3.wrap = <li class="end">|</li>
		4.current = 1
		4.wrap = |
	    }
	    # show only if more or equal 2 Images (negate isfalse begin = 2)
	    if.negate = 1
	    if.isFalse.cObject = COA
	    if.isFalse.cObject < temp.contentToSplit
	    # if.isFalse.cObject.10.begin = 2
	    if.isFalse.cObject.10.begin = 1
	}
	# if only 1 image or none then show 20 (set to class "active") otherwise 10 (isfalse begin = 2)
	20 = COA
	20 < .10
	20.if.negate = 0
	# 20.stdWrap.split.cObjNum = 1 || 4
	20.stdWrap.split.cObjNum = 1 
    }
    
    header_data = COA
    header_data {
	20 = TEXT
	20.value (
	<script src="typo3conf/ext/mffdesign/Resources/Public/script/mff_mediaslides.js" type="text/javascript"></script>
	)

	30 = TEXT
	30.value (
	<script type="text/javascript"> startSlideImages( {$plugin.mffdesign.settings.wechseldauer} , {$plugin.mffdesign.settings.slideshowdauer} ); </script>
	
	)
	if.negate = 1
	if.isFalse.cObject = COA
	if.isFalse.cObject < temp.contentToSplit
	# if.isFalse.cObject.10.begin = 2
	if.isFalse.cObject.10.begin = 1
    }
}

# den Inhalt der Variable uebergeben
lib.mediaslides = COA
lib.mediaslides < temp.mffmediaslides_objects.headline_image

# JS zum wechseln der Bilder: Startbefehl einbinden
page.headerData.120 = TEXT
page.headerData.120 < temp.mffmediaslides_objects.header_data

# jQuery Skript NICHT einbinden, wird in settings/page.ts eingebunden
# [globalVar = LIT:1 = {$plugin.mffdesign.settings.loadjquery}]
# page.includeJS.jquery_min = http://code.jquery.com/jquery.min.js
# [global]

plugin.tx_mffmediaslides_pi1._CSS_DEFAULT_STYLE (
	.content_box #mediaslides { padding:0; }
      #slideheader {
			position:relative;
			z-index:1;
			min-height:50px;
			height:auto;
			width:100%;
      }
      #slideheader IMG {
			width:100%;
			height:auto;
			border-radius:2px 8px 0 0;
      }
      #slideheader ul{
			list-style: none outside none; 
			margin: 0; 
			padding: 0;
      }
      #slideheader li {
			position:absolute;
			top:0;
			left:0;
			z-index:1;
			list-style: none outside none; 
			margin: 0; 
			padding: 0;
			display: none;
      }
      #slideheader li.last-active {
			z-index:2;
      }
      #slideheader li.active {
			z-index:3;
			display: inline;
      }
      #imagelabel {
			font-family:Fago,Helvetica,verdana,  sans-serif;
			font-size: 28px;
			text-shadow:#aaa 0 0 1px;
			color:#eee;
			position:absolute;
			bottom:8px;
			left:10px;
			z-index:4;
      }
)

