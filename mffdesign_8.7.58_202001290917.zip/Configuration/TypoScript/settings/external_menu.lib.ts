## + external Menu
lib.external_menu = COA
lib.external_menu.wrap = <div id="external_menu">|</div>
lib.external_menu.10 = TEXT
lib.external_menu.10.value = SfGZ Seiten
lib.external_menu.10.wrap = <h2> | </h2>
lib.external_menu.20 = COA
lib.external_menu.20 {
    wrap = <ul> | </ul>
    10 = TEXT
    10 {
  value = Homepage
  stdWrap.typolink {
      parameter = http://sfgz.ch
      extTarget = _blank
  }
    }
    20 < .10
    20 {
  value = Intranet
  stdWrap.typolink.parameter = http://intranet.sfgz.ch
    }
    30 < .10
    30 {
  value = Moodle
  stdWrap.typolink.parameter = https://bgzmoodle.tam.ch/
    }
    40 < .10
    40 {
  value = Wiki
  stdWrap.typolink.parameter = http://wiki.sfgz.ch
    }
    50 = TEXT
    50 {
  value = Daten
  wrap = <span class="selgroup"> | </span>
    }
    60 < .10
    60 {
  value = Cloud
  stdWrap.typolink.parameter = http://cloud.sfgz.ch
    }
}

plugin.external_menu._CSS_DEFAULT_STYLE (
    DIV#external_menu {height:151px;margin:0;overflow:visible;}
    #external_menu li, #external_menu ul {list-style-type:none;}
    #external_menu ul {margin:0 0 0 3px;padding:0;}
    #external_menu A, #external_menu span {font-family:FagoMedium;}
    #external_menu A.selgroup, #external_menu span.selgroup {color:#C50;}
    #external_menu A:hover {text-decoration:underline;}
    #external_menu A, #external_menu span {
      color:black;
      width:auto;
      text-decoration:none;
      display:block;
      white-space:nowrap;
      margin:0;
      padding:0;
    }
)
