## + ContentMenu

lib.content_menu = COA
lib.content_menu {
  10 = HMENU
  10 {
		### Erste Ebene ###
		1 = TMENU
		1 {
			noBlur = 1
			wrap = <div class="navimain">|</div> 
			expAll = 1
			NO.wrapItemAndSub = <div class="headings">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
					field = fe_group
					wrap = class="group|"
					split{
							token = ,
							cObjNum = 1
							1.current = 1
							1.stdWrap {
									insertData = 1
									noTrimWrap = | fe_| |
							}
					}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap = class="group selgroup|"

		}
		### Zweite Ebene ###
		2 = TMENU
		2 {
			noBlur = 1
			wrap =    <div class="firstbox">|</div>
			expAll = 1
			NO.wrapItemAndSub = <div class="first">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
			field = fe_group
			wrap = class="group|"
			split{
			token = ,
			cObjNum = 1
			1.current = 1
			1.stdWrap {
			insertData = 1
			noTrimWrap = | fe_| |
			}
			}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap = class="group selgroup|"
		}
		### Dritte Ebene ###
		3 = TMENU
		3 {
		noBlur = 1
			wrap = <div class="secondbox" style="">|</div>
			expAll = 1
			NO.wrapItemAndSub = <div class="second">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
			field = fe_group
			wrap = class="group|"
			split{
			token = ,
			cObjNum = 1
			1.current = 1
			1.stdWrap {
			insertData = 1
			noTrimWrap = | fe_| |
			}
			}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap = class="group selgroup|"
		}
		### Vierte Ebene ###
		4 = TMENU
		4 {
		noBlur = 1
			wrap = <div class="thirdbox">|</div>
			expAll = 1
			NO.wrapItemAndSub = <div class="third">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
			field = fe_group
			wrap = class="group|"
			split{
			token = ,
			cObjNum = 1
			1.current = 1
			1.stdWrap {
			insertData = 1
			noTrimWrap = | fe_| |
			}
			}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap  = class="group selgroup|"
		}
		### Fuenfte Ebene ###
		5 = TMENU
		5 {
		noBlur = 1
			wrap = <div class="fourthbox">|</div>
			expAll = 1
			NO.wrapItemAndSub = <div class="fourth">|</div> 
			NO.ATagParams.cObject = COA
			NO.ATagParams.cObject.10 = TEXT
			NO.ATagParams.cObject.10 {
			field = fe_group
			wrap = class="group|"
			split{
			token = ,
			cObjNum = 1
			1.current = 1
			1.stdWrap {
			insertData = 1
			noTrimWrap = | fe_| |
			}
			}
			}
			NO.allStdWrap.insertData = 1
			ACT < .NO
			ACT = 1
			ACT.ATagParams.cObject.10.wrap  = class="group selgroup|"
		}
	}
}


plugin.navimain._CSS_DEFAULT_STYLE (
    /* Structure */
    DIV.navimain {padding:0 3px 9px 0;}
    DIV.navimain A {text-decoration:none;}
    div.first A  {margin-left:8px;font-size:100%;}
    div.second A  {margin-left:16px;font-size:100%;}
    div.third A  {margin-left:24px;font-size:95%;}
    div.fourth A  {margin-left:32px;font-size:90%;}
    DIV.navimain A.selgroup {text-decoration:none;color:white;;}
    .group:hover,DIV.navimain A.selgroup:hover {text-decoration:underline;}
	@media screen and (max-width:800px) {
		DIV.navimain A.selgroup {color:#009ee0;}
	}
    .navimain A.fe_0, .navimain A.fe_ {padding-left:6px;border-left:0px solid transparent;}
    .navimain A.fe_-1{padding-left:4px;border-left:2px solid transparent;} 
    .navimain A.fe_-2{padding-left:4px;border-left:2px solid #9cff00;font-style:italic;}
    .navimain A.fe_7{border:1px solid #ff009c;background:#faa;} 
    .navimain A.fe_2{padding-left:4px;border-left:2px solid #9cff00;}
    .navimain A.fe_3{padding-left:4px;border-left:2px solid #dfdf00;}
    .navimain A.fe_4{padding-left:4px;border-left:2px solid #90ef00;}
    .navimain A.fe_5{padding-left:4px;border-left:2px solid #acef00;}
    .navimain A.fe_8{padding-left:4px;border-left:2px solid #7cdf00;}
    .navimain A.fe_1{padding-left:4px;border-left:2px solid #6ccf00;}
    .navimain A.fe_6{padding-left:4px;border-left:2px solid #5cbf00;}
    .navimain A.fe_11{padding-left:4px;border-left:2px solid #6cef00;}
    .navimain A.fe_9{padding-left:4px;border-left:2px solid #6aef00;}
    .navimain A.fe_10{padding-left:4px;border-left:2px solid #6bef00;}
    .navimain A.fe_12{padding-left:4px;border-left:2px solid #6def00;}
    .navimain A.fe_13{padding-left:4px;border-left:2px solid #6eef00;}
    .navimain A.fe_14{padding-left:4px;border-left:2px solid #6fef00;}
    .navimain A.fe_15{padding-left:4px;border-left:2px solid #aaef00;}
    .navimain A.fe_18{padding-left:4px;border-left:2px solid #7bdf00;}
    .navimain A.fe_17{padding-left:4px;border-left:2px solid #6acf00;}
    .navimain A.fe_16{padding-left:4px;border-left:2px solid #5bbf00;}
    .navimain A.fe_19{padding-left:4px;border-left:2px solid #6cef00;}
    
)

