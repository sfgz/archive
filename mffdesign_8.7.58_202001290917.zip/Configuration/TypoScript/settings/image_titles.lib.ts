lib.logo_full = IMAGE
lib.logo_full.stdWrap.typolink.parameter = {$plugin.mffdesign.settings.mainpage_uid}
lib.logo_full.file ={$plugin.mffdesign.settings.pathToResources}images/logo.png
lib.logo_full.params = alt="Schule fuer Gestaltung Zuerich"
lib.logo_full.file.width = 300px

lib.logo_bild = IMAGE
#lib.logo_bild.stdWrap.typolink.parameter = {$plugin.mffdesign.settings.mainpage_uid}
lib.logo_bild.file ={$plugin.mffdesign.settings.pathToResources}images/logo/sfgz_nurbild_quadrat.svg
lib.logo_bild.params = alt="SfGZ" title="https://sfgz.ch"
lib.logo_bild.file.width = 82px
lib.logo_bild.file.height = 64px
#lib.logo_bild.wrap = <a onclick="anfang()" hef="">|</a>

lib.link_home = TEXT
lib.link_home.stdWrap.typolink.parameter = {$plugin.mffdesign.settings.mainpage_uid}
lib.link_home.value = &nbsp;


lib.logo_text = IMAGE
lib.logo_text.stdWrap.typolink.parameter = {$plugin.mffdesign.settings.mainpage_uid}
lib.logo_text.file ={$plugin.mffdesign.settings.pathToResources}images/logo/sfgz_nurtext.svg
lib.logo_text.params = alt="SfGZ" title="https://sfgz.ch"
lib.logo_text.width = 218px
lib.logo_text.height = 64px

lib.sitetitle = COA
lib.sitetitle {
   7 = TEXT
   7.wrap = <span class="sitetitle"> | </span>
   7.data = levelfield:0, title, slide
}

lib.pagetitle = COA
lib.pagetitle.10 = COA
lib.pagetitle.10 {
    # aktueller Seitentitel aus Tabelle page
    10 = TEXT
    10 {
        data = levelfield:-1, title, slide
        noTrimWrap = | | |
    }
}
lib.pagesubtitle = COA
lib.pagesubtitle.10 = COA
lib.pagesubtitle.10 {
    15 = TEXT
    15.value = &nbsp;|&nbsp;
    30 = TEXT
    30 {
        data = page:subtitle
        wrap = |
    }
}

