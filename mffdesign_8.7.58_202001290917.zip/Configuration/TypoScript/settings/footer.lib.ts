## HeaderTop
lib.footer_left = TEXT
lib.footer_left.value (
	<p class="csc-default">
      Dies ist eine andere Seite der Schule für Gestaltung Zürich,
      <a target="_blank" class="sfgz" title="SfGZ" href="http://www.sfgz.ch">www.sfgz.ch</a>.
	</p>
)

lib.footer_right = TEXT
lib.footer_right.value = <p class="csc-default align-right"></p>

plugin.footer._CSS_DEFAULT_STYLE (
    .footer { margin:0; }
    .footer P.csc-default {padding:0px;margin:0; }
    div#footer_left {
      float:left;
      width:80%;
      white-space:nowrap;
      overflow:visible;
      padding-left:15px;
    }
    div#footer_right {
      float:right;
      width:20%;
      text-align:right;
      white-space:nowrap;
      overflow:visible;
      padding-right:15px;
    }
)
