## datamints_feuser variable replacement
page.10.variables.content_main.stdWrap.replacement {
  10 {
    search = #vorname#
    replace.cObject = TEXT
    replace.cObject {
      data = TSFE:fe_user|user|first_name
      insertData=1
    }
  }
  20 < .10
  20.search = #nachname#
  20.replace.cObject.data = TSFE:fe_user|user|last_name

  25 < .10
  25.search = #title#
  25.replace.cObject.data = TSFE:fe_user|user|title
  25.replace.cObject.noTrimWrap = || |
  25.replace.cObject.required = 1
  
  30 < .10
  30.search = #email#
  30.replace.cObject.data = TSFE:fe_user|user|email
  
  35 < .10
  35.search = #telephone#
  35.replace.cObject.data = TSFE:fe_user|user|telephone
  35.replace.cObject.noTrimWrap = |Telefon |<br>|
  35.replace.cObject.required = 1

  40 < .10
  40.search = #fachbereich#
  40.replace.cObject.data = TSFE:fe_user|user|company
  40.replace.cObject.wrap = |<br>
  40.replace.cObject.required = 1
  
  45 < .10
  45.search = #fachbereiche#
  45.replace.cObject.data = TSFE:fe_user|user|city
  45.replace.cObject.wrap = |<br>
  45.replace.cObject.required = 1
}
page.10.variables.content_column_1.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement
page.10.variables.content_column_2.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement
page.10.variables.content_border.stdWrap.replacement < page.10.variables.content_main.stdWrap.replacement
