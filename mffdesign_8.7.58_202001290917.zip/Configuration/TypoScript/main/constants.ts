# customsubcategory=base=Grundeinstellungen
# customsubcategory=storage=Standard Speicherort
# customsubcategory=specialUid=Spezielle Seiten
# customsubcategory=geometry=Geometrie
# customsubcategory=slideheader=Diashow in Kopfzeile
 
plugin.mffdesign {
	view {
		# cat=mff_design/file; type=string; label=Path to template root
		templateRootPaths.10 = EXT:mffdesign/Resources/Private/Templates/
		# cat=mff_design/file; type=string; label=Path to template partials
		partialRootPaths.10 = EXT:mffdesign/Resources/Private/Partials/
		# cat=mff_design/file; type=string; label=Path to template layouts 
		layoutRootPaths.10 = EXT:mffdesign/Resources/Private/Layouts/
	}
	settings {
	    # cat=mff_design/base; type=text; label=Website-Titel:Website-Titel im Rahmen des Browsers.
	    sitetitle = daten@medienformfarbe.ch
	    # cat=mff_design/base; type=text; label=baseURL:Basis URL mit Protokoll zB. http://my.example.com/path2typo3/
	    baseURL = http://local.t3/t37/
	    # cat=mff_design/base; type=int; label=Meldungen nach x Sekunden ausblenden, oder nicht 0.
	    hideAlerts = 0
	    # cat=mff_design/geometry; type=int; label=Seite Breite.
	    pageWidth = 1014
	    # cat=mff_design/geometry; type=int; label=linke Sidebar Breite.
	    leftSideBarWidth = 169
	    # cat=mff_design/geometry; type=int; label=Inhalt Breite.
	    contentWidth = 676
	    # cat=mff_design/geometry; type=int; label=rechte Sidebar Breite.
	    rightSideBarWidth = 169
	    # cat=mff_design/specialUid/1; type=int; label=Hauptseite uid.
	    mainpage_uid = 1
	    # cat=mff_design/specialUid/2; type=int; label=Loginseite uid.
	    loginpage_uid = 2
	    # cat=mff_design/specialUid/3; type=int; label=Sekretariat Loginseite uid.
	    loginpage_secretary_uid = 4
	    # cat=mff_design/specialUid/4; type=int; label=Sekretariat Gruppen: Gruppen uids Sekretariat Kommasepariert.
	    secretary_group_uids = 4,5,6
	    # cat=mff_design/specialUid/5; type=int; label=permacontent_right:Uid des Content Elements in rechter Sidebar.
	    permacontent_right = 8
	    # cat=mff_design/specialUid/6; type=string; label=Teaser auf Seite(n): Mehrere Seiten mit Pipe trennen [ 1|27|... ]
	    teaser_uid = 1
	    # cat=mff_design/file; type=text; label=Resources - Verzeichnis: relativer Pfad zum Resources - Verzeichnis.
	    pathToResources = typo3conf/ext/mffdesign/Resources/Public/
	    # cat=mff_design/slideheader/show; type=text; label=Anzeigedauer: Dauer der Anzeige eines Bildes. Wert muss groesser als Wechseldauer sein!
	    slideshowdauer= 6000
	    # cat=mff_design/slideheader/show; type=text; label=Wechseldauer: Dauer des Ueberganges. Wert muss kleiner als Anzeigedauer sein, flackern!
	    wechseldauer= 2500
	    # cat=mff_design/slideheader/geometry; type=text; label=Bildhoehe: Hoehe des Bildes in Pixel
	    imgheight=170
	    # cat=mff_design/slideheader/geometry; type=text; label=Bildbreite: Breite des Bildes in Pixel
	    imgwidth=676
	    # cat=mff_design/slideheader/base; type=boolean; label=Bilder vererben: Bilder vererben wenn keine vorhanden
	    inherit_images=1
	    # cat=mff_design/slideheader/base; type=boolean; label=JQuery laden: Nur markieren wenn JQuery nicht anderweitig geladen wird
	    loadjquery=0
	}
}
