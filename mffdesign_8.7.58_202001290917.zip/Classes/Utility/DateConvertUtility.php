<?php
namespace Mff\Mffdesign\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class DateConvertUtility
 */

class DateConvertUtility implements \TYPO3\CMS\Core\SingletonInterface 
{
    /**
     * datestring2unixtime
     *
     * @param string $dateString
     * @return int
     */
    public function datestring2unixtime( $dateString )
    {
			if( $this->isDatestring( $dateString ) == FALSE ) return $dateString;
			
			$aDateTime = explode( ' ' , $dateString );
			
			$aDate = explode( '.' , $aDateTime[0] );
			if( empty( $aDate[0] ) ) return;
			
			$aTime = count($aDateTime)==2 ? explode( ':' , $aDateTime[1] ) : [ 12 , 0 , 0 ]; // default time is 'noon' (12:00:00)
			if( !isset($aTime[0]) ) $aTime[0] = 0;
			if( !isset($aTime[1]) ) $aTime[1] = 0;
			if( !isset($aTime[2]) ) $aTime[2] = 0;
			
			return mktime( $aTime[0] , $aTime[1] , $aTime[2] , $aDate[1] , $aDate[0] , $aDate[2] );
    }
    
    /**
     * isDatestring
     *
     * @param string $dateString
     * @return bool
     */
    public function isDatestring( $dateString )
    {
			if( empty( $dateString ) ) return FALSE;
			if( is_numeric( $dateString ) ) return FALSE;
			return strpos( $dateString , '.' ) ? TRUE : FALSE;
    }
	
}
