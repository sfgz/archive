
plugin.tx_mffcloud_access {
  view {
    templateRootPaths.0 = EXT:mff_cloud/Resources/Private/Templates/
    templateRootPaths.1 = {$plugin.tx_mffcloud_access.view.templateRootPath}
    partialRootPaths.0 = EXT:mff_cloud/Resources/Private/Partials/
    partialRootPaths.1 = {$plugin.tx_mffcloud_access.view.partialRootPath}
    layoutRootPaths.0 = EXT:mff_cloud/Resources/Private/Layouts/
    layoutRootPaths.1 = {$plugin.tx_mffcloud_access.view.layoutRootPath}
  }
  persistence {
    storagePid = {$plugin.tx_mffcloud_access.persistence.storagePid}
  }
  settings {
    uploadDir = uploads/tx_mffcloud/
    webDavDomain = https://cloud.sfgz.ch
    webDavUri = remote.php/webdav
  }
}

plugin.tx_mffcloud._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .tx-mff-cloud table {
        border-collapse:separate;
        border-spacing:10px;
    }

    .tx-mff-cloud table th {
        font-weight:bold;
    }

    .tx-mff-cloud table td {
        vertical-align:top;
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
)
