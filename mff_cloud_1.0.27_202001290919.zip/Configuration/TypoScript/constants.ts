
plugin.tx_mffcloud_access {
  view {
    # cat=plugin.tx_mffcloud_access/file; type=string; label=Path to template root (FE)
    templateRootPath = EXT:mff_cloud/Resources/Private/Templates/
    # cat=plugin.tx_mffcloud_access/file; type=string; label=Path to template partials (FE)
    partialRootPath = EXT:mff_cloud/Resources/Private/Partials/
    # cat=plugin.tx_mffcloud_access/file; type=string; label=Path to template layouts (FE)
    layoutRootPath = EXT:mff_cloud/Resources/Private/Layouts/
  }
  persistence {
    # cat=plugin.tx_mffcloud_access//a; type=string; label=Default storage PID
    storagePid =
  }
}
