<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_cloud/Resources/Private/Language/locallang_db.xlf:tx_mffcloud_domain_model_accesspoints',
        'label' => 'remote_dir',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
        ],
		'searchFields' => 'remote_dir,username',
        'iconfile' => 'EXT:mff_cloud/Resources/Public/Icons/tx_mffcloud_domain_model_accesspoints.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'remote_dir, username',
    ],
    'types' => [
		'1' => ['showitem' => 'remote_dir, username'],
    ],
    'columns' => [
        'remote_dir' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_cloud/Resources/Private/Language/locallang_db.xlf:tx_mffcloud_domain_model_accesspoints.remote_dir',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	    'username' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_cloud/Resources/Private/Language/locallang_db.xlf:tx_mffcloud_domain_model_accesspoints.username',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
    ],
];
