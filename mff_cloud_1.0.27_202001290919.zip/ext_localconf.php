<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
	{

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Mff.MffCloud',
            'Access',
            [
                'Accesspoints' => 'list, new, create, edit, update, delete'
            ],
            // non-cacheable actions
            [
                'Accesspoints' => 'create, update, delete'
            ]
        );

	// wizards
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
		'mod {
			wizards.newContentElement.wizardItems.plugins {
				elements {
					access {
						icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($extKey) . 'Resources/Public/Icons/user_plugin_access.svg
						title = LLL:EXT:mff_cloud/Resources/Private/Language/locallang_db.xlf:tx_mff_cloud_domain_model_access
						description = LLL:EXT:mff_cloud/Resources/Private/Language/locallang_db.xlf:tx_mff_cloud_domain_model_access.description
						tt_content_defValues {
							CType = list
							list_type = mffcloud_access
						}
					}
				}
				show = *
			}
	   }'
	);
    },
    $_EXTKEY
);
