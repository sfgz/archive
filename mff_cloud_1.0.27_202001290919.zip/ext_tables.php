<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffCloud',
            'Access',
            'Accesspionts'
        );
	if (TYPO3_MODE === 'BE') {
	      \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
		      'Mff.' . $extKey,
		      'user',	 // Make module a submodule of 'user'
		      'filecompare',	// Submodule key
		      '',						// Position
		      array(
			      'BackendLayout' => 'details,cloud,list,joindates',
		      ),
		      array(
			      'access' => 'user,group',
			      'icon'   => 'EXT:' . $extKey . '/ext_icon.gif',
			      'labels' => 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_filecompare.xlf',
		      )
	      );
	}

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($extKey, 'Configuration/TypoScript', 'CloudAccess');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffcloud_domain_model_accesspoints', 'EXT:mff_cloud/Resources/Private/Language/locallang_csh_tx_mffcloud_domain_model_accesspoints.xlf');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffcloud_domain_model_accesspoints');

    },
    $_EXTKEY
);
