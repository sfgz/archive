<?php
namespace Mff\MffCloud\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class CloudUsersUtility
 */

class CloudUsersUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * cloudUrl
	 *
	 * @var string
	 */
	protected $cloudUrl = 'cloud.sfgz.ch/ocs/v1.php/cloud';
	
	/**
	 * cloudProt
	 *
	 * @var string
	 */
	protected $cloudProt = 'https://';
	
	/**
	 * cloudUsername
	 *
	 * @var string
	 */
	protected $cloudUsername = 'daniel_ruegg';

	/**
	 * cloudPassword
	 *
	 * @var string
	 */
	protected $cloudPassword = 'D4n137!-';

	/**
	 * filedir
	 *
	 * @var array
	 */
	public $filedir = array();

	/**
	 * partialFilePaths
	 *
	 * @var array
	 */
	protected $partialFilePaths = array( 'cloudusers'=>'uploads/tx_mffcloud/cloudusers/' , 'processing'=>'uploads/tx_mffcloud/cloudusers/processing/' , 'filecompare'=>'uploads/tx_mffcloud/filecompare/' );

	/**
	 * xmClass
	 * 
	 * @var \Mff\MffCloud\Controller\AccesspointsController
	 */
	public $xmClass = NULL;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct() {
			foreach($this->partialFilePaths as $dirname => $directoryPath) $this->filedir[$dirname] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( rtrim( PATH_site , '/' ) . '/' . $directoryPath );
			$this->xmClass = new \Mff\MffCloud\Controller\AccesspointsController();
    }
    
    /**
     * readFromFile_CloudUsersAndAttributes
     *
     * @return array
     */
    public function readFromFile_CloudUsersAndAttributes(){
			$rowsUserAttributes = file( $this->filedir['cloudusers'] . 'userAttributes.csv' );
			$aCloudUserAttributes = array();
			$sHeadline = array_shift($rowsUserAttributes);
			$headline = explode( ';', trim($sHeadline));
			$fieldNumbers = array_flip($headline);
			foreach($rowsUserAttributes as $i=>$row) {
				$line = explode( ';', trim($row));
				$username = $line[ $fieldNumbers['ID'] ];
				foreach($line as $cellId=>$cell) {
					if(
						$headline[$cellId] == 'ID' ||
						$headline[$cellId] == 'QUOTA' ||
						$headline[$cellId] == 'ENABLED' ||
						$headline[$cellId] == 'EMAIL' ||
						substr( $headline[$cellId] , 0 , 4 ) == 'grp_'
					)
					$aCloudUserAttributes[$username][$headline[$cellId]] = $cell;
				}
			}
			return $aCloudUserAttributes;
    }
    
    /**
     * readCloudUsersAndAttributes
     *
     * @param int $exectime
     * @return array
     */
    public function readCloudUsersAndAttributes( $exectime ){
			//if( empty($exectime) ) return;
			$runtime[0] = microtime(true); // actual time in seconds

			$users = $this->getDataFromCloud( '/users' );
			$runtime[1] = microtime(true) - $runtime[0]; // runtime in seconds
			
			foreach($users['USERS']['ELEMENT'] as $usrId){
					$fullfilled = 0;
					$totalRuntime = $runtime[ count($runtime) -1 ];
					if( $totalRuntime > $exectime ) break;
					$fullfilled = 1;
					
					$table[] = $this->getDataFromCloud( '/users/'.$usrId.''  );
					$runtime[count($runtime)] = microtime(true) - $runtime[0]; // total runtime in seconds
			}
			
			// if fullfilled, then write file for comparison with cloudQuotaUtility values
			if( $fullfilled ) {
				$csvData = $this->arrayToCsv( $table );
				if( !empty($csvData) ) {
					if(file_exists($this->filedir['cloudusers'] . 'userAttributes.csv')) unlink($this->filedir['cloudusers'] . 'userAttributes.csv');
					file_put_contents( $this->filedir['cloudusers'] . 'userAttributes.csv' , $csvData );
				}
			}
			
			return array( 'users'=>$users['USERS']['ELEMENT'] , 'userAttributes'=>$table , 'time'=>$runtime , 'fullfilled'=>$fullfilled );
    }
    
    /**
     * getDataFromCloud
     * calls API to get data an write it to a file
     * or reads the file if call is already done
     * transforms xml-data to array
     *
     * @param string $query URI-part behind URL
     * @return array
     */
    public function getDataFromCloud( $query ){
		$query = trim( $query , '/' ) ;
		
		// if there is already a file with same filename like the query, show cached data
		$filename = $this->filedir['processing'] . str_replace( '/' , '_' , $query) . '.txt';
		
		if( file_exists( $filename ) ){
		
			$xmlData = file_get_contents( $filename );
			
		}else{
		
			$xmlData = $this->callApiRead( $query );
			file_put_contents( $filename , $xmlData );
			
		}
		
		return $this->ocsData2array($xmlData , 'DATA' );
    }
    
    /**
     * callApiRead
     * executes the API call
     *
     * @param string $query URI-part behind URL
     * @return array
     */
    private function callApiRead( $query ){
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, rtrim( $this->cloudProt . $this->cloudUrl , '/' ) . '/' . trim( $query , '/' ) );
 		curl_setopt($curl, CURLOPT_HTTPHEADER, array( 'OCS-APIRequest: true' ) );
		curl_setopt($curl, CURLOPT_USERPWD, $this->cloudUsername.':'.$this->cloudPassword );
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
 		$result = curl_exec($curl);
		curl_close($curl);
		return ($result);
    }
    
    /**
     * callApiUpdate
     * executes the API calls
     *
     * @param int $exectime in seconds
     * @return array
     */
    public function callApiUpdateGroups( $exectime = 10 ){
		$runtime[0] = microtime(true); // actual time in seconds
		$groups = $this->getDataFromCloud( '/groups' );
		$existingGroups = array_flip($groups['GROUPS']['ELEMENT']);
		$fullfilled = 0;
		$markedToRunUser = array();
		$creationResults = array();
		if( file_exists( $this->filedir['cloudusers'] . 'cronjob.addgroups.txt' ) ){
			$jsCheckedValues = file_get_contents( $this->filedir['cloudusers'] . 'cronjob.addgroups.txt' );
			$markedToRunUser = json_decode($jsCheckedValues , true );
			if(!count($markedToRunUser))return;
			$runtime[1] = microtime(true) - $runtime[0]; // runtime in seconds
			foreach($markedToRunUser as $groupname => $row ){
					$fullfilled = 0;
					$totalRuntime = $runtime[ count($runtime) -1 ];
					if( $totalRuntime > $exectime ) break;

					if( !isset($existingGroups[$groupname]) ) {
						$result = $this->execApi( 'POST', 'groupid='.$groupname , '/groups' );
						$creationResults[] =  $this->ocsData2array( $result );
						$errNr = $creationResults[count($creationResults)-1]['STATUSCODE'];
						if( 100 != $errNr && 102 != $errNr ) return array( 'results' => $creationResults , 'fullfilled' => $fullfilled );
						$existingGroups[$groupname] = $groupname;
						$filename = $this->filedir['processing'] . 'groups.txt';
						if(file_exists($filename)) unlink($filename);
					}
					foreach( array_keys($row) as $username ){
						$creationResults[] = $this->apiAddUserToGroup( $username , $groupname );
						$runtime[count($runtime)] = microtime(true) - $runtime[0]; // total runtime in seconds
						$fullfilled = 1;
						unset($markedToRunUser[$groupname][$username]);
					}
			}
		}else{ return array( 'results' => $creationResults , 'fullfilled' => 1 ); }
		if($fullfilled){
			unlink( $this->filedir['cloudusers'] . 'cronjob.addgroups.txt' );
		}elseif( count($markedToRunUser) ){
			$jsCheckedValues = json_encode($markedToRunUser);
			file_put_contents( $this->filedir['cloudusers'] . 'cronjob.addgroups.txt' , $jsCheckedValues );
		}
		return array( 'results' => $creationResults , 'fullfilled' => $fullfilled );
		
    }
    
    /**
     * callApiUpdate
     * executes the API calls
     *
     * @param int $exectime in seconds
     * @return array
     */
    public function callApiUpdateUsers( $exectime = 10 ){
		$creationResults = array();
		$runtime[0] = microtime(true); // actual time in seconds
		$groups = $this->getDataFromCloud( '/groups' );
		$existingGroups = array_flip($groups['GROUPS']['ELEMENT']);
		
		$markedToRunUser = array();
		if( file_exists( $this->filedir['cloudusers'] . 'cronjob.addusers.txt' ) ){
			$jsCheckedValues = file_get_contents( $this->filedir['cloudusers'] . 'cronjob.addusers.txt' );
			$markedToRunUser = json_decode($jsCheckedValues , true );
		}
		if(!count($markedToRunUser))return array( 'results' => $creationResults , 'fullfilled' => 1 );
		
		$runtime[1] = microtime(true) - $runtime[0]; // runtime in seconds
		foreach($markedToRunUser as $username => $row ){
				$fullfilled = 0;
				$totalRuntime = $runtime[ count($runtime) -1 ];
				if( $totalRuntime > $exectime ) break;

				$firstGroup = array_shift( $row['groups'] );
				if( !isset($existingGroups[$firstGroup]) ) {
					$result = $this->execApi( 'POST', 'groupid='.$firstGroup , '/groups' );
					$creationResults[] =  $this->ocsData2array( $result );
					$errNr = $creationResults[count($creationResults)-1]['STATUSCODE'];
					if( 100 != $errNr && 102 != $errNr ) return array( 'results' => $creationResults , 'fullfilled' => $fullfilled );
					$existingGroups[$firstGroup] = $firstGroup;
				}
				$creationResults[] = $this->apiCreateUser( $username , 'Mypassw0.rd' , $row['email'] , $row['quota'] , $firstGroup );
				$runtime[count($runtime)] = microtime(true) - $runtime[0]; // total runtime in seconds
				$fullfilled = 1;
				unset($markedToRunUser[$username]);
		}
		
		if($fullfilled){
			unlink( $this->filedir['cloudusers'] . 'cronjob.addusers.txt' );
		}elseif( count($markedToRunUser) ){
			$jsCheckedValues = json_encode($markedToRunUser);
			file_put_contents( $this->filedir['cloudusers'] . 'cronjob.addusers.txt' , $jsCheckedValues );
		}
		// let the script read users again on next call
		if( file_exists( $this->filedir['processing'] . 'users.txt' ) ) unlink( $this->filedir['processing'] . 'users.txt' );
		
		return array( 'results' => $creationResults , 'fullfilled' => $fullfilled );
    }
    
    /**
     * apiCreateUser()
     * executes the API call
     *
     * @param string $user 
     * @param string $password 
     * @param string $email
     * @param string $quota
     * @param string $group
     * @return array
     */
    public function apiCreateUser( $user , $password , $email , $quota , $group ){
		$startRuntime = microtime(true); // actual time in seconds
		// create user
		$createResult = $this->execApi( 'POST', 'userid='  . $user .  '&password=' . $password , '/users' );
		$runtime[] = microtime(true) - $startRuntime; // runtime in seconds
		$result[] = array( 'res' => $this->ocsData2array( $createResult ) , 'time' => $runtime );
		// return if create user failed
		if( 100 != $result[count($result)-1]['STATUSCODE'] ) return $result;
		
		// set email
		$createResult = $this->execApi( 'PUT', 'key=email&value=' . $email  , '/users/' . $user );
		$runtime[] = microtime(true) - $startRuntime; // runtime in seconds
		$result[] = array( 'res' => $this->ocsData2array( $createResult ) , 'time' => $runtime );
		// set quota
		$sQuota = is_numeric( $quota ) ? $quota.'GB' : $quota;
		$createResult = $this->execApi( 'PUT', 'key=quota&value=' . $sQuota , '/users/' . $user );
		$runtime[] = microtime(true) - $startRuntime; // runtime in seconds
		$result[] = array( 'res' => $this->ocsData2array( $createResult ) , 'time' => $runtime );
		// add to group
		$createResult = $this->execApi( 'POST', 'groupid='  . $group  , '/users/' . $user . '/groups' );
		$runtime[] = microtime(true) - $startRuntime; // runtime in seconds
		$result[] = array( 'res' => $this->ocsData2array( $createResult ) , 'time' => $runtime );
		return $result;
	}
    
    /**
     * apiAddUserToGroup()
     * executes the API call
     *
     * @param string $user 
     * @param string $group 
     * @return array
     */
    public function apiAddUserToGroup( $user , $group ){
		$result = $this->execApi( 'POST', 'groupid='.$group , '/users/' . $user . '/groups' );
		return $this->ocsData2array( $result );
	}
    
    /**
     * apiRemoveUserFromGroup()
     * executes the API call
     *
     * @param string $user 
     * @param string $group 
     * @return array
     */
    public function apiRemoveUserFromGroup( $user , $group ){
		$result = $this->execApi( 'DELETE', 'groupid='.$group , '/users/' . $user . '/groups' );
		return $this->ocsData2array( $result );
	}
    
    /**
     * execApi
     * executes the API calls
     *
     * @param string $method CUSTOMREQUEST [ POST | GET | DELETE ]
     * @param string $data POSTFIELDS
     * @param string $query uri-part
     * @return array
     */
    public function execApi( $method , $data , $query ){
		 $aHeaderdata = array( 
			'OCS-APIRequest: true' , 
			'Content-Type: application/x-www-form-urlencoded'
		);
		$curl = curl_init( $this->cloudProt . $this->cloudUsername.':'.$this->cloudPassword.'@' . $this->cloudUrl . $query );
		curl_setopt($curl, CURLOPT_HTTPHEADER, $aHeaderdata );
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method );
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$result = curl_exec($curl);
		curl_close($curl);
		return $result;
    }
    
    /**
     * ocsData2array
     *
     * @param string $xmlData  as string
     * @param string $varToReturn META or DATA
     * @return array
     */
    public function ocsData2array( $xmlData , $varToReturn = 'META' ){
	    $att = $this->xmClass->XMLtoArray( $xmlData );
	    return is_array($att['OCS'][$varToReturn]) ? $att['OCS'][$varToReturn] : array();
    }

	/**
	 * dwn_arrayToCsv
	 * 
	 * @param array $aTable
	 * @param array $options
	 * @return string
	 */
	protected function arrayToCsv( $aTable , $options = array( 'fieldseparer' => ';' , 'textbrace' => '"' ) ) {
			$c = $options['fieldseparer'];
			$t = $options['textbrace'];
			/// evaluate amount of fields
			$titlerow = array();
			foreach( $aTable as $idx => $row){
					foreach( $row as $fld => $cnt){
						if( $fld == 'QUOTA' ){
							if( is_array($cnt) ){
								foreach( $cnt as $subFld => $subCnt){
									$titlerow['Q'][$subFld] = $subFld;
								}
							}
						}elseif( $fld == 'GROUPS' ){
							if( is_array($cnt['ELEMENT']) ){
								for( $z=1 ; $z<=count($cnt['ELEMENT']) ; ++$z){
									$titlerow['G']['grp_'.$z] = $z;
								}
							}else{
								$titlerow['G']['grp_1'] = 1;
							}
						}elseif( !isset($titlerow['F'][$fld]) ){
							$titlerow['F'][$fld] = $fld;
						}
					}
			}

			$csvOut = implode( $c , $titlerow['F'] ) . $c;
			$csvOut .= implode( $c , array_keys($titlerow['Q']) ) . $c;
			$csvOut .= implode( $c , array_keys($titlerow['G']) ) . "\n";

			foreach( $aTable as $idx => $row){
				foreach( $titlerow['F'] as $fld ){
					$rawArray[$idx][$fld] = isset($row[$fld]) ? $row[$fld]: '';
				}
				if( isset($row['QUOTA']) ){
					foreach( $row['QUOTA'] as $subFld => $subCnt ){
						if( $subFld == 'RELATIVE' ){
							$rawArray[$idx][$subFld] = $subCnt;
						}elseif( is_numeric($subCnt) ){
							$rawArray[$idx][$subFld] = round( $subCnt / (1024*1024*1024) , 3);
						}else{
							$rawArray[$idx][$subFld] = $subCnt;
						}
					}
				}else{
					if( is_array($titlerow['Q']) )foreach( $titlerow['Q'] as $subFld => $subCnt ) $rawArray[$idx][$subFld] = '';
				}
				if( isset($row['GROUPS']) ){
					if( is_array($row['GROUPS']['ELEMENT']) ){
						foreach( $row['GROUPS']['ELEMENT'] as $i => $subCnt ) $rawArray[$idx]['grp_'.($i+1)] = $subCnt;
						$iGrp = count($row['GROUPS']['ELEMENT'])+1;
					}else{
						$rawArray[$idx]['grp_1'] = $row['GROUPS']['ELEMENT'];
						$iGrp = 1;
					}
					for( $z = $iGrp+1 ; $z <= count($titlerow['G']) ; ++$z) $rawArray[$idx]['grp_'.$z] = '';
				}else{
					foreach( $titlerow['G'] as $subFld => $subCnt ) $rawArray[$idx][$subFld] = '';
				}
				$csvOut .= implode( $c , $rawArray[$idx] ) . "\n";
			}
			return $csvOut;
	}
    
}
