<?php
namespace Mff\MffCloud\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class IntranetUsersUtility
 */

class IntranetUsersUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\CloudquotaRepository
	 */
	protected $cloudquotaRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\TeacherRelationRepository
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	/**
	 * cloudquota
	 *
	 * @var array
	 */
	protected $cloudquota = array();

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {
			
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']);

	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);

	      $pidArr['studentPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
	      $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $userQuerySettings->setRespectStoragePage(TRUE);
	      $userQuerySettings->setStoragePageIds($pidArr);

	      $this->fachbereichRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachbereichRepository');
	      $this->fachbereichRepository->setDefaultQuerySettings($this->querySettings);

	      $this->teacherRelationRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\TeacherRelationRepository');
	      $this->teacherRelationRepository->setDefaultQuerySettings($this->querySettings);

	      $this->ecouserRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
	      $this->ecouserRepository->setDefaultQuerySettings($userQuerySettings);

	      $this->cloudquotaRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\CloudquotaRepository');
	      $this->cloudquotaRepository->setDefaultQuerySettings($this->querySettings);
	      
	      $this->readQuotas();
	}

	/**
	* dwnDocument_allUsers
	* teacher quota and groups from Database
	* students groups from File
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function readIntranetUsersAndCloudgroups($now=0) {
		if($now == FALSE ) $now = time();
		$tabelleKontingente = array();
 		$fieldAmount = 0;
		$teaEcouserGroups = $this->getTeacherFachbereich();
		foreach( $teaEcouserGroups as $teaRow ){
		    if( isset($tabelleKontingente[$teaRow['username']]) ){
				if($tabelleKontingente[$teaRow['username']]['quota'] < $teaRow['quota']) $tabelleKontingente[$teaRow['username']] = $teaRow;
		    }else{
				$tabelleKontingente[$teaRow['username']] = $teaRow;
		    }
			// count number of Fields
		    $trc = 0;
			foreach( $teaRow as $fld => $cnt ){ if(!empty($cnt)) ++$trc;}
			if( $trc > $fieldAmount ) $fieldAmount = $trc;
		}
		// merge with students from File, text-values possably embraced with "
		$aStudFromFile = $this->getStudentGroupFromFile();
		foreach( $aStudFromFile as $teaRow ){
		    if( isset($tabelleKontingente[$teaRow['username']]) ){
				if($tabelleKontingente[$teaRow['username']]['quota'] < $teaRow['quota']) $tabelleKontingente[$teaRow['username']] = $teaRow;
		    }else{
				$tabelleKontingente[$teaRow['username']] = $teaRow;
		    }
		}
		ksort($tabelleKontingente);
		$headrow = array('username','firstname','lastname','email','quota');
		for( $z=1 ; $z <= ( $fieldAmount - 5) ; ++$z ) $headrow[] = 'grp_' . $z;
		array_unshift( $tabelleKontingente , $headrow );
		return $tabelleKontingente;
		
		// teacher quota from Database fe_user 
		// or if in fachbereich then default-quota from quotaUidTeacher
// 		$fieldAmount = 0;
		$teaEcouserGroups = $this->getTeacherFachbereich();
		foreach( $teaEcouserGroups as $teaRow ){
		    $tabelleKontingente[($teaRow['quota']) .'.'. $teaRow['username']][$teaRow['username']] = $teaRow;
			// count number of Fields
// 		    $trc = 0;
// 			foreach( $teaRow as $fld => $cnt ){ if(!empty($cnt)) ++$trc;}
// 			if( $trc > $fieldAmount ) $fieldAmount = $trc;
		}
		
		// merge with students from File, text-values possably embraced with "
		$aStudFromFile = $this->getStudentGroupFromFile();
		foreach( $aStudFromFile as $teaRow ){
		    $tabelleKontingente[($teaRow['quota']) .'.'. $teaRow['username']][$teaRow['username']] = $teaRow;
		}
		
		// sort output, substitute index with username
		ksort($tabelleKontingente);
		foreach($tabelleKontingente as $quota=>$sortows){foreach($sortows as $sortow){$out[$sortow['username']]=$sortow;}}
		
		// insert head-row
// 		$headrow = array('username','email','quota');
// 		for( $z=3 ; $z< $fieldAmount ; ++$z ) $headrow[ $z ] = 'grp_' . ($z-2);
// 		array_unshift( $out , $headrow );
		
		return $out;
	}

	/**
	* public function dwnDocument_allUsers ( $now = 0 )
	* renamed to readIntranetUsersAndCloudgroups
	*/

	public function getStudentGroupFromFile() {
		$classKontingent = $this->getClassQuotaUid($now);
		$iconnFile = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( rtrim( PATH_site , '/' ) . '/' . 'uploads/tx_mffimport/iconn/iconnusers.csv' );
		if( file_exists( $iconnFile ) ){
			$iconArr = file( $iconnFile );
			$firstRow = array_shift( $iconArr );
			$aHeadrow = array_flip(explode( ';' , str_replace( '"' , '' , trim($firstRow))));
			foreach( $iconArr as $id=> $row) {
				$dsRw =$row;
// 				$dsRw = iconv( 'ISO-8859-15' , 'UTF-8//TRANSLIT' , $row);
				$aRw = explode( ';' , str_replace( '"' , '' , trim($dsRw) ) );
				$tab = array();
				if(!$aRw[ $aHeadrow['Benutzername'] ]) continue;
				if(!$aRw[ $aHeadrow['EMail'] ]) continue;
				$tab['username'] = $aRw[ $aHeadrow['Benutzername'] ];
				$tab['firstname'] = $aRw[ $aHeadrow['Vorname'] ];
				$tab['lastname'] = $aRw[ $aHeadrow['Nachname'] ];
				$tab['email'] = $aRw[ $aHeadrow['EMail'] ];
				// quota
				$key = trim($aRw[ $aHeadrow['Klassen'] ]);
				$tab['quota'] = $this->cloudquota[ $classKontingent[$key] ];
				$tab['quota'] = trim(str_replace( 'GB' , '' , $tab['quota']));
				if(empty($tab['quota'])) $tab['quota'] = $this->cloudquota[ $this->settings['quotaUidZero'] ];
				// insert scoolclass as first group
				$tab['grp_1'] = trim($aRw[ $aHeadrow['Klassen'] ]);
				// empty cells for unused groups
				// for( $z=4 ; $z< $fieldAmount ; ++$z ) $tab['grp_' . ($z-2)] = '';
				// store in an array 
				$tabelleKontingente[$tab['username']] =$tab;
			}
		}
		return $tabelleKontingente;
	}

	/**
	* public function dwnDocument_allUsers ( $now = 0 )
	* renamed to readIntranetUsersAndCloudgroups
	*/

	public function getTeacherFachbereich() {
		$fachbereiches = $this->fachbereichRepository->findAll();
		$fbTeachers = $this->teacherRelationRepository->findAll();
		// $fachbereichCloudKey: GruppeBezeichnung aus Fachbereich
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    $cloudKey = $fb->getCloudKey();
		    if(!empty($cloudKey)) $fachbereichCloudKey[$uid] = $cloudKey;
		}
		// $teaEcouser: Fachbereiche der Lehrpersonen
		$teaEcouser = array();
		foreach( $fbTeachers as $tea ){
		    $user = $tea->getTeaEcouser();
		    if( !empty($user) ) {
				$uid = $user->getUid();
				$teaFb = $tea->getFachbereich();
				if(!isset($teaEcouser[$uid]['username'])) {
					$username = $user->getUsername();
					if( strpos( $username , '.' ) == 0) continue; // user .nn (n.n.)
					$teaEcouser[$uid]['username'] = $username;
					$teaEcouser[$uid]['firstname'] = $user->getFirstName();
					$teaEcouser[$uid]['lastname'] = $user->getLastName();
					$teaEcouser[$uid]['email'] = $user->getEmail();
					$teaEcouser[$uid]['quota'] = $user->getCloudQuota();
				}
				if(!empty($fachbereichCloudKey[$teaFb])) $teaEcouser[$uid]['grp'][] = $this->settings['csv_options']['fachbereich_prefix'].$fachbereichCloudKey[$teaFb];
		    }
		}
		// $rowCount: Anzahl Gruppen ermitteln
		$rowCount = 0;
		foreach( $teaEcouser as $uid=>$teaRow ){
		    if( '.nn' == $teaRow['username'] ) continue;
		    if( empty($teaRow['email']) ) continue;
		    $gidCount = count($teaRow['grp']);
		    if( $gidCount > $rowCount ) {$rowCount = $gidCount;}
// 		    $trc = 0;
// 			if(count($teaRow['grp'])){foreach( $teaRow['grp'] as $fld => $cnt ){ if(!empty($cnt)) ++$trc;}}
// 			if( $trc > $rowCount ) $rowCount = $trc;
		}
		// $tabelle: Output Lehrpersonen und Fachbereiche zusammenziehen
		$tabelle = array();
		foreach( $teaEcouser as $uid=>$teaRow ){
		    if( !is_array($teaRow['grp']) ) continue;
		    if( strpos( $teaRow['username'] , '.' ) == 0) continue;
		   // $uid = $teaRow['username'];
		    $tabelle[$uid]['username'] = $teaRow['username'];
		    $tabelle[$uid]['firstname'] = $teaRow['firstname'];
		    $tabelle[$uid]['lastname'] = $teaRow['lastname'];
		    $tabelle[$uid]['email'] = $teaRow['email'];
		    $tabelle[$uid]['quota'] = !empty($teaRow['quota']) ? trim(str_replace( 'GB' , '' , $teaRow['quota'])) : $this->cloudquota[ $this->settings['quotaUidTeacher'] ];
		    sort($teaRow['grp']);
		    for( $gid = 0 ; $gid < $rowCount ; ++$gid ){
				$rNr = $gid+1;
				if(isset($teaRow['grp'][$gid])) $tabelle[$uid]['grp_'.$rNr] = $teaRow['grp'][$gid];
				//$tabelle[$uid]['grp_'.$rNr] = isset($teaRow['grp'][$gid]) ? $teaRow['grp'][$gid]: '';
		    }
		}
		return $tabelle;
	}
	
	/**
	* getClassQuotaUid
	* creates array $klasseKontingent with Quota per Klasse
	* 
	* @param int $now timestamp or empty
	* @return array
	*/
	public function getClassQuotaUid($now=0) {
		if($now == FALSE ) $now = time();
		$klasseKontingent = array();
		$fachbereiches = $this->fachbereichRepository->findAll();
		$today = floor( $now / (3600*24) ) * 3600 * 24;
		foreach( $fachbereiches as $fb ){
		    $uid = $fb->getUid();
		    // teachers FachbereichTeacherQuotaUid
		    $fbCloudKey = $this->settings['csv_options']['fachbereich_prefix'] . $fb->getCloudKey();
		    $klasseKontingent[$fbCloudKey] = $this->settings['quotaUidTeacher'];
		    // students classQuotaUid
		    $fbKurzklassen = $fb->getFbKurzklassen();
		    if(empty($fbKurzklassen)) continue;
		    foreach( $fbKurzklassen as $krzKlasse ){
				$quotaUid = $krzKlasse->getKrzCloudquota();
				$klassen = $krzKlasse->getKrzKlassen();
				if(empty($klassen)) continue;
				foreach( $klassen as $klasse ){
					$clsId =  trim($klasse->getClassShort());
					$clsEnd = $klasse->getKlasseEnde();
					if(empty($clsId)) continue;
					if($clsEnd >= $today){
						$klasseKontingent[$clsId] = $quotaUid->getUid();
					}else{
						$klasseKontingent[$clsId] = $this->settings['quotaUidZero'];
					}
				}
		    }
		}
		return $klasseKontingent;
	}

	/**
	* readQuotas
	* initialiize quota array
	* @return array
	*/
	public function readQuotas() {
		// $cloudQuota: Quotas.Array
		$cloudquotas = $this->cloudquotaRepository->findAll();
		foreach( $cloudquotas as $quota ) $this->cloudquota[ $quota->getUid() ] = trim(str_replace( 'GB' , '' , $quota->getSpeicherplatz() ));
	}
	
	/**
	* compareDatabaseWithClouddata
	* 
	* @param array $dbData     array from this->readIntranetUsersAndCloudgroups()
	* @param array $cloudData  array from CloudUsersUtility-readFromFile_CloudUsersAndAttributes()
	* @return array
	*/
	public function compareDatabaseWithClouddata( $dbData , $cloudData ) {
			$classKontingent = $this->getClassQuotaUid($now);
			$responseArr = array();
			
			$src = array( $dbData , $cloudData );
			// sub-array for groups
			if(!is_array($src)) return $responseArr;
			
			foreach( $src as $tabIx => $table ){
				if(is_array($table)){foreach( $table as $username => $dbRow ){
					if(is_array($dbRow)){foreach($dbRow as $field => $content ){
						if( substr( $field , 0 , 4 ) == 'grp_' && !empty($content) ){ 
							$src[$tabIx][$username]['groups'][$content] = $content; 
 							unset($src[$tabIx][$username][$field]); 
						}
					}}
				}}
			}
			
			$dbLabel = array( '' , 'cloud' );
			$attLabel = array( 'MaybeObsolete' , 'Missed' );

			foreach( $src as $tableIx => $table ){
				if(is_array($table)){foreach( $table as $username => $dbRow ){
						$otherTable = ( $tableIx-1 ) * ( $tableIx-1 ) ;
						if($dbRow['grp_1'] == 'admin') continue;
						if($dbRow['grp_1'] == 'fachbereich-daten') continue;
						if( !isset($src[$otherTable][$username]) ){
							$students = $this->ecouserRepository->findByUsername( $username );
							if( count($students) ) $responseArr[$dbLabel[$otherTable].'Users'.$attLabel[$otherTable]][$username] = $dbRow;
						}else{
							if(is_array($dbRow['groups'])){foreach($dbRow['groups'] as $colName => $groupname ){
									if(empty($groupname) ) continue;
									if( !isset($src[$otherTable][$username]['groups'][$groupname]) ){
										// set user missing or overdue in group
										$responseArr[$dbLabel[$otherTable].'Group'.$attLabel[$otherTable]][$groupname]['users'][$username] = $src[$otherTable][$username];
									}
							}}
						}
				}}
			}
			if(is_array($responseArr['cloudGroupMissed'])){foreach( $responseArr['cloudGroupMissed'] as $groupname => $grouprow ){
					// set quota for all users
					$responseArr['cloudGroupMissed'][$groupname]['quota'] = $this->cloudquota[ $classKontingent[$groupname] ];
			}}
			if(is_array($responseArr['GroupMaybeObsolete'])){foreach( $responseArr['GroupMaybeObsolete'] as $groupname => $grouprow ){
				foreach( $grouprow['users'] as $username => $row ){
					$responseArr['GroupMaybeObsolete'][$groupname][$username] = $row;
				}
				unset($responseArr['GroupMaybeObsolete'][$groupname]['users']);
			}}
			return $responseArr;
	}

}
