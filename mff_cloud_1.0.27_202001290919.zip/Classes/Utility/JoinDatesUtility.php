<?php
namespace Mff\MffCloud\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class JoinDatesUtility
 */

class JoinDatesUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * csvOptions
	 *
	 * @var array
	 */
	protected $csvOptions = array('encoding' => 'ISO-8859-15' ,'in_delimiter' => ';' ,'text_qualifier' => '"' ,'ascii_replace' => '11:0,150:45,151:45');
	
	/**
	 * filename
	 *
	 * @var string
	 */
	protected $filename = '';
	
	/**
	 * table
	 *
	 * @var array
	 */
	protected $table =  array();
	
	/**
	 * fieldnames
	 *
	 * @var array
	 */
	protected $fieldnames =  array();

	/**
	 * kalenderRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KalenderRepository
	 */
	protected $kalenderRepository = NULL;
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct() {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);

	      $this->kalenderRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KalenderRepository');
	      $this->kalenderRepository->setDefaultQuerySettings($this->querySettings);
	}
	
	/**
	 * readTable
	 * returns array table
	 *
	 * @param string $filename
	 * @return void
	 */
	public function readTable( $filename ) {
			$this->filename = $filename;
			$shortTable = array();
			$csvUtil = new \Mff\Mffplan\Utility\CsvToArrayUtility( $this->csvOptions );
			$fullTable = $csvUtil->CsvToArray( $filename ) ;
			$this->table = $this->joinDateFields( $fullTable );
			if(count($this->table)){
// 				$this->table = $this->shrinkByDate();
				$this->table = $this->shrinkByTime( 15 );
 				$this->table = $this->adjustRoom();
 				$shortTable = $this->redimTable();
			}
			return $shortTable;
	}
	
	/**
	 * joinDateFields
	 * returns array with shrunken table
	 *
	 * @param array $fullTable
	 * @return string
	 */
	public function joinDateFields( $fullTable ) {
			// Fields: "Wochentag";"Zeit_von";"Zeit_bis";"Datum_von";"Datum_bis";"Periodizitaet";"Periode";"Klasse";"Angebot";"Fach";"Fachprefix";"Lehrer";"Gebaeude";"Raum";"Anz_Wochenlek"
			$this->fieldnames = array_flip( array_shift( $fullTable ) );
			$fldDatumVon = $this->fieldnames['Datum_von'];
			$fldDatumBis = $this->fieldnames['Datum_bis'];
			foreach( $fullTable as $row ){
					$day = substr($row[$this->fieldnames['Datum_von']] , 0 , 2) ;
					$month = substr($row[$this->fieldnames['Datum_von']] , 2 , 2) ;
					$year = substr($row[$this->fieldnames['Datum_von']] , 4 , 4) ;
					$prsIx = $row[$this->fieldnames['Angebot']] . '.' . 
								$row[$this->fieldnames['Fach']] . '.' . 
								$row[$this->fieldnames['Lehrer']] . '.' . 
								$row[$this->fieldnames['Wochentag']] . '.' . 
								$row[$this->fieldnames['Raum']] . '.' . 
								$row[$this->fieldnames['Zeit_von']] ;
					$datelessRow[ $year . '.' . $month . '.' . $day ][ $prsIx ] = $row;
			}
			
			if( !count($datelessRow) ) return array();
 			ksort($datelessRow);
			foreach( array_keys($datelessRow) as $i ) {
				ksort($datelessRow[$i]); 
			}
			
			return  $datelessRow ;
    }
	
	/**
	* shrinkByDate
	*
	* @return array
	*/
	public function shrinkByDate() {
			$table = $this->table;
					$firstUxDate = time() * 2;
					$lastUxDate = 0;
					foreach( array_keys($table) as $i ) {
							$dateArr =explode('.' , $i );
							$aktDate = mktime(12,0,0,$dateArr[1],$dateArr[2],$dateArr[0]);
							if( $aktDate > $lastUxDate ) $lastUxDate = $aktDate;
							if( $aktDate < $firstUxDate ) $firstUxDate = $aktDate;
					}
					$nextWeek = $this->mkArrayNextWeek( $firstUxDate , $lastUxDate );
					
					foreach( $table as $date => $classGroup ) {
							$aDate = explode( '.' , $date );
							$uxDateStart = mktime( 12,0,0, $aDate[1] , $aDate[2] , $aDate[0] );
							foreach( $classGroup as $ownIx => $row) {
									// loop weekwise from startdate to last possible date
									// and join weeks
									for( $loopDay = $uxDateStart+(7*3600*24) ; $loopDay <= $lastUxDate ; $loopDay+=(7*3600*24)){
											$ttdate = date( 'Y.m.d' , $loopDay );
											$caldate = date( 'Ymd' , $loopDay );
											if( isset( $table[$ttdate][$ownIx] ) ){
											//		$table[$date][$ownIx][ $rowNames['Datum_bis'] ] = date( 'dmY' , $loopDay );
													unset( $table[$ttdate][$ownIx] );
											}elseif( isset( $nextWeek[$caldate] ) ){
													$calNewDate = date( 'Y.m.d' ,$nextWeek[$caldate]);
													if( isset( $table[$calNewDate][$ownIx] ) ){
											//				$table[$date][$ownIx][ $rowNames['Datum_bis'] ] = date( 'dmY' ,$nextWeek[$caldate]);
															unset( $table[$calNewDate][$ownIx] );
													}
											}
									}
							}
							if(!count($table[$date])) unset($table[$date]);
					}
					return $table;
	}

	/**
	 * mkArrayNextWeek
	 * returns array with date as key and nextweek-date as value
	 *
	 * @param int $firstUxDate
	 * @param int $lastUxDate
	 * @return string
	 */
	public function mkArrayNextWeek( $firstUxDate , $lastUxDate ) {
 			$alleKalender = $this->kalenderRepository->findByPrivat( '0' );
			$nextWeek = array();
			$sNextWeek = array();
			foreach($alleKalender as $objCal){
				$ganztag = $objCal->getGanztag();
				if( !$ganztag ) continue;
				$cal = array( 'beginn' => $objCal->getBeginn()+(12*3600) , 'ende' => $objCal->getEnde()+(12*3600) );
				if( empty( $cal['beginn'] ) ) continue;
				if( $cal['ende'] < $firstUxDate ) continue;
				if( $cal['beginn'] > $lastUxDate ) continue;
				$newTo = $cal['beginn']+round( ($cal['ende']-$cal['beginn']) / (3600*24) ) * (3600*24);
				// step through each day and set startday, copy old endday
				for( $akt = $cal['beginn'] ; $akt <= $cal['ende'] ; $akt += (3600*24*1) ){
						$calendar[$akt] = $objCal->getFerientext() . ' - '.date('d.m.y',$cal['ende']);
						$nextWeek[$akt] = $cal['ende'] ;
				}
			}
			ksort( $nextWeek );
			// step through each day and set endday corresponding to weekday
			foreach( $nextWeek as $akt => $oldDateTo ) {
				$endWeekday = date( 'N' , $oldDateTo );
				$wdAkt = date('N',$akt);
				if( $wdAkt > $endWeekday ){
					$daysToAdd = $wdAkt - $endWeekday;
				}else{
					$daysToAdd = 7-( $endWeekday - $wdAkt );
				}
				$newDate = $oldDateTo + ( 3600 * 24 * $daysToAdd );
				$sNextWeek[date( 'Ymd' , $akt )] =  $newDate ;
			}
			return $sNextWeek;
    }
	
	/**
	* groupByRoom
	*
	* @return array
	*/
	public function adjustRoom() {
			$outTable = $this->table;
			foreach( $this->table as $i=> $groups ) {
					foreach( $groups as $ownIx=>$row ) {
							$aZmr = explode( ' ' , $row[$this->fieldnames['Raum']] );
							$outTable[$i][$ownIx][$this->fieldnames['Raum']] = trim( array_pop( $aZmr ) );
							$outTable[$i][$ownIx][$this->fieldnames['Gebaeude']] = trim( array_shift( $aZmr ) );
					}
			}
			return $outTable;
	}
	
	/**
	* shrinkByTime
	*
	* @param int $maxBreakMinutes
	* @return array
	*/
	public function shrinkByTime( $maxBreakMinutes = 15 ) {
			$deepTable = array();
			$outTable = array();
			$table = $this->table;
			foreach( $table as $dateStart => $groups ) {
					foreach( $groups as $teaClasTime => $row ) {
							$aIx = explode('.' , $teaClasTime);
							$deepTable[$dateStart][implode('.',array_slice($aIx,0,5))][$aIx[5]] = $row;
					}
					foreach($deepTable[$dateStart] as $blockIx => $blockRows ){
							$lastEnd = 0;
							$lastIndex = 0;
							foreach($blockRows as $timeIx => $row ){
									$aThisStart = explode( ':' , $timeIx );
									$thisStart = $aThisStart[0] * 60 + $aThisStart[1];
									$aThisEnd = explode( ':' , $row[$this->fieldnames['Zeit_bis']] );
									$thisEnd = $aThisEnd[0] * 60 + $aThisEnd[1];
									if( $lastEnd + $maxBreakMinutes >= $thisStart ){
										$deepTable[$dateStart][$blockIx][$lastIndex][$this->fieldnames['Zeit_bis']] = $row[$this->fieldnames['Zeit_bis']];
										unset( $deepTable[$dateStart][$blockIx][$timeIx] );
									}else{
										$lastIndex = $timeIx;
									}
									$lastEnd = $thisEnd;
							}
					}
					foreach($deepTable[$dateStart] as $blockIx => $blockRows ){
							foreach($blockRows as $timeIx => $row ){
									$outTable[$dateStart][$blockIx . '.' . $timeIx ] = $row;
							}
					}
			}
// 			array_unshift( $outTable , array_flip($this->fieldnames) );
			return $outTable;
	}
	
	/**
	* groupByRoom
	*
	* @return array
	*/
	public function redimTable() {
			foreach( $this->table as $i=> $groups ) {
					foreach( $groups as $ownIx=>$row ) {
							$shortTable[] = $row;
					}
			}
			array_unshift( $shortTable , array_flip($this->fieldnames) );
			return $shortTable;
	}
	
	public function getTable(){
		return $this->table;
	}
	
	public function getFieldnames(){
		return $this->fieldnames;
	}

	/**
	 * downloadAsCsv
	 *
	 * @param int $shortTable
	 * @return void
	 */
	public function downloadAsCsv($shortTable) {
			foreach($shortTable as $row){
					$textString .=  implode( ';' , $row ) .  "\n";
			}
			header('Content-Type: application/force-download');
			header('Content-Type: application/xls');
			header("Content-Transfer-Encoding: Binary");
			header("Content-disposition: attachment; filename=compressed_".pathinfo($this->filename,PATHINFO_FILENAME).'.csv');
			print($textString);
			exit();
    }
}
