<?php
namespace Mff\MffCloud\Domain\Model;

/***
 *
 * This file is part of the "CloudAccess" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * Accesspoints
 */
class Accesspoints extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * Name of remote access diirectory
     *
     * @var string
     */
    protected $remoteDir = '';

    /**
     * username
     *
     * @var string
     */
    protected $username = '';

    /**
     * Returns the remoteDir
     *
     * @return string $remoteDir
     */
    public function getRemoteDir()
    {
        return $this->remoteDir;
    }

    /**
     * Sets the remoteDir
     *
     * @param string $remoteDir
     * @return void
     */
    public function setRemoteDir($remoteDir)
    {
        $this->remoteDir = $remoteDir;
    }

    /**
     * Returns the username
     *
     * @return string $username
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Sets the username
     *
     * @param string $username
     * @return void
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }
}
