<?php
namespace Mff\MffCloud\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2017
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * BackendLayoutController
 */
class BackendLayoutController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);

	      $this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($this->querySettings);
	}

    /**
     * action list
     * Listenvergleich
     * compares files: userCloud.csv, userTeacher.csv, userStudents.csv
     *
     * @return void
     */
    public function listAction()
    {
		$maindir = rtrim( PATH_site , '/' );
		$this->view->assign('mainDir', $maindir);
		$compareDirectory = "uploads/tx_mffcloud/filecompare";
 		$uploadpath = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($compareDirectory);
		$this->view->assign('path', $uploadpath);
		
		$dateien = array();
		$d = dir($uploadpath);
		while (false !== ($entry = $d->read())) if( 'file' == filetype($d->path.'/'.$entry) ) $dateien[] = $entry;
		$d->close();
		$this->view->assign('dateien', $dateien);
		$isInCloud = array( false => 'lost' , true => 'luky' );
		if( $this->request->hasArgument('start') ){
		      $req = $this->request->getArgument('start');
		      $aCsv['userCloud.csv'] = array_map('str_getcsv', file($uploadpath.'/userCloud.csv'));
		      $aCsv['userTeacher.csv'] = array_map('str_getcsv', file($uploadpath.'/userTeacher.csv'));
		      $aCsv['userStudents.csv'] = array_map('str_getcsv', file($uploadpath.'/userStudents.csv'));
		      foreach($aCsv as $tabName=>$table){
			  foreach($table as $ix=>$namRow){ $persDb[$tabName][ trim($namRow[0]) ] = trim($namRow[0]); }
		      }
		      if(isset($aCsv[$req])){
			    $this->view->assign('fileContent', array( $req=>$persDb[$req]));
		      }else{
		      
			    foreach($persDb['userTeacher.csv'] as $userName){$mailDb[$userName]['source'] = 'userTeacher.csv';$mailDb[$userName]['mail'] = $userName.'@medienformfarbe.ch';}
			    foreach($persDb['userStudents.csv'] as $userName){if(!isset($mailDb[$userName]['mail'])){$mailDb[$userName]['source'] = 'userStudents.csv';$mailDb[$userName]['mail'] = $userName.'@stud.medienformfarbe.ch';}}
			    
			    foreach($mailDb as $username => $row) $outputDb[ $isInCloud[ isset($persDb['userCloud.csv'][$username]) ] ][$row['source']][$username] = $row['mail'];
			    foreach($persDb['userCloud.csv'] as $userName ) if( !isset($mailDb[$userName]['mail']) ) $outputDb['arch']['userCloud.csv'][$userName] = $userName;
			    if(isset($outputDb[$req])){
				  krsort($outputDb[$req]);
				  $this->view->assign('fileContent', $outputDb[$req]);
			    }
		      }
		}
	}

    /**
     * action cloud
     *
     * @param bool $noexec
     * @return void
     */
    public function cloudAction( $noexec = false ){

		$CloudUsersUtility= new \Mff\MffCloud\Utility\CloudUsersUtility();
		
		if ( $this->request->hasArgument('download') ) {
			if( file_exists($CloudUsersUtility->filedir['cloudusers'] . 'userAttributes.csv') ){
				$strUserAttributesFilecontent = file_get_contents( $CloudUsersUtility->filedir['cloudusers'] . 'userAttributes.csv' );
				$this->dwn_downloadAsCsv( $strUserAttributesFilecontent , 'NextcloudUserAttributes.csv' ); 
				return;
			}else{
				$this->addFlashMessage('Datei nicht vorhanden, Import von Cloud API nicht abgeschlossen. ' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
		}
        
		$minExecTime = $this->request->hasArgument('exectime') ? $this->request->getArgument('exectime') :10;
		
	    $this->view->assign('exectime', $minExecTime );
	    
        if( !$this->request->hasArgument('exectime') ){ // enter first time or reload
			return;
		}
			
		// run action if theres is a directive in a file
		// delete old API request-result after running action
		
		// run imports from API if afforable
		$aCloudUsersAndAttributes = $CloudUsersUtility->readCloudUsersAndAttributes( $minExecTime );
		if ( !$aCloudUsersAndAttributes['fullfilled'] ){
			if( $minExecTime ) $this->addFlashMessage('Import von Cloud API nicht abgeschlossen... '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			if( $noexec != true ) $this->view->assign('table', array( 'fromAPI' => $aCloudUsersAndAttributes ) );
			return;
		}
		
		$this->addFlashMessage('Import von Cloud API abgeschlossen. '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$IntranetUsersUtility = new \Mff\MffCloud\Utility\IntranetUsersUtility();
		
		$aIntranetUsers =  $IntranetUsersUtility->readIntranetUsersAndCloudgroups( time() );
		$aCloudUserAttributes = $CloudUsersUtility->readFromFile_CloudUsersAndAttributes();
		
		$compared = $IntranetUsersUtility->compareDatabaseWithClouddata( $aIntranetUsers , $aCloudUserAttributes );
		
		// adding users: get checkbox values from input or file
		if ( $this->request->hasArgument('addUser') ) {
			$chkArr = $this->request->getArgument('addUser');
		}elseif( file_exists($CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addusers.txt') ){
			$jsCheckedValues = file_get_contents( $CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addusers.txt' );
			$chkArr = json_decode( $jsCheckedValues , true );
		}
		// adding users: set checkbox values in $compared for form 
		// and in $markedToRunUser for storing in file for cron
		if( count($compared['cloudUsersMissed']) ){
			foreach( $compared['cloudUsersMissed'] as $usr=>$row){
				$compared['cloudUsersMissed'][$usr]['checked']= !empty($chkArr[$usr]);
				if(!empty($chkArr[$usr])) $markedToRunUser[$usr] = $compared['cloudUsersMissed'][$usr];
			}
		}
		if ( $this->request->hasArgument('addUser') ) {
			$jsCheckedValues = json_encode($markedToRunUser);
			file_put_contents( $CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addusers.txt' , $jsCheckedValues );
		}
		
		// adding groups: get rdiobutton values from input or file
		if ( $this->request->hasArgument('addGroup') ) {
			$radArr = $this->request->getArgument('addGroup');
		}elseif( file_exists($CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addgroups.txt') ){
			$jsCheckedValues = file_get_contents( $CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addgroups.txt' );
			$radArr = json_decode( $jsCheckedValues , true );
		}
		// adding or changing groups: set radiobutton values in $compared for form 
		// and in $markedToRunGroup for storing in file for cron
		if(is_array($compared['cloudGroupMissed'])){
			foreach( $compared['cloudGroupMissed'] as $groupname=>$grouprow){
				foreach( $grouprow['users'] as $usr=>$row){
					$compared['cloudGroupMissed'][$groupname]['users'][$usr]['checked']= $radArr[$groupname][$usr];
					if($radArr[$groupname][$usr]) $markedToRunGroup[$groupname][$usr] = $radArr[$groupname][$usr];
				}
			}
		}
		if ( $this->request->hasArgument('addGroup') ) {
			$jsCheckedValues = json_encode($markedToRunGroup);
			file_put_contents( $CloudUsersUtility->filedir['cloudusers'] . 'cronjob.addgroups.txt' , $jsCheckedValues );
		}
		
		if ( $this->request->hasArgument('exec') && $noexec != true ) {
			$compared['resultFromAdd'] = $CloudUsersUtility->callApiUpdateUsers( $minExecTime );
			if ( $compared['resultFromAdd']['fullfilled'] ){
				$compared['resultFromGroups'] = $CloudUsersUtility->callApiUpdateGroups( $minExecTime );
				if ( $compared['resultFromGroups']['fullfilled'] ) $this->addFlashMessage('Export zu Cloud API abgeschlossen. '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
				if( $minExecTime ) $this->addFlashMessage('Export zu Cloud API nicht abgeschlossen... '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			}
		}
		
		$this->view->assign('table', $compared  );
   
    }

    /**
     * action joindates
     *
     * @return void
     */
    public function joindatesAction() {
		
		$uploadFieldName = 'timetablefile';
		$this->view->assign('uploadFieldName', $uploadFieldName );
		
		$uploadpath = "/uploads/tx_mffcloud/joindates";
		$this->view->assign('path', $uploadpath);
		$maindir = rtrim( PATH_site , '/' );
// 		$maindir = dirname(dirname(dirname(dirname(dirname(dirname(__FILE__))))));
		$this->view->assign('mainDir', $maindir);
		
		$path = $maindir . $uploadpath . '/';
		
		if( $this->request->hasArgument('ok') ) {
				$isUploadet = $this->up_uploadCsvFile( $path , $uploadFieldName , 'UTF-16');
		}elseif( $this->request->hasArgument('delete') ) {
				@unlink( $path . $this->request->getArgument('delete') );
		}

		$files = array_diff(scandir($path), array('.', '..'));
		$this->view->assign('files', $files);
		
		$file = array_shift( $files );
		$filename = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($path . $file);
		
		$shortTable = array();
		if( ( $this->request->hasArgument('ok') || $this->request->hasArgument('download') ) && $file && !$isUploadet  ){
			$joinDatesUtil = new \Mff\MffCloud\Utility\JoinDatesUtility(  );
			$shortTable = $joinDatesUtil->readTable( $filename );
			if( $this->request->hasArgument('download')){
					$joinDatesUtil->downloadAsCsv($shortTable);
			}
		}
		$this->view->assign('table', $shortTable );
// 		$this->view->assign('table', $joinDatesUtil->getTable() );
    }

    /**
     * action details
     * Timetable from Intranet Sek II
     *
     * @return void
     */
    public function detailsAction()
    {
		$ts = $this->configurationManager->getConfiguration('FullTypoScript');
		$this->view->assign('baseURL', $ts['config.']['baseURL']);

		$intranetTimetableUtility = new \Mff\MffCloud\Utility\IntranetTimetableUtility();
		
        $aPeriods = $this->periodsRepository->findAll();
		if($this->request->hasArgument('period')){
			$period = $this->request->getArgument('period');
			foreach( $aPeriods as $aPer) {
				if( $aPer->getUid()== $period){
					$aktPeriode = $aPer; break;
				}
			}
		}else{
			$jetzt = time();
			foreach( $aPeriods as $aPer) {
				if( $aPer->getDavorBis()->format('U') <= $jetzt && $aPer->getDanachAb()->format('U') >= $jetzt){
					$aktPeriode = $aPer; break;
				}
			}
			$period = ($aktPeriode) ? $aktPeriode->getUid() : 0;
		}
        $this->view->assign('periods', $aPeriods );
        $this->view->assign('period', $period );

        if($this->request->hasArgument('ok')||$this->request->hasArgument('download')){
			$foreignTimetable = 1;//1|2
			$rawQueryResult = $intranetTimetableUtility->getCourses($foreignTimetable,$period);
			foreach( $rawQueryResult as $idx => $row){
				$out[$idx] = $intranetTimetableUtility->transformFieldContents( $row , $aktPeriode->getSemester() );
			}
        }
        if($this->request->hasArgument('ok')){
			$this->view->assign('table', $rawQueryResult );
        }elseif ($this->request->hasArgument('download')) {
			$csvOut = $this->dwn_arrayToCsv($out);
			$this->dwn_downloadAsCsv($csvOut);
// 			foreach( $out as $idx => $row){
// 				$csvOut = '"'.implode( '";"' , array_keys($row) ).'"' . "\n";
// 				break;
// 			}
// 			foreach( $out as $idx => $row){
// 				$csvOut .= '"'.implode( '";"' , $row ).'"' . "\n";
// 			}
// // 			$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
// // 			$downloader->downloadAsXls( array('stundenplan'=>$out) );
	    }
     }

	/**
	 * handles file upload and deletion 
	 * returns string with filename, if action successful
	 *
	 * @param string $uploadDir
	 * @param string $fieldname corresponding to field in ViewHelper default 'timetablefile'
	 * @param string $encoding charset of incoming filcontent eg. 'UTF-16' default 'ISO-8859-15'
	 * @return string
	 */
	public function up_uploadCsvFile( $uploadDir , $fieldname = 'timetablefile' , $encoding = 'ISO-8859-15' ) {
		$fileName = '';
		if( !$this->request->hasArgument($fieldname) ) return;
		$extKeyPlgNam = 'tx_mffcloud_user_mffcloudfilecompare';
		if ($_FILES[$extKeyPlgNam]['tmp_name'][$fieldname]) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name'][$fieldname];
			if( file_exists($uploadDir.$fileName) ) @unlink($uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name'][$fieldname] , $uploadDir.$fileName );
 			if( $encoding != 'ISO-8859-15') file_put_contents( $uploadDir.$fileName , iconv( $encoding , 'ISO-8859-15' , file_get_contents($uploadDir.$fileName) ) );
			$this->addFlashMessage('Datei "'.$fileName.'" hochgeladen.'  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}else{
			if( !empty($_FILES[$extKeyPlgNam]['tmp_name'][$fieldname]) ) $this->addFlashMessage('Datei "'.$_FILES[$extKeyPlgNam]['tmp_name'][$fieldname].'" nicht hochgeladen.'  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		}
		return $fileName;
	}

	/**
	 * dwn_arrayToCsv
	 * 
	 * @param array $aTable 
	 * @return string
	 */
	protected function dwn_arrayToCsv($aTable) {
			$headRow = array_shift($aTable);
			$csvOut = ''.implode( ';' , array_keys($headRow) ).'' . "\n";
			foreach( $aTable as $idx => $row){
				$csvOut .= ''.implode( ';' , $row ).'' . "\n";
			}
			return $csvOut;
	}
	/**
	 * @param string $strOut 
	 * @param string $filename
	 */
	protected function dwn_downloadAsCsv($strOut, $filename = 'verarbeitet.csv'
	) {
		$headers = array(
			'Pragma' => 'public',
			'Expires' => 0,
			'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
			'Cache-Control' => 'public',
			'Content-Description' => 'File Transfer',
			'Content-Type' => 'application/vnd.ms-excel',
			'Content-Disposition' => 'attachment; filename="' . $filename . '"',
			'Content-Transfer-Encoding' => 'binary'
		);
		foreach ($headers as $header => $data) {
			$this->response->setHeader($header, $data);
		}
		$this->response->sendHeaders();
		echo $strOut;
		die;
	}

}
