<?php
namespace Mff\MffCloud\Controller;

/***
 *
 * This file is part of the "CloudAccess" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>
 *
 ***/

/**
 * AccesspointsController
 */
class AccesspointsController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * accesspointsRepository
     *
     * @var \Mff\MffCloud\Domain\Repository\AccesspointsRepository
     * @inject
     */
    protected $accesspointsRepository = null;

    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
	      $loginuser = $GLOBALS['TSFE']->fe_user->user['username'];
	      $accesspoints = $this->accesspointsRepository->findByUsername( $loginuser );
	      $this->view->assign('accesspoints', $accesspoints);
	      
	      if( $this->request->hasArgument('view') ){
		      $rsUid = $this->request->getArgument('view');
		      $point = $this->accesspointsRepository->findByUid($rsUid);
		      $directory = $point->getRemoteDir();
		      $username = $point->getUsername();
		      $data = $this->getCloudData( $directory , $username , 10 );
	      }else{
		      $data = array(); 
	      }
	      
		$url = 'https://cloud.sfgz.ch/ocs/v1.php/cloud/users';
		$username = 'daniel_ruegg';
		$cleanPassword = 'D4n137!-';
		
		$data = $this->getCloudUsers( $url  , $username , $cleanPassword );
	      $this->view->assign('data', $data);
return;
// 		$uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['uploadDir'] ) , '/' ) . '/';
// 	    $fullFilePathName = $uploadDir.'xml_pp.xml';
//   	    exec('curl https://daniel_ruegg:D4n137!-@cloud.sfgz.ch/ocs/v1.php/cloud/users -H "OCS-APIRequest: true"'.' > '.$fullFilePathName);
// 	    $result = file_get_contents($fullFilePathName);
	    
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
//  		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PROPFIND');
 		curl_setopt($curl, CURLOPT_HTTPHEADER, array('OCS-APIRequest: true' ) );
 		curl_setopt($curl, CURLOPT_USERPWD, $username.':'.$cleanPassword );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
// 		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
 		$result2 = curl_exec($curl);
		curl_close($curl);
	    $att = $this->XMLtoArray($result2);

// 	    $att = json_decode($result2 , true );
		      $data = array('heissa'=>$result2,'data'=>$att); 
    }
    
    /**
     * getCloudUsers
     *
     * @param string $url
     * @param string $username
     * @param string $cleanPassword
     * @return array
     */
    public function getCloudUsers( $url , $username , $cleanPassword ){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
// 		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PROPFIND');
 		curl_setopt($curl, CURLOPT_HTTPHEADER, array('OCS-APIRequest: true' ) );
 		curl_setopt($curl, CURLOPT_USERPWD, $username.':'.$cleanPassword );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
 		$result = curl_exec($curl);
		curl_close($curl);
	    $att = $this->XMLtoArray($result);

		return $att;
    }
    
    /**
     * getUserData
     *
     * @return string
     */
    public function getUserData(){
	    require_once(  dirname(dirname(dirname(dirname(__FILE__)))) . '/mff_feloginrsaauth/Classes/Utility/CryptUtility.php'  );
	    $rsaauthExtConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_feloginrsaauth']);
	    $passVraname = $rsaauthExtConf['passname'];
 	    $sessData = $GLOBALS['TSFE']->fe_user->getKey('ses',  'mfffeloginrsaauth_logindata');
 	    $encryptedPassword = $sessData[$passVraname];
 	    $cryptUtility = new \CryptUtility();
	    $cleanPassword = $cryptUtility->decrypt($encryptedPassword);
	    return $cleanPassword;
    }
    
    /**
     * getCloudData
     *
     * @param string $directory
     * @param string $username
     * @return void
     */
    public function getCloudData( $directory , $username , $depth='1'){
	    
	    $uri = trim( $directory , '/' ).'/';
	    $webDavDomain = trim( $this->settings['webDavDomain'], '/' ).'/';
	    $webDavUri = trim( $this->settings['webDavUri'], '/' ).'/';
	    $url = $webDavDomain.$webDavUri.$uri;
	    
		$cleanPassword = $this->getUserData();
		
// 	    old one-line cUrl-style to fill variable $result:
// 	    $uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['uploadDir'] ) , '/' ) . '/';
// 	    $fullFilePathName = $uploadDir.'xml_pp.xml';
// 	    exec('curl -X PROPFIND -H "Depth: '.$depth.'" -u '.$username.':'.$cleanPassword.' '.$url.' > '.$fullFilePathName);
// 	    $result = file_get_contents($fullFilePathName);

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PROPFIND');
		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Depth:'.$depth ) );
		curl_setopt($curl, CURLOPT_USERPWD, $username.':'.$cleanPassword );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$result = curl_exec($curl);
		curl_close($curl);

	    $att = $this->XMLtoArray($result);
	    
	    $flatData = $att['D:MULTISTATUS']['D:RESPONSE'];
		if(is_array($flatData)){
			    $data = $this->dataToDirTree( $flatData );
		}else{
			    $data = array( 'NO DATA!'=>['NO DATA!'=>['dirname'=>'NO DATA!']] ); 
		}
	    return $data;
    }
    
    /**
     * getFileFromCloud
     * NOT USED AND NOT TESTED
	 * from curl example https://blog.ortlepp.eu/2016/access_nextcloud_with_php_and_curl.html
     *
     * @param string $fullFilePathName like 'https://www.example.com/nextcloud/remote.php/webdav/ExampleFolder/example.txt'
     * @param string $username
     * @return void
     */
    public function getFileFromCloud( $fullFilePathName , $username  ){
				$cleanPassword = $this->getUserData();
				$curl = curl_init();
				curl_setopt($curl, CURLOPT_URL, $fullFilePathName);
				curl_setopt($curl, CURLOPT_USERPWD, $username.':'.$cleanPassword );
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
				$content = curl_exec($curl);
				curl_close($curl); 
				// Now $content contains the content of the file, to write it to disk you can use file_put_contents('example.txt', $content).
    }
    
    /**
     * putFileToCloud
     * NOT USED AND NOT TESTED
	 * from curl example https://blog.ortlepp.eu/2016/access_nextcloud_with_php_and_curl.html
     *
     * @param string $fullFilePathName
     * @param string $uploadDir
     * @param string $username
     * @return void
     */
    public function putFileToCloud( $fullFilePathName , $uploadDir , $username  ){
			$webDavDomain = trim( $this->settings['webDavDomain'], '/' ).'/';
			$webDavUri = trim( $this->settings['webDavUri'], '/' ).'/';
			$uri = trim( $uploadDir , '/' ).'/';
			
			$filebasename = pathinfo( $fullFilePathName , PATHINFO_BASENAME );
				
			$curl = curl_init( $webDavDomain . $webDavUri . $uri . $filebasename );

			$cleanPassword = $this->getUserData();
			
			$filesize = filesize($fullFilePathName);
			$file = fopen($fullFilePathName, 'r');
			
			curl_setopt($curl, CURLOPT_USERPWD, $username.':'.$cleanPassword );
			curl_setopt($curl, CURLOPT_PUT, true);
			curl_setopt($curl, CURLOPT_INFILE, $file);
			curl_setopt($curl, CURLOPT_INFILESIZE, $filesize);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_exec($curl);

			curl_close($curl);
			fclose($file);
			
			return ( '201' == curl_getinfo($curl, CURLINFO_HTTP_CODE) ) ? TRUE : FALSE;
	}
    
    /**
    * Convert XML to an Array
    *
    * @param string  $XML
    * @return array
    */
    function XMLtoArray($XML)
    {
	$xml_parser = xml_parser_create();
	xml_parse_into_struct($xml_parser, $XML, $vals);
	xml_parser_free($xml_parser);
	$_tmp='';
	foreach ($vals as $xml_elem) {
	    $x_tag=$xml_elem['tag'];
	    $x_level=$xml_elem['level'];
	    $x_type=$xml_elem['type'];
	    if ($x_level!=1 && $x_type == 'close') {
		if (isset($multi_key[$x_tag][$x_level]))
		    $multi_key[$x_tag][$x_level]=1;
		else
		    $multi_key[$x_tag][$x_level]=0;
	    }
	    if ($x_level!=1 && $x_type == 'complete') {
		if ($_tmp==$x_tag)
		    $multi_key[$x_tag][$x_level]=1;
		$_tmp=$x_tag;
	    }
	}
	// jedziemy po tablicy
	foreach ($vals as $xml_elem) {
	    $x_tag=$xml_elem['tag'];
	    $x_level=$xml_elem['level'];
	    $x_type=$xml_elem['type'];
	    if ($x_type == 'open')
		$level[$x_level] = $x_tag;
	    $start_level = 1;
	    $php_stmt = '$xml_array';
	    if ($x_type=='close' && $x_level!=1)
		$multi_key[$x_tag][$x_level]++;
	    while ($start_level < $x_level) {
		$php_stmt .= '[$level['.$start_level.']]';
		if (isset($multi_key[$level[$start_level]][$start_level]) && $multi_key[$level[$start_level]][$start_level])
		    $php_stmt .= '['.($multi_key[$level[$start_level]][$start_level]-1).']';
		$start_level++;
	    }
	    $add='';
	    if (isset($multi_key[$x_tag][$x_level]) && $multi_key[$x_tag][$x_level] && ($x_type=='open' || $x_type=='complete')) {
		if (!isset($multi_key2[$x_tag][$x_level]))
		    $multi_key2[$x_tag][$x_level]=0;
		else
		    $multi_key2[$x_tag][$x_level]++;
		$add='['.$multi_key2[$x_tag][$x_level].']';
	    }
	    if (isset($xml_elem['value']) && trim($xml_elem['value'])!='' && !array_key_exists('attributes', $xml_elem)) {
		if ($x_type == 'open')
		    $php_stmt_main=$php_stmt.'[$x_type]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
		else
		    $php_stmt_main=$php_stmt.'[$x_tag]'.$add.' = $xml_elem[\'value\'];';
		eval($php_stmt_main);
	    }
	    if (array_key_exists('attributes', $xml_elem)) {
		if (isset($xml_elem['value'])) {
		    $php_stmt_main=$php_stmt.'[$x_tag]'.$add.'[\'content\'] = $xml_elem[\'value\'];';
		    eval($php_stmt_main);
		}
		foreach ($xml_elem['attributes'] as $key=>$value) {
		    $php_stmt_att=$php_stmt.'[$x_tag]'.$add.'[$key] = $value;';
		    eval($php_stmt_att);
		}
	    }
	}
	return $xml_array;
    }
    
    /**
     * dataToDirTree
     *
     * @param array $flatData
     * @return void
     */
    public function dataToDirTree( $flatData ){
// 	  return $flatData;
	  $webDavUri = trim( $this->settings['webDavUri'], '/' ).'/';
	  
	  foreach( $flatData as $index => $entry ){
		if( !isset($entry['D:HREF']) ) continue;
		$type = isset($entry['D:PROPSTAT'][$index]['D:PROP'][$index]['D:GETCONTENTTYPE']) ? $entry['D:PROPSTAT'][$index]['D:PROP'][$index]['D:GETCONTENTTYPE']: 'dir';
		if( 'dir' == $type ){
		      $indizes[substr( rtrim( $entry['D:HREF'], '/' ), strlen($webDavUri))]= $index;
		}
	  }
	  
	  $data = array();
	  foreach( $flatData as $index => $entry ){
		if( !isset($entry['D:HREF']) ) continue;
		$type = isset($entry['D:PROPSTAT'][$index]['D:PROP'][$index]['D:GETCONTENTTYPE']) ? $entry['D:PROPSTAT'][$index]['D:PROP'][$index]['D:GETCONTENTTYPE']: 'dir';
		$dirindex = $indizes[ substr( dirname($entry['D:HREF']), strlen($webDavUri)) ];
		if( 'dir' != $type ){
		      $data[$dirindex][$index]=$entry['D:PROPSTAT'][$index]['D:PROP'][$index];
		      $data[$dirindex][$index]['dirname'] = substr( dirname($entry['D:HREF']), strlen($webDavUri));
		      $data[$dirindex][$index]['filename'] = substr( $entry['D:HREF'], 1+strlen($webDavUri.$data[$dirindex][$index]['dirname']));
		}else{
		      $data[$index]['directory'] = substr( $entry['D:HREF'], strlen($webDavUri));
		}
	  }
	  return $data;
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * action create
     *
     * @param \Mff\MffCloud\Domain\Model\Accesspoints $newAccesspoints
     * @return void
     */
    public function createAction(\Mff\MffCloud\Domain\Model\Accesspoints $newAccesspoints)
    {
        $this->addFlashMessage('The object was created', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->accesspointsRepository->add($newAccesspoints);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Mff\MffCloud\Domain\Model\Accesspoints $accesspoints
     * @ignorevalidation $accesspoints
     * @return void
     */
    public function editAction(\Mff\MffCloud\Domain\Model\Accesspoints $accesspoints)
    {
        $this->view->assign('accesspoints', $accesspoints);
    }

    /**
     * action update
     *
     * @param \Mff\MffCloud\Domain\Model\Accesspoints $accesspoints
     * @return void
     */
    public function updateAction(\Mff\MffCloud\Domain\Model\Accesspoints $accesspoints)
    {
        $this->addFlashMessage('The object was updated', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->accesspointsRepository->update($accesspoints);
        $this->redirect('list');
    }

    /**
     * action delete
     *
     * @param \Mff\MffCloud\Domain\Model\Accesspoints $accesspoints
     * @return void
     */
    public function deleteAction(\Mff\MffCloud\Domain\Model\Accesspoints $accesspoints)
    {
        $this->addFlashMessage('The object was deleted', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->accesspointsRepository->remove($accesspoints);
        $this->redirect('list');
    }

}
