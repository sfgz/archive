<?php
## Unused sice extension mff_lsb has its own pdfUtilitity extendet from PdfRotatePagegroup

require( __DIR__ . '/PdfRotatePagegroup.php');
define( 'FPDF_FONTPATH' , __DIR__ . '/font/' ); 

class MffPdf extends PdfRotatePagegroup {
      Public $lineHeight = 4;
      Public $fontFamilyHead = 'FagoNo';
      Public $fontFamilyFoot = 'FagoNo';
      Public $pdf_charset = 'ISO-8859-15';
      Public $textes = array(
	  1 => array(
	      1=> 'Schule für Gestaltung Zürich',
	      3=> '3',
	      4=> 'Weiterbildung',
	  ),
	  2 => array(
	      1=> '',
	      3=> '3.5',
	      4=> 'Leistungsevaluation',
	  ),
	  3 => array(
	      2=> 'VA',
	      3=> '3.5.1',
	      4=> 'Unterrichtsentwicklung evaluieren',
	  ),
	  4 => array(
	      2=> 'FO',
	      3=> '3.5.1.2',
	      4=> 'Auswertung Kursbewertung',
	  ),
      );

	/**
	* pageConf
	*
	* @var array
	*/
	Public $pageConf = array(
		'specchars' => array( 'laquo' => 171 , 'raquo' => 187 , 'copy' => 169 , 'C' => 169 , 'registered' => 174 , 'at' => 64 ) , 
		'keywords' => '' , 
		'fontfamily' => 'Helvetica' , 
		'fontFamilyHead' => '' , 
		'fontFamilyFoot' => '' , 
		'fsize' => 10 , 
		'ReportFooter' => array( 'fsize' => 10 , 'lines_min' => 8 , 'lines_max' => 20 , 'rows' => array() ) , 
		'lfeed' => 5 , 
		'slfeed' => 2.5 , 
		'cellwidthPoints' => 8 , 
		'cellwidthSumma' => 11 , 
		'cellwidthSummas' => 16 , 
		'cellwidthReportDescription' => 116 , 
		'lineSmall' => 0.15 , 
		'lineBold' => 1.55 , 
		'docuwidth' => 210 , 
		'TopMargin' => 15 , 
		'RightMargin' => 15 , 
		'BottomMargin' => 10 , 
		'Subject' => 10 , 
		'LeftMargin' => 25 , 
		'footerBottomMargin' => 5 , 
		'lineWidth' => '0.2' ,
		'dokuHeight' => 297,
		'HeaderText' => 'HeaderText',
		'matrixTitle' => 'A Auswertung',
		'SummaryLineConf' => array(  ),
		'HeadLine' => array( 'rows'=>'78,7,1,15,71' )
	  );

	/**
	* data
	*
	* @var array
	*/
	public $data = array( 'main' => array( '##Titel##' => 'testTitel' ) , 'body'=>array() , 'HEADER'=>array() , 'FOOTER'=>array() );
	
	public function initializePdf( $pageConf = array() ) {
		
		if(count($pageConf)){
		      foreach($pageConf as $key=>$value) {
					if(isset($this->pageConf[$key] )) $this->pageConf[$key] = $value;
		      }
		      if( is_array($pageConf['HeaderTexts']) ){
					foreach($pageConf['HeaderTexts'] as $key0=>$row) {
							foreach($row as $key1=>$content) {
									$this->textes[$key0][$key1]=iconv($this->pdf_charset,"UTF-8",$content);
							}
					}
		      }
		}
		
		if(!empty($this->pageConf['fontFamilyHead'])) $this->fontFamilyHead = $this->pageConf['fontFamilyHead'];
		if(!empty($this->pageConf['fontFamilyFoot'])) $this->fontFamilyFoot = $this->pageConf['fontFamilyFoot'];
		
		if( $this->fontFamilyHead != 'Helvetica' ) $this->AddFont($this->fontFamilyHead);
		if( $this->fontFamilyFoot != 'Helvetica' ) $this->AddFont($this->fontFamilyFoot);
		
		if( empty( $this->pageConf['keywords'] ) ) $this->pageConf['keywords'] = str_replace('_' , ' ' , $pageConf['filename']);
		
		$this->SetTopMargin( $this->pageConf['TopMargin'] );
		$this->SetLeftMargin( $this->pageConf['LeftMargin'] );
		$this->SetRightMargin( $this->pageConf['RightMargin'] );
	 	$this->SetAutoPageBreak( TRUE , $this->pageConf['BottomMargin'] );
		$this->SetTextColor(0,0,0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		$this->SetLineWidth(  $this->pageConf['lineWidth'] );
		$this->SetKeywords(  $this->pageConf['keywords'] );
		$this->SetSubject(  $this->pageConf['Subject'] );
		$this->SetTitle(  $this->pageConf['Title'] );
 		$this->HeaderText = $this->pageConf['HeaderText'] ;
		
	}
	
	function encode( $value ) {
		return iconv("UTF-8", $this->pdf_charset,$value);
	}
	
	function weiterbildungHeader() {
	      $this->replacePatternWithValues();
	      if(is_array($this->HeaderTexts)){
		  foreach($this->HeaderTexts as $row=>$rs){
		      foreach($rs as $col=>$cell){
			  $this->textes[$row][$col] = $cell;
		      }
		  }
	      }
	      if(!empty($this->HeaderText)) $this->textes[4][4] = $this->HeaderText;
	      foreach($this->textes as $row=>$rs){
		  foreach($rs as $col=>$cell){
		      $contents = str_replace( array_keys($this->data['replacements']) , $this->data['replacements'] , $cell );
		      $head[$row][$col] = $this->encode($contents);
		  }
	      }

	      $L = '0.3';
	      $S = '0.15';
	      $fontSize = 8.5;
	      $this->SetFont($this->fontFamilyHead,'',$fontSize);
	      
	      list( $c1 , $c2 , $c3 , $c4 , $c5 ) = explode(',' , $this->pageConf['HeadLine']['rows']);
	      $lineHeight = $this->pageConf['lfeed'];
	      
	      $this->SetY(10);
	      $this->SetLineWidth($L);
	      $this->Cell( $c1+$c2 ,$lineHeight, $head[1][1], 'T'  );
	      $this->Cell( $c3 ,$lineHeight, '' , ''  );
	      $this->Cell( $c4 ,$lineHeight, $head[1][3] , 'T'  );
	      $this->Cell( 1 ,$lineHeight, '' , 'T' , 0 );
	      $this->Cell( $c5-1 ,$lineHeight, $head[1][4] , 'T' , 1 );

	      $this->SetLineWidth($S);
	      $this->Cell( $c1 ,$lineHeight, $head[2][1] , ''  );
	      $this->Cell( $c2 ,$lineHeight, $head[2][2] , ''  );
	      $this->Cell( $c3 ,$lineHeight, '' , ''  );
	      $this->Cell( $c4 ,$lineHeight, $head[2][3] , 'B'  );
	      $this->SetX( $this->GetX()+1 );
	      $this->Cell( $c5-1 ,$lineHeight, $head[2][4] , 'B' , 1 );

	      $this->SetFont($this->fontFamilyHead,'B',$fontSize);
	      $this->Cell( $c1 ,$lineHeight, $head[3][1] , ''  );
	      $this->Cell( $c2 ,$lineHeight, $head[3][2] , ''  );
	      $this->Cell( $c3 ,$lineHeight, '' , ''  );
	      $this->SetTextColor(255,255,255);
	      $this->SetFillColor(0,0,0);
	      $this->Cell( $c4 ,$lineHeight, $head[3][3] , 'TBLR' , 0 , 'L' , 1 );
	      $this->SetFillColor(255,255,255);
	      $this->SetTextColor(0,0,0);
	      
	      $this->SetX( $this->GetX()+1 );
	      $this->Cell( $c5-1 ,$lineHeight, $head[3][4] , '' , 1 );

	      $this->SetLineWidth($L);
	      $this->Cell( $c1 ,$lineHeight, $head[4][1] , 'B'  );
	      $this->Cell( $c2 ,$lineHeight, $head[4][2] , 'B'  );
	      $this->Cell( $c3 ,$lineHeight, '' , ''  );
	      $this->Cell( $c4+1 ,$lineHeight, $head[4][3] , 'B'  );
	      $this->Cell( $c5-1 ,$lineHeight, $head[4][4] , 'B' , 1 );
	      $this->Ln( $lineHeight );
	      $this->TopY = $this->getY();
// 	      $this->SetY($this->pageConf['marginTop']);
// 		$this->replacePatternWithValues();
// 		$this->drawCsvCellContents( 'Kopfzeile wb' , 170 , 1 , 'R' );
	}
	
      function grundbildungHeader() {
	      $L = '1';
	      $S = '0.15';
	      $this->SetLineWidth($S);
	      $x1= 115;
	      $x2= 160;
	      $x3= 201;
	      $y= 6.5;
	      $y2= $y + ( ($L-$S)/2 );
	      $this->Line( $x1 , $y , $x2  , $y );
	      $this->SetLineWidth($L);
	      $this->Line( $x2 , $y2 , $x3  , $y2 );
	      $this->SetTextColor(0,0,0);
	      $this->SetY($y);
	      $this->SetX( $x2 );
	      $this->SetFont( $this->fontFamilyHead ,'', $this->pageConf['fsize']);
	      $this->Cell($x3-$x2+1.5 , $this->pageConf['fsize'] , $this->HeaderText ,'0',1,'R');
	      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
	      $this->Ln( $this->pageConf['lfeed'] );
	      $this->TopY = $this->getY();
      }
	
	function Header() {
	      $this->TopY = $this->getY();
		if( !empty($this->pageConf['HeadLine']['method']) ) {
		  $method = $this->pageConf['HeadLine']['method'];
		  if( method_exists( $this , $method ) ) { 
			$this->$method();
			return;
		  }
		}
		if( !count($this->data['HEADER']) ) {parent::Header();return;}
		
		$this->replacePatternWithValues();
		$isFirstPage = $this->GroupPageNo() == 1 ? 1 : 0;
		foreach($this->data['HEADER'] as $ix => $row){
		    if( $row['condition']== 'first_page_only' && empty($isFirstPage) )continue;
		    if( $row['condition']== 'following_pages_only' && $isFirstPage )continue;
		    $footrow[$ix] = $row;
		    $rowCount += $row['ln'];
		}
		if( !count($footrow) ) return;
		
		$xPos = $this->GetX();
		
		$this->SetFont( $this->fontFamilyHead , '' , $this->pageConf['fsize'] );
		foreach($footrow as $ix => $cell){
		    $this->drawCsvCellContents( $cell['width'] ,$cell['content'] , '' , $cell['ln'] , $cell['align'] );
		    $this->SetX($xPos);
		}
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		$this->Ln( $this->pageConf['lfeed'] );
	      $this->TopY = $this->getY();
// 	      $this->SetY($this->pageConf['marginTop']);
	      
	}
	function Footer() {
		if( !count($this->data['FOOTER']) ) {parent::Footer();return;}
		$this->replacePatternWithValues();

		$isFirstPage = $this->GroupPageNo() == 1 ? 1 : 0;
		foreach($this->data['FOOTER'] as $ix => $row){
		    if( $row['condition']== 'first_page_only' && empty($isFirstPage) )continue;
		    if( $row['condition']== 'following_pages_only' && $isFirstPage )continue;
		    $footrow[$ix] = $row;
		    $rowCount += $row['ln'];
		}
		if( !count($footrow) ) return;
		
// 		$xPos = $this->GetX();
		$xPos = $this->pageConf['LeftMargin'];
		
		$yOffset = ($rowCount * $this->pageConf['lfeed']) + $this->pageConf['footerBottomMargin'];
		$this->SetY(-$yOffset);
		
		$this->SetFont( $this->fontFamilyFoot , '' , $this->pageConf['fsize'] );
		foreach($footrow as $ix => $cell){
			if( !empty($cell['condition']) ){
				$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
			}
		    $this->drawCsvCellContents( $cell['width'] , $cell['content'] , '' , $cell['ln'] , $cell['align'] );
			$this->SetFont( $this->fontFamilyFoot , '' , $this->pageConf['fsize'] );
		    $this->SetX($xPos);
		}
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		
	}
      
	public function drawCsvCellContents( $width=0  , $contents ,  $border='' ,  $ln=0 , $align='L' ){
		if( 'auto' == $width ) $width = $this->GetStringWidth( $contents );
		$contents = str_replace( array_keys($this->data['replacements']) , $this->data['replacements'] , $contents );
		$this->Cell( $width , $this->pageConf['lfeed'] , $contents , $border , $ln , $align);
	}
	
	function replacePatternWithValues() {
		$this->data['replacements']['__PAGE__'] = $this->GroupPageNo();
		$this->data['replacements']['__PAGES__'] = $this->PageGroupAlias();
		$this->data['replacements']['__DATE__'] = date( 'd.m.Y' );
 		$this->data['replacements']['__C__'] = chr(169);
		foreach( $this->pageConf['specchars'] as $charStr => $charNr ) {
		      $this->data['replacements'][ '__' . $charStr . '__' ] = chr($charNr);
		}
	}
}
// Handle special IE contype request
if(isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT']=='contype')
{
	header('Content-Type: application/pdf');
	exit;
}

?>
