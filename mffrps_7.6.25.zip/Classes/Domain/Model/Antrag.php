<?php
namespace Mff\Mffrps\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Antrag
 */
class Antrag extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * uid
	 *
	 * @var int
	 */
	protected $uid = NULL;

	/**
	 * tstamp
	 *
	 * @var int
	 */
	protected $tstamp = NULL;

	/**
	 * datum
	 *
	 * @var \DateTime
	 * @validate NotEmpty,DateTime
	 */
	protected $datum = NULL;

	/**
	 * zeitStart
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $zeitStart = '';

	/**
	 * zeitEnde
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $zeitEnde = '';
	
	/**
	 * betreff
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $betreff = '';

	/**
	 * text
	 *
	 * @var string
	 */
	protected $text = '';

	/**
	 * mieter
	 *
	 * @var string
	 */
	protected $mieter = '';

	/**
	 * kalender
	 *
	 * @var string
	 */
	protected $kalender = '';

	/**
	 * anzeige
	 *
	 * @var string
	 */
	protected $anzeige = '';

	/**
	 * zimmer
	 * @lazy
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 */
	protected $zimmer = NULL;

	/**
	 * bearbeiter
	 * @lazy
	 * @var \TYPO3\CMS\Extbase\Domain\Model\FrontendUser
	 */
	protected $bearbeiter = NULL;
	


	/**
	 * Returns the uid
	 *
	 * @return int $uid
	 */
	public function getUid() {
		return $this->uid;
	}

	/**
	 * Sets the uid
	 *
	 * @param int $uid
	 * @return void
	 */
	public function setUid($uid) {
		$this->uid = $uid;
	}

	/**
	 * Returns the tstamp
	 *
	 * @return int $tstamp
	 */
	public function getTstamp() {
		return $this->tstamp;
	}

	/**
	 * Sets the tstamp
	 *
	 * @param int $tstamp
	 * @return void
	 */
	public function setTstamp($tstamp) {
		$this->tstamp = $tstamp;
	}

	/**
	 * Returns the datum
	 *
	 * @return \DateTime $datum
	 */
	public function getDatum() {
		return $this->datum;
	}

	/**
	 * Sets the datum
	 *
	 * @param \DateTime $datum
	 * @return void
	 */
	public function setDatum(\DateTime $datum) {
		$this->datum = $datum;
	}

	/**
	 * Returns the zeitStart
	 *
	 * @return string $zeitStart
	 */
	public function getZeitStart() {
		return $this->zeitStart;
	}

	/**
	 * Sets the zeitStart
	 *
	 * @param string $zeitStart
	 * @return void
	 */
	public function setZeitStart($zeitStart) {
		$this->zeitStart = $zeitStart;
	}

	/**
	 * Returns the zeitEnde
	 *
	 * @return string $zeitEnde
	 */
	public function getZeitEnde() {
		return $this->zeitEnde;
	}

	/**
	 * Sets the zeitEnde
	 *
	 * @param string $zeitEnde
	 * @return void
	 */
	public function setZeitEnde($zeitEnde) {
		$this->zeitEnde = $zeitEnde;
	}

	/**
	 * Returns the betreff
	 *
	 * @return string $betreff
	 */
	public function getBetreff() {
		return $this->betreff;
	}

	/**
	 * Sets the betreff
	 *
	 * @param string $betreff
	 * @return void
	 */
	public function setBetreff($betreff) {
		$this->betreff = $betreff;
	}

	/**
	 * Returns the text
	 *
	 * @return string $text
	 */
	public function getText() {
		return $this->text;
	}

	/**
	 * Sets the text
	 *
	 * @param string $text
	 * @return void
	 */
	public function setText( $text = '' ) {
		$this->text = $text;
	}

	/**
	 * Returns the mieter
	 *
	 * @return string $mieter
	 */
	public function getMieter() {
		return $this->mieter;
	}

	/**
	 * Sets the mieter
	 *
	 * @param string $mieter
	 * @return void
	 */
	public function setMieter( $mieter = '' ) {
		$this->mieter = $mieter;
	}

	/**
	 * Returns the kalender
	 *
	 * @return string $kalender
	 */
	public function getKalender() {
		return $this->kalender;
	}

	/**
	 * Sets the kalender
	 *
	 * @param string $kalender
	 * @return void
	 */
	public function setKalender( $kalender = '' ) {
		$this->kalender = $kalender;
	}

	/**
	 * Returns the anzeige
	 *
	 * @return string $anzeige
	 */
	public function getAnzeige() {
		return $this->anzeige;
	}

	/**
	 * Sets the anzeige
	 *
	 * @param string $anzeige
	 * @return void
	 */
	public function setAnzeige( $anzeige = '' ) {
		$this->anzeige = $anzeige;
	}

	/**
	 * Returns the zimmer
	 *
	 * @return \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 */
	public function getZimmer() {
		return $this->zimmer;
	}

	/**
	 * Sets the zimmer
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @return void
	 */
	public function setZimmer(\Mff\Mffdb\Domain\Model\Zimmer $zimmer = NULL ) {
		$this->zimmer = $zimmer;
	}

	/**
	 * Returns the bearbeiter
	 *
	 * @return \TYPO3\CMS\Extbase\Domain\Model\FrontendUser $bearbeiter
	 */
	public function getBearbeiter() {
		return $this->bearbeiter;
	}

	/**
	 * Sets the bearbeiter
	 *
	 * @param \TYPO3\CMS\Extbase\Domain\Model\FrontendUser $bearbeiter
	 * @return void
	 */
	public function setBearbeiter(\TYPO3\CMS\Extbase\Domain\Model\FrontendUser $bearbeiter = NULL) {
		$this->bearbeiter = $bearbeiter;
	}

}