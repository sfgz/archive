<?php
namespace Mff\Mffrps\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Ausnahme
 */
class Ausnahme extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * timetable
	 *
	 * @var int
	 */
	protected $timetable = 0;

	/**
	 * import_uid
	 *
	 * @var int
	 */
	protected $import_uid = 0;

	/**
	 * datum
	 *
	 * @var \DateTime
	 */
	protected $datum = NULL;

	/**
	 * zeitAb
	 *
	 * @var string
	 */
	protected $zeitAb = '';

	/**
	 * zeitBis
	 *
	 * @var string
	 */
	protected $zeitBis = '';

	/**
	 * neuZeitAb
	 *
	 * @var string
	 */
	protected $neuZeitAb = '';

	/**
	 * neuZeitBis
	 *
	 * @var string
	 */
	protected $neuZeitBis = '';

	/**
	 * infoDatum
	 *
	 * @var \DateTime
	 */
	protected $infoDatum = NULL;

	/**
	 * ausnahmetext
	 *
	 * @var string
	 */
	protected $ausnahmetext = '';

	/**
	 * infoPerson
	 * @lazy
	 * @var \Mff\Mffdb\Domain\Model\Ecouser
	 */
	protected $infoPerson = NULL;

	/**
	 * ausZimmer
	 * @lazy
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 */
	protected $ausZimmer = NULL;

	/**
	 * neuZimmer
	 * @lazy
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 */
	protected $neuZimmer = NULL;

	/**
	 * Returns the timetable
	 *
	 * @return string $timetable
	 */
	public function getTimetable() {
		return $this->timetable;
	}

	/**
	 * Sets the timetable
	 *
	 * @param string $timetable
	 * @return void
	 */
	public function setTimetable($timetable) {
		$this->timetable = $timetable;
	}

	/**
	 * Returns the importUid
	 *
	 * @return int $importUid
	 */
	public function getImportUid() {
		return $this->importUid;
	}

	/**
	 * Sets the importUid
	 *
	 * @param int $importUid
	 * @return void
	 */
	public function setImportUid($importUid) {
		$this->importUid = $importUid;
	}

	/**
	 * Returns the datum
	 *
	 * @return \DateTime $datum
	 */
	public function getDatum() {
		return $this->datum;
	}

	/**
	 * Sets the datum
	 *
	 * @param \DateTime $datum
	 * @return void
	 */
	public function setDatum(\DateTime $datum) {
		$this->datum = $datum;
	}

	/**
	 * Returns the zeitAb
	 *
	 * @return string $zeitAb
	 */
	public function getZeitAb() {
		return $this->zeitAb;
	}

	/**
	 * Sets the zeitAb
	 *
	 * @param string $zeitAb
	 * @return void
	 */
	public function setZeitAb($zeitAb) {
		$this->zeitAb = $zeitAb;
	}

	/**
	 * Returns the zeitBis
	 *
	 * @return string $zeitBis
	 */
	public function getZeitBis() {
		return $this->zeitBis;
	}

	/**
	 * Sets the zeitBis
	 *
	 * @param string $zeitBis
	 * @return void
	 */
	public function setZeitBis($zeitBis) {
		$this->zeitBis = $zeitBis;
	}

	/**
	 * Returns the neuZeitAb
	 *
	 * @return string $neuZeitAb
	 */
	public function getNeuZeitAb() {
		return $this->neuZeitAb;
	}

	/**
	 * Sets the neuZeitAb
	 *
	 * @param string $neuZeitAb
	 * @return void
	 */
	public function setNeuZeitAb($neuZeitAb) {
		$this->neuZeitAb = $neuZeitAb;
	}

	/**
	 * Returns the neuZeitBis
	 *
	 * @return string $neuZeitBis
	 */
	public function getNeuZeitBis() {
		return $this->neuZeitBis;
	}

	/**
	 * Sets the neuZeitBis
	 *
	 * @param string $neuZeitBis
	 * @return void
	 */
	public function setNeuZeitBis($neuZeitBis) {
		$this->neuZeitBis = $neuZeitBis;
	}

	/**
	 * Returns the infoDatum
	 *
	 * @return \DateTime $infoDatum
	 */
	public function getInfoDatum() {
		return $this->infoDatum;
	}

	/**
	 * Sets the infoDatum
	 *
	 * @param \DateTime $infoDatum
	 * @return void
	 */
	public function setInfoDatum(\DateTime $infoDatum = NULL) {
		$this->infoDatum = $infoDatum;
	}

	/**
	 * Returns the ausnahmetext
	 *
	 * @return string $ausnahmetext
	 */
	public function getAusnahmetext() {
		return $this->ausnahmetext;
	}

	/**
	 * Sets the ausnahmetext
	 *
	 * @param string $ausnahmetext
	 * @return void
	 */
	public function setAusnahmetext($ausnahmetext) {
		$this->ausnahmetext = $ausnahmetext;
	}

	/**
	 * Returns the infoPerson
	 *
	 * @return \Mff\Mffdb\Domain\Model\Ecouser $infoPerson
	 */
	public function getInfoPerson() {
		return $this->infoPerson;
	}

	/**
	 * Sets the infoPerson
	 *
	 * @param \Mff\Mffdb\Domain\Model\Ecouser $infoPerson
	 * @return void
	 */
	public function setInfoPerson(\Mff\Mffdb\Domain\Model\Ecouser $infoPerson = null) {
		$this->infoPerson = $infoPerson;
	}

	/**
	 * Returns the ausZimmer
	 *
	 * @return \Mff\Mffdb\Domain\Model\Zimmer $ausZimmer
	 */
	public function getAusZimmer() {
		return $this->ausZimmer;
	}

	/**
	 * Sets the ausZimmer
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $ausZimmer
	 * @return void
	 */
	public function setAusZimmer(\Mff\Mffdb\Domain\Model\Zimmer $ausZimmer) {
		$this->ausZimmer = $ausZimmer;
	}

	/**
	 * Returns the neuZimmer
	 *
	 * @return \Mff\Mffdb\Domain\Model\Zimmer $neuZimmer
	 */
	public function getNeuZimmer() {
		return $this->neuZimmer;
	}

	/**
	 * Sets the neuZimmer
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $neuZimmer
	 * @return void
	 */
	public function setNeuZimmer(\Mff\Mffdb\Domain\Model\Zimmer $neuZimmer) {
		$this->neuZimmer = $neuZimmer;
	}

}