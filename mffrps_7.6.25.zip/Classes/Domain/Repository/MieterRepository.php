<?php
namespace Mff\Mffrps\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Mieters
 */
class MieterRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	 * findByUidOrKurz
	 * returns array of objects
	 * 
	 * @param $kurz
	 * @return void
	 */
	public function findByUidOrKurz( $kurz ){
	      $numList = array();
	      $kurz = trim($kurz);
	      if( is_numeric($kurz) ){
		  $numList[$kurz] = $kurz;
	      }else{
		  $varList = explode( ',' , $kurz );
		  foreach( $varList as $rawNum ){
		      if( is_numeric( trim($rawNum) ) ) $numList[$rawNum] = $rawNum;
		  }
	      }
	      
	      $anlasses = array();
	      if( count($numList) ){
		    foreach($numList as $mtrUid){
			  $objMieter = $this->findByUid($mtrUid);
			  if($objMieter) $mtrAnlasses = $objMieter->getMtrAnlass();
			  if($mtrAnlasses){
				foreach($mtrAnlasses as $anlass){$anlasses[] = $anlass;}
			  }
		    }
	      }else{
		    $objsMieters = $this->findLikeKurz($kurz);
		    if($objsMieters) {
			    foreach($objsMieters as $objMieter){
				$mtrAnlasses = $objMieter->getMtrAnlass();
				if($mtrAnlasses){
				      foreach($mtrAnlasses as $anlass){$anlasses[]=$anlass;}
				}
			    }
		    }
	      }
	      return $anlasses;
	}

	/**
	 * findLikeKurz
	 * 
	 * @param $kurz
	 * @return void
	 */
	public function findLikeKurz( $kurz ){
	    if( empty( $kurz ) ){
		  $sqlStmt = 'SELECT * FROM tx_mffrps_domain_model_mieter;';
	    }else{
		  if( strpos( ' ' . $kurz , '*' ) ){
			$pattern = str_replace( '*' , '%' , trim( $kurz ) );
		  }else{
			$pattern = str_replace( array('%!','!%') , '' , '%'.trim( $kurz ).'%' );
		  }
		  $sqlStmt = 'SELECT * FROM tx_mffrps_domain_model_mieter WHERE kurz LIKE "'.$pattern.'";';
	    }
	    return $this->callSqlStatement( $sqlStmt , FALSE );
	}

	/**
	 * @param $qryStatement
	 * @param $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
// 		$Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}
	
}