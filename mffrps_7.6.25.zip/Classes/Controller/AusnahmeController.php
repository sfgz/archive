<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * AusnahmeController
 */
class AusnahmeController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * ausnahmeRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AusnahmeRepository
	 * @inject
	 */
	protected $ausnahmeRepository = NULL;

	/**
	 * teacherRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TeacherRepository
	 * @inject
	 */
	protected $teacherRepository = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;

	/**
	 * timetableUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $timetableUtility = NULL;

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();
		$this->timetableUtility = new \Mff\Mffrps\Utility\TimetableUtility();
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['userfields'] = $this->systemOptionsUtility->getUserOptions();
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$inVars = array();
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $res =  $this->request->getArgument($this->settings['formname']);
		     if( is_array( $res ) ) $inVars = $res;
		}
		if ( (!isset($inVars['filter']) || !count($inVars['filter']) ) &&  $this->request->hasArgument('filter') ) {
		     $inVarsFilter =  $this->request->getArgument('filter');
		     $inVars['filter'] = $inVarsFilter;
		}
		$this->settings = $this->systemOptionsUtility->handleRequestVars( $inVars , $this->settings );
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$cObj = $configurationManager->getContentObject();
		$this->settings['piUid'] = $cObj->data['uid'];
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		// evaluate room-UIDs
		$zmrArr = array();
		if($this->settings['userfields']['filter_room']['value'] != '*' && !empty($this->settings['userfields']['filter_room']['value']) ) {
			$zmrArr = array(0=>999);
			$zimmers = $this->zimmerUtility->getZimmerRepository()->findByRoom($this->settings['userfields']['filter_room']['value'],TRUE);
			foreach( $zimmers as $zmr ){ $zmrArr[] = $zmr->getUid(); }
		}
		
		// get ausnahmes filtered by room & date
		$ausnahmes = $this->ausnahmeRepository->findByRoomsAndDates( $zmrArr , $this->settings['filter'] );
		
		// get user infos for mail-action
		$userObj = $GLOBALS['TSFE']->fe_user;
		$userEmail = '';
		if($userObj) $userEmail = $userObj->user['email'];
		if(empty($userEmail)) $userEmail = $this->settings['optionfields']['backup_user']['value'];
		
		// evaluate if mail action is triggered 
		// otherwise set default values for message and adress
		if ( $this->request->hasArgument('editList') ) {
			$editList = $this->request->getArgument('editList');
			$editList['updated'] = 1;
		}else{
			$editList = array(
			    'mail_message' => $this->settings['optionfields']['info_lp_mailtext']['value'],
			    'sender_email' => $userEmail
			);
			$editList['updated'] = 0;
			$editList['blincopy_sender'] = 1;
			$editList['mailSubject'] = $this->settings['optionfields']['info_lp_mailsubject']['value'];
		}
		$rpc = array( '_email_'=>$userEmail , '_first_name_'=>$userObj->user['first_name'] ,  '_last_name_'=>$userObj->user['last_name'] , '_company_'=>$userObj->user['company'] , '_telephone_'=>$userObj->user['telephone'] , );
		$editList['mailSignature'] = str_replace( array_keys($rpc) , $rpc , $this->settings['optionfields']['mail_signature']['value']);
		$editList['mailSubject'] = str_replace( array_keys($rpc) , $rpc , $editList['mailSubject']);
		
		// append parts of belegungen to ausnahmen
		$tableRows = array() ;
		$noTtCss = array( '' , 'nott' );
		$ttRep = $this->timetableUtility->getTimetableRepository();
		if($ausnahmes){
		    foreach($ausnahmes as $key=>$obj){
			$ix = $obj->getUid();
			$zeitAb = str_replace( ':' , '.' ,  $obj->getZeitAb() );
			$zeitBis = str_replace( ':' , '.' ,  $obj->getZeitBis() );
			$datObj = $obj->getDatum();
			$zmrObj = $obj->getAusZimmer();
			$ttUid = $obj->getTimetable();
			if($ttUid) {
			      $fndRes = $ttRep->findByUid( $ttUid ) ;
			      $noTimetable = $fndRes ? 0 : 1;
			}else{
			      $noTimetable = 1;
			}
			$tableRows[$ix]['nott'] = $noTtCss[$noTimetable];
			if(!empty($editList['editcheck'][$ix])) {
			      $tableRows[$ix]['ischecked'] = 'checked';
			      $tableRows[$ix]['valid'] = $this->settings['filter']['show_informated'];
			}else{
			      $tableRows[$ix]['ischecked'] = false;
			      $tableRows[$ix]['valid'] = empty( $obj->getInfoDatum() ) ? true : $this->settings['filter']['show_informated'];
			}
			$tableRows[$ix]['obj'] = $obj;
			$tableRows[$ix]['bel'] = $this->dbHelperUtility->findBelegungByRoomDateTime(
			      $zmrObj->getUid() , 
			      array( 'date'=>$datObj->format('U') , 'todate'=>$datObj->format('U') ) , 
			      array( 'timeFrom'=>$zeitAb , 'timeTo'=> $zeitBis ) 
			);
			if(count($tableRows[$ix]['bel'])){
			      $ausBelRow=array();
			      foreach( $tableRows[$ix]['bel'] as $bel){
				  $ausBelRow[] =  $bel->getAb() . '-' . $bel->getBis() . ' ' . $bel->getBelegungstext();
			      }
			      $tableRows[$ix]['lst'] = implode( '|' , $ausBelRow );
			}
		    }
		}
		
		// download ausnahmes with parts of belegungen
		if ($this->request->hasArgument('download')) {
		      $this->downloadList($tableRows , $this->request->getArgument('download') );
		}
		
		// send messages and set info-date if mail action is triggered
		if ( $editList['updated'] ) {
		      $aInfoTeacher = $this->changeInfodate($tableRows);
		      $editList['messagesSendt'] = $this->mailToTeacher( $editList , $aInfoTeacher );
		      $this->addFlashMessage( ($editList['messagesSendt'] ? $editList['messagesSendt'] : 'Keine') . ' Nachrichten Gesendet', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		      $this->addFlashMessage('In Wirklichkeit wurde Mail an Absender gesendet, dieser Teil ist noch in Entwicklung', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		$editList['mailSignature'] = str_replace( "\n" , "<br />" , $editList['mailSignature']);
		
		$this->view->assign( 'ausnahmes' , $tableRows );
		$this->view->assign('editList', $editList );
		$this->view->assign('settings', $this->settings );
		
		// passtrough
		if ($this->request->hasArgument('sysoptions')) {
			$this->view->assign('sysoptions', $this->request->getArgument('sysoptions') );
		}
		
	}

	/**
	 * downloadList
	 * used by action list
	 *
	 * @param array $tableRows
	 * @param string $reqFormat
	 * @return void
	 */
	public function downloadList($tableRows , $reqFormat='xls') {
		      if ($reqFormat == 'xls') {
			      $xlsRows = array();
			      foreach($tableRows as $ix=>$aObjs){
				    $obj = $aObjs['obj'];
				    $datObj = $obj->getDatum();
				    $zmrObj = $obj->getAusZimmer();
				    $NeuZmrObj = $obj->getNeuZimmer();
				    $boolInfoDate = !empty( $obj->getInfoDatum() );
				    $hasInfoDate = $boolInfoDate ? 'informiert' : 'nicht informiert';
				    $aBelegungFeld = array();
				    foreach($tableRows[$ix]['bel'] as $objBelegung) $aBelegungFeld[] =  $objBelegung->getAb() . '-' . $objBelegung->getBis() . ' ' . $objBelegung->getBelegungstext();
				    
				    if($boolInfoDate) {
					  $xlsRows[$hasInfoDate][$ix]['info_datum'] = $obj->getInfoDatum()->format('d.m.Y');
				    }
				    $xlsRows[$hasInfoDate][$ix]['uid'] = $obj->getUid();
				    $xlsRows[$hasInfoDate][$ix]['datum'] = $datObj->format('d.m.Y');
				    $xlsRows[$hasInfoDate][$ix]['zeit_ab'] = $obj->getZeitAb();
				    $xlsRows[$hasInfoDate][$ix]['zeit_bis'] = $obj->getZeitBis();
				    $xlsRows[$hasInfoDate][$ix]['aus_zimmer'] = $zmrObj->getHaus() . ' ' . $zmrObj->getZimmer();
				    $xlsRows[$hasInfoDate][$ix]['neu_zeit_ab'] = $obj->getNeuZeitAb();
				    $xlsRows[$hasInfoDate][$ix]['neu_zeit_bis'] = $obj->getNeuZeitBis();
				    $xlsRows[$hasInfoDate][$ix]['neu_zimmer'] = $NeuZmrObj->getUid() == $zmrObj->getUid() ? 'Kein Ersatz' : $NeuZmrObj->getHaus() . ' ' . $NeuZmrObj->getZimmer();
				    $xlsRows[$hasInfoDate][$ix]['ausnahmetext'] = $obj->getAusnahmetext();
				    $personRS = $obj->getInfoPerson();
				    $xlsRows[$hasInfoDate][$ix]['info_person'] = $personRS ?  $obj->getInfoPerson()->getName() : '';
				    $xlsRows[$hasInfoDate][$ix]['info_email'] = $personRS ? $obj->getInfoPerson()->getEmail() : '';
				    $xlsRows[$hasInfoDate][$ix]['belegungen'] = implode( ', ' , $aBelegungFeld );
			      }
			      krsort($xlsRows);
			      $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
			      $downloader->downloadAsXls( $xlsRows , 'ausnahmen_' . date('ymd_Hi') . '.xlsx');
			      return;
		      }
	}

	/**
	 * changeInfodate
	 * used by action list, returns array $aInfoTeacher
	 *
	 * @param array $tableRows
	 * @return array 
	 */
	public function changeInfodate( $tableRows ) {
	      $dateNow = new \DateTime('NOW');
	      $aInfoTeacher = array();
	      if($tableRows){
		  foreach($tableRows as $ix=>$aObjs){
		      if($aObjs['ischecked'] == 'checked') {
			    $aObjs['obj']->setInfoDatum( $dateNow );
			    $this->ausnahmeRepository->update($aObjs['obj']);
			    $aBelegungFeld = array();
			    foreach($aObjs['bel'] as $objBelegung) $aBelegungFeld[] =  $objBelegung->getAb() . '-' . $objBelegung->getBis() . ' ' . $objBelegung->getBelegungstext();
			    $aObjs['belegungen'] = implode( ', ' , $aBelegungFeld );
			    $teacherUid = $aObjs['obj']->getInfoPerson()->getName();
			    $aInfoTeacher[$teacherUid][$ix] = $aObjs;
		      }
		  }
	      }
	      return $aInfoTeacher;
	}

	/**
	 * mailToTeacher
	 * used by action list
	 * 
	 * @param array $edFields
	 * @param array $aInfoTeacher
	 * @return int amount of sendt mails
	 */
	public function mailToTeacher( $edFields , $aInfoTeacher ) {
	      if( !is_array($aInfoTeacher) || !count($aInfoTeacher) ) return 0;
	      if( $edFields['debug_send'] && empty($edFields['blincopy_sender']) ) return 0;
	      $aMessageRec = array();
	      $signature = $edFields['exclude_signature'] ? '' : "<br />" . $edFields['mailSignature'];
	      for($wDay = 0 ; $wDay<=7 ; ++$wDay) $aWeekday[$wDay] = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('weekdays.short.' . $wDay , 'mffrps' );
	      foreach($aInfoTeacher as $teacherUid=> $teacherGroup){
		  $ausnahmeZeile = array();
		  foreach($teacherGroup as $ix=>$ausnahme){
			$obj = $ausnahme['obj'];
			$datumObj = $obj->getDatum();
			$zmrObj = $obj->getAusZimmer();
			$NeuZmrObj = $obj->getNeuZimmer();
			$oPerson = $obj->getInfoPerson();
			if($oPerson){
			      $sendto_email = $oPerson->getEmail();
			      $sendto_name = $oPerson->getName();
			}
			$bel['tag'] = $aWeekday[$datumObj->format('N')];
			$bel['datum'] = $datumObj->format('d.m.Y');
			$bel['aus_zimmer'] = $zmrObj->getHaus() . ' ' . $zmrObj->getZimmer();
			$bel['zeit_abBis'] = $obj->getZeitAb().'-'.$obj->getZeitBis() . ' Uhr';
			$bel['rArr'] = ' &rarr; ';
			$bel['neu_zimmer'] = $NeuZmrObj->getUid() == $zmrObj->getUid() ? 'Kein Ersatz' : $NeuZmrObj->getHaus() . ' ' . $NeuZmrObj->getZimmer();
			$bel['neu_zeit_abBis'] = $obj->getNeuZeitAb().'-'.$obj->getNeuZeitBis() . ' Uhr';
			$bel['ausnahmetext'] = $obj->getAusnahmetext();
			$bel['belegungen'] = '(' .$ausnahme['belegungen'].')';
			$ausnahmeZeile[] =  implode( ' ' , $bel);
		  }
		  if(empty($sendto_email))continue;
		  $ausnahmeBody = implode( "<br />" , $ausnahmeZeile);
		  $varRep = array( '_ausnahmen_' => $ausnahmeBody , '_sendto_email_' => $sendto_email , '_sendto_name_' =>$sendto_name );
		  $rawBodyText = str_replace( array_keys($varRep) , $varRep , $edFields['mail_message'] );
		  $bodyText = str_replace( "\n" , "<br />" , $rawBodyText . $signature );
		  $aBcc = array();
		  if( $edFields['debug_send'] && $edFields['blincopy_sender'] ){
			$aMailto = array( $edFields['sender_email'] );
		  }elseif( empty($edFields['debug_send']) ){
			if( $edFields['blincopy_sender'] ) $aBcc = array( $edFields['sender_email'] );
// 			if( $this->settings['sendmail_mode'] == 1 ){
// 			      $aMailto =  array( $sendto_email );
// 			}else{
			      $aMailto =  array( $edFields['sender_email'] );
// 			}
		  }else{ // debug-mode AND NOT blindcopy
			continue;
		  }
		  $aMessageRec[$teacherUid] = array(
		      'Body' => $bodyText,
		      'Subject' => $edFields['mailSubject'],
		      'From' => $edFields['sender_email'],
		      'To' => $aMailto,
		      'Bcc' => $aBcc
		  );
	      }
	      
	      $mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
	      foreach($aMessageRec as $teacherUid=> $teacherGroup){
		  $mail->setBody( $teacherGroup['Body']   , 'text/html' );
		  $mail->setSubject( $teacherGroup['Subject'] );
		  $mail->setFrom( $teacherGroup['From'] );
		  $mail->setTo( $teacherGroup['To'] );
		  if( count($teacherGroup['Bcc']) ) $mail->setBcc( $teacherGroup['Bcc'] );
		  $mail->send();
	      }
	      
	      return count($aMessageRec);
	}
	
	/**
	 * action conflicts
	 *
	 * @return void
	 */
	public function conflictsAction() {
		$addToDate = $this->settings['userfields']['conflicts_days']['value'];
		if( empty($addToDate) ) $addToDate = 365;
		$aDates = array( 'date'=> $this->settings['filter']['date'] , 'todate'=> $this->settings['filter']['date']+(3600*24*$addToDate) );
		$conflicts = $this->dbHelperUtility->mkArrConflictsByRoomAndDates( array() , $aDates );
		
		if ($this->request->hasArgument('download')) $this->downloadConflicts($conflicts , $this->request->getArgument('download') );
		
// 		$aStrDates = array( 'date'=>date( 'd.m.Y' , $this->settings['filter']['date']) , 'todate'=> date( 'd.m.Y' , $this->settings['filter']['date']+(3600*24*$addToDate) ) );
		$this->view->assign('filter', $aDates);
		$this->view->assign('conflicts', $conflicts);
	}

	/**
	 * downloadConflicts
	 * used by action conflicts
	 *
	 * @param array $conflicts
	 * @param string $reqFormat
	 * @return void
	 */
	public function downloadConflicts($conflicts , $reqFormat='xls') {
		$tableRows = array();
		foreach($conflicts as $conflict){
		      foreach($conflict['tt'] as $key=>$timetable){
			    if( method_exists( $conflict['bel'] , 'getDatum' ) ) {
				$objDatum = $conflict['bel']->getDatum();
				$objZimmer = $conflict['bel']->getBelZimmer();
				$belegungstext = $conflict['bel']->getBelegungstext();
				$zeitAb = $conflict['bel']->getAb();
				$zeitBis = $conflict['bel']->getBis();
			    }else{
				$objDatum = $conflict['bel']->datum;
				$objZimmer = $conflict['bel']->belZimmer;
				$belegungstext = $conflict['bel']->belegungstext;
				$zeitAb = $conflict['bel']->ab;
				$zeitBis = $conflict['bel']->bis;
			    }
			    if(!$objDatum) continue;
			    if(!$objZimmer) continue;
			    $status = method_exists( $conflict['bel'] ,  'getStatus' ) ? $conflict['bel']->getStatus() : $conflict['bel']->status;
			    $ix = $objDatum->format('U').$zeitAb.$timetable['ab'] .$key.$objZimmer->getUid();
			    $tableRows[$status][$ix]['datum'] = $objDatum->format('d.m.y');
			    $tableRows[$status][$ix]['zimmer'] = $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer();
			    $tableRows[$status][$ix]['belZeit'] = $zeitAb . '-' . $zeitBis;
			    $tableRows[$status][$ix]['belegungstext'] = $belegungstext;
			    $tableRows[$status][$ix]['planZeit'] = $timetable['ab'] . '-' . $timetable['bis'];
			    $tableRows[$status][$ix]['planText'] = $timetable['belegungstext'];
		      }
		}
		
		if ($reqFormat == 'xls') {
			if( count($tableRows) ){
			      $aTables = array();
			      $aLabels = array( 1 => 'Stundenplan' , 102 => 'Ausnahme' );
			      foreach( $tableRows as $status => $rowGroup ){
				    if( count($rowGroup) ) $aTables[count($rowGroup) . ' Konflikte mit ' . $aLabels[$status] ] = $rowGroup;
				  
			      }
			      if( count($aTables) ){
				    $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				    $downloader->downloadAsXls( $aTables , 'konflikte_' . date('ymd_Hi') . '.xlsx');
				    return;
			      }
			}
		}
		return $tableRows;
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		$newAusnahme = $this->getRequests();
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 2 );
		if($newAusnahme['ausZimmer']) $zimmers[$newAusnahme['ausZimmer']->getUid()]->zimmer = 'Kein Ersatz! ' . $zimmers[$newAusnahme['ausZimmer']->getUid()]->zimmer;
		if($newAusnahme['timetable'] && $newAusnahme['datum']) $ttAusnahme = $this->ausnahmeRepository->findByTimetableAndDate($newAusnahme['timetable'] , $newAusnahme['datum']);

		$this->view->assign('zimmer', $zimmers );
		$this->view->assign('newAusnahme', $newAusnahme );
		$this->view->assign('ausnahmengruppe', $ttAusnahme );
		
	}
	/**
	 * getRequests
	 * used by action new, returns an associated 1-dim array with incoming values
	 *
	 * @return array
	 */
	public function getRequests() {
		if ($this->request->hasArgument('timetable')) {
		    $newAusnahme['timetable'] = $this->request->getArgument('timetable');
		    $ttRep = $this->timetableUtility->getTimetableRepository()->findByUid( $newAusnahme['timetable'] );
		    $newAusnahme['zeitAb'] = $ttRep->getTimeFrom();
		    $newAusnahme['zeitBis'] = $ttRep->getTimeTo();
		    $newAusnahme['neuZeitAb'] = $newAusnahme['zeitAb'] ;
		    $newAusnahme['neuZeitBis'] = $newAusnahme['zeitBis'] ;
		    $newAusnahme['infoPerson'] = $ttRep->getRelTeacher();
		}
		if ($this->request->hasArgument('setValue')) {
		      $newVals =  $this->request->getArgument('setValue');
		      if( is_numeric($newVals['belZimmer']) && !empty($newVals['belZimmer']) ) {
			    $zimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['belZimmer']);
			    $newAusnahme['neuZimmer'] = $zimmer;
			//    $newAusnahme['ausZimmer'] = $zimmer; // hack: if click-event sends only belZimmer but no ausZimmer
		      }
		      if( is_numeric($newVals['ausZimmer']) && !empty($newVals['ausZimmer']) ) {
			    $ausZimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['ausZimmer']);
			    $newAusnahme['ausZimmer'] = $ausZimmer;
		      }
		      if( is_numeric($newVals['datum']) && !empty($newVals['datum']) ) {
			  $newAusnahme['datum'] = $newVals['datum'];
		      }elseif(!empty($newVals['datum'])){
			  $da = explode( '.' , $newVals['datum'] );
			  if( is_numeric($da[0]) && is_numeric($da[1]) && is_numeric($da[2])  ){
			      $newAusnahme['datum'] = mktime( 12,0,0,$da[1],$da[0],$da[2]);
			  }
		      }
		}
		return $newAusnahme;
	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
		$args = $this->arguments['newAusnahme']->getPropertyMappingConfiguration();
		$args->forProperty('infoDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffrps\Domain\Model\Ausnahme $newAusnahme
	 * @return void
	 */
	public function createAction(\Mff\Mffrps\Domain\Model\Ausnahme $newAusnahme) {
		    $numbHowerFrom = 0 + str_replace( ':' , '.' , $newAusnahme->getNeuZeitAb());
		    $numbHowerTo = 0 + str_replace( ':' , '.' , $newAusnahme->getNeuZeitBis());
		    $howerFrom = floor( $numbHowerFrom );
		    $howerTo = floor( $numbHowerTo );
		    $minFrom = round(($numbHowerFrom-$howerFrom)*100); // eg. 5
		    $minTo = round(($numbHowerTo-$howerTo)*100); // eg. 55
		    $from = sprintf( '%02s' , $howerFrom ) . ':' . sprintf( '%02s' , $minFrom );
		    $to = sprintf( '%02s' , $howerTo ) . ':' . sprintf( '%02s' , $minTo );
		    if( $newAusnahme->getNeuZeitAb() != $from ){$newAusnahme->setNeuZeitAb($from);}
		    if( $newAusnahme->getNeuZeitBis() != $to ){$newAusnahme->setNeuZeitBis($to);}
		$this->ausnahmeRepository->add($newAusnahme);
		$this->persistenceManager->persistAll();
		$this->addFlashMessage('Neue Ausnahme erstellt: #'.$newAusnahme->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 2 );
		$updated = 1;
		$this->forward('edit', NULL, NULL, array('ausnahme' => $newAusnahme,'zimmer'=>$zimmers,'pageType'=>'95','updated'=>$updated));
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffrps\Domain\Model\Ausnahme $ausnahme
	 * @ignorevalidation $ausnahme
	 * @return void
	 */
	public function editAction(\Mff\Mffrps\Domain\Model\Ausnahme $ausnahme) {
		// if called from a link manipulate ausnahme
		if ($this->request->hasArgument('setValue')) {
		      $newVals =  $this->request->getArgument('setValue');
		      if($newVals['belZimmer']){
			    $neuZimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['belZimmer']);
			    $ausnahme->setNeuZimmer($neuZimmer);
		      }
		}
		$this->view->assign('ausnahme', $ausnahme);
		
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 2 );
		$ausZimmer = $ausnahme->getAusZimmer()->getUid();
		$zimmers[$ausZimmer]->zimmer = 'Kein Ersatz! ' . $zimmers[$ausZimmer]->zimmer;
		$this->view->assign('zimmer', $zimmers );
		
		$aAusnahme['timetable'] = $ausnahme->getTimetable();
		$ttRep = $this->timetableUtility->getTimetableRepository();
		$fndRes = $ttRep->findByUid( $aAusnahme['timetable'] ) ;
		$theZimmer = $ausnahme->getNeuZimmer()->getUid();
//		$cssStatus = ( $ausZimmer == $theZimmer &&  $ausnahme->getNeuZeitAb() < $ausnahme->getZeitBis() && $ausnahme->getNeuZeitBis() > $ausnahme->getZeitAb()  ) ? 103 : 102;
		$cssStatus = ( $ausZimmer == $theZimmer ) ? 103 : 102;
		$noTt =  !$fndRes ? 'nott ' : '';
		$this->view->assign('status', $noTt.'bel_status_'.$cssStatus);
		
		$aAusnahme['datum'] = $ausnahme->getDatum()->format('U');
		$ttAusnahme = $aAusnahme['timetable'] && $aAusnahme['datum'] ? $this->ausnahmeRepository->findByTimetableAndDate($aAusnahme['timetable'] , $aAusnahme['datum']) : array();
		$this->view->assign('ausnahmengruppe', $ttAusnahme );
		
		$updated = $this->request->hasArgument('updated') ? $this->request->getArgument('updated') : 0;
		$this->view->assign('updated', $updated);
		$this->view->assign('oldact', $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht');
		$setting = $this->settings;
		if ($this->request->hasArgument('filter')) {
			$setting['filter'] = $this->request->getArgument('filter');
		}
		$this->view->assign('settings', $setting );
	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		$args = $this->arguments['ausnahme']->getPropertyMappingConfiguration();
		$args->forProperty('infoDatum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		$this->settings['forwardingArguments']['oldact'] =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht';
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffrps\Domain\Model\Ausnahme $ausnahme
	 * @return void
	 */
	public function updateAction(\Mff\Mffrps\Domain\Model\Ausnahme $ausnahme) {
		    $numbHowerFrom = 0 + str_replace( ':' , '.' , $ausnahme->getNeuZeitAb());
		    $numbHowerTo = 0 + str_replace( ':' , '.' , $ausnahme->getNeuZeitBis());
		    $howerFrom = floor( $numbHowerFrom );
		    $howerTo = floor( $numbHowerTo );
		    $minFrom = round(($numbHowerFrom-$howerFrom)*100); // eg. 5
		    $minTo = round(($numbHowerTo-$howerTo)*100); // eg. 55
		    $from = sprintf( '%02s' , $howerFrom ) . ':' . sprintf( '%02s' , $minFrom );
		    $to = sprintf( '%02s' , $howerTo ) . ':' . sprintf( '%02s' , $minTo );
		    if( $ausnahme->getNeuZeitAb() != $from ){$ausnahme->setNeuZeitAb($from);}
		    if( $ausnahme->getNeuZeitBis() != $to ){$ausnahme->setNeuZeitBis($to);}
		$this->addFlashMessage('Gespeichert', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->ausnahmeRepository->update($ausnahme);
		$updated = 1;
		$this->settings['forwardingArguments']['ausnahme'] = $ausnahme;
		$this->settings['forwardingArguments']['pageType'] = '95';
		$this->settings['forwardingArguments']['updated'] = $updated;
		if ($this->request->hasArgument('filter')) {
			$this->settings['forwardingArguments']['filter'] = $this->request->getArgument('filter');
		}else{
			$this->settings['forwardingArguments']['filter'] = $this->settings['filter'];
		}
		$this->forward('edit', NULL, NULL, $this->settings['forwardingArguments']);
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffrps\Domain\Model\Ausnahme $ausnahme
	 * @return void
	 */
	public function deleteAction(\Mff\Mffrps\Domain\Model\Ausnahme $ausnahme) {
		$this->addFlashMessage('Ausnahme gelöscht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->ausnahmeRepository->remove($ausnahme);
		$this->persistenceManager->persistAll();
		
// 		$oldact = ($this->request->hasArgument('oldact')) ? $this->request->getArgument('oldact') : 'edit';
// 		$this->settings['forwardingArguments']['ausnahme'] = $ausnahme;
// 		$this->settings['forwardingArguments']['pageType'] = '95';
// 		$this->settings['forwardingArguments']['updated'] = 3;
// 		if ($this->request->hasArgument('filter')) {
// 			$this->settings['forwardingArguments']['filter'] = $this->request->getArgument('filter');
// 		}else{
// 			$this->settings['forwardingArguments']['filter'] = $this->settings['filter'];
// 		}
// 		$this->forward($oldact, NULL, NULL, $this->settings['forwardingArguments']);
	}

}
