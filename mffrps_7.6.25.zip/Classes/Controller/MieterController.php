<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * MieterController
 */
class MieterController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * mieterRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\MieterRepository
	 * @inject
	 */
	protected $mieterRepository = NULL;

	/**
	 * anlassRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
	 * @inject
	 */
	protected $anlassRepository = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['userfields'] = $this->systemOptionsUtility->getUserOptions();
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$cObj = $configurationManager->getContentObject();
		$this->settings['piUid'] = $cObj->data['uid'];
	}


	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		if ($this->request->hasArgument($this->settings['formname'])) {
			$inVars = $this->request->getArgument($this->settings['formname']);
			if(isset($inVars['filter'])) $this->settings['filter'] = $inVars['filter'];
			$this->view->assign($this->settings['formname'] , $this->request->getArgument($this->settings['formname']) );
		}
		
		$this->view->assign('settings', $this->settings);
		$mieters = $this->mieterRepository->findAll();
		
		if ($this->request->hasArgument('download')) {
			$reqFormat = $this->request->getArgument('download');
			if ($reqFormat == 'xls') {
				$mieterinfo = array();
				foreach($mieters as $mieterObj){
				      $uid = $mieterObj->getUid();
				      $mieterinfo[$uid]['mieter_uid'] = $uid;
				      $mieterinfo[$uid]['anrede'] = $mieterObj->getAnrede();
				      $mieterinfo[$uid]['name'] = $mieterObj->getName();
				      $mieterinfo[$uid]['kurz'] = $mieterObj->getKurz();
				      $mieterinfo[$uid]['telefon'] = $mieterObj->getTelefon();
				      $mieterinfo[$uid]['email'] = $mieterObj->getEmail();
				      $mieterinfo[$uid]['telefax'] = $mieterObj->getTelefax();
				      $mieterinfo[$uid]['strasse_nr'] = $mieterObj->getStrasseNr();
				      $mieterinfo[$uid]['plz_ort'] = $mieterObj->getPlzOrt();
				      $mieterinfo[$uid]['intern'] = $mieterObj->getIntern() ? 'Ja' : '';
				      $mieterinfo[$uid]['verstecken'] = $mieterObj->getVerstecken() ? 'Ja' : '';
				}
				$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				$downloader->downloadAsXls( array('Mieter'=>$mieterinfo), 'mieter_' . date('ymd_Hi') . '.xlsx');
				return;
			}
		}

		$this->view->assign('mieters', $mieters);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffrps\Domain\Model\Mieter $newMieter
	 * @return void
	 */
	public function createAction(\Mff\Mffrps\Domain\Model\Mieter $newMieter) {
		$this->addFlashMessage('Mieter erstellt', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->mieterRepository->add($newMieter);
		$this->persistenceManager->persistAll();
		$forwardingArguments['mieter'] = $newMieter;
		$forwardingArguments['pageType'] = '95';
		$this->forward( 'edit' , NULL, NULL, $forwardingArguments );
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffrps\Domain\Model\Mieter $mieter
	 * @ignorevalidation $mieter
	 * @return void
	 */
	public function editAction(\Mff\Mffrps\Domain\Model\Mieter $mieter) {
		$this->view->assign('mieter', $mieter);
		//$this->dataUtility->deleteAnlass();
		$anlass = $this->request->hasArgument('anlass') ? $this->request->getArgument('anlass') : array();
		if(!empty($anlass)){
		      $this->deleteAnlass( $anlass );
		}
		$mtrAnlass = $this->anlassRepository->findByMieter( $mieter->getUid() );
		$this->view->assign('anlasses', $mtrAnlass);
		
		$anlassList = array();
		foreach($mtrAnlass as $objAnlass){ $anlassList[] = $objAnlass->getUid(); }
		$this->view->assign('anlassList', implode( ',' , $anlassList) );
	}

	/**
	 * addMtrAnlassToMieter
	 *
	 * @param \Mff\Mffrps\Domain\Model\Mieter $mieter
	 * @param string $verwendungszweck
	 * @ignorevalidation $mieter
	 * @return void
	 */
	public function addMtrAnlassToMieter(\Mff\Mffrps\Domain\Model\Mieter $mieter , $verwendungszweck ) {
		$uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->settings['optionfields']['pdf_signature_images']['path'] ) , '/' ) . '/';
		$signatureFiles = $this->systemOptionsUtility->readInDir($uploadDir) ;
		$userSignature = array_search( $GLOBALS['TSFE']->fe_user->user['username'] , $signatureFiles );
		$acronym = $GLOBALS['TSFE']->fe_user->user['eco_acronym'] ? $GLOBALS['TSFE']->fe_user->user['eco_acronym'] : $GLOBALS['TSFE']->fe_user->user['username'];
		$dateObj= new \DateTime( date("Y-m-d\TH:i:s") );
	      $kuerzel = $userSignature ? $signatureFiles[$userSignature] : $acronym;
	      $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\Anlass');
	      $newCode->setMieter($mieter->getUid());
	      $newCode->setVerwendungszweck($verwendungszweck);
	      $newCode->setSchulleitungKurz( $kuerzel );
	      $newCode->setSchulleitungDatum( $dateObj );
	      $mieter->addMtrAnlass($newCode);
	      return $mieter;
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffrps\Domain\Model\Mieter $mieter
	 * @return void
	 */
	public function updateAction(\Mff\Mffrps\Domain\Model\Mieter $mieter) {
		$request = $this->request->getArgument('mtrAnlass');
		$anlass = $this->request->hasArgument('anlass') ? $this->request->getArgument('anlass') : array();
		if(!empty($request['verwendungszweck'])){
		      $mieter = $this->addMtrAnlassToMieter( $mieter , $request['verwendungszweck'] );
		}
		if(!empty($anlass)){
		      $this->deleteAnlass( $anlass );
		}
		$this->addFlashMessage('Mieter '.$mieter->getUid().' was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->mieterRepository->update($mieter);
		/*if(!empty($request['verwendungszweck']))*/
		$this->persistenceManager->persistAll();
		$this->forward('edit', NULL, NULL, array('mieter' => $mieter));
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffrps\Domain\Model\Mieter $mieter
	 * @return void
	 */
	public function deleteAction(\Mff\Mffrps\Domain\Model\Mieter $mieter) {
		$this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->mieterRepository->remove($mieter);
		$this->persistenceManager->persistAll();
// 		$this->redirect('list');
	}

	/**
	 * deleteAnlass
	 *
	 * @param int $anlassUid
	 * @return void
	 */
	public function deleteAnlass( $anlassUid ) {
		$this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$anlass = $this->anlassRepository->findByUid($anlassUid);
		$this->anlassRepository->remove($anlass);
		$this->persistenceManager->persistAll();
	}

}