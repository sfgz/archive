<?php
namespace Mff\Mffrps\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * BelegungController
 */
class BelegungController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 * @inject
	 */
	protected $belegungRepository = NULL;

	/**
	 * anlassRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
	 * @inject
	 */
	protected $anlassRepository = NULL;

	/**
	 * mieterRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\MieterRepository
	 * @inject
	 */
	protected $mieterRepository = NULL;

	/**
	 * ausnahmeRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AusnahmeRepository
	 * @inject
	 */
	protected $ausnahmeRepository = NULL;

	/**
	 * antragRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AntragRepository
	 * @inject
	 */
	protected $antragRepository = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;

	/**
	 * tagesansichtUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $tagesansichtUtility = NULL;

	/**
	 * dbHelperUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $dbHelperUtility = NULL;

	/**
	 * sucheUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $sucheUtility = NULL;
	
	/**
	 * calendarUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $calendarUtility = NULL;
	
	/**
	 * mailUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $mailUtility = NULL;

	/**
	 * belegungListEditorUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $belegungListEditorUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	protected $configurationManager ;
	
	/**
	 * initializeAction
	 *
	 */
	public function initializeAction() {
		date_default_timezone_set ( 'Europe/Zurich' );
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings['userfields'] = $this->systemOptionsUtility->getUserOptions();
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$this->settings['anchor2category'] = $this->systemOptionsUtility->settings['anchor2category'];
		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		}
		$this->settings = $this->systemOptionsUtility->handleRequestVars( $inVars , $this->settings );
		$this->dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility( $this->settings );
		$this->tagesansichtUtility = new \Mff\Mffrps\Utility\TagesansichtUtility( $this->settings );
		$this->calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
		$this->mailUtility = new \Mff\Mffrps\Utility\MailUtility( $this->settings );

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$this->configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->settings['zimmerPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['zimmerPid'];
		$this->refreshAntrag();
// 		print_r( $this->settings['userfields'] );
// 		print_r( $this->settings['filter'] );
	}

	/**
	 * refreshAntrag
	 *
	 * @param int $interval minutes interval to refresh
	 * @return void
	 */
	public function refreshAntrag( $interval = 60 ) {
		$calendarData = $GLOBALS['TSFE']->fe_user->getKey('user', 'calendarData');
		$this->settings['antrag']['update_hint'] =0;
		if ( isset($calendarData['meta']['calendarDate']) ) {
		      $calendarArr = $calendarData['data'];
		      $calendarDate = $calendarData['meta']['calendarDate'];
		      $nowTime = time();
		      $calendars['backup_updated']  = $nowTime-( $interval * 60 ) > $calendarDate ? 0 : 1;
		}else{
		      $calendars['backup_updated']  = 0;
		}
		if ( !$calendars['backup_updated'] ) {
		      $calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
		      $calendarDate = time();
		      $calendarArr = $calendarUtility->getCalendarsData( 1 );
		      $calendarData = array( 'meta'=>array('calendarDate'=>$calendarDate) , 'data'=>$calendarArr );
		      $GLOBALS["TSFE"]->fe_user->setKey("user","calendarData", $calendarData);
		      $GLOBALS["TSFE"]->fe_user->sesData_change = true;
		      $GLOBALS["TSFE"]->fe_user->storeSessionData();
		}
		if( count($calendarData['data']) ) {$this->settings['antrag']['update_hint'] +=1;}
		$antrags = $this->antragRepository->findAll();
		if( count($antrags) ) {$this->settings['antrag']['update_hint'] +=2;}
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function initializeListAction() {
		$this->belegungListEditorUtility = new \Mff\Mffrps\Utility\BelegungListEditorUtility( $this->settings );
		
		$fieldList = explode( ',' , $this->settings['userfields']['display_belegung_listenfelder']['value'] );
		$z=0;
		foreach( $fieldList as $fieldToShow ){
		    ++$z;
		    $this->settings['spalten'][$z] = trim($fieldToShow);
		}
		
		if ( $this->request->hasArgument('belegungen') ) {
			$edFields = $this->request->getArgument('belegungen');
			$rawEditFieldName = strtolower($this->settings['spalten'][$edFields['editfield']]);
			$rawEditValue = isset($edFields[$rawEditFieldName]) ? $edFields[$rawEditFieldName] : $edFields['editvalue'];
			if(is_array($edFields['editcheck'])){
			    foreach($edFields['editcheck'] as $belid=>$belCheck){
				if($belid != $belCheck) continue;
				$this->belegungListEditorUtility->editBelegungByFieldname( $rawEditFieldName ,  $rawEditValue , $belid);
			    }
			    $this->persistenceManager->persistAll();
			}
		}
		
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		if( $this->settings['filter']['anlass'] && $this->settings['filter']['anlassexclusive'] ){
		      $belegungs = $this->belegungRepository->findByAnlassList( $this->settings['filter']['anlass'] );
		}else{
		      $zimmers = $this->zimmerUtility->getZimmerRepository()->findByRoom($this->settings['userfields']['filter_room']['value'],TRUE);
		      foreach( $zimmers as $zmr ){ $zmrArr[] = $zmr->getUid(); }
		      $rawBelegungs = $this->belegungRepository->findByRoomsAndDates( $zmrArr , $this->settings['filter'] );
		      if( $this->settings['filter']['anlass'] ){
			  $aAnlasses = explode( ',' , $this->settings['filter']['anlass'] );
			  foreach($aAnlasses as $rAnlassUid){ $anlassUids[trim($rAnlassUid)]=trim($rAnlassUid);}
			  foreach($rawBelegungs as $ix=>$obj){
				$aUid = $obj->getAnlass();
				if( !isset($anlassUids[$aUid]) ) continue;
				$belegungs[$ix] = $obj;
			  }
		      }else{
			  $belegungs = $rawBelegungs;
		      }
		}
		
		if( !$belegungs ) return;
		
		if ($this->request->hasArgument('download')) {
			$reqFormat = $this->request->getArgument('download');
			if ($reqFormat == 'xls') {
				$tableRows = $this->belegungObjToArr( $belegungs , false ) ;
				$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				$downloader->downloadAsXls( array('Belegungen'=>$tableRows), 'belegungen_' . date('ymd_Hi') . '.xlsx');
				return;
			}
		}

		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 1 );
		$this->view->assign('zimmer', $zimmers );
		if ( $this->request->hasArgument('belegungen') ) {
			$edFields = $this->request->getArgument('belegungen');
			$this->view->assign('belegungen', $edFields );
			$tableRows = $this->belegungObjToArr( $belegungs , true , 3 ) ;
			if(is_array($tableRows)){
			    foreach($tableRows as $ix=>$arrBelegung){
				$tableRows[$ix]['uid']=$ix;
				$tableRows[$ix]['ischecked'] = $edFields['editcheck'][$ix] == $ix ? $edFields['editcheck'][$ix] : false;
			    }
			}
			$this->view->assign( 'belegungs' , $tableRows );
			$this->view->assign( 'editobjectcssclass' , '' );
		}else{
			$this->view->assign( 'belegungs' , $this->belegungObjToArr($belegungs , true ) );
			$this->view->assign( 'editobjectcssclass' , 'editobject' );
		}
		
		$this->settings['dateFilter']['date'] = date( 'd.m.Y' , $this->settings['filter']['date']);
		$this->settings['dateFilter']['todate'] = date( 'd.m.Y' , $this->settings['filter']['todate']);
		
		$cObj = $this->configurationManager->getContentObject();
		$this->settings['piUid'] = $cObj->data['uid'];
		
		$setting = $this->settings;
		if ($this->request->hasArgument('filter')) {
			$setting['filter'] = $this->request->getArgument('filter');
		}
		$this->view->assign('settings', $setting );
	}

	/**
	 * belegungObjToArr
	 *
	 * @param array $objBelegung
	 * @param boolean $addUid add the uid field or not
	 * @param int $dim 2-or 3-dim array
	 * @return array
	 */
	public function belegungObjToArr( $objBelegung , $addUid = false , $dim = 2 ) {
		$aAnlass = $this->dbHelperUtility->getAnlassMieterInfos();
		$tableRows = array();
		foreach($objBelegung as $ix=>$obj){
		      $aUid = $obj->getAnlass();
		      $uid = $obj->getUid();
		      if( $addUid ) $tableRows[$uid]['uid'] = $uid;
		      $tableRows[$uid]['belegung_uid'] = $uid;
		      $datumObj = $obj->getDatum();
		      $tableRows[$uid]['datum'] = $datumObj ? $datumObj->format('d.m.Y') : '01.01.1979';
		      $tableRows[$uid]['ab'] = $this->dbHelperUtility->cleanTimeString($obj->getAb());
		      $tableRows[$uid]['bis'] = $this->dbHelperUtility->cleanTimeString($obj->getBis());
// 		      $tableRows[$uid]['ab'] = $obj->getAb();
// 		      $tableRows[$uid]['bis'] = $obj->getBis();
		      $zimmerObj = $obj->getBelZimmer();
		      if( $dim == 3 ){
			    $tableRows[$uid]['belZimmer']['uid'] = $zimmerObj ? $zimmerObj->getUid(): '';
			    $tableRows[$uid]['belZimmer']['haus'] = $zimmerObj ? $zimmerObj->getHaus() : '';
			    $tableRows[$uid]['belZimmer']['zimmer'] = $zimmerObj ? $zimmerObj->getZimmer() : '';
		      }
		      $tableRows[$uid]['zimmerUid'] = $zimmerObj ? $zimmerObj->getUid(): '';
		      $tableRows[$uid]['zimmer'] = $zimmerObj ? $zimmerObj->getHaus() . ' ' . $zimmerObj->getZimmer() : 'LEER!';
		      $tableRows[$uid]['belegungstext'] = $obj->getBelegungstext();
		      $tableRows[$uid]['zusatztext'] = $obj->getZusatztext();
		      $tableRows[$uid]['betrag'] = $obj->getBetrag();
		      $tableRows[$uid]['status'] = $obj->getStatus();
		      if(is_array($aAnlass[$aUid])) foreach($aAnlass[$aUid] as $key => $value) $tableRows[$uid][$key] = $value;
		}
		return $tableRows;
	}

	/**
	 * action tagesansicht
	 *
	 * @return void
	 */
	public function tagesansichtAction() {

		$cellWidth = $this->settings['display_tagesplan_cell_width'];
		$this->settings['userfields']['display_tagesplan_content_height']['value'] = $this->settings['userfields']['display_tagesplan_cell_height']['value'];
		$limit = $this->settings['userfields']['display_tagesplan_linkzeiten_limit']['value'];
		$howers = $this->settings['filter']['filter_tagesplan_timerange_to'] - $this->settings['filter']['filter_tagesplan_timerange_from'] ;
		if( $howers >= $limit ) {
		      $cellWidth = $this->settings['display_tagesplan_cell_width_short'];
		      $this->settings['cellWidthCss'] = 'small';
		}else{
		      $this->settings['cellWidthCss'] = 'large';
		}
		$this->settings['display_tagesplan_cell_width'] = $cellWidth;
		$this->tagesansichtUtility->settings = $this->settings;
		
		// store zimmer-objects in a 1-dimensional array
		$aFilteredRooms = array();
		$zimmers = $this->zimmerUtility->getZimmerRepository()->findByRoom($this->settings['userfields']['filter_room']['value'],FALSE);
		foreach( $zimmers as $zmr ) $aFilteredRooms[$zmr->getUid()] = $zmr;

		// store filemaker-timetable object in a 2-dimensional array
		$zmrResObj = $this->dbHelperUtility->mkArrTimetableByRoomAndDate( $aFilteredRooms , $this->settings['filter']['date'] , array() );
 		$zmrResObj = $this->dbHelperUtility->mkArrAusnahmeByRoomAndDate( $aFilteredRooms , $this->settings['filter']['date'] , $zmrResObj );
 		$zmrResObj = $this->dbHelperUtility->mkArrBelegungByRoomAndDate( $aFilteredRooms , $this->settings['filter']['date'] , $zmrResObj );

 		$aDates = array( 'date'=>$this->settings['filter']['date'] , 'todate'=>$this->settings['filter']['date'] );
 		$calendarObj = $this->dbHelperUtility->mkArrHolidayByDates( $aDates , $this->settings['optionfields']['filter_startTimeFrom']['value'] );
		$this->settings['holiday'] = $calendarObj[ date('d.m.y',$this->settings['filter']['date']) ];
		if( !is_array($this->settings['holiday']) ){
		      $this->settings['holiday'] = array( 'from'=>24 , 'allFrom'=>24 );
		}

		// calculate howers in belegung array
 		$merged_sorted_belegung = $this->tagesansichtUtility->sortMergedBelegung(  $zmrResObj );
		$a_belegung = $this->tagesansichtUtility->calcTimesInBelegung( $merged_sorted_belegung );
		// evaluate amount of rows per zimmer
		$setBlankCell = $this->tagesansichtUtility->evaluateRowNumbers( $a_belegung );
		// create belegung/timetable objects
		$o_belegung = $this->tagesansichtUtility->createObjects( $a_belegung );

		// assemble objects and set howers grid
		$tagesansicht = array();
		foreach( array_keys($aFilteredRooms) as $zimmerIdx ){
		      $aBelPerHwr = array();
		      if(!is_array($setBlankCell[$zimmerIdx]['from'])) $setBlankCell[$zimmerIdx]['from'][0] =array();
		      foreach(array_keys($setBlankCell[$zimmerIdx]['from']) as $zmrRow){
			    for(
				$timeIdx = $this->settings['filter']['filter_tagesplan_timerange_from'] ;
				$timeIdx <= $this->settings['filter']['filter_tagesplan_timerange_to'] ; 
				++$timeIdx
			    ){
				if( !isset($setBlankCell[$zimmerIdx]['noBlank'][$zmrRow][$timeIdx]) && !isset($setBlankCell[$zimmerIdx]['obj'][$zmrRow][$timeIdx]) ){
				      $oBelSlic = new \stdClass();
				      $oBelSlic->type = 'empty';
				      $oBelSlic->label = '';
				      $oBelSlic->title = $zimmerIdx.' '.$timeIdx;
				      $oBelSlic->width = '';//$cellWidth;
				      $oBelSlic->from = 60 * ( $timeIdx + $this->settings['optionfields']['filter_startTimeFrom']['value'] );
				      $oBelSlic->ab =  $this->dbHelperUtility->cleanTimeArray( array( $this->settings['optionfields']['filter_startTimeFrom']['value'] + $timeIdx , 0 ) );//sprintf( '%02s' , $this->settings['optionfields']['filter_startTimeFrom']['value'] + $timeIdx) . ':00';
				      $oBelSlic->bis = $this->dbHelperUtility->cleanTimeArray( array( $this->settings['optionfields']['filter_startTimeFrom']['value'] + 1 + $timeIdx , 0) );
				      $aBelPerHwr[$zmrRow][$timeIdx][0] = $oBelSlic;
				}else{
				      if(is_array($setBlankCell[$zimmerIdx]['from'][$zmrRow][$timeIdx])){
					  foreach($setBlankCell[$zimmerIdx]['from'][$zmrRow][$timeIdx] as $loopCount=>$fromMin){
						$toMin = $setBlankCell[$zimmerIdx]['to'][$zmrRow][$timeIdx][$loopCount];
						$toH = floor( $toMin / 60 );
						$fromH = floor( $fromMin / 60 );
						$restFromMin = $fromMin  - ( $fromH * 60 );
						$restToMin = $toMin - ( $toH * 60 );
						$oBelSlic = new \stdClass();
						$oBelSlic->type = 'empty';
						$oBelSlic->label = '';
						$oBelSlic->title = $fromMin.'-'.$toMin .'='.round($toMin-$fromMin );
						$width = round((($toMin-$fromMin ) / 60)*$cellWidth , 2);
						$oBelSlic->width = ' style="width:'.$width.'px;"';
						$oBelSlic->from = $fromMin;
						$oBelSlic->ab = $this->dbHelperUtility->cleanTimeArray( array( $fromH , $restFromMin ) ); // sprintf( '%02s' , $fromH) . ':' . sprintf( '%02s' , $restFromMin );
						$oBelSlic->bis = $this->dbHelperUtility->cleanTimeArray( array( $toH , $restToMin ) );
						$aBelPerHwr[$zmrRow][$timeIdx][$fromMin] = $oBelSlic;
						
						if( isset($setBlankCell[$zimmerIdx]['obj'][$zmrRow][$timeIdx][$loopCount]) ){
						    $tFrom = $setBlankCell[$zimmerIdx]['obj'][$zmrRow][$timeIdx][$loopCount]['tFrom'];
						    $itemIndex = $setBlankCell[$zimmerIdx]['obj'][$zmrRow][$timeIdx][$loopCount]['uid'];
						    $aBelPerHwr[$zmrRow][$timeIdx][$tFrom] = $o_belegung[$zimmerIdx][ $itemIndex ];
						}
					  }
					  ksort($aBelPerHwr[$zmrRow][$timeIdx]);
				      }
				}
			    }
			    if(isset($aBelPerHwr[$zmrRow])) ksort($aBelPerHwr[$zmrRow]);
		      }
		      $tagesansicht[$zimmerIdx] = new \stdClass();
		      $tagesansicht[$zimmerIdx]->room = $aFilteredRooms[$zimmerIdx];
		      if(isset($aBelPerHwr)) $tagesansicht[$zimmerIdx]->data = $aBelPerHwr;
		}
		$this->view->assign('tagesansicht', $tagesansicht);
		
		// assign new settings
		$startTime = $this->settings['optionfields']['filter_startTimeFrom']['value'];
		for(
		    $timeIdx = $this->settings['filter']['filter_tagesplan_timerange_from'] ;
		    $timeIdx <= $this->settings['filter']['filter_tagesplan_timerange_to'] ; 
		    ++$timeIdx
		)  {
		    $this->settings['allHowers'][$timeIdx] = array(
			  'idx'=>$timeIdx , 
			  'from'=> $this->dbHelperUtility->cleanTimeArray( array( $timeIdx + $startTime , 0 ) ) , 
			  'to'=> $this->dbHelperUtility->cleanTimeArray( array(  1+$timeIdx + $startTime , 0 ) )
		    );
		}
		for(
		    $timeIdx = 0 ;
		    $timeIdx < $this->settings['optionfields']['filter_maxHowers']['value'] ; 
		    ++$timeIdx
		)  {
		    $this->settings['filter_options_timerange_from'][$timeIdx] = $this->dbHelperUtility->cleanTimeArray( array( $timeIdx + $startTime , 0) );
		    $this->settings['filter_options_timerange_to'][$timeIdx] = $this->dbHelperUtility->cleanTimeArray( array( 1+$timeIdx + $startTime , 0 ) );
		}
		$this->settings['dateFilter']['date'] = date( 'd.m.Y' , $this->settings['filter']['date']);
		$this->settings['double']['display_tagesplan_cell_width'] = 2 * $cellWidth;
		
		$this->view->assign('settings', $this->settings);

	}

	/**
	 * Initialize  suche
	 *
	 * @return void
	 */
	public function initializeSucheAction() {
		$this->sucheUtility = new \Mff\Mffrps\Utility\SucheUtility( $this->settings );
		if ($this->request->hasArgument('suche') && $this->request->hasArgument('ok')) {
			$bel = $this->request->getArgument('suche');
			 // create Anlass and Mieter if affored
			if (empty($bel['belegungstext'])) {
			      $this->settings['errorMessages'][] = 'Belegungstext leer, nicht gespeichert!';
			}elseif (empty($bel['anlass'])) {
				if( $this->request->hasArgument('addNew')) {
				      $newUpperRecord = $this->request->getArgument('addNew');
				      if(!empty($newUpperRecord['verwendungszweck'])) {
					  if(!empty($newUpperRecord['kurz']) && !empty($newUpperRecord['name'])) { // create Mieter
					      $newUpperRecord['mieter'] = $this->dbHelperUtility->createNewMieter( $newUpperRecord );
					  }
					  if(!empty($newUpperRecord['mieter'])) { // create Anlass with given Mieter 
						$bel['anlass'] = $this->dbHelperUtility->createNewAnlass( $newUpperRecord );
					  }else{
						if(empty($newUpperRecord['kurz'])) {
						    $this->settings['errorMessages'][] = 'kein Mieter gewählt. Anlass nicht erfasst!';
						}else{
						    $this->settings['errorMessages'][] = 'Mangelnde Angaben zu Mieter. Mieter und Anlass nicht erfasst!';
						}
					  }
				      }else{
					    $this->settings['errorMessages'][] = 'kein Anlass gewählt oder Verwendungszweck leer, nicht gespeichert!';
				      }
				}else{
				      $this->settings['errorMessages'][] = 'kein Anlass gewählt, nicht gespeichert!';
				}
			}
			if(!is_array($this->settings['errorMessages'])){
			      // get days, idx like day_0 day_1 ...
			      foreach( $bel as $idx => $inVar ){
				    if(empty($inVar)) continue;
				    $idxAtoms = explode( '_' , $idx );
				    if($idxAtoms[0] == 'day' ) {
					  $dayAt = explode( '.' ,  $inVar );
					  $aDays[$idxAtoms[1]] = mktime( 12,0,0, $dayAt[1] , $dayAt[0] , $dayAt[2]);
				    }
			      }
			      $eventDB=array();
			      $notifyRequester = array();
			      $crdate = new \DateTime('@' . $GLOBALS['EXEC_TIME']);
			      $timeFrom = $this->dbHelperUtility->cleanTimeString( $this->settings['filter']['filter_suche_timerange_from'] );
			      $timeTo = $this->dbHelperUtility->cleanTimeString( $this->settings['filter']['filter_suche_timerange_to'] );
			      foreach( $bel as $idx => $roomUid ){
				    // get room-rows, idx like room_0_14, room_0_132, room_1_14, room_1_132 ...
				    if(empty($roomUid)) continue;
				    $idxAtoms = explode( '_' , $idx );
				    if($idxAtoms[0] != 'room' ) continue;
				    $dateObj= new \DateTime(date("Y-m-d\TH:i:s", $aDays[$idxAtoms[1]]));
				    
				    $roomObj = $this->zimmerUtility->getZimmerRepository()->findByUid($roomUid);
				    $newBelegung = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\Belegung');
				    $newBelegung->setCrdate( $crdate->getTimestamp() );
				    $newBelegung->setDatum( $dateObj );
				    $newBelegung->setBelZimmer( $roomObj );
				    $newBelegung->setAnlass( $bel['anlass'] );
				    $newBelegung->setBelegungstext( $bel['belegungstext'] );
				    $newBelegung->setZusatztext( $bel['zusatztext'] );
				    $newBelegung->setBetrag( $bel['betrag'] );
				    $newBelegung->setStatus( $bel['status'] );
				    $newBelegung->setAb( $timeFrom );
				    $newBelegung->setBis( $timeTo );
				    $this->belegungRepository->add($newBelegung);
				    //$calendarName = $this->calendarUtility->getCalendarByRoom( $roomObj );
				    $createdBelegung[] = $newBelegung;
				    $this->settings['infoMessages'][] = 'Belegung fuer '.date("d.m.y", $aDays[$idxAtoms[1]]).' in Zimmer '.$roomObj->getHaus().' '.$roomObj->getZimmer().' erfasst.';
			      }
			      $this->persistenceManager->persistAll();
			      if( count($createdBelegung) ) {
// 				      foreach($createdBelegung as $calendarName => $calendarsNewBelegung){
					      foreach($createdBelegung as $newBelegung){
							$this->calendarUtility->updateEventFromBelegung($newBelegung);
							//$eventDB[$calendarName][] = $this->calendarUtility->belegungObj2calendarArr($newBelegung , $calendarName );
							$notifyRequester[] = $newBelegung;
					      }
// 					      $this->calendarUtility->calendarService->calendarPutData( $eventDB[$calendarName] , $calendarName , 'create_'.microtime(true) );
// 				      }
				      if( $this->settings['filter']['deleteAntrag'] ) {
					    $source = $this->settings['filter']['source'];
					    if( empty($source) ) {
						  $antrag = $this->antragRepository->findByUid($this->settings['filter']['deleteAntrag']);
						  if($antrag){
							$this->antragRepository->remove($antrag);
							$this->settings['infoMessages'][] ='Antrag Nr. '.$this->settings['filter']['deleteAntrag'].' entfernt.';
							$this->persistenceManager->persistAll();
						  }
					    }else{
						// $source = calendarName of requesting calendar
						$this->calendarUtility->deleteEventByUid( $source , $this->settings['filter']['deleteAntrag'] );
						$this->settings['infoMessages'][] ='Antrag in Kalender '.$source.' entfernt :'.$this->settings['filter']['deleteAntrag'].'.';
						$this->settings['filter']['source']  ='';
					    }
					    if ( $this->settings['optionfields']['info_to_antragsteller']['value'] && !empty($bel['requestEmail'])) {
						  $emailResult = $this->mailUtility->mailToAntragsteller( $notifyRequester , $bel['requestEmail'] );
						  $this->settings['infoMessages'][] ='Email an '.$bel['requestEmail'].' senden: '.$emailResult.'';
					    }
					    $this->settings['filter']['deleteAntrag'] = '';
				      }
			      }
			}
		}
	}

	/**
	 * action suche
	 *
	 * @return void
	 */
	public function sucheAction() {
		if(is_array($this->settings['errorMessages'])){
		    $this->addFlashMessage( implode(', ' , $this->settings['errorMessages'] ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		}
		if (is_array($this->settings['infoMessages'])){
		    $this->addFlashMessage( implode(', ' , $this->settings['infoMessages'] ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}
		// if option suche_force_weekday is set: adjust dateEnd if weekday is not corresponding with dateStart
		if($this->settings['userfields']['suche_force_weekday']['value']){
		      if( empty($this->settings['filter']['all_days']) && $this->settings['filter']['date'] != $this->settings['filter']['todate'] ){
			    $wdFrom = date('N',$this->settings['filter']['date']);
			    $wdTo = date('N',$this->settings['filter']['todate']);
			    if( $wdFrom != $wdTo ) $this->settings['filter']['todate'] += ( ($wdFrom-$wdTo) * 86400 );
		      }
		}
		if( strlen($this->settings['filter']['filter_suche_timerange_from']) == 2) $this->settings['filter']['filter_suche_timerange_from'] .= ':00';
		if( strlen($this->settings['filter']['filter_suche_timerange_to']) == 2) $this->settings['filter']['filter_suche_timerange_to'] .= ':00';
		if( empty($this->settings['filter']['filter_suche_timerange_from']) ) $this->settings['filter']['filter_suche_timerange_from'] = ($this->settings['optionfields']['filter_startTimeFrom']['value']+ $this->settings['filter']['filter_tagesplan_timerange_from']) .':00';
		if( empty($this->settings['filter']['filter_suche_timerange_to']) ) $this->settings['filter']['filter_suche_timerange_to'] = (1 + $this->settings['optionfields']['filter_startTimeFrom']['value']+ $this->settings['filter']['filter_tagesplan_timerange_to']) .':00';

		if ( $this->request->hasArgument($this->settings['formname']) ) {
		     $inVars =  $this->request->getArgument($this->settings['formname']);
		      $this->view->assign($this->settings['formname'], $inVars);
		}
		if ( $this->request->hasArgument('ok') ) {
			// store zimmer-objects in a 1-dimensional array
			$aFilteredRooms = array();
			$zimmers = $this->zimmerUtility->getZimmerRepository()->findByRoom($this->settings['userfields']['filter_room']['value'],FALSE);
			foreach( $zimmers as $zmr ) $aFilteredRooms[$zmr->getUid()] = $zmr;

			$filter = $this->settings['filter'];
			$filter['howerFrom'] = str_replace( ':' , '.' ,  $this->settings['filter']['filter_suche_timerange_from'] );
			$filter['howerTo'] = str_replace( ':' , '.' ,  $this->settings['filter']['filter_suche_timerange_to'] );
			$filter['suche_showplan_info_deep'] = $this->settings['userfields']['suche_showplan_info_deep']['value'];
			$outArr = $this->sucheUtility->sucheLeereZimmer( $aFilteredRooms , $filter );
			$this->view->assign('outArr', $outArr);
		}
		
		// FIXME wenn variable $suche vorhanden, versucht das skript eine neue Belegung zu erzeugen
		if ($this->request->hasArgument('suche')) {
			$suche = $this->request->getArgument('suche');
			$this->view->assign('suche', $suche );
		}
		if(empty($this->settings['filter']['status'])) $this->settings['filter']['status'] = 1;
		if ($this->request->hasArgument('deleteAntrag')) {
		      $deleteAntragNr = $this->request->getArgument('deleteAntrag');
		      $this->view->assign('deleteAntrag', $deleteAntragNr );
		      $this->settings['filter']['deleteAntrag'] = $deleteAntragNr;
		}
		if ($this->request->hasArgument('source')) {
		      $source = $this->request->getArgument('source');
		      $this->view->assign('source', $source );
		      $this->settings['filter']['source'] = $source;
		}
			
		if ($this->request->hasArgument('addNew')) {
			$addNew = $this->request->getArgument('addNew');
			$this->view->assign('addNew', $addNew );
		}
		
		$this->view->assign('anlaesse', $this->dbHelperUtility->mkAnlassSelectArray() );
		$this->view->assign('mieters', $this->dbHelperUtility->mkMieterSelectArray() );
		$this->view->assign('settings', $this->settings);
	}

	/**
	 * action antrag
	 *
	 * @return void
	 */
	public function antragAction() {
		$belegungs = $this->belegungRepository->findAll();
		$this->view->assign('belegungs', $belegungs);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		if ($this->request->hasArgument('setValue')) {
		      $newVals =  $this->request->getArgument('setValue');
		      $newBelegung = $newVals;
		      if($newVals['belZimmer']) {
			    $zimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['belZimmer']);
			    $newBelegung['belZimmer'] = $zimmer;
		      }
		      if($newVals['from']) $newBelegung['ab'] = $newVals['from'];
		      if($newVals['to']) $newBelegung['bis'] = $newVals['to'];
		      $requestEmail =  $newVals['requestEmail'] ? $newVals['requestEmail'] : 0;
		}
		$newBelegung['intAb'] = floor(str_replace(':','.',$newVals['from'])) - $this->settings['optionfields']['filter_startTimeFrom']['value'];
		$newBelegung['intBis'] = floor(str_replace(':','.',$newVals['to'])) - 1 - $this->settings['optionfields']['filter_startTimeFrom']['value'];
		$newBelegung['status']=1; 
		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 2 );
		$this->view->assign('zimmer', $zimmers );
		$this->view->assign('anlaesse', $this->dbHelperUtility->mkAnlassSelectArray() );
		$this->view->assign('mieters', $this->dbHelperUtility->mkMieterSelectArray() );
		$this->view->assign('newBelegung', $newBelegung );
		
		$action =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht';
		$deleteAntrag =  $this->request->hasArgument('deleteAntrag') ? $this->request->getArgument('deleteAntrag') : 0;
		$source =  $this->request->hasArgument('source') ? $this->request->getArgument('source') :'';

		$this->view->assign('oldact', $action);
		$this->view->assign('deleteAntrag', $deleteAntrag);
		$this->view->assign('source', $source);
		$this->view->assign('requestEmail', $requestEmail);
	}

	/**
	 * Initialize  create
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
		if ($this->request->hasArgument('newBelegung')) {
			$args = $this->arguments['newBelegung']->getPropertyMappingConfiguration();
			$args->forProperty('datum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			
			$this->settings['forwardingArguments']['oldact'] =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht';
			$this->settings['forwardingArguments']['deleteAntrag'] =  $this->request->hasArgument('deleteAntrag') ? $this->request->getArgument('deleteAntrag') : 0;
			$this->settings['forwardingArguments']['source'] =  $this->request->hasArgument('source') ? $this->request->getArgument('source') : '';
 			$this->settings['forwardingArguments']['requestEmail'] =  $this->request->hasArgument('requestEmail') ? $this->request->getArgument('requestEmail') : '';

			$bel = $this->request->getArgument('newBelegung');
			
			if(empty($bel['belZimmer'])) {
			      $this->settings['errorMessages'][] = 'Zimmer leer, nicht gespeichert!';
			      $this->arguments->getArgument('newBelegung')->getPropertyMappingConfiguration()->skipProperties('belZimmer');
			}
			
			if(empty($bel['datum'])) {
			      $this->settings['errorMessages'][] = 'Datum leer, nicht gespeichert!';
			      $this->arguments->getArgument('newBelegung')->getPropertyMappingConfiguration()->skipProperties('datum');
			}
			 // create Anlass and Mieter if affored
			if (empty($bel['anlass'])) {
				if( $this->request->hasArgument('addNew')) {
				      $newUpperRecord = $this->request->getArgument('addNew');
				      if(!empty($newUpperRecord['verwendungszweck'])) {
					  if(!empty($newUpperRecord['kurz'])) { // create Mieter
					      $newUpperRecord['mieter'] = $this->dbHelperUtility->createNewMieter( $newUpperRecord );
					  }
					  if(!empty($newUpperRecord['mieter'])) { // create Anlass with given Mieter 
						$this->settings['newRecordAnlassUid'] = $this->dbHelperUtility->createNewAnlass( $newUpperRecord );
						$this->arguments->getArgument('newBelegung')->getPropertyMappingConfiguration()->skipProperties('anlass');
					  }else{
						if(empty($newUpperRecord['kurz'])) {
						    $this->settings['errorMessages'][] = 'kein Mieter gewählt. Anlass nicht erfasst!';
						}else{
						    $this->settings['errorMessages'][] = 'Mangelnde Angaben zu Mieter. Mieter und Anlass nicht erfasst!';
						}
					  }
				      }else{
					    $this->settings['errorMessages'][] = 'Verwendungszweck leer, Anlass nicht erfasst!';
				      }
				}else{
				      $this->settings['errorMessages'][] = 'kein Anlass gewählt leer, nicht gespeichert!';
				}
			}
		}
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $newBelegung
	 * @validate $newBelegung \Mff\Mffrps\Validation\Validator\BelegungValidator
	 * @return void
	 */
	public function createAction(\Mff\Mffrps\Domain\Model\Belegung $newBelegung) {
		$action = 'edit';
		if(is_array($this->settings['errorMessages'])){
		    $this->addFlashMessage( implode(', ' , $this->settings['errorMessages'] ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    $action = 'new';
		    $this->settings['forwardingArguments']['updated'] = 0;
		    $this->settings['forwardingArguments']['newBelegung'] = $newBelegung;
		}else{
		    $inComeAnlass = $newBelegung->getAnlass();
		    if($this->settings['newRecordAnlassUid'] && empty($inComeAnlass) ) $newBelegung->setAnlass($this->settings['newRecordAnlassUid']);
		    $crdate = new \DateTime('@' . $GLOBALS['EXEC_TIME']);
		    $newBelegung->setCrdate( $crdate->getTimestamp() );
		    $originalAb = $newBelegung->getAb();
		    $originalBis = $newBelegung->getBis();
		    $from = $this->dbHelperUtility->cleanTimeString( $originalAb );
		    $to = $this->dbHelperUtility->cleanTimeString( $originalBis );
		    if( $originalAb != $from ){$newBelegung->setAb($from);}
		    if( $originalBis != $to ){$newBelegung->setBis($to);}
		    $this->belegungRepository->add($newBelegung);
		    $this->persistenceManager->persistAll();
		    $this->calendarUtility->createEventFromBelegung( $newBelegung  );
		    $this->addFlashMessage('Neue Belegung erstellt: #'.$newBelegung->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    if( $this->settings['forwardingArguments']['deleteAntrag'] ) {
			  $source = $this->settings['forwardingArguments']['source'];
			  if( empty($source) ) {
				$antrag = $this->antragRepository->findByUid($this->settings['forwardingArguments']['deleteAntrag']);
				if($antrag) $this->antragRepository->remove($antrag);
				$this->persistenceManager->persistAll();
				$this->addFlashMessage('Antrag Nr. '.$this->settings['forwardingArguments']['deleteAntrag'].' entfernt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			  }else{
			      // $source = calendarName of requesting calendar
			      $msg = $this->calendarUtility->deleteEventByUid( $source , $this->settings['forwardingArguments']['deleteAntrag'] );
			      $this->addFlashMessage('Antrag in Kalender '.$source.' entfernt :'.$this->settings['forwardingArguments']['deleteAntrag'].'. '.$msg, '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			  }
			  if ($this->settings['optionfields']['info_to_antragsteller']['value'] && !empty($this->settings['forwardingArguments']['requestEmail'])) {
				$emailResult = $this->mailUtility->mailToAntragsteller( array( $newBelegung ) , $this->settings['forwardingArguments']['requestEmail'] );
				$this->addFlashMessage('Email an '.$this->settings['forwardingArguments']['requestEmail'].' senden: '.$emailResult.'', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			  }
		    }
		    if(!empty($this->settings['clearCachePid'])) $GLOBALS['TSFE']->clearPageCacheContent_pidList($this->settings['clearCachePid']);
		    $action = 'edit';
		    $this->settings['forwardingArguments']['updated'] = 1;
		    $this->settings['forwardingArguments']['belegung'] = $newBelegung;
		}
		$this->settings['forwardingArguments']['pageType'] = '95';
		$this->forward( $action , NULL, NULL, $this->settings['forwardingArguments'] );
	}

	/**
	 * action edit
	 * 
	 * @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	 * @ignorevalidation $belegung
	 * @return void
	 */
	public function editAction(\Mff\Mffrps\Domain\Model\Belegung $belegung = NULL) {
		if ( $this->request->hasArgument('updateCalendars') ) {
		      $this->calendarUtility->sendDataFromUpdateFile();
		}
		$setting = $this->settings;
		if ($this->request->hasArgument('filter')) {
			$setting['filter'] = $this->request->getArgument('filter');
			$this->view->assign('updated', 2);
		}else{
			$this->view->assign('updated', $this->request->hasArgument('updated')  ?  $this->request->hasArgument('updated') : 0);
		}
		$this->view->assign('settings', $setting );

		$action =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht';
		$this->view->assign('oldact', $action);

		if(!$belegung) return;
		
		if ($this->request->hasArgument('setValue')) { 
		      $newVals =  $this->request->getArgument('setValue');
		      if($newVals['belZimmer']) {
			    $zimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($newVals['belZimmer']);
			    $belegung->setBelZimmer($zimmer);
		      }
		      if($newVals['from']) $belegung->setAb($newVals['from']);
		      if($newVals['minutes']) {
			    $cellWidth = $this->settings['display_tagesplan_cell_width'];
			    $minutes = $newVals['minutes'] ;
			    $frmArr = explode( ':' , str_replace( '.' , ':' , $belegung->getAb()) );
			    $frmTim = ($frmArr[0]*60) + $frmArr[1];
			    $toTim = $frmTim + $minutes;
			    $toH = floor( $toTim / 60 );
			    $toMin = round( ( $toTim - ($toH*60) )  ) ;
// 			    $belegung->setBis(  sprintf( '%02s' , $toH ) . ':' . sprintf( '%02s' , $toMin ) );
			    $belegung->setBis(  $this->dbHelperUtility->cleanTimeArray( array($toH , $toMin) ) );
		      }
		      
		}
		$this->view->assign('belegung', $belegung);

		$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 2 );
		$this->view->assign('zimmer', $zimmers );
		
		$belMieterInfo = $this->dbHelperUtility->getBelegungMieterInfos( $belegung->getUid() );

		$this->view->assign('anlaesse', $this->dbHelperUtility->mkAnlassSelectArray( ($belMieterInfo['verstecken'] || $belMieterInfo['anlass_verstecken']) ) );
		
		$zimmerObj = $belegung->getBelZimmer();
		if(!$zimmerObj)return;
		
 		$calendarName = $this->calendarUtility->getCalendarByRoom( $zimmerObj );
		$this->view->assign('oldCalendar', $calendarName);
		
		$objDate = $belegung->getDatum();
		if(!$objDate)return;
		
		$zimmerIdx = $zimmerObj->getUid();
		$uxDate = $objDate->format('U');
		$zmrResObj = $this->dbHelperUtility->mkArrTimetableByRoomAndDate( array($zimmerIdx=>$zimmerIdx) , $uxDate, array() );
		$zmrResObj = $this->dbHelperUtility->mkArrAusnahmeByRoomAndDate( array($zimmerIdx=>$zimmerIdx) , $uxDate , $zmrResObj );
		$zmrResObj = $this->dbHelperUtility->mkArrBelegungByRoomAndDate( array($zimmerIdx=>$zimmerIdx) , $uxDate , $zmrResObj );
		$merged_sorted_belegung = $this->tagesansichtUtility->sortMergedBelegung(  $zmrResObj );
		$this->view->assign('sublist', $merged_sorted_belegung[$zimmerIdx] );

	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		$args = $this->arguments['belegung']->getPropertyMappingConfiguration();
		$args->forProperty('datum')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		if($this->request->hasArgument('oldCalendar')) {
			$this->settings['oldCalendar'] = $this->request->getArgument('oldCalendar');
		}
		if ($this->request->hasArgument('belegung')) {
			$bel = $this->request->getArgument('belegung');
			if(empty($bel['datum'])) {
			      $this->settings['errorMessages'][] = 'Datum leer, nicht gespeichert!';
			      $this->arguments->getArgument('belegung')->getPropertyMappingConfiguration()->skipProperties('datum');
			}
			if(empty($bel['belZimmer'])) {
			      $this->settings['errorMessages'][] = 'Zimmer leer, nicht gespeichert!';
			      $this->arguments->getArgument('belegung')->getPropertyMappingConfiguration()->skipProperties('belZimmer');
			}
			if(empty($bel['anlass'])) {
			      $this->settings['errorMessages'][] = 'Anlass leer, nicht gespeichert!';
			}
		}
		$this->settings['forwardingArguments']['oldact'] =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'tagesansicht';
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	 * @return void
	 */
	public function updateAction(\Mff\Mffrps\Domain\Model\Belegung $belegung) {
		if(is_array($this->settings['errorMessages'])){
		    $this->addFlashMessage( implode(', ' , $this->settings['errorMessages'] ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    $updated = 0;
		}else{
		    if( $belegung->getAnlass() >= 1 ){
			$originalAb = $belegung->getAb();
			$originalBis = $belegung->getBis();
			$from = $this->dbHelperUtility->cleanTimeString( $originalAb );
			$to = $this->dbHelperUtility->cleanTimeString( $originalBis );
			if( $belegung->getStatus() < 1 ){$belegung->setStatus( 0 );}
			if( $originalAb != $from ){$belegung->setAb($from);}
			if( $originalBis != $to ){$belegung->setBis($to);}
			$this->belegungRepository->update($belegung);
			$this->persistenceManager->persistAll();
			$this->calendarUtility->updateEventFromBelegung( $belegung , $this->settings['oldCalendar'] );
			$calendarMessage = '';
			$this->addFlashMessage('The object was updated ('.$belegung->getAb().'-'.$belegung->getBis().'). Calendar'.$calendarMessage.' updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$updated = 1;
			if(!empty($this->settings['clearCachePid'])) $GLOBALS['TSFE']->clearPageCacheContent_pidList($this->settings['clearCachePid']);
		    }else{
			$this->addFlashMessage( 'Anlass leer, nicht gespeichert!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			$updated = 0;
		    }
		}
		if ($this->request->hasArgument('filter')) {
			$this->settings['forwardingArguments']['filter'] = $this->request->getArgument('filter');
		}else{
			$this->settings['forwardingArguments']['filter'] = $this->settings['filter'];
		}
		$this->settings['forwardingArguments']['belegung'] = $belegung;
		$this->settings['forwardingArguments']['pageType'] = '95';
		$this->settings['forwardingArguments']['updated'] = $updated;
		$this->forward('edit', NULL, NULL, $this->settings['forwardingArguments']);
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	 * @return void
	 */
	public function deleteAction(\Mff\Mffrps\Domain\Model\Belegung $belegung) {
		$this->calendarUtility->deleteEventFromBelegung( $belegung );
 		$this->belegungRepository->remove($belegung);
		$action =  $this->request->hasArgument('oldact') ? $this->request->getArgument('oldact') : 'list';
		$this->settings['forwardingArguments']['oldact'] =  $action;
		$this->settings['forwardingArguments']['updated'] = 2;
		$this->settings['forwardingArguments']['pageType'] = 95;
		$this->settings['forwardingArguments']['sysoptions']['filter']['date'] = date('d.m.y',$this->settings['filter']['date']);
		$this->settings['forwardingArguments']['sysoptions']['filter']['todate'] = date('d.m.y',$this->settings['filter']['todate']);
		$this->settings['forwardingArguments']['filter']['date'] = date('d.m.y',$this->settings['filter']['date']);
		$this->settings['forwardingArguments']['filter']['todate'] = date('d.m.y',$this->settings['filter']['todate']);
		if(!empty($this->settings['clearCachePid'])) $GLOBALS['TSFE']->clearPageCacheContent_pidList($this->settings['clearCachePid']);
		$this->addFlashMessage('Belegung gelöscht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		// redirect: new request-response-cycle started
		// forward: no request-response-cycle ist started
// 		$this->redirect('list', NULL, NULL, $forwardingArguments );
// 		if ($this->request->hasArgument('filter')) {
// 			$this->settings['forwardingArguments']['filter'] = $this->request->getArgument('filter');
// 		}else{
// 			$this->settings['forwardingArguments']['filter'] = $this->settings['filter'];
// 		}
//		$this->forward('edit', NULL, NULL, $this->settings['forwardingArguments'] );
	}

	/**
	 * action zimmer
	 * 
	 *
	 * @param \Mff\Mffdb\Domain\Model\Zimmer $zimmer
	 * @ignorevalidation $zimmer
	 * @return void
	 */
	public function zimmerAction(\Mff\Mffdb\Domain\Model\Zimmer $zimmer = NULL) {
		if($zimmer) $this->settings['filter']['filter_zimmer'] = $zimmer->getUid();
		$this->view->assign('settings', $this->settings );
		$this->view->assign('zimmers', $this->zimmerUtility->mkZimmerSelectObject( 2 ) );

		if(!$zimmer) return;
		$this->view->assign('zimmer', $zimmer );
		$zimmerIdx = $this->settings['filter']['filter_zimmer'];
		$roomFilter = array($zimmerIdx=>$zimmerIdx);
		$dayToCorr = date( 'N' , $this->settings['filter']['date'] ) - 1 ;
		$dateCorr = (3600*24*$dayToCorr);
		$filterDate = $this->settings['filter']['date']-$dateCorr;
		$aDateFilters = array( 'date'=>$filterDate , 'todate' => $filterDate+(6*3600*24));

		for($d=0;$d<=6;++$d){
		    $uxDay = $filterDate + ( $d * 3600*24 );
		    $zmrResObj = array();
		    $zmrResObj = $this->dbHelperUtility->mkArrTimetableByRoomAndDate( $roomFilter , $uxDay, $zmrResObj );
		    $zmrResObj = $this->dbHelperUtility->mkArrAusnahmeByRoomAndDate( $roomFilter , $uxDay , $zmrResObj );
		    $zmrResObj = $this->dbHelperUtility->mkArrBelegungByRoomAndDate( $roomFilter , $uxDay , $zmrResObj );
		    $merged_sorted_belegung = $this->tagesansichtUtility->sortMergedBelegung(  $zmrResObj );
		    $a_belegung[$uxDay] = $merged_sorted_belegung[$zimmerIdx];
		}
 		
		$this->view->assign('dates', $aDateFilters );
		$this->view->assign('sublist', $a_belegung );
		
	}
}
