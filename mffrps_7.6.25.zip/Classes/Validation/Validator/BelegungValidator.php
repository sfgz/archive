<?php
namespace Mff\Mffrps\Validation\Validator;

class BelegungValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractValidator {
    /**
    * Object Manager
    * 
    * @var \TYPO3\CMS\Extbase\Object\ObjectManagerInterface
    * @inject
    */
    protected $objectManager;
    
    /**
    * Validates the given value
    * 
    * @param mixed $object
    * @return bool
    */
    protected function isValid($object){
	  $aFailed = array();
	  
	  $aNotEmptyFields = array( 'datum' , 'ab' , 'bis' , 'belZimmer' , 'belegungstext' );
	  
	  $aDateTimeFields = array( 'datum' );
	  $aMsg = array( 1=>'ist leehr' , 2=>'exisitert nicht' );
	  foreach($aNotEmptyFields as $prop){
		$ucProperty = ucFirst( $prop );
		$method = 'get' . $ucProperty ;
		if( !method_exists( $object , $method ) ){$aFailed[$prop] = 2; continue;}
		$fieldValue = $object->$method();
		if( empty($fieldValue) ) $aFailed[$prop] = 1;
		if( $aFailed[$prop] ){
		    $error = $this->objectManager->get(
			  'TYPO3\\CMS\\Extbase\\Validation\\Error',
			  $ucProperty . ' '.$aMsg[$aFailed[$prop]].'.',
			  1486686503
		    );
		    $this->result->forProperty($prop)->addError($error);
		}
	  }
	  
	  $success = count($aFailed) ? FALSE : TRUE;
	  return $success;
	  
    }
}
