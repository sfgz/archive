<?php
namespace Mff\Mffrps\Command;
use \DateTime;

 /** 
 * Class DeferredCalendarCommandController
 * 
 * Usage of DeferredCalendarCommandController:
 * 
 * 
 */
 
class DeferredCalendarCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mffrps';
	public    $plugin = 'rpsopt';
	    
	protected $settings = array(); // Extension settings

	/**
	 * calendarUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $calendarUtility = NULL;
	
	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	public function execute(){
	    $this->getSettings();
	    $this->calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
	    $result = $this->calendarUtility->sendDataFromUpdateFile();
	    return true;//$result;
	}
	
	/**
	* getSettings
	*
	* @return void
	*/
	public function getSettings() {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$typoscript = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$settings = $typoscript['plugin.']['tx_'.$this->extKey.'_'.$this->plugin.'.']['settings.'];
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings = $this->systemOptionsUtility->settings;
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
	}
}