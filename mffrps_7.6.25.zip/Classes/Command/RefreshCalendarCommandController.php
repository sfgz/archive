<?php
namespace Mff\Mffrps\Command;
use \DateTime;

 /** 
 * Class RefreshCalendarCommandController
 *  reads belegungen, then
 *  - updates calendarEvents 
 *  - delete orphan calendar-entries
 *  
 * Run this script after mirgating 
 * or if Calendar needs synchonisation
 * 
 */
 
class RefreshCalendarCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	
	public    $extKey = 'mffrps';
	public    $plugin = 'rpsopt';
	    
	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;
	
	/**
	 * calendarUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $calendarUtility = NULL;

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	public function execute(){
	    $this->getSettings();
	    $repBelegungen = $this->belegungRepository->findAll();
	    $aLimitDays = array( 'from'=>2 , 'to'=>730 );
	    $result = $this->calendarUtility->refreshEventsFromBelegungen( $repBelegungen , $aLimitDays );
	    return $result;
	    
//  	    better get all recordsets and 
//  	    use $aLimitDays as second parameter for refreshEventsFromBelegungen()
//  	    
//  	    Because calendar will delete events without corresponding belegung
//  	    dont do this:
//  	    $now = time();
//  	    $before = $now - (3600*24*365*2);
//  	    $end    = $now + (3600*24*365*2);
// 	    $repBelegungen = $this->belegungRepository->findByRoomsAndDates( array() , array( 'date'=>$before , 'todate'=>$end ) );
	}
	
	/**
	* getSettings
	*
	* @return void
	*/
	public function getSettings() {

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$typoscript = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storage['storagePid'] = $typoscript['plugin.']['tx_'.$this->extKey.'_'.$this->plugin.'.']['persistence.']['storagePid'];

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );

		$this->belegungRepository = $objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings = $this->systemOptionsUtility->settings;
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$this->calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
	}
}