<?php
namespace Mff\Mffrps\Command;

 /** 
 * Class BackupDbCommandController
 * 
 * 
 */
 
class BackupDbCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	
	/**
	 * backupUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $backupUtility = NULL;
	
	public function execute(){
	    
	    $ml = new \Mff\Mffrps\Utility\BackupUtility();
	    
	    $result = $ml->runBackup();
	    
	    return $result;
	    
	}
	
}