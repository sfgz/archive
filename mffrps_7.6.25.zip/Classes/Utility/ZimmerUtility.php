<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ZimmerUtility
 *  reads options from settings.userfields and settings.optionfields
 *  returns ZimmerRepository
 * 
 */

class ZimmerUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	* querySettings
	*
	* @var array
	*/
	protected $querySettings = array();
	
	/**
	 * objectManager
	 *
	 * @var \TYPO3\CMS\Extbase\Object\ObjectManager
	 */
	protected $objectManager ;

	/**
	 * zimmerRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\ZimmerRepository
	 */
	protected $zimmerRepository ;
	
	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->getSettings();
	      $this->zimmerRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
	      $this->zimmerRepository->setDefaultQuerySettings($this->querySettings);
	}
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	public function getSettings( ){
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$settings = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['settings.'];//['optionfields.']
		$this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $settings );

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$storage['foreignStoragePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
		// timetable ist not used yet
// 		$storage['planStoragePid'] = $fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		return $querySettings;
	}
	
	/**
	 * getZimmerRepository
	 * 
	 * @return void
	 */
	public function getZimmerRepository() {
	    return $this->zimmerRepository;
	}
	
	
	/**
	* prepare zimmer for select box
	*
	* @param int $showAll default ist 1
	* @return array
	*/
	public function mkZimmerSelectObject( $showAll=1 ) {
	    if($showAll == 1){
		// show all, ignore hide/verstecken fields, ignore PIDs
		$zimmers = $this->getZimmerRepository()->findAll();
	    }elseif($showAll == 2){
		// show filtered selection BUT ignore PIDs and ignore hide/verstecken fields
		$zimmers = $this->getZimmerRepository()->findByAusschliessen( '0' );
	    }else{
		// show filtered selection, AND respect PIDs and hide/verstecken fields
		$zimmers = $this->getZimmerRepository()->findByRoom($this->settings['userfields']['filter_room']['value'],FALSE);
	    }
	    $categories = array();
	    foreach($zimmers as $entry) {
		$uid = $entry->getUid();
		$category = new \stdClass();
		$category->uid = $uid;
		$category->zimmer = $entry->getHaus() . ' ' . $entry->getZimmer();
		$categories[$uid] = $category;
	    }
	    return $categories;
	}
	

// 	/**
// 	 * searchByFilter
// 	 * 
// 	 * @param string $search search-pattern for both, building and room
// 	 * @return void
// 	 */
// 	public function searchByFilter( $search = '' ) {
// 	    return $this->zimmerRepository->findByRoom($search);
// 	}
	

}