<?php
namespace Mff\Mffrps\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class DbHelperUtility
 */

class DbHelperUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * mieterRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\MieterRepository
	 */
	protected $mieterRepository = NULL;

	/**
	 * ausnahmeRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AusnahmeRepository
	 */
	protected $ausnahmeRepository = NULL;

	/**
	 * antragRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AntragRepository
	 */
	protected $antragRepository = NULL;

	/**
	 * anlassRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\AnlassRepository
	 */
	protected $anlassRepository = NULL;

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;

	/**
	 * sysoptionsRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\SysoptionsRepository
	 */
	protected $sysoptionsRepository = NULL;

	/**
	 * klasseRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KlasseRepository
	 */
	protected $klasseRepository = NULL;

	/**
	 * kursRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KursRepository
	 */
	protected $kursRepository = NULL;

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 */
	protected $fachRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
	 */
	protected $ecouserRepository = NULL;

	/**
	 * timetableUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $timetableUtility = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;
	
	protected $objectManager ;

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();

	/**
	* msg
	*
	* @var array
	*/
	Public $msg = array();
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );
		$this->mieterRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\MieterRepository');
		$this->mieterRepository->setDefaultQuerySettings($querySettings);
		$this->anlassRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AnlassRepository');
		$this->anlassRepository->setDefaultQuerySettings($querySettings);
		$this->belegungRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		$this->ausnahmeRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AusnahmeRepository');
		$this->ausnahmeRepository->setDefaultQuerySettings($querySettings);
		$this->antragRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\AntragRepository');
		$this->antragRepository->setDefaultQuerySettings($querySettings);
		$this->sysoptionsRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\SysoptionsRepository');
		$this->sysoptionsRepository->setDefaultQuerySettings($querySettings);
		$this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

		$this->timetableUtility = new \Mff\Mffrps\Utility\TimetableUtility();
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();

		$dbQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$dbStorage['foreignStoragePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
		$dbQuerySettings->setStoragePageIds( $dbStorage );
		$this->klasseRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
		$this->klasseRepository->setDefaultQuerySettings($dbQuerySettings);
		$this->kursRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KursRepository');
		$this->kursRepository->setDefaultQuerySettings($dbQuerySettings);
		$this->fachRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
		$this->fachRepository->setDefaultQuerySettings($dbQuerySettings);
		
		$teachersQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$teacherStorage['teacherStoragePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		$teachersQuerySettings->setStoragePageIds( $teacherStorage );
		$teachersQuerySettings->setIgnoreEnableFields( TRUE );
		$this->ecouserRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
		$this->ecouserRepository->setDefaultQuerySettings($teachersQuerySettings);
	}
	
	/**
	 * getBelegungRepository
	 *
	 * @return \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	public function getBelegungRepository() {
		return $this->belegungRepository;
	}
	
	/**
	 * msgReturn
	 *
	 * @param string $msgLog
	 * @param string $returnvalue
	 * @return void
	 */
	private function msgReturn( $msgLog , $returnvalue ) {
		$this->msg[] = $msgLog;
		return $returnvalue;
	}
	
	/**
	 * getAnlassObjByUid
	 *
	 * @param int $anlassUid
	 * @return array
	 */
	public function getAnlassObjByUid( $anlassUid ) {
		  if(empty($anlassUid)) return false;
		  $objAnlass = $this->anlassRepository->findByUid($anlassUid);
		  return $objAnlass;
	}

	/**
	 * getBelegungMieterInfos
	 * used in mkArrBelegungByRoomAndDate()
	 * part of belegungController tagesansichtAction()
	 *
	 * @param int $belegungUid if optional filter is given, 1-dim array is returned. otherwise 2-dim
	 * @return array
	 */
	public function getBelegungMieterInfos( $belegungUid = 0 ) {
		if( !$belegungUid ) return $this->getAllMieterInfos();
		$objBel = $this->belegungRepository->findByUid($belegungUid);
		$anlassUid = $objBel->getAnlass();
		return $this->getAnlassMieterInfos( $anlassUid );
	}
	
	public function getAllMieterInfos() {
		// get mieter-intern/extern for each belegung 
		$mieterRep = $this->mieterRepository->findAll();
		foreach($mieterRep as $mieterObj){
		      $oMtrAnlaesse = $mieterObj->getMtrAnlass();
		      foreach($oMtrAnlaesse as $anlassObj){
			  $mieterinfo['Anlass'] = $anlassObj->getUid();
			  $mieterinfo['Verwendungszweck'] = $anlassObj->getVerwendungszweck();
			  $mieterinfo['Kontaktperson'] = $anlassObj->getKontaktPerson();
			  $mieterinfo['anlass_verstecken'] = $anlassObj->getVerstecken();
			  $mieterinfo['Email'] = $anlassObj->getKontaktEmail();
			  $mieterinfo['Telefon'] = $anlassObj->getKontaktTelefon();
			  $mieterinfo = $this->getMieterInfosByObj( $mieterObj , $mieterinfo);
			  $oAnlBelegungen = $anlassObj->getAnlBelegung();
			  foreach($oAnlBelegungen as $belegungObj) $aBelegIntern[ $belegungObj->getUid() ] = $mieterinfo;
		      }
		}
		return $aBelegIntern;
	}
	
	public function getMieterInfosByObj( $mieterObj , $mieterinfo = array()) {
		$mieterinfo['verstecken'] = $mieterObj->getVerstecken();
		$mieterinfo['intern'] = $mieterObj->getIntern();
		$mieterinfo['Kurz'] = $mieterObj->getKurz();
		$mieterinfo['Name'] = $mieterObj->getName();
		$mieterinfo['StrasseNr'] = $mieterObj->getStrasseNr();
		$mieterinfo['PlzOrt'] = $mieterObj->getPlzOrt();
		$mieterinfo['Telefax'] = $mieterObj->getTelefax();
		if(empty($mieterinfo['Telefon'])) $mieterinfo['Telefon'] = $mieterObj->getTelefon();
		if(empty($mieterinfo['Email'])) $mieterinfo['Email'] = $mieterObj->getEmail();
		$mieterinfo['verwendungszweck'] = $mieterinfo['Verwendungszweck'];
		$mieterinfo['kontakt_person'] = $mieterinfo['Kontaktperson'];
		$mieterinfo['email'] = $mieterinfo['Email'];
		$mieterinfo['telefon'] = $mieterinfo['Telefon'];
		$mieterinfo['telefax'] = $mieterinfo['Telefax'];
		$mieterinfo['name'] = $mieterinfo['Name'];
		$mieterinfo['kurz'] = $mieterinfo['Kurz'];
		$mieterinfo['anlass'] = $mieterinfo['Anlass'];
		$mieterinfo['strasse_nr'] = $mieterinfo['StrasseNr'];
		$mieterinfo['plz_ort'] = $mieterinfo['PlzOrt'];
		$mieterinfo['zuschlag_betrag'] = $mieterinfo['ZuschlagBetrag'];
		$mieterinfo['zuschlag_text'] = $mieterinfo['ZuschlagText'];
		return $mieterinfo;
	}
	
	/**
	 * cleanTimeString
	 * padding with leading or following zeros
	 *
	 * @param string $sTime in format HH:ii or H:i
	 * @return string
	 */
	public function cleanTimeString( $sTime ) {
		if(empty($sTime)) return false;
		$pToDoublePoint = str_replace('.',':',$sTime);
		$aTime = explode(':' , $pToDoublePoint );
		if( count($aTime) == 1){
		      if( strlen($aTime[1]) == 4 ){ // no separer set (: or .)
				$aTime[0] = substr( $aTime[0] , 0 , 2 );
				$aTime[1] = substr( $aTime[0] , 2 , 2 );
		      }elseif(is_numeric($aTime[0])){
				$aTime[0] = $aTime[0] + 0; // transorm 010 to 10
				$aTime[1] = '00';
		      }else{
				$aTime[0] =  0; // FIXME ERROR
				$aTime[1] = '00';
		      }
		}
		return $this->cleanTimeArray( $aTime );
	}
	
	/**
	 * cleanTimeArray
	 * padding with leading or following zeros
	 *
	 * @param array $aTime in format array( HH , ii ) or array( H , i )
	 * @return string
	 */
	public function cleanTimeArray( $aTime ) {
		return str_pad( $aTime[0], 2, '0', STR_PAD_LEFT) . ':' . str_pad( $aTime[1], 2, '0', STR_PAD_RIGHT);
// 		return sprintf( '%02s' , $aTime[0] ) . ':' . sprintf( '%-02s' , (string) $aTime[1] );
	}
	
	
	/**
	 * getRaumplanungSqlDump
	 * used in backupUtility Backup()
	 * used if real sqldump command not avayable on Mff\Mffrps\Utility\BackupUtility->createSqlDumpFiles()
	 * returns cntent for file
	 *
	 * @param string $strTablenames
	 * @return string filecontent
	 */
	public function getRaumplanungSqlDump($strTablenames) {
		$aFieldList = [
            'anlass' => 'uid,pid,mieter,verwendungszweck,kontakt_person,kontakt_anrede,kontakt_email,kontakt_telefon,bemerkungen,zuschlag_betrag,zuschlag_text,schulleitung_kurz,schulleitung_datum,gesuch_datum,rechnungs_datum,catering_text,verstecken,anl_belegung,import_uid',
            'belegung' => 'uid,pid,anlass,belegungstext,zusatztext,datum,ab,bis,betrag,status,bel_zimmer,import_uid,editor',
            'mieter' => 'uid,pid,kurz,anrede,name,strasse_nr,plz_ort,rechnungsadresse,email,telefon,telefax,intern,verstecken,mtr_anlass,import_uid',
            'ausnahme'=> 'uid,pid,timetable,datum,zeit_ab,zeit_bis,aus_zimmer,neu_zimmer,neu_zeit_ab,neu_zeit_bis,info_datum,info_person,ausnahmetext,import_uid',
            'sysoptions' => 'uid,pid,option_key,content,text_content',
		];
		
		$strIntegerFieldsList = 'uid,pid,mieter,verstecken,anl_belegung,import_uid';
		$strIntegerFieldsList .= 'anlass,status,bel_zimmer,editor';
		$strIntegerFieldsList .= 'anrede,intern,verstecken,mtr_anlass';
		$strIntegerFieldsList .= 'timetable,info_person';
		$aIntegers = array_flip( explode( ',' , $strIntegerFieldsList ) );
		
        $aTabNam = explode( ',' , trim(trim($strTablenames),',') );
        $aAskForTables = array_flip($aTabNam);
        
		foreach( $aFieldList as $table => $strFieldlist){
            if( !isset( $aAskForTables[$table] ) ) continue;
             $aFields[$table] = explode(',',$strFieldlist);
		}

		$aAllRs = [];
        $aRep['mieter'] = $this->mieterRepository->findAll();
		// anlass
		if( isset($aFields['anlass']) ){
            foreach($aRep['mieter'] as $mieterObj){
                $aRep['anlass'] = $mieterObj->getMtrAnlass();
                foreach($aRep['anlass'] as $anlassObj){
                    $aIdx = $anlassObj->getUid();
                    foreach($aFields['anlass'] as $sgl_field){
                        if(empty($sgl_field)) continue;
                        $command = 'get' . GeneralUtility::underscoredToUpperCamelCase( trim( $sgl_field ) );
                        if( method_exists( $anlassObj , $command ) ){
                            $aAllRs['anlass'][$aIdx][$sgl_field] = $anlassObj->$command();
                        }else{
                            $aAllRs['anlass'][$aIdx][$sgl_field] = '';
                        }
                    }
                }
            }
        }
		// belegung
		if( isset($aFields['belegung']) ){
            foreach($aRep['mieter'] as $mieterObj){
                $aRep['anlass'] = $mieterObj->getMtrAnlass();
                foreach($aRep['anlass'] as $anlassObj){
                    $aRep['belegung'] = $anlassObj->getAnlBelegung();
                    foreach($aRep['belegung'] as $belegungObj ){
                        $bIdx = $belegungObj->getUid();
                        foreach($aFields['belegung'] as $sgl_field){
                            if(empty($sgl_field)) continue;
                            $command = 'get' . GeneralUtility::underscoredToUpperCamelCase( trim( $sgl_field ) );
                            if( method_exists( $belegungObj , $command ) ){
                                $aAllRs['belegung'][$bIdx][$sgl_field] = $belegungObj->$command();
                            }else{
                                $aAllRs['belegung'][$bIdx][$sgl_field] = '';
                            }
                        }
                    }
                }
            }
        }
		// mieter
		if( isset($aFields['mieter']) ){
            foreach($aRep['mieter'] as $mieterObj){
                $mIdx = $mieterObj->getUid();
                foreach($aFields['mieter'] as $sgl_field){
                    if(empty($sgl_field)) continue;
                    $command = 'get' . GeneralUtility::underscoredToUpperCamelCase( trim( $sgl_field ) );
                    if( method_exists( $mieterObj , $command ) ){
                        $aAllRs['mieter'][$mIdx][$sgl_field] = $mieterObj->$command();
                    }else{
                        $aAllRs['mieter'][$mIdx][$sgl_field] = '';
                    }
                }
            }
        }
        
        
		// ausnahme
		if( isset($aFields['ausnahme']) ){
            $aRep['ausnahme'] = $this->ausnahmeRepository->findAll();
            foreach($aRep['ausnahme'] as $ausnahmeObj){
                $mIdx = $ausnahmeObj->getUid();
                foreach($aFields['ausnahme'] as $sgl_field){
                    if(empty($sgl_field)) continue;
                    $command = 'get' . GeneralUtility::underscoredToUpperCamelCase( trim( $sgl_field ) );
                    if( method_exists( $ausnahmeObj , $command ) ){
                        $aAllRs['ausnahme'][$mIdx][$sgl_field] = $ausnahmeObj->$command();
                    }else{
                        $aAllRs['ausnahme'][$mIdx][$sgl_field] = '';
                    }
                }
            }
        }
        
		// sysoptions
		if( isset($aFields['sysoptions']) ){
            $aRep['sysoptions'] = $this->sysoptionsRepository->findAll();
            foreach($aRep['sysoptions'] as $sysoptObj){
                $mIdx = $sysoptObj->getUid();
                foreach($aFields['sysoptions'] as $sgl_field){
                    if(empty($sgl_field)) continue;
                    $command = 'get' . GeneralUtility::underscoredToUpperCamelCase( trim( $sgl_field ) );
                    if( method_exists( $sysoptObj , $command ) ){
                        $aAllRs['sysoptions'][$mIdx][$sgl_field] = $sysoptObj->$command();
                    }else{
                        $aAllRs['sysoptions'][$mIdx][$sgl_field] = '';
                    }
                }
            }
        }
        
        // create sql formatted list
        $strOut = '';
        $maxLines = 250;
        $crTime = time();

        $sr = [ "\r\n"=>'<br>' , "\n"=>'' , "\r"=>'' , "'"=>'*' ];
        
        foreach( $aAllRs as $tablename => $aTable ){
            if( !isset($aAskForTables[$tablename]) ) continue;

            $strOut .= "\n--\n-- TRUNCATE Tabelle vor dem Einfügen `tx_mffrps_domain_model_$tablename`\n--\n\n";
            $strOut .= "TRUNCATE TABLE `tx_mffrps_domain_model_$tablename`;\n--\n";
            $strOut .= "-- Daten für Tabelle `tx_mffrps_domain_model_$tablename`\n--\n";
            
            $strTabHead[$tablename] = "\nINSERT INTO `tx_mffrps_domain_model_$tablename` ";
            
            // first row
            foreach( $aTable as $mIdx => $aRs ){
                $aFlds = [];
                foreach( $aFields[$tablename] as $sgl_field ){
                    $aFlds[] = '`' . $sgl_field . '`';
                }
                // collect fieldnames to string
                $strTabHead[$tablename] .= '(';
                $strTabHead[$tablename] .= implode( ',' , $aFlds ); // regular table-fieldnames from list.
                $strTabHead[$tablename] .= ',`tstamp`'; // additional fieldname tstamp
                $strTabHead[$tablename] .= ',`crdate`'; // additional fieldname crdate
                $strTabHead[$tablename] .= ',`cruser_id`'; // additional fieldname cruser_id
                $strTabHead[$tablename] .= ')';
                break; // first line finished. stop here.
            }
            $strTabHead[$tablename] .= " VALUES \n";
            
            $aLines = [];
            $strOut .= $strTabHead[$tablename];
            $z=0;
            // body
            foreach( $aTable as $mIdx => $aRs ){
                // create content for 1 line in a table
                $aFieldContents = [];
                
                foreach( $aFields[$tablename] as $sgl_field ){
                    $content = $aRs[$sgl_field];
                    if( is_array($content) ) {
                        $str = '';
                        foreach($content as $v ) {
                            $str .= $v;
                        }
                        $aFieldContents[] = "'".$str."'";
                    }elseif(is_object($content)){
                        // integer. e.g. mtr_anlass in mieter or anl_belegung in anlass
                        $aFieldContents[] = count($content);
                    }else{
                         $cnt = str_replace( array_keys($sr) , $sr , $content );
                        if( isset($aIntegers[$sgl_field]) ){
                            if( empty($cnt) ){
                                $aFieldContents[] = 0;
                            }else{
                                if( is_numeric($cnt) ){
                                    $aFieldContents[] = $cnt + 0;
                                }else{
                                    $aFieldContents[] = $cnt;
                                }
                            }
                        }else{
                            $aFieldContents[] = "'" . $cnt . "'";
                        }
                    }
                }
                // look out for errors and goto next on error
                if( count($aFields[$tablename]) != count($aFieldContents) ) {
                    $this->msg[] = $aRs['uid'] . '=fields(' . count($aAskForTables[$tablename]) . ')+values(' . count($aFieldContents) . '). ';
                    continue;
                }
                
                // collect contents to array (via string)
                $strLine  = '(';
                $strLine .= implode( ',' , $aFieldContents ); // regular table-fields from list.
                $strLine .= ','.time().''; // additional content for tstamp
                $strLine .= ','.$crTime.''; // additional content for cr_date
                $strLine .= ',1'; // additional content for cruser_id
                $strLine .= ')';
                
                $aLines[] = $strLine;

                ++$z;
                if( $z >= $maxLines ){
                        // step for e.g. 250 lines
                        $z=0;
                        // collect last 250 lines to string
                        $strOut .= implode( ",\n" , $aLines ) . ';';
                        $strOut .= $strTabHead[$tablename];
                        // reset lines
                        $aLines = [];
                        // finished or next 250 steps
                }
            }
            // if $aLines remaining then collect the $aLines to string
            if( count($aLines) ) $strOut .= implode( ",\n" , $aLines ) . ';';
        }
        
        // file finished
        $filecontent = $this->getSqlTemplates(1) . $strOut . $this->getSqlTemplates(2);
        return $filecontent;
	}
	
	/**
	 * getSqlTemplates
	 *
	 * @param int $part default all
	 * @return array
	 */
	Private function getSqlTemplates( $part = 1 ) {
        $head = "-- phpMyAdmin SQL Dump\n-- version 5.0.1\n-- https://www.phpmyadmin.net/\n--\n";
        $head .= "-- Host: daten:3306\n-- Erstellungszeit: " . date('d.m.Y') . " um " . date('H:i') . "\n";
        $head .= "-- Server-Version: 5.7.27\n";
        $head .= "-- PHP-Version: 7.4.1\n\n";
        $head .= 'SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO"' . ";\n";
        $head .= 'SET AUTOCOMMIT = 0;' . "\n";
        $head .= 'START TRANSACTION;' . "\n";
        $head .= 'SET time_zone = "+00:00";' . "\n\n\n";
        $head .= "/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;\n";
        $head .= "/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;\n";
        $head .= "/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;\n";
        $head .= "/*!40101 SET NAMES utf8mb4 */;\n";
        $head .= "\n--\n-- Datenbank: `daten`\n--\n";
        $tmpl[1] = $head;
        
        $foot = "\nCOMMIT;\n\n/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;\n/";
        $foot .="*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;\n";
        $foot .="/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;\n";
        $tmpl[2] = $foot;
        if( $part ) return $tmpl[$part];
        return $tmpl;
	}
	
	/**
	 * getBelegungenBackup
	 * used in backupUtility Backup()
	 *
	 * @return array
	 */
	public function getBelegungenBackup() {
		$aBelegung = array();
		$mieterRep = $this->mieterRepository->findAll();
		foreach($mieterRep as $mieterObj){
		      
		      $mieterinfo['MieterUid'] = $mieterObj->getUid();
		      $mieterinfo['Kurz'] = $mieterObj->getKurz();
		      $mieterinfo['Name'] = $mieterObj->getName();
		      
		      $oMtrAnlaesse = $mieterObj->getMtrAnlass();
		      if($oMtrAnlaesse){
                foreach($oMtrAnlaesse as $anlassObj){
                    $mieterinfo['AnlassUid'] = $anlassObj->getUid();
                    $mieterinfo['Verwendungszweck'] = $anlassObj->getVerwendungszweck();
                    $mieterinfo['Kontaktperson'] = $anlassObj->getKontaktPerson();
                    
                    $belegungRep = $anlassObj->getAnlBelegung();
                    if($belegungRep){
                        foreach($belegungRep as $belegungObj){
                            $bUid = $belegungObj->getUid();
                            $zmrObj = $belegungObj->getBelZimmer();
                            $datObj = $belegungObj->getDatum();

                            $aBelegung[$bUid]['bUid'] = $bUid;
                            $aBelegung[$bUid]['Datum'] = $datObj ? $datObj->format('d.m.Y') : '';
                            $aBelegung[$bUid]['uxDatum'] = $datObj ? $datObj->format('U') : '';
                            $aBelegung[$bUid]['Zimmer'] = $zmrObj ? $zmrObj->getHaus() . ' ' . $zmrObj->getZimmer() : '';
                            $aBelegung[$bUid]['Ab'] = $this->cleanTimeString($belegungObj->getAb());
                            $aBelegung[$bUid]['Bis'] = $this->cleanTimeString($belegungObj->getBis());
                            $aBelegung[$bUid]['Belegungstext'] = $belegungObj->getBelegungstext();
                            $aBelegung[$bUid]['Zusatztext'] = $belegungObj->getZusatztext();
                            $aBelegung[$bUid]['Betrag'] = $belegungObj->getBetrag();
                            $aBelegung[$bUid]['Verwendungszweck'] = $mieterinfo['Verwendungszweck'];
                            $aBelegung[$bUid]['Kontaktperson'] = $mieterinfo['Kontaktperson'];
                            $aBelegung[$bUid]['AnlassUid'] = $mieterinfo['AnlassUid'];
                            $aBelegung[$bUid]['Kurz'] = $mieterinfo['Kurz'];
                            $aBelegung[$bUid]['Name'] = $mieterinfo['Name'];
                            $aBelegung[$bUid]['MieterUid'] = $mieterinfo['MieterUid'];
                        }
                    }
                    
                }
		    }
		    
		}
		return $aBelegung;
	}
	
	/**
	 * getAnlassMieterInfos
	 * used in belegungController listAction()
	 * used in anlassController listAction()
	 *
	 * @param int $anlassUid if optional filter is given, 1-dim array is returned. otherwise 2-dim
	 * @return array
	 */
	public function getAnlassMieterInfos( $anlassUid = 0 ) {
		if( !empty($anlassUid) ){
		    $anlassObj =  $this->getAnlassObjByUid( $anlassUid );
		    if( !$anlassObj ) return;
		    $mieterinfo['Anlass'] = $anlassUid;
		    $mieterinfo['Verwendungszweck'] = $anlassObj->getVerwendungszweck();
		    $mieterinfo['anlass_verstecken'] = $anlassObj->getVerstecken();
		    $mieterinfo['Kontaktperson'] = $anlassObj->getKontaktPerson();
		    $mieterinfo['Email'] = $anlassObj->getKontaktEmail();
		    $mieterinfo['Telefon'] = $anlassObj->getKontaktTelefon();
		    $mieterinfo['ZuschlagBetrag'] = $anlassObj->getZuschlagBetrag();
		    $mieterinfo['ZuschlagText'] = $anlassObj->getZuschlagText();
		    $mieterUid = $anlassObj->getMieter();
		    $mieterObj = $this->mieterRepository->findByUid($mieterUid);
		    $mieterinfo = $this->getMieterInfosByObj( $mieterObj , $mieterinfo);
		    return $mieterinfo;
		}
		$mieterinfo = array();
		$aAnlass = array();
		$mieterRep = $this->mieterRepository->findAll();
		foreach($mieterRep as $mieterObj){
		    $mieter_uid = $mieterObj->getUid();
		    $mieterinfo[$mieter_uid]['mieter_uid'] = $mieter_uid;
		    $mieterinfo[$mieter_uid]['anrede'] = $mieterObj->getAnrede();
		    $mieterinfo[$mieter_uid]['name'] = $mieterObj->getName();
		    $mieterinfo[$mieter_uid]['kurz'] = $mieterObj->getKurz();
		    $mieterinfo[$mieter_uid]['telefon'] = $mieterObj->getTelefon();
		    $mieterinfo[$mieter_uid]['telefax'] = $mieterObj->getTelefax();
		    $mieterinfo[$mieter_uid]['email'] = $mieterObj->getEmail();
		    $mieterinfo[$mieter_uid]['strasse_nr'] = $mieterObj->getStrasseNr();
		    $mieterinfo[$mieter_uid]['plz_ort'] = $mieterObj->getPlzOrt();
		    $mieterinfo[$mieter_uid]['intern'] = $mieterObj->getIntern() ? 'Ja' : '';
		    $mieterinfo[$mieter_uid]['verstecken'] = $mieterObj->getVerstecken() ? 'Ja' : '';
		}
		$anlasses = $this->anlassRepository->findAll();
		foreach($anlasses as $anlassObj){
		    $aUid = $anlassObj->getUid();
		    $aAnlass[$aUid]['anlass_uid'] = $aUid;
		    $mieter_uid = $anlassObj->getMieter();
		    $aAnlass[$aUid]['anlass'] = $aUid;
		    $aAnlass[$aUid]['verwendungszweck'] = $anlassObj->getVerwendungszweck();
		    $aAnlass[$aUid]['kontakt_anrede'] = $anlassObj->getKontaktAnrede();
		    $aAnlass[$aUid]['kontakt_person'] = $anlassObj->getKontaktPerson();
		    $aAnlass[$aUid]['kontakt_email'] = $anlassObj->getKontaktEmail();
		    $aAnlass[$aUid]['kontakt_telefon'] = $anlassObj->getKontaktTelefon();
		    $aAnlass[$aUid]['schulleitung_datum'] = $anlassObj->getSchulleitungDatum() ? $anlassObj->getSchulleitungDatum()->format('d.m.Y') : '';
		    $aAnlass[$aUid]['anlass_verstecken'] = $anlassObj->getVerstecken() ? 'Ja' : '';
		    $aAnlass[$aUid]['bemerkungen'] = $anlassObj->getBemerkungen();
		    $aAnlass[$aUid]['zuschlag_betrag'] = $anlassObj->getZuschlagBetrag();
		    $aAnlass[$aUid]['zuschlag_text'] = $anlassObj->getZuschlagText();
		    if(!isset($mieterinfo[$mieter_uid])) {
			  $mieterinfo[$mieter_uid]['mieter_uid'] = 0;
			  continue;
		    }
		    foreach($mieterinfo[$mieter_uid] as $key => $value) {$aAnlass[$aUid][$key] = $value;}
		}
		if( !empty($anlassUid) && is_array($aAnlass[$anlassUid]) ) return $aAnlass[$anlassUid];
		return $aAnlass;
	}

	/**
	 * createNewMieter
	 * part of initializeCreateAction()
	 *
	 * @param array $aNewRecordset
	 * @return int
	 */
	public function createNewMieter( $aNewRecordset ) {
	    $newMieter = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\Mieter');
	    $newMieter->setKurz( $aNewRecordset['kurz'] );
	    $newMieter->setAnrede( $aNewRecordset['anrede'] );
	    $newMieter->setName( $aNewRecordset['name'] );
	    $this->mieterRepository->add($newMieter);
	    $this->persistenceManager->persistAll();
	    return $newMieter->getUid();
	}

	/**
	 * createNewAnlass
	 * part of initializeCreateAction()
	 *
	 * @param array $aNewRecordset
	 * @return int
	 */
	public function createNewAnlass( $aNewRecordset ) {
	    $newAnlass = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffrps\Domain\Model\Anlass');
	    $newAnlass->setMieter( $aNewRecordset['mieter'] );
	    $newAnlass->setVerwendungszweck( $aNewRecordset['verwendungszweck'] );
	    $this->anlassRepository->add($newAnlass);
	    $this->persistenceManager->persistAll();
	    return $newAnlass->getUid();
	}
	
	
	/**
	* prepare anlass for select box
	*
	* @param int $showHidden default ist 0
	* @return array
	*/
	public function mkAnlassSelectArray( $showHidden=0 ) {
	      $orderValues = array();
	      $mieterinfo = array();
	      $selAnlass = array();
	      $sortAnlass = array();
	      $fillUid  = $this->settings['userfields']['sel_fill_uid']['value'];
	      $cropMax = $this->settings['userfields']['sel_max_chars']['value'];
	      $cropChr = $this->settings['userfields']['sel_postfix_chars']['value'];
	      $cropWrd = $this->settings['userfields']['sel_crop_word']['value'];
	      if($this->settings['userfields']['sel_no_umlaut']['value']){
		    $umRep = array( 'Ä' => 'Ae' , 'ä' => 'ae' , 'Ö' => 'Oe' , 'ö' => 'oe' , 'Ü' => 'Ue' , 'ü' => 'ue' );
	      }else{
		    $umRep = array( '' => '' );
	      }
	      $mieterRep = $showHidden ? $this->mieterRepository->findAll() : $this->mieterRepository->findByVerstecken(0);
	      $iOrderBy = $this->settings['userfields']['anlass_select_orderby']['value'] ;
	      $orderBy = empty($iOrderBy) ? '' : \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate( 'options.anlass_select_orderby.selopt.'.$iOrderBy , 'mffrps' ) ;
	      foreach($mieterRep as $mieterObj){
		    $uid = $mieterObj->getUid();
		    $mieterinfo[$uid]['Uid'] = $fillUid ? sprintf( "%0".$fillUid."s" , $uid ) : $uid;
		    $mieterinfo[$uid]['Kurz'] = $this->smartCrop($mieterObj->getKurz(), $cropMax , $cropChr , $cropWrd);
 		    $mieterinfo[$uid]['Namen'] = $this->smartCrop( str_replace( array_keys($umRep) , $umRep , $mieterinfo[$uid]['Namen'] ) , $cropMax , $cropChr , $cropWrd);
		    $oMtrAnlaesse = $mieterObj->getMtrAnlass();
		    foreach($oMtrAnlaesse as $anlassObj){
			if( empty($showHidden) && $anlassObj->getVerstecken() ) continue;
			$anlassUid = $anlassObj->getUid();
			$oAnlass = $mieterinfo[$uid];
			$oAnlass['Uid'] = $fillUid ? sprintf( "%0".$fillUid."s" , $anlassUid ) : $anlassUid;
			$oAnlass['Verwendungszweck'] = $this->smartCrop( str_replace( array_keys($umRep) , $umRep , $anlassObj->getVerwendungszweck() ) , $cropMax , $cropChr , $cropWrd);
//			$oAnlass['Verwendungszweck'] =  str_replace( array_keys($umRep) , $umRep , $anlassObj->getVerwendungszweck() );
			$replacedText = $this->replaceTemplatestring( $oAnlass , $this->settings['userfields']['anlass_select_items']['value'] );
			$orderValues[$anlassUid] = empty($iOrderBy) ? $replacedText : strtolower( $oAnlass[ $orderBy ] ) . '.' . $anlassUid;
			$selAnlass[$anlassUid] = $replacedText ;
		    }
	      }
	      asort($orderValues);
	      foreach( array_keys($orderValues) as $anlassUid ){ $sortAnlass[$anlassUid] = $selAnlass[$anlassUid];}
	      return $sortAnlass;
	}
	
	/**
	* prepare mieter for select box
	*
	* @param int $showHidden default ist 0
	* @return array
	*/
	public function mkMieterSelectArray( $showHidden=0 ) {
	      $orderValues = array();
	      $selMieter = array();
	      $sortMieter = array();
	      $fillUid  = $this->settings['userfields']['sel_fill_uid']['value'];
	      $cropMax  = $this->settings['userfields']['sel_max_chars']['value'];
	      $cropChr  = $this->settings['userfields']['sel_postfix_chars']['value'];
	      $cropWrd  = $this->settings['userfields']['sel_crop_word']['value'];
	      $iOrderBy = $this->settings['userfields']['mieter_select_orderby']['value'] ;
	      $orderBy = empty($iOrderBy) ? '' :\TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate( 'options.mieter_select_orderby.selopt.'.$iOrderBy , 'mffrps' ) ;
	      $mieterRep = $showHidden ? $this->mieterRepository->findAll() : $this->mieterRepository->findByVerstecken(0);
	      foreach($mieterRep as $mieterObj){
		    $uid = $mieterObj->getUid();
		    $mieterinfo = array();
		    $mieterinfo['Uid'] = $fillUid ? sprintf( "%0".$fillUid."s" , $uid ) : $uid;
		    $mieterinfo['Kurz'] = $this->smartCrop( $mieterObj->getKurz() , $cropMax , $cropChr , $cropWrd );
		    $mieterinfo['Namen'] = $this->smartCrop( $mieterObj->getName() , $cropMax , $cropChr , $cropWrd );
		    $replacedText = $this->replaceTemplatestring( $mieterinfo , $this->settings['userfields']['mieter_select_items']['value'] );
		    $orderValues[$uid] = empty($iOrderBy) ? $replacedText : strtolower( $mieterinfo[ $orderBy ] ) . '.' . $uid;
		    $selMieter[$uid] = $replacedText;
	      }
	      asort($orderValues);
	      foreach( array_keys($orderValues) as $uid ){ $sortMieter[$uid] = $selMieter[$uid];}
	      return $sortMieter;
	}
	
	public function smartCrop( $string , $length , $replaceString = '...' , $respectWord = true ) {
	      $originalLength = strlen($string);
	      $repStrLength = empty($replaceString) ? 0 : strlen($replaceString);
	      if( $length > $originalLength - $repStrLength ) return $string;
	      if( $respectWord ){
		  if( strpos( ' ' . $string , ' ' , $length  ) == 0 ) return $string;
		  $firstBlank = $length + strpos( $string , ' ' , $length  );
		  $croppedString = substr( $string , 0 , $firstBlank-1 );
	      }else{
		  $umlauds = explode(',','ä,ö,ü,ë,Ä,Ö,Ü,Ë');
		  foreach($umlauds as $char){
			if( strpos( $string , $char ) == $length-1 ){ $length += 1; break; }
		  }
		  $croppedString = substr( $string , 0 , $length );
	      }
	      $crpStrLength = strlen($croppedString);
	      if( substr( $string , $crpStrLength , 1 ) == ' ' ) $croppedString .= ' ';
	      if( $crpStrLength < $originalLength ) $croppedString .= $replaceString;
	      return $croppedString ;
	}

	/**
	 * mkArrTimetableByRoomAndDate
	 * part of tagesansichtAction() and EditAction()
	 *
	 * @param array $zimmerArr uids of rooms, or empty 
	 * @param int $uxDate unix Timestamp of Ausnahme-date
	 * @param array $zmrReservationObj array with other reservation-objects to megre with -  or empty 
	 * @return void
	 */
	public function mkArrTimetableByRoomAndDate( $zimmerArr , $uxDate , $zmrReservationObj = array()) {
		// store filemaker-timetable object in a 2-dimensional array
		$zmrTtObj = array();
		$displaySet = empty($this->settings['filter']['display_feldliste_favorit']) ? 0 : $this->settings['filter']['display_feldliste_favorit'];
		$tipSet = $this->settings['userfields']['display_feldliste_tiptext_'.$displaySet]['value'];
		//$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 1 );
		$repZimmer = $this->zimmerUtility->getZimmerRepository();
		foreach( array_keys($zimmerArr) as $zimmerIdx ){
		      $zmrTtObj = $this->timetableUtility->getArrayByRoomsAndDate( array($zimmerIdx) , $uxDate );
		      $objZimmer = $repZimmer->findByUid( $zimmerIdx );
		      $zimmer = empty($objZimmer) ? '' : $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer();
		      foreach($zmrTtObj as $iUid=>$item) {
			    $zmrReservationObj[$zimmerIdx]['tt-'.$iUid] = $item;
			    $repVar = array(
				'Uid'=>$item['uid'],
				'Lehrperson'=>$item['name'],
				'Periode'=> date( 'd.m.y' , $item['date_start']) .'-'. date( 'd.m.y' , $item['date_end']),
				'Fachlang'=>$item['fachbezeichnung'],
				'Fach'=>$item['fachkurz'],
				'Klasse'=>$item['class_short'],
				'Zeit'=> $item['ab'] .'-'. $item['bis'],
				'Zimmer' => $zimmer
			    );
			    $zmrReservationObj[$zimmerIdx]['tt-'.$iUid]['belegungstext'] = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagplan_feldliste_'.$displaySet]['value']);
			    $zmrReservationObj[$zimmerIdx]['tt-'.$iUid]['tiptext'] = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagplan_feldliste_'.$tipSet]['value']);
		      }
		}
		// set the status for timetable. used if ausnahme is in a not-displayd room
		foreach( array_keys($zimmerArr) as $zimmerIdx ){
		      if(is_array($zmrReservationObj[$zimmerIdx])){
			  foreach($zmrReservationObj[$zimmerIdx] as $iUid=>$item) {
			      $ttAusnahmen = $this->ausnahmeRepository->findByTimetableAndDate( $item['uid'] , $uxDate );
			      if(!empty($ttAusnahmen)){
				    foreach( $ttAusnahmen as $ausnahme ){
					  $oldZimmerObj = $ausnahme->getAusZimmer();
					  if(empty($oldZimmerObj))continue;
					  $oldZimmerUid = $oldZimmerObj->getUid();
					  if( $oldZimmerUid != $zimmerIdx )continue;
					  $zimmerObj = $ausnahme->getNeuZimmer();
					  if(empty($zimmerObj))continue;
					  $zimmerUid = $zimmerObj->getUid();
					  if( $zimmerUid == $zimmerIdx ) {
					      $zmrReservationObj[$zimmerIdx][$iUid]['status']=103;
					  }else{
					      $zmrReservationObj[$zimmerIdx][$iUid]['status']=104;
					  }
					  $zmrReservationObj[$zimmerIdx][$iUid]['belegungstext'] =  $zmrReservationObj[$oldZimmerUid][$iUid]['belegungstext'];
					  if(!isset($zmrReservationObj[$zimmerIdx][$iUid]['zimmerinfo'])){
					      $zmrReservationObj[$zimmerIdx][$iUid]['zimmerinfo']='';
					  }else{
					      $zmrReservationObj[$zimmerIdx][$iUid]['zimmerinfo'].=', ';
					  }
					  $zmrReservationObj[$zimmerIdx][$iUid]['zimmerinfo'] .=  $zimmerObj->getHaus() . ' ' . $zimmerObj->getZimmer();
				    }
			      }
			  }
		      }
		}
		return $zmrReservationObj;
	}

	/**
	 * mkArrAusnahmeByRoomAndDate
	 * part of tagesansichtAction() and EditAction()
	 *
	 * @param array $zimmerArr uids of rooms, or empty 
	 * @param int $uxDate unix Timestamp of Ausnahme-date
	 * @param array $zmrReservationObj array with other reservation-objects to megre with -  or empty 
	 * @return void
	 */
	public function mkArrAusnahmeByRoomAndDate( $zimmerArr , $uxDate , $zmrReservationObj = array()) {
		// store ausnahmen object in the same 2-dimensional array
		// unset filemaker-timetable object if there is a corresponding record in ausnahme
		$aUnsetter = array();
		$displaySet = empty($this->settings['filter']['display_feldliste_favorit']) ? 0 : $this->settings['filter']['display_feldliste_favorit'];
		$tipSet = $this->settings['userfields']['display_feldliste_tiptext_'.$displaySet]['value'];
		$o_ausnahmen = $this->ausnahmeRepository->findByRoomsAndDate( array_keys($zimmerArr) ,  $uxDate );
		if(!$o_ausnahmen) return $zmrReservationObj;
		foreach( $o_ausnahmen as $ausnahme ){
			  $ttUid = $ausnahme->getTimetable();
			  $ausnTimetable  = $this->timetableUtility->getTimetableRepository()->findByUid( $ttUid );
			  if(!($ausnTimetable)) continue;
			  $ausZimmerObj = $ausnahme->getAusZimmer();
			  if(empty($ausZimmerObj)) continue;
			  $ausZimmerUid = $ausZimmerObj->getUid();
			  $zimmerObj = $ausnahme->getNeuZimmer();
			  if(empty($zimmerObj))continue;
			  $zimmerIdx = $zimmerObj->getUid();
			  if(empty($zimmerIdx))continue;
			  $itemIdx =  $ausnahme->getUid();
			  if(empty($itemIdx))continue;
			  $sGetFirstName = $ausnahme->getInfoPerson()->getFirstName();
			  $sFirstName = empty($sGetFirstName) ? '' : substr($sGetFirstName,0,1).'. ';
			  $repVar['Lehrperson'] = $sFirstName . $ausnahme->getInfoPerson()->getLastName();
			  if(method_exists( $ausnTimetable , 'getRelClass' )){
			      // Mffplan Timetable if settings['allowForeignTimetable'] = 1
			      $repVar['Periode'] =  $ausnTimetable->getDateStart()->format('d.m.y') .'-'. $ausnTimetable->getDateEnd()->format('d.m.y');
			      $relClass = $ausnTimetable->getRelClass();
			      $fachRep = $ausnTimetable->getRelSubject();
			      $aFaecher = array();
			      foreach($fachRep as $fachObj){
						$uid = $fachObj->getUid();
						$objFach = $this->fachRepository->findByUid($uid);
						if( $objFach ) {
							$aFaecher['kurz'][] = $objFach->getFachkurz();
							$aFaecher['lang'][] = $objFach->getFachbezeichnung();
						}
			      }
			      if(count($aFaecher)){
				    $repVar['Fach'] = implode( ', ' , $aFaecher['kurz'] );
				    $repVar['Fachlang'] = implode( ', ' , $aFaecher['lang'] );
			      }
			  }elseif(method_exists( $ausnTimetable , 'getKurs' )){
			      // Mffdb Stundenplan if settings['allowForeignTimetable'] = 0
			      $repVar['Periode'] = date( 'd.m.y' , $ausnTimetable->getPlanStart()) .'-'. date( 'd.m.y' , $ausnTimetable->getPlanEnde());
			      $kurs = $this->kursRepository->findByUid($ausnTimetable->getKurs());
			      if( $kurs ){
						$relClass = $kurs->getKurseKlassen();
						$repVar['Fach'] = $kurs->getCourseShort();
						$kFach = $kurs->getFach();
						$fachRs = $kFach ? $this->fachRepository->findByUid($kFach) : FALSE;
						$repVar['Fachlang'] = $fachRs ? $fachRs->getFachbezeichnung() : '-';
			      }
			  }
			  if(!empty($relClass)){
			      $aPersClass = array();
			      foreach($relClass as $class){
					  $objKlasse = $this->klasseRepository->findByUid( $class->getUid() );
					  $aPersClass[] = $objKlasse ? $objKlasse->getClassShort() : 'KURS';
			      }
			      if(count($aPersClass)) $repVar['Klasse'] = implode( '/' , $aPersClass );
			  }
			  $neuZeitAb = $ausnahme->getNeuZeitAb();
			  $neuZeitBis = $ausnahme->getNeuZeitBis();
			  $aTimeFrom = explode( ':' , str_replace('.' , ':' , $neuZeitAb ) );
			  $aTimeTo = explode( ':' , str_replace('.' , ':' , $neuZeitBis ) );
			  $sTfrom = $this->cleanTimeArray( $aTimeFrom );//sprintf( '%02s' , $aTimeFrom[0] ) . ':' . sprintf( '%02s' , $aTimeFrom[1] );
			  $sTto =  $this->cleanTimeArray( $aTimeTo );// sprintf( '%02s' , $aTimeTo[0] ) . ':' . sprintf( '%02s' , $aTimeTo[1] );
 			  if( $ausZimmerUid == $zimmerIdx ) {
				  $aUnsetter[$ausZimmerUid]['tt-'.$ttUid] = 1;
				  $status = 103;
				  $repVar['Zimmer'] =  'Kein Ersatz';
			  }else{ 
				  $zmrReservationObj[$ausZimmerUid]['tt-'.$ttUid]['status']=104;
				  $status = 102; 
				  $repVar['Zimmer'] =  $ausZimmerObj->getHaus() . ' ' . $ausZimmerObj->getZimmer();
			  }
			  $repVar['Zeit'] =  $sTfrom.'-'.$sTto;
			  $belegungstext = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagplan_feldliste_'.$displaySet]['value']);
			  $tiptext = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagplan_feldliste_'.$tipSet]['value']);
			  
			  $zmrReservationObj[$zimmerIdx]['stpaus-'.$itemIdx] = array(
			      'uid' => $itemIdx,
			      'type' => 'ausnahme',
			      'timetable' => $ttUid,
			      'tiptext' =>  $tiptext,
			      'belegungstext' => $belegungstext,
			      'zimmerinfo' => $repVar['Zimmer'],
			      'status' => $status,
			      'ab' => $sTfrom,
			      'bis' => $sTto
			  );
		}
		foreach( $aUnsetter as $ausZimmerUid => $ttObjs ){
		      foreach( array_keys($ttObjs) as $obiUid ){ unset($zmrReservationObj[$ausZimmerUid][$obiUid]); }
		}
		return $zmrReservationObj;
	}

	/**
	 * mkArrBelegungByRoomAndDate
	 * part of tagesansichtAction() and EditAction()
	 *
	 * @param array $zimmerArr uids of rooms, or empty 
	 * @param int $uxDate unix Timestamp of Ausnahme-date
	 * @param array $zmrReservationObj array with other reservation-objects to megre with -  or empty 
	 * @return void
	 */
	public function mkArrBelegungByRoomAndDate( $zimmerArr , $uxDate , $zmrReservationObj = array()) {
		// get mieter-intern/extern for each belegung 
		//$aMieterinfos = $this->getAllMieterInfos();
		//$zimmers = $this->zimmerUtility->mkZimmerSelectObject( 1 );
		$beteiligteAnlaesse = array();
		$korrZmrReservationObj = array();
		$objList = array();
		$repZimmer = $this->zimmerUtility->getZimmerRepository();
		// store belegung object in a copy of the 2-dimensional array and include mieter
		$displaySet = empty($this->settings['filter']['display_feldliste_favorit']) ? 0 : $this->settings['filter']['display_feldliste_favorit'];
		$tipSet = $this->settings['userfields']['display_feldliste_tiptext_'.$displaySet]['value'];
		foreach( array_keys($zimmerArr) as $zimmerIdx ){
		      if(is_array($zmrReservationObj[$zimmerIdx])){
			      foreach($zmrReservationObj[$zimmerIdx] as $ix=>$ttItem){
				    if(
					$ttItem['type'] == 'timetable' &&
					$ttItem['status'] == 101  ) {
					    $korrZmrReservationObj[$zimmerIdx][$ix] = $ttItem;
					    $korrZmrReservationObj[$zimmerIdx][$ix]['status'] = 105;
				    }
			      }
		      }
		}
		foreach( array_keys($zimmerArr) as $zimmerIdx ){
		      $objList[$zimmerIdx] = $this->belegungRepository->findByRoomsAndDates( array($zimmerIdx) , array( 'date'=>$uxDate ) );
		      foreach($objList[$zimmerIdx] as $belegung){
				  $anlassUid = $belegung->getAnlass() ;
				  $beteiligteAnlaesse[$anlassUid] = $anlassUid;
		      }
		}
		foreach( $beteiligteAnlaesse as $anlassUid ){
		    $anlassMieterinfos[$anlassUid] = $this->getAnlassMieterInfos( $anlassUid );
		}
		
		foreach( array_keys($objList) as $zimmerIdx ){
		      $zmrBelegungen = $objList[$zimmerIdx];//$this->belegungRepository->findByRoomsAndDates( array($zimmerIdx) , array( 'date'=>$uxDate ) );
		      $objZimmer = $repZimmer->findByUid( $zimmerIdx );
		      $zimmer = empty($objZimmer) ? '' : $objZimmer->getHaus() . ' ' . $objZimmer->getZimmer();
		      foreach($zmrBelegungen as $belegung){
				  $itemIdx = $belegung->getUid();
				  $numbHowerFrom = 0 + str_replace( ':' , '.' , $belegung->getAb()  );
				  $numbHowerTo = 0 + str_replace( ':' , '.' , $belegung->getBis() );
				  $howerFrom = floor( $numbHowerFrom );
				  $howerTo = floor( $numbHowerTo );
				  $minFrom = round(($numbHowerFrom-$howerFrom)*100); // eg. 5
				  $minTo = round(($numbHowerTo-$howerTo)*100); // eg. 55
				  $anlassUid = $belegung->getAnlass();
				  $status = $belegung->getStatus() . $anlassMieterinfos[$anlassUid]['intern'];
				  $repVar['Text'] = $belegung->getBelegungstext();
				  $repVar['Verwendungszweck'] = $anlassMieterinfos[$anlassUid]['Verwendungszweck'];
				  $repVar['Zusatztext'] = $belegung->getZusatztext();
				  $repVar['Uid'] = $itemIdx;
				  $repVar['Zeit'] = $this->cleanTimeArray( array( $howerFrom , (string) str_pad($minFrom, 2, '0', STR_PAD_LEFT) ) ) . '-' .  $this->cleanTimeArray( array( $howerTo , str_pad($minTo, 2, '0', STR_PAD_LEFT) ) );// sprintf( '%02s' , $howerTo ) . ':' . sprintf( '%02s' , $minTo );
				  $repVar['Zimmer'] = $zimmer;
				  $repVar['Kontaktperson'] = $anlassMieterinfos[$anlassUid]['Kontaktperson'];
				  $repVar['Email'] = $anlassMieterinfos[$anlassUid]['Email'];
				  $repVar['Telefon'] = $anlassMieterinfos[$anlassUid]['Telefon'];
				  $repVar['Kurzbezeichnung'] = $anlassMieterinfos[$anlassUid]['Kurz'];
				  $belegungstext = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagbelg_feldliste_'.$displaySet]['value']);
				  $tiptext = $this->replaceTemplatestring( $repVar , $this->settings['userfields']['display_tagbelg_feldliste_'.$tipSet]['value']);
// 				  $belegungstext = $repVar['Text'] . ' | ' . $repVar['Verwendungszweck'];
// 				  $tiptext = $repVar['Zusatztext'];
				  $zmrReservationObj[$zimmerIdx]['bel-'.$itemIdx] = array(
				      'uid' => $itemIdx,
				      'type' => 'bel',
				      'timetable' =>  $itemIdx,
				      'tiptext' =>  $tiptext,
				      'belegungstext' => $belegungstext,
				      'zimmerinfo' => '',
				      'status' => $status,
				      'ab' => $this->cleanTimeArray( array(  $howerFrom , (string) str_pad($minFrom, 2, '0', STR_PAD_LEFT) ) ),
				      'bis' => $this->cleanTimeArray( array( $howerTo , (string) str_pad($minTo, 2, '0', STR_PAD_LEFT) ) )
				  );
				  // look for corresponding timetable-entries and change theirs status
				  if(is_array($korrZmrReservationObj[$zimmerIdx])){
					foreach($korrZmrReservationObj[$zimmerIdx] as $ix=>$ttItem){
					      if(
						  $ttItem['numAb'] < $numbHowerTo &&
						  $ttItem['numBis'] > $numbHowerFrom ) {
						      $zmrReservationObj[$zimmerIdx][$ix]['status'] = 105;
 					      }
					}
				  }
		      }
		}
		return $zmrReservationObj;
	}

	/**
	 * mkArrTimetableByRoomAndDate
	 * part of tagesansichtAction() and EditAction()
	 *
	 * @param array $zimmerArr uids of rooms, or empty 
	 * @param int $uxDate unix Timestamp of Ausnahme-date
	 * @param array $zmrReservationObj array with other reservation-objects to megre with -  or empty 
	 * @return void
	 */
	public function mkArrAntragByRoomAndDate( $zimmerArr , $uxDate , $zmrReservationObj = array()) {
		foreach( array_keys($zimmerArr) as $zimmerIdx ){
		      $antrags = $this->antragRepository->findByRoomsAndDate( array($zimmerIdx => $zimmerIdx) , $uxDate);
		      foreach( $antrags as $aIx => $objAntrag ){
			    $antragUid = $objAntrag->getUid();
			    $zmrReservationObj[$zimmerIdx][ 'ant-' . $antragUid ] = array(
			    'uid' => $antragUid,
			    'type' => 'antrag',
			    'timetable' => 'tt0',
			    'tiptext' => 'tiptext',
			    'belegungstext' => 'belegungstext',
			    'bearbeiter' => $objAntrag->getBearbeiter(),
			    'status' => 105,
			    'ab' => $objAntrag->getZeitStart(),
			    'bis' => $objAntrag->getZeitEnde(),
			    );
		      }
		}
		return $zmrReservationObj;
	}

	/**
	 * mkArrHolidayByDates
	 * part of conflictsAction() in AusnahmeController
	 *
	 * @param array $aDates array with unix Timestamps for date and todate
	 * @param int $hOffset ofset howers
	 * @return void
	 */
	public function mkArrHolidayByDates( $aDates , $hOffset = 0) {
		// get calendarRecordsets by timerange
		// cut them into day-slices
		$aTa = explode('.' , date('m.d.Y',$aDates['date']) );
		$ab = mktime(0,0,0,$aTa[0],$aTa[1],$aTa[2]);
		$aTb = explode('.' , date('m.d.Y',$aDates['todate']) );
		$bis = mktime(23,59,0,$aTb[0],$aTb[1],$aTb[2]);
 		$calendarObj = $this->timetableUtility->getKalenderRepository()->findInTimerange( $ab ,  $bis );
		$holiday = array();
 		foreach($calendarObj as $obj) {
		    $ferientext = $obj->getFerientext() ;
		    $nurGrundbildung = $obj->getPrivat();
		    $ganztag = $obj->getGanztag();
		    $objUxBeginn = $obj->getBeginn();
		    $objUxEnde =  $obj->getEnde();
		    $grundbildungText = $nurGrundbildung ? ' (nur Grundbildung)' : '';
		    if(date('d.m.y',$objUxBeginn)!=date('d.m.y',$objUxEnde)){
			  $datumText = ' '.date('d.m.y',$objUxBeginn).date('-d.m.y',$objUxEnde) . $grundbildungText.' '.$ferientext;
			  for( $loopDay = $objUxBeginn+86400; $loopDay < $objUxEnde ; $loopDay+=86400 ){
				$holiday[date('d.m.y',$loopDay)] = array(
                        'from'=>0,
                        'allFrom'=>$nurGrundbildung ? 24-$hOffset : 0,
                        'to'=>24-$hOffset,
                        'allTo'=>$nurGrundbildung ? 0 : 24-$hOffset,
                        'text'=>$datumText,
                        'privat' => $nurGrundbildung,
				);
			  }
			  $holiday[date('d.m.y',$objUxBeginn)] = array(
				'from'=>date('H',$objUxBeginn)-$hOffset,
				'allFrom'=>$nurGrundbildung ? 24-$hOffset : date('H',$objUxBeginn)-$hOffset,
				'to'=>24-$hOffset,
				'allTo'=>$nurGrundbildung ? 0 : 24-$hOffset,
				'text'=>$datumText,
				'privat' => $nurGrundbildung,
			  );
			  $holiday[date('d.m.y',$objUxEnde)] = array(
				'from'=>0,
				'allFrom'=>$nurGrundbildung ? 24-$hOffset : 0,
				'to'=>date('H',$objUxEnde)-$hOffset,
				'allTo'=>$nurGrundbildung ? 0 : date('H',$objUxEnde)-$hOffset,
				'text'=>$datumText,
				'privat' => $nurGrundbildung,
			  );
		    }else{
			  $index = date('d.m.y',$objUxBeginn);
			  $uxBeginn = $ganztag ? $ab : $objUxBeginn;
			  $uxEnde = $ganztag ? $bis : $objUxEnde;
			  if( $ganztag ){
				$timeText = ''; // ganztags
			  }elseif( date('H.i',$uxBeginn)==date('H.i',$uxEnde) ){
				$timeText = ''; // ganztags
			  }elseif( '00' == date('H',$uxBeginn) && date('H',$uxEnde) < 16 ){
				$timeText = ' bis '.date('H:i',$uxEnde);
			  }elseif('00' != date('H',$uxBeginn)){
				$timeText = ' ab '.date('H:i',$uxBeginn);
			  }
			  
			  $holiday[date('d.m.y',$objUxBeginn)] = array(
				'from' => date('H',$uxBeginn)-$hOffset,
				'allFrom' => $nurGrundbildung ? 24-$hOffset : date('H',$uxBeginn)-$hOffset,
				'to' => date('H',$uxEnde)-$hOffset,
				'allTo' => $nurGrundbildung ? 0 : date('H',$uxEnde)-$hOffset,
				'text' => ' '.date('d.m.y',$objUxBeginn) . $grundbildungText .' '.$ferientext.$timeText,
				'privat' => $nurGrundbildung,
			  );
		    }
 		}
 		return $holiday;
	}

    /**
        * mkArrConflictsByRoomAndDates
        * part of conflictsAction() in AusnahmeController
        *
        * @param array $zimmerArr uids of rooms, or empty 
        * @param int $aDates unix Timestamps for  date and todate
        * @return void
        */
    public function mkArrConflictsByRoomAndDates( $zimmerArr , $aDates ) {
        $aConflicts = array();
        
        $calendarObj = $this->mkArrHolidayByDates( $aDates );

        // maybe conflict with foreign ausnahme moved to this place
        $zmrAusnahme = array();
        $tagesAusnahmen = $this->ausnahmeRepository->findByRoomsAndDates( $zimmerArr , $aDates );
        foreach($tagesAusnahmen as $ausnahme){
                $zimmerIdx = $ausnahme->getNeuZimmer()->getUid();
                $belIdx = '0.'.$ausnahme->getUid();
                $uxDate = $ausnahme->getDatum()->format('U');
                $zmrTtObj = $this->timetableUtility->getArrayByRoomsAndDate( array($zimmerIdx) , $uxDate );
                $holiday = $calendarObj[ date('d.m.y' , $uxDate ) ];
                $dAusAb = 0 + str_replace( ':' , '.' , $ausnahme->getNeuZeitAb() );
                $dAusBis = 0 + str_replace( ':' , '.' , $ausnahme->getNeuZeitBis() );
                $ausnahmeForTimetableUid = $ausnahme->getTimetable();
                // look up in timetable if recordset for same room an day
                foreach($zmrTtObj as $timetable){
                        if( $timetable['numAb'] >= $dAusBis )continue;
                        if( $timetable['numBis'] <= $dAusAb )continue;
                        if( isset($holiday['from']) && empty($timetable['ignore_vacation']) ){
                            if( empty($timetable['ignore_holiday']) ){ // tt is grundbildung, termin (gb) starts before timetable : no conflict
                                    if( $holiday['from']<=$timetable['numAb'] )continue;
                            }else{// tt is weiterbildung, termin (wb) starts before timetable : no conflict
                                    if( $holiday['allFrom']<=$timetable['numAb'] )continue;
                            }
                        }
                        // no conflict if tt recordset belongs to own ausnahme (from outer loop)
                        if( $ausnahmeForTimetableUid == $timetable['uid'] ) continue;
                        // maybe there is already a ausnahme-recordset to move the timetable-record
                        $ttAusnahmen = $this->ausnahmeRepository->findByTimetableAndDate( $timetable['uid'] , $uxDate );
                        foreach($ttAusnahmen as $aAusnahme) $zmrAusnahme[$aAusnahme->getAusZimmer()->getUid() . '.' . $aAusnahme->getTimetable()] = $aAusnahme; 
                        if(!isset($zmrAusnahme[$zimmerIdx . '.' . $timetable['uid']])) {
                            $aConflicts[ $belIdx ]['tt'][ $timetable['uid'] ] = $timetable;
                        }
                }
                if(count($aConflicts[ $belIdx ]['tt'])) {
                $infoPerson = $ausnahme->getInfoPerson();
                $name = $infoPerson ? $infoPerson->getName() : 'unknown';
                $aConflicts[ $belIdx ]['bel'] = new \stdClass();
                $aConflicts[ $belIdx ]['bel']->datum = $ausnahme->getDatum();
                $aConflicts[ $belIdx ]['bel']->ab = $ausnahme->getNeuZeitAb();
                $aConflicts[ $belIdx ]['bel']->bis = $ausnahme->getNeuZeitBis();
                $aConflicts[ $belIdx ]['bel']->belZimmer = $ausnahme->getAusZimmer();
                $aConflicts[ $belIdx ]['bel']->belegungstext =  $name . ' tt#' . $ausnahmeForTimetableUid;
                $aConflicts[ $belIdx ]['bel']->status = 102;
                }
        }
                
        $zmrBelegungen = $this->belegungRepository->findByRoomsAndDates( $zimmerArr , $aDates );
        foreach( $zmrBelegungen as $belegung ){
                $objZimmer = $belegung->getBelZimmer();
                if(!$objZimmer) continue;
                $zimmerIdx = $objZimmer->getUid();
                $belIdx = $belegung->getUid();
                $uxDate = $belegung->getDatum()->format('U');
                $belTimeFrom = 0 + str_replace( ':' , '.' , $belegung->getAb());
                $belTimeTo = 0 + str_replace( ':' , '.' , $belegung->getBis());
                $zmrTtObj = $this->timetableUtility->getArrayByRoomsAndDate( array($zimmerIdx) , $uxDate );
                $holiday = $calendarObj[ date('d.m.y' , $uxDate ) ];
                foreach($zmrTtObj as $timetable){
                    if( $timetable['numAb'] >= $belTimeTo )continue;
                    if( $timetable['numBis'] <= $belTimeFrom )continue;
                    if( isset($holiday['from']) && empty($timetable['ignore_vacation']) ){
                        if( empty($timetable['ignore_holiday']) ){
                            // tt is grundbildung, termin (gb) starts before timetable : no conflict
                            if(  $holiday['from']<=$timetable['numAb'] )continue;
                        }else{
                            // tt is weiterbildung, termin (wb) starts before timetable : no conflict
                            if(  $holiday['allFrom']<=$timetable['numAb'] )continue;
                        }
                    }
                    // maybe there is already a ausnahme-recordset to move the timetable-record
                    $ttAusnahmen = $this->ausnahmeRepository->findByTimetableAndDate( $timetable['uid'] , $uxDate );
                    foreach($ttAusnahmen as $ausnahme) $zmrAusnahme[$ausnahme->getAusZimmer()->getUid() . '.' . $ausnahme->getTimetable()] = $ausnahme; 
                    if(!isset($zmrAusnahme[$zimmerIdx . '.' . $timetable['uid']])){
                        $aConflicts[ $belIdx ]['tt'][ $timetable['uid'] ] = $timetable;
                    }
                }
                if(count($aConflicts[ $belIdx ]['tt'])) $aConflicts[ $belIdx ]['bel'] = $belegung;
        }
        return $aConflicts;
    }
	  
	  /**
	  *  Find by pattern 'search'
	  * 
	 * @param int $zimmerUid
	 * @param array $dateRangeArr array with one or two values for date an todate
	 * @param array $timeRangeArr array with one or two values for timeFrom an timeTo
	 * @return void
	  */
	  public function findBelegungByRoomDateTime( $zimmerUid , $dateRangeArr , $timeRangeArr ) {
	      $zmrBelegungen = $this->belegungRepository->findByRoomsAndDates( array($zimmerUid=>$zimmerUid) , $dateRangeArr );
	      $outBels = array();
	      $timeFilter = array();
	      foreach( $timeRangeArr as $name => $value ){ $timeFilter[$name] = str_replace( ':' , '.' , $value ); }
	      foreach( $zmrBelegungen as $belegung ){
		    $belIdx = $belegung->getUid();
		    $belTimeFrom = 0 + str_replace( ':' , '.' , $belegung->getAb());
		    $belTimeTo = 0 + str_replace( ':' , '.' , $belegung->getBis());
		    if( $belTimeFrom > $timeFilter['timeTo'] ) continue;
		    if( $belTimeTo < $timeFilter['timeFrom'] ) continue;
		    $outBels[$belIdx]=$belegung;
	      }
	      return $outBels;
	  }
	
	/**
	 * sortReplaceVariable
	 *
	 * @param array $repVar Fieldnames as array-names, replace as values. 
	 * @param string $pattens mandatory eg. ## for trmplating
	 * @param array $aRpl mandatory array to append Data on 
	 * @return array
	 */
	public function sortReplaceVariable( $repVar , $pattens='' , $aRpl = array() ) {
	      $toSortRepl = array();
	      // create array with string-length as value, but keeping the array-keys
	      foreach( array_keys($repVar) as $fieldName ) $toSortRepl[$fieldName]=strlen($fieldName);
	      // sort descendent by keeping assotiations 
	      arsort($toSortRepl);
	      // now only use the array-keys 
	      foreach( array_keys($toSortRepl) as $fieldName ) {
		  $aRpl[$pattens.$fieldName.$pattens] = $repVar[$fieldName] ; 
	      }
	      return $aRpl;
	}
	
	/**
	 * replaceTemplatestring
	 *
	 * @param array $repVar Fieldnames as array-names, replace as values. 
	 * @param string $templatestring String with Fieldnames to replace
	 * @return array
	 */
	public function replaceTemplatestring( $repVar , $templatestring ) {
		$srtRep = $this->sortReplaceVariable( $repVar );
		return str_replace( array_keys($srtRep) , $srtRep , $templatestring );
	}

}
