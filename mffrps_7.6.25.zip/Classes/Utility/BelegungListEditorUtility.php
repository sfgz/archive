<?php
namespace Mff\Mffrps\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class BelegungListEditorUtility
 */

class BelegungListEditorUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * belegungRepository
	 *
	 * @var \Mff\Mffrps\Domain\Repository\BelegungRepository
	 */
	protected $belegungRepository = NULL;

	/**
	* belegung
	*
	* @var \Mff\Mffrps\Domain\Model\Belegung
	*/
	public $belegung = NULL;

	/**
	 * zimmerUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $zimmerUtility = NULL;
	
	/**
	 * calendarUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $calendarUtility = NULL;

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();

	/**
	* calendarnameBeforeUpdate
	*
	* @var string
	*/
	private $calendarnameBeforeUpdate = '';

	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings ) {
		$this->settings = $settings;
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $this->getSettings();
		$this->belegungRepository = $this->objectManager->get('Mff\\Mffrps\\Domain\\Repository\\BelegungRepository');
		$this->belegungRepository->setDefaultQuerySettings($querySettings);
		$this->zimmerUtility = new \Mff\Mffrps\Utility\ZimmerUtility();
		$this->calendarUtility = new \Mff\Mffrps\Utility\CalendarUtility( $this->settings );
	}
	
	/**
	 * editBelegungByFieldname
	 *
	 * @param string $editFieldName FieldName
	 * @param string $editValue Value
	 * @param int $uid
	 * @return string modified Value
	 */
	public function editBelegungByFieldname( $editFieldName ,  $editValue , $uid = NULL ) {
	      if($uid) $this->setBelegungByUid( $uid );
	      $edited = false;
	      $cmd = 'set'.ucfirst($editFieldName);
	      switch( strtolower($editFieldName) ){
		  case 'zeit':
			$aZeit = explode( '-' , $editValue );
			$von = $this->handleTimeValue( trim($aZeit[0]) );
			$bis = $this->handleTimeValue( trim($aZeit[1]) );
			$work1 = $this->editBelegungByMethod( 'setAb' , $von );
			$work2 = $this->editBelegungByMethod( 'setBis' , $bis );
			if( $work1 && $work2 ){
			    $edited = true;
			}
		  break;
		  case 'ab':
		  case 'bis':
			$sZeit = $this->handleTimeValue( $editValue );
			if( $this->editBelegungByMethod( $cmd , $sZeit ) ){
			    $edited = true;
			}
		  break;
		  case 'zimmer':
			$objZimmer = $this->zimmerUtility->getZimmerRepository()->findByUid($editValue);
			if( $objZimmer ){
			      if( $this->editBelegungByMethod( 'setBelZimmer' , $objZimmer ) ){
				  $edited = true;
			      }
			}
		  break;
		  case 'datum':
			$uxDate = $this->handleDateValue( trim($editValue) );
			$timeZoneGMT = new \DateTimeZone( 'GMT' );
			$datevalue = new \DateTime( date('Y-m-d',$uxDate) , $timeZoneGMT );
			if( $this->editBelegungByMethod( $cmd , $datevalue ) ){
			    $edited = true;
			}
		  break;
		  case 'text':
			if( $this->editBelegungByMethod( 'setBelegungstext' , $editValue ) ){
			    $edited = true;
			}
		  break;
		  default:
			if( $this->editBelegungByMethod( $cmd , $editValue ) ){
			    $edited = true;
			}
	      }
	      if($edited) $this->updateBelegung( $this->belegung );
	      return $edited;
	}
	
	/**
	 * updateBelegung
	 *
	 * @param \Mff\Mffrps\Domain\Model\Belegung $belegung
	 * @return void
	 */
	public function updateBelegung( \Mff\Mffrps\Domain\Model\Belegung $belegung ) {
	      $this->belegungRepository->update( $belegung );
	      $this->calendarUtility->updateEventFromBelegung( $belegung , $this->calendarnameBeforeUpdate );
	}
	
	/**
	 * setBelegungByUid
	 *
	 * @param int $uid
	 * @return void
	 */
	public function setBelegungByUid( $uid ) {
	      $this->belegung = $this->belegungRepository->findByUid($uid);
	      if( $this->belegung ) $objZimmer = $this->belegung->getBelZimmer();
	      if( $objZimmer ) $this->calendarnameBeforeUpdate = $this->calendarUtility->getCalendarByRoom( $objZimmer );
	      return $this->belegung;
	}
	
	/**
	 * editBelegungByMethod
	 *
	 * @param string $cmd
	 * @param string $editValue
	 * @return boolean 
	 */
	public function editBelegungByMethod( $cmd , $editValue ) {
	      $edited = false;
	      if( method_exists( $this->belegung , $cmd ) ){
		  $this->belegung->$cmd( $editValue );
		  $edited = true;
	      }
	      return $edited;
	}
	
	/**
	 * handleDateValue
	 * translates d.m.y-date-value into unix-Timestamp 05:00 am
	 *
	 * @param string $editValue Value
	 * @return string modified Value
	 */
	public function handleDateValue( $editValue ) {
	      $rawDate = explode( '.' , trim($editValue) );
	      if( count($rawDate) != 3 ) return $editValue;
	      return mktime( 5,0,0 , $rawDate[1] , $rawDate[0] , $rawDate[2] );
	}
	
	/**
	 * handleTimeValue
	 * replaces dot with doublepoint 
	 * and adds leading zeros if affored
	 *
	 * @param string $editValue Value
	 * @return string modified Value
	 */
	public function handleTimeValue( $editValue ) {
	      $rawTime = str_replace( '.' , ':' , $editValue );
	      $aTime = explode( ':' , $rawTime);
	      return sprintf( '%02s' , $aTime[0] ) . ':' . sprintf( '%02s' , $aTime[1] );
	}
	
	/**
	 * reads configuration , returns querySettings
	 *
	 * @return object
	 */
	public function getSettings( ){
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$storage['storagePid'] = $fullsettings['plugin.']['tx_mffrps_rpsopt.']['persistence.']['storagePid'];
		$querySettings->setStoragePageIds( $storage );
		return $querySettings;
	}

}