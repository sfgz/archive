<?php
namespace Mff\Mffrps\Utility;

class BackupUtility {

	/**
	 * settings
	 *
	 * @var array
	 */
	protected $settings = array();

	/**
	 * systemOptionsUtility
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $systemOptionsUtility = NULL;

	/**
	* msg
	*
	* @var array
	*/
	Public $msg = array();

	/**
	* sqldumpIsAvaiable
	*
	* @var boolean
	*/
	Public $sqldumpIsAvaiable = false;
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct() {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$typoscript = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$settings = $typoscript['plugin.']['tx_'.$this->extKey.'_'.$this->plugin.'.']['settings.'];
		$this->systemOptionsUtility = new \Mff\Mffrps\Utility\SystemOptionsUtility();
		$this->settings = $this->systemOptionsUtility->settings;
		$this->settings['optionfields'] = $this->systemOptionsUtility->getSystemOptions();
		$extPath = dirname(dirname(dirname(__FILE__)));
		$this->settings['uploadPath'] = dirname(dirname(dirname($extPath))).'/uploads/tx_mffrps/calendar/';
	}
	
	function runBackup(){
	      // on friday we return also csv-files
	      $weekday = date('N');
	      $type = $weekday == 5 ? 'weekly' : 'daily' ;
	      return $this->Backup( $type );
	}
	
	/**
	* Backup
	* 
	* @param string $job can be 'daily' or 'weekly'
	* @return boolean
	*/
	function Backup( $job = 'daily' ){
      
	      $backup_user = $this->settings['optionfields']['backup_user']['value'];
	      $backup_pass = $this->settings['optionfields']['backup_pass']['value'];
	      
	      $tablenames = $this->settings['optionfields'][ 'backup_tables_'.$job ]['value'];

	      if( $this->sqldumpIsAvaiable ){
                $dumpResFilename = $this->Original_createSqlDumpFiles( $tablenames );
	      }else{
                $dumpResFilename = $this->createSqlDumpFiles( $tablenames );
	      }
	      
	      if( $dumpResFilename ) {
            $writeToFilePathNames[] = $dumpResFilename;
	      }

	      $errMess = count($this->msg);
	      
	      if( $job == 'weekly' || !$dumpResFilename ){
		    $Filename = $this->createXlsTables();
		    if($Filename) $writeToFilePathNames[] = $Filename;
		    if(!$dumpResFilename) $job = 'extra';
	      }
	      
	      $now = time();
	      $extratext = $job == 'weekly' ? 'SQL- und CSV-Dateiformat': 'SQL-Dateiformat';
	      
	      $htmlText = $errMess ? "Anzahl Fehler: $errMess\r\n\r\n" : "";
	      $htmlText .= "Im Anhang das »".$job."« Backup der Raumplanung-Datenbank. \r\nEs enthält die Tabellen mieter,anlass,belegung,ausnahme,sysoptions im " .  $extratext . ".\r\n";
	      $htmlText .= "\r\n<span style=\"font-size:smaller;\">Ein Dienst von <a href='https://daten.sfgz.ch'>daten.sfgz.ch</a>";
	      $htmlText .= " | ";
	      $htmlText .= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate( 'weekdays.short.'.date('w' , $now ) , 'mffrps' );
	      $htmlText .= ", ".date('d' , $now ).". ";
	      $htmlText .= \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate( 'monthnames.selopt.'. ( 0 + date('m' , $now ) ) , 'mffrps' );
	      $htmlText .= " ".date('Y H:i:s T \(\G\M\T P\)' , $now )."</span>\r\n";

	      $emailSender = !empty($GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress']) ? $GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] : 'daten@medienformfarbe.ch';
	      
	      $aTitle = array( 'daily'=>' SQL' , 'weekly'=>' XLS and SQL' , 'extra'=>'Aufgrund eines Problems nur XLS anstelle von SQL');
	      $emlSubject=''.$job.' '.$aTitle[$job].' '.date('d.m.Y H:i' , $now );

	      $mailMessage = $this->createMailMessage( $backup_user , $emlSubject , utf8_decode($htmlText) , $emailSender , $writeToFilePathNames);

	      $this->uploadMailMessageWithAttatchments( $backup_user , $backup_pass , $mailMessage  );

	      if(is_array($writeToFilePathNames)) {
		    foreach($writeToFilePathNames as $file){if( file_exists($file) ) unlink($file);}
	      }
	      
	      return true;
	}
	
	function createXlsTables(){
	      $dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility($this->settings);
	      $aOut = $dbHelperUtility->getAnlassMieterInfos();
	      $aXls = array();
	      $Filename = '';
	      if($aOut){
		      foreach($aOut as $ix=>$row){
			  foreach($row as $fNam=>$val){ $aXls[$ix][ ucFirst($fNam) ] = $val; }
		      }
		      $aBel = $dbHelperUtility->getBelegungenBackup();
		      $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
		      $Filename = $this->settings['uploadPath'] . date('ymd_Hi') . '.xlsx';
		      $downloader->saveAsXls( array( 'Belegung'=>$aBel , 'Anlass' => $aXls ), $Filename);
		}
		return $Filename;
	}
	
	/**
	* createSqlDumpFiles
	* 
	* @param string $tablenames comma- separed list with short-named tablenames (eg. timetable, klasse)
	* @return string 
	*/
	function createSqlDumpFiles( $tablenames ){
        // get utility
        $dbHelperUtility = new \Mff\Mffrps\Utility\DbHelperUtility($this->settings);
        
        // create dump-content
        $writeToFilePathName = $this->settings['uploadPath'] . date('ymd_Hi') . '.sql';
        $strSqlContent = $dbHelperUtility->getRaumplanungSqlDump( $tablenames );
        $this->msg = $dbHelperUtility->msg;
        // write content to file
        file_put_contents( $writeToFilePathName , $strSqlContent );
        
        // return filename
        return $writeToFilePathName;
	}
	
	/**
	* Original_createSqlDumpFiles
	*  broken since Server does not support sqlDump
	* 
	* @param string $tablenames comma- separed list with short-named tablenames (eg. timetable, klasse)
	* @return string 
	*/
	function Original_createSqlDumpFiles( $tablenames ){
		$writeToFilePathName = $this->settings['uploadPath'] . date('ymd_Hi') . '.sql';
		
		$rawTables = explode( ',' , $tablenames );
		
		$prefix = 'tx_mffrps_domain_model_';
		foreach($rawTables as $tab){$aTablenames[] = $prefix . str_replace( $prefix , '' , strtolower(trim($tab)));}
		
		$tabelle = implode( ' ' , $aTablenames );

		$createCommand = 'mysqldump -h ' . TYPO3_db_host;
		$createCommand .= ' -u ' . TYPO3_db_username;
		$createCommand .= ' -p' . TYPO3_db_password; 
		$createCommand .= ' ' . TYPO3_db . ' ' . $tabelle;
		$createCommand .= ' -r ';
		$createCommand .= $writeToFilePathName;

		exec($createCommand,$error);
		if( $error ) return false;
		return $writeToFilePathName;
	}

	/**
	* createMailMessage
	* returns a RFC-formatted Mailmessage
	* 
	* @param string $emlAdr
	* @param string $emlSubject
	* @param string $rawHtmlText
	* @param string $emlFrom
	* @param array $anhangDateinamen
	* @return string 
	*/
	function createMailMessage($emlAdr , $emlSubject , $rawHtmlText , $emlFrom , $anhangDateinamen){

	      $mailTextHtm = '<div style="font-family:Helvetica,Verdana,Tahoma,sans-serif;font-size:11pt.;">'.$rawHtmlText.'</div>';
	      
	      $random_hash = md5(date('r'));
	      
	      $subject = '=?UTF-8?B?'.base64_encode(utf8_encode($emlSubject)).'?=';

	      $envelopeHeaders = "Return-path: <".$emlFrom.">
		  Envelope-to: ".$emlAdr."
		  Delivery-date: ".date('r')."\r\n";
	      $envelopeHeaders .= "To: ".$emlAdr."\r\n";
	      $envelopeHeaders .= "Subject: ".$subject."\r\n";
	      
	      $envelopeHeaders .= "From: ".$emlFrom."\r\nReply-To: ".$emlFrom;
	      $envelopeHeaders .= "\r\nContent-Type: multipart/mixed;  boundary=\"PHP-mixed-".$random_hash."\"\n";
	      
	      if(is_array($anhangDateinamen)){
			foreach( $anhangDateinamen as $dateiNr => $dateiname){
			  if(empty($dateiname)) continue;
			  if( !is_numeric($dateiNr) ){ // ev. dateinamen, Array enthaelt Datei-Inhalt
				$aDatei[]=$dateiNr;
				$aAttachment[] = chunk_split(base64_encode($dateiname));
			  }elseif(file_exists($dateiname)){
				$aDatei[$dateiNr]=$dateiname;
				$aAttachment[$dateiNr] = chunk_split(base64_encode(file_get_contents($dateiname)));
			  }
			}
	      }
	      
	      ob_start(); //Turn on output buffering
	      
	      echo  "\n\n--PHP-mixed-".$random_hash."\nContent-Type: multipart/alternative; boundary=\"PHP-alt-".$random_hash."\"\n";
	      echo  "\n--PHP-alt-".$random_hash."\nContent-Type: text/plain;  charset=\"UTF-8\"\nContent-Transfer-Encoding: 7bit\n\n".strip_tags(utf8_encode(html_entity_decode($rawHtmlText)));
	      echo  "\n--PHP-alt-".$random_hash."\nContent-Type: text/html; charset=\"UTF-8\"\nContent-Transfer-Encoding: 7bit\n\n".nl2br(utf8_encode($mailTextHtm));
	      echo  "\n--PHP-alt-".$random_hash."--\n";
	      
	      if(is_array($aDatei)){
			foreach(array_keys($aDatei) as $datNr){
			  echo  "\n--PHP-mixed-".$random_hash."\n";
			  echo  "Content-Type: ".$this->mailGetContentType($aDatei[$datNr])."; name=\"".pathinfo($aDatei[$datNr],PATHINFO_BASENAME)."\"\n";
			  echo  "Content-Transfer-Encoding: base64\n";
			  echo  "Content-Disposition: attachment;\n\n";
			  echo $aAttachment[$datNr];
			}
	      }
	      
	      echo "\n\n--PHP-mixed-".$random_hash."--\n";
	      
	      $message = ob_get_clean(); //copy current buffer contents into $message variable and delete current output buffer
	      
	      return $envelopeHeaders . $message;
	}
	
	/**
	* uploadMailMessageWithAttatchments
	* 
	* @param string $mailAccount_user Username in calendar-Account
	* @param string $mailAccount_pass Password in calendar-Account
	* @param string $mailMessage RFC-formatted Mailmessage
	* @return boolean
	*/
	function uploadMailMessageWithAttatchments( $mailAccount_user , $mailAccount_pass , $mailMessage ){
	      $backup_baseurl = $this->settings['optionfields']['backup_baseurl']['value'];
	      $backup_folder = $this->settings['optionfields']['backup_folder']['value'];
	      $mailMessName = $this->settings['uploadPath'].'mymessage.msg';
	      
	      if( file_exists($mailMessName) ) unlink($mailMessName);
	      
	      file_put_contents( $mailMessName , $mailMessage );
	      
	      exec('curl --user '.$mailAccount_user.':'.$mailAccount_pass.' --upload-file '.$mailMessName.' '.$backup_baseurl.$mailAccount_user.'/'.$backup_folder.' -k');
	}

	/**
	* mailGetContentType
	* used by mailer to construct attatchment-header
	* returns a string with the mymetype and content-type of the attatched file
	* 
	* @param string $dateiname
	* @return string 
	*/
	function mailGetContentType($dateiname){ 
	      $mimeTypes = array( 'pdf'=>'application/pdf' , 'txt'=>'text/txt' , 'mp3'=>'application/octet-stream');
	      $mimeTypeImg=array("jpg"=>1,"jpeg"=>1,"gif"=>1,"png"=>1,"xbm"=>1);
	      $ext = strtolower( pathinfo($dateiname,PATHINFO_EXTENSION) );
	      
	      if(!empty($mimeTypeImg[$ext])){
		  $contentType =  "image/".$ext;
	      }elseif(!empty($mimeTypes[$ext])){
		  $contentType = $mimeTypes[$ext];
	      }else{	      
		  $contentType = "application/".$ext;
	      }
	      return $contentType;
	}
}
?>
