<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag',
		'label' => 'betreff',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'datum, zeit_start, zeit_ende, betreff, text, mieter, kalender, anzeige, zimmer, bearbeiter,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffrps') . 'Resources/Public/Icons/tx_mffrps_domain_model_antrag.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'datum, zeit_start, zeit_ende, betreff, text, mieter, kalender, anzeige, zimmer, bearbeiter',
	),
	'types' => array(
		'1' => array('showitem' => 'datum, zeit_start, zeit_ende, betreff, text, mieter, kalender, anzeige, zimmer, bearbeiter, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(
		'datum' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.datum',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'required,date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			)
		),
		'zeit_start' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.zeit_start',
			'config' => array(
				'type' => 'input',
				'size' => 8,
				'eval' => 'trim,required'
			),
		),
		'zeit_ende' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.zeit_ende',
			'config' => array(
				'type' => 'input',
				'size' => 8,
				'eval' => 'trim,required'
			),
		),
		'betreff' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.betreff',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim,required'
			),
		),
		'text' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.text',
			'config' => array(
				'type' => 'text',
				'cols' => 40,
				'rows' => 15,
				'eval' => 'trim'
			)
		),
		'mieter' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.mieter',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kalender' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.kalender',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'anzeige' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.anzeige',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'zimmer' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.zimmer',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array(
					array('waehlen', 0),
				),
			),
		),
		'bearbeiter' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffrps/Resources/Private/Language/locallang_db.xlf:tx_mffrps_domain_model_antrag.bearbeiter',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array(
					array('waehlen', 0),
				),
			),
		),
		'tstamp' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),

	),
);