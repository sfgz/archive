<?php
/***************************************************************
*  Copyright notice
*
*  (c) 2007-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Hooks for the 'mff_import' extension
 *
 * @author		Daniel Rueegg, Francois Suter (Cobweb) <typo3@cobweb.ch>
 * @package		TYPO3
 * @subpackage	tx_mffimport
 */
class tx_mffrps_hook implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * This method responds to the "processResponse" hook of the svconnector_csv class.
	 * 
	 *
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_csv object. Not used.
	 * @return array
	 */
	function processResponse($data, $pObj) {
		// get table header with fieldnames
		date_default_timezone_set ( 'UTC' );
		foreach( $data as $uid => $userrow ){
		      foreach( $userrow as $fld => $cont ){
			  if( !empty($cont) && (
				( ($fld == 'datum' || $fld == 'schulleitung_datum' || $fld == 'rechnungs_datum') && ($cont != '0000-00-00') )  || 
				( $fld == 'info_datum' && $cont != '0000-00-00 00:00:00'))
			  ){
				$value = strtotime($cont);
				$outrow[$uid][$fld] = $value;
			  }else{
			      $outrow[$uid][$fld] = $cont;
			  }
		      }
		}
		date_default_timezone_set ( 'Europe/Zurich' );
		return $outrow;
		
	}

}