<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
// mffrps/ext_localconf.php

// Register hook for import-routine
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['svconnector_sql']['processResponse'][] = 'EXT:mffrps/class.tx_mffrps_hook.php:tx_mffrps_hook';

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'Rpsopt',
	array(
		'Belegung' => 'list, edit, new, create, update,suche,antrag,tagesansicht,zimmer,delete',
		'SysOptions' => 'sysconfig, useroptions',
		'Mieter' => 'list, edit, new, create, update, delete',
		'Anlass' => 'list, edit, new, create, update, delete, mailform,sendmail',
		'Antrag' => 'list, edit, new, create, update, delete,accept',
		'Ausnahme' => 'list, conflicts, edit, new, create, update, delete',
		'Json' => 'update',
	),
	// non-cacheable actions
	array(
		'Belegung' => 'list,edit,new,create,update,suche,antrag,tagesansicht,zimmer',
		'SysOptions' => 'sysconfig,useroptions',
		'Mieter' => 'list, edit,new,update',
		'Anlass' => 'list,edit,update,mailform,sendmail',
		'Antrag' => 'list,edit,new',
		'Ausnahme' => 'list,conflicts,edit,new,create,update',
		'Json' => 'update'
	)
);

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'Aushang',
	array(
		'Antrag' => 'aushang,list, edit, new, create, update, delete,accept',
	),
	// non-cacheable actions
	array(
		'Antrag' => 'aushang,list,edit, new',
	)
);
// Register scheduler-Tasks
if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\RebuildAusnahmeCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.rebuild_ausnahme.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.rebuild_ausnahme.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\MigrateDbBySqlCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.migrate_db_by_sql.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.migrate_db_by_sql.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\RefreshCalendarCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.refresh_calendar.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.refresh_calendar.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\MailDaemonCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\DeferredCalendarCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.deferred_calendars.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.deferred_calendars.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\BackupDbCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.backup_db.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.backup_db.description',
		'additionalFields'	=> ''
	);
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffrps\\Command\\FindOrphansCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.find_orphans.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.find_orphans.description',
		'additionalFields'	=> 'Mff\\Mffrps\\Command\\FindOrphansCommandControllerAdditionalFieldProvider'
	);
}