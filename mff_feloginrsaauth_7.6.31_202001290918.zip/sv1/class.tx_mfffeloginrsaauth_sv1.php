<?php
/**
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * Class extends salted-password hashes authentication service.
 *
 * Contains authentication service class for salted hashed passwords
 * 
 * Authenticates first against typo3-DB, then, 
 * if failed, against Iconn-API, 
 * then, if also failed, against Zibra-API.
 * Finally it stores the password, if successfull.
 * 
 * Created with help from http://jimsuperfly.de/blog/typo3-auth-service/
 * and some ideas from extension fbconnect by Søren Thing Andersen.
 * 
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 * @since 2015-01-17
 */

require_once(  dirname(dirname(__FILE__)) . '/Classes/Utility/CryptUtility.php'  );
 
class tx_mfffeloginrsaauth_sv1 extends \TYPO3\CMS\Saltedpasswords\SaltedPasswordService {

	/**
	 * Find a user (eg. look up the user record in database when a login is sent)
	 *
	 * @return mixed User array or FALSE
	 */
	public function getUser() {
	      $user = false;
	      if ($this->login['status'] != 'login' || empty($this->login['uident']) ) return false;
	      $extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_feloginrsaauth']);
	      $cryptUtility = new CryptUtility();
	      
	      $lifetimeSeconds = $GLOBALS['TYPO3_CONF_VARS']['FE']['lifetime'] ? $GLOBALS['TYPO3_CONF_VARS']['FE']['lifetime'] : $GLOBALS['TYPO3_CONF_VARS']['FE']['sessionDataLifetime'];
	      if( empty($lifetimeSeconds) ) $lifetimeSeconds = 3600;
	      $now = time();
	      $expiredate = $now + $lifetimeSeconds;
	      $neutralCounter = $extConf['clear_pass'] ? array( 'expires'=>$now , 'counter'=>0 , $extConf['passname']=>$cryptUtility->encrypt($this->login['uident_text'])) :  array( 'expires'=>$now , 'counter'=>0);
	      
	      $aLogcounter = $GLOBALS['TSFE']->fe_user->getKey('ses','mfffeloginrsaauth_logindata');
	      
	      if( $aLogcounter['expires'] <= $now ){ $aLogcounter = $neutralCounter ;}
	      $logcounter = 1 + $aLogcounter['counter'];
	      
 	      $GLOBALS['TSFE']->fe_user->setKey('ses', 'mfffeloginrsaauth_logindata',  array( 'expires'=>$expiredate , 'counter'=>$logcounter ) );
	      
	      // is there a user with matching username?
	      $user = $this->fetchUserRecord( $this->login['uname'] ); // get the fe_user from typo3
	      if(!$user) return false;
	      
	      // INTERNAL AUTHENTICATION
	      $isAuth = $this->compareUident( $user, $this->login);
	      if($isAuth){
			$GLOBALS['TSFE']->fe_user->setKey('ses', 'mfffeloginrsaauth_logindata',  $neutralCounter );
			$GLOBALS["TSFE"]->fe_user->sesData_change = true;
			$GLOBALS["TSFE"]->fe_user->storeSessionData();	
			return $user;
	      }

	      $errormessage = '';
	      //EXTERNAL AUTHENTICATION OF LOGIN DATA:
	      if( $logcounter > $extConf['maxFeLoginTrialsApi']){
 		  if($extConf['maxFeLoginTrialsApi'] > 0) $errormessage .= '<p>Bereits "'.($logcounter-1).'" Versuche misslungen, kein weiterer Loginversuch &uuml;ber zertifizierte Auth-API</p>';
	      }elseif( $extConf['maxFeLoginTrialsApi'] ){
		    $isAuth = $this->authAgainstAPI( $this->login['uname']  , $this->login['uident_text'] , $extConf['urlApi'] );
		    if( $isAuth ){
			      $GLOBALS['TSFE']->fe_user->setKey('ses', 'mfffeloginrsaauth_logindata',  $neutralCounter );
			      $GLOBALS["TSFE"]->fe_user->sesData_change = true;
			      $GLOBALS["TSFE"]->fe_user->storeSessionData();	
			      // logged in via API, change fe_users password to password from API
			      $user['password'] = $this->login['uident_text'];
			      return $user;
		    }
	      }

	      
	      if( $logcounter > $extConf['maxFeLoginTrialsWebmail']){
 		    if($extConf['maxFeLoginTrialsWebmail'] > 0) $errormessage .=  '<p>Bereits "'.($logcounter-1).'" Versuche misslungen, kein weiterer Loginversuch &uuml;ber Webmail</p>';
	      }elseif( $extConf['maxFeLoginTrialsWebmail'] ){
		    $isAuth = $this->authAgainstZimbra( $user['email']  , $this->login['uident_text'] ,  str_replace( '_USEREMAIL_' , $user['email'] , $extConf['urlWebmail'] ) );
		    if( $isAuth ){
			      $GLOBALS['TSFE']->fe_user->setKey('ses', 'mfffeloginrsaauth_logindata',  $neutralCounter );
			      $GLOBALS["TSFE"]->fe_user->sesData_change = true;
			      $GLOBALS["TSFE"]->fe_user->storeSessionData();	
			      // logged in via API, change fe_users password to password from API
			      $user['password'] = $this->login['uident_text'];
			      return $user;
		    }
	      }
	      
	      return false;
	}
	
	/**
	 * Authenticate a user (Check various conditions for the user that might invalidate its authentication, eg. password match, domain, IP, etc.)
	 *
	 * @param array $user Data of user.
	 *
	 * @return integer >= 200: User authenticated successfully.
	 *                         No more checking is needed by other auth services.
	 *                 >= 100: User not authenticated; this service is not responsible.
	 *                         Other auth services will be asked.
	 *                 > 0:    User authenticated successfully.
	 *                         Other auth services will still be asked.
	 *                 <= 0:   Authentication failed, no more checking needed
	 *                         by other auth services.
	 */
	public function authUser(array $user) {
	      $OK = 100;
	      if ($this->login['uident'] && $this->login['uname'] && $user != false){
		  $OK = $this->compareUident($user, $this->login); // true if login-data matched
	      }
	      return $OK;
	}
	
	/**
	 * authenticate against Zimbra by calling the Calendar
	 *
	 * @param string $userEmail username with following [at]domain.ch
	 * @param string $password plain password
	 * 
	 * @return mixed TRUE or FALSE
	 */
	function authAgainstZimbra( $userEmail , $password , $urlName ){
	  //$urlName = "https://tcs.tam.ch/home/_USEREMAIL_/Calendar?fmt=json";
	  //$urlNameWithEmail = str_replace( '_USEREMAIL_' , $userEmail , $urlName );
	  $ch = curl_init();
	  curl_setopt($ch,CURLOPT_URL,$urlName);
	  curl_setopt($ch, CURLOPT_USERPWD, $userEmail.':'.$password);
	  curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false); 
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	  $result = curl_exec($ch);
	  curl_close($ch);
	  
	  // if a mail-folder was choosen
	  $arr = json_decode( $result , true );
	  if( is_array($arr) ) $res = true;
	  
	  // if a calendar was choosen
	  if(substr( $result, 1 , 7 ) == '"appt":' ) { $res = true; }
	  return $res;
	}
	
	/**
	 * authenticate against IntranetConnector API 
	 * needs certificate from subdirectory
	 *
	 * @param string $username username without following [at]domain.ch
	 * @param string $password plain password
	 * 
	 * @return mixed TRUE or FALSE
	 */
	function authAgainstAPI( $username , $password , $urlName){
	      //     CURLOPT_SSL_VERIFYHOST values: (from http://unitstep.net/blog/2009/05/05/using-curl-in-php-to-access-https-ssltls-protected-sites/)
	      //     0: Don’t check the common name (CN) attribute
	      //     1: Check that the common name attribute at least exists
	      //     2: Check that the common name exists and that it matches the host name of 
	      //$urlName = "https://77.109.129.155/api.php";
	      $certPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('mff_feloginrsaauth').'sv1/lib/iconn.crt';
	      $ch = curl_init();
	      curl_setopt($ch,CURLOPT_URL,$urlName);
	      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
	      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	      curl_setopt($ch, CURLOPT_CAINFO, $certPath);
	      curl_setopt($ch, CURLOPT_POST, true); 
	      curl_setopt($ch, CURLOPT_POSTFIELDS, array( 'username'=>$username , 'password'=>$password )); 
	      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	      $result = curl_exec($ch);

	      $res = false ;
	      if ($result === false || empty($username) ) { echo 'curl-request: error! '.curl_error($ch);
		    //$db['code'] = 'curl-request: error! '.curl_error($ch);
		    $res = false ;
	      }else{
		    $db = json_decode($result, true );
		    if( $db['username'] == $username ) $res = true ;
	      }
	      curl_close($ch);
	      return $res;
	}
}
?>
