<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "tnm_feloginrsaauth".
 *
 * Auto generated 16-01-2016 18:13
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
	'title' => '(mff) FE-Login RSA-Auth',
	'description' => 'Login gegen Webmail und Intranet-Connector API',
	'category' => 'fe',
	'version' => '7.6.31',
	'state' => 'beta',
	'uploadfolder' => 0,
	'createDirs' => '',
	'clearcacheonload' => 0,
	'author' => 'Daniel Rueegg',
	'author_email' => 'daten@verarbeitung.ch',
	'author_company' => 'medienformfarbe',
	'constraints' => 
	array (
		'depends' => 
		array (
			'felogin' => '',
			'rsaauth' => '',
			'typo3' => '6.2.0-7.9.99',
		),
		'conflicts' => 
		array (
		),
		'suggests' => 
		array (
		),
	),
);

