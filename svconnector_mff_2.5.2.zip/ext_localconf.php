<?php
if (!defined ('TYPO3_MODE')) {
 	die ('Access denied.');
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addService(
		$_EXTKEY,
        // Service type
        'connector',
        // Service key
        'tx_svconnectormff_sv1',
		array(
			'title' => 'Mff JSON connector',
			'description' => 'Connector service connects with hashed password to get JSON data to store in a file.',

			'subtype' => 'mff',

			'available' => TRUE,
			'priority' => 50,
			'quality' => 50,

			'os' => '',
			'exec' => '',

			'className' => \Cobweb\SvconnectorMff\Service\ConnectorMff::class
		)
);
