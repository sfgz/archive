<?php 
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
 
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addService(
	$_EXTKEY,  
	'auth',  
	'tx_sfgzfeloginrsaauth_sv1',
	array(
		'title' => 'Example-Service',
		'description' => 'Authenticates against API service',
		'subtype' => 'authUserFE,getUserFE',
		'available' => TRUE,
		'priority' => 70,
		'quality' => 70,
		'os' => '',
		'exec' => '',
		'classFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY).'sv1/class.tx_sfgzfeloginrsaauth_sv1.php',
		'className' => 'tx_sfgzfeloginrsaauth_sv1',
	)
);
?>
