<?php
namespace Sfgz\SfgzFeloginrsaauth\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>, SfGZ
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PreauthLinkUtility
 * Generiert Preauth-Links um auf «intern.sfgz.ch» einzuloggen
 */

class PreauthLinkUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * Property aIngredients
	 *
	 * @var array
	*/
	Private $aIngredients = array(
			'account' => 'daniel.rueegg',
			'role' => 'teacher',
			'school' => 'sfgz',
			'timestamp' => 0,
			'preauth' => '',
	);
    
	/**    
    * __construct
    * 
    * @param array $conf optional. Overrides values of aIngedients
    * @return void
    */
    public function __construct( $conf = array() ) {
			$this->setConfiguration( $conf );
    }
    
	/**    
    * preauthUri
    * 
    * @param  string $content Empty string (no content to process)
    * @param  array $conf TypoScript configuration
    * @return string
    */
    public function preauthUri($content, $conf) {
			$this->setConfiguration( array( 'timestamp' => time() . '000' , 'account' => $GLOBALS['TSFE']->fe_user->user['username'] ) );
			return $this->createPreauthUri();
    }
    
	/**    
    * preauthLink
    * 
    * @param  string $content Empty string (no content to process)
    * @param  array $conf TypoScript configuration
    * @return string
    */
    public function preauthLink($content, $conf) {
    
			$uri = $this->preauthUri($content, $conf);

			$timeInfo = 'g&uuml;ltig bis um ' . date( 'H:i' , ( time() + 600 ) )  . ' Uhr';
			$userFulllname = $GLOBALS['TSFE']->fe_user->user['first_name'].' '.$GLOBALS['TSFE']->fe_user->user['last_name'];

			$subdom = isset($conf['subdomain'] ) && !empty( $conf['subdomain'] ) ? $conf['subdomain'] : '';
			$subdom2 = isset($conf['subdomain2'] ) && !empty( $conf['subdomain2'] ) ? $conf['subdomain2'] : '';
			
			$strTitle =  'title="Link f&uuml;r &laquo;'.$userFulllname.'&raquo;, '.$timeInfo.'"';

			$strForm =  '';
			if( $subdom ) $strForm .=  '<a ' . $strTitle . ' class="arrowlink" target="_blank" href="' . $subdom . '/apps/Login.aspx' . $uri . '">' . $subdom . '</a>';
			if( $subdom2 && $subdom) $strForm .= ', ';
			if( $subdom2 ) $strForm .=  '<a ' . $strTitle . ' class="arrowlink" target="_blank" href="' . $subdom2 . '/apps/Login.aspx' . $uri . '">' . $subdom2 . '</a>';
			$strForm .= '.';
			
			return $strForm;
    }
    
	/**    
    * createPreauthUri
    * 
    * @param var string $url optional
    * @return string
    */
    public function createPreauthUri( $url = '' ) {
    
			if( empty( $this->aIngredients['timestamp'] ) ) {
				$this->aIngredients['timestamp'] = time() . '000';
			}

			$this->aIngredients['preauth'] = $this->getToken();

			$url .= '?account=' . $this->aIngredients['account'] . '';
			$url .= '&amp;role=' . $this->aIngredients['role'] . '';
			$url .= '&amp;school=' . $this->aIngredients['school'] . '';
			$url .= '&amp;timestamp=' . $this->aIngredients['timestamp'] . '';
			$url .= '&amp;preauth=' . $this->aIngredients['preauth'] . '';
			return $url;
    }
    
	/**    
    * setConfiguration
    * 
    * @param array $conf mandatory. Overrides values of aIngedients
    * @return void
    */
    public function setConfiguration( $conf ) {
			if( !count( $conf ) ) return false;
			foreach( $conf as $key => $confValue ) {
					if( !isset( $this->aIngredients[$key] ) ) continue;
					$this->aIngredients[$key] = $confValue;
			}
			return true;
    }
     
	/**    
    * getToken
    * 
    * @return string
    */
    private function getToken() {

			$xDataString = $this->aIngredients['account'] . "|";
			$xDataString .= $this->aIngredients['role'] . "|";
			$xDataString .= $this->aIngredients['school'] . "|";
			$xDataString .= $this->aIngredients['timestamp'];
			
			return $this->stringToHashMac( $xDataString );

    }
    
	/**    
    * stringToHashMac
    * 
    * @param var string $xDataString
    * @return string
    */
    private function stringToHashMac( $xDataString ) {
			$secretString = '92b67cd576543d393335176024e8a5955e07c18c';
			return hash_hmac('sha1', $xDataString , $secretString );
	}
}
