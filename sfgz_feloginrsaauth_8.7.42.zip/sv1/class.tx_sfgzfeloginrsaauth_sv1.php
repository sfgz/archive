<?php
/**
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * Class extends salted-password hashes authentication service.
 *
 * Contains authentication service class for salted hashed passwords
 * 
 * Authenticates first against typo3-DB, then, 
 * if failed, against Iconn-API, 
 * then, if also failed, against Zibra-API.
 * Finally it stores the password, if successfull.
 * 
 * Created with help from http://jimsuperfly.de/blog/typo3-auth-service/
 * and some ideas from extension fbconnect by Søren Thing Andersen.
 * 
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 * @since 2015-01-17
 */

require_once(  dirname(dirname(__FILE__)) . '/Classes/Utility/CryptUtility.php'  );
 
class tx_sfgzfeloginrsaauth_sv1 extends \TYPO3\CMS\Saltedpasswords\SaltedPasswordService {

	/**
	* cryptUtility
	*
	* @var TYPO3\CMS\Core\SingletonInterface
	*/
	protected $cryptUtility = NULL;

	/**
	* extConf
	*
	* @var array
	*/
	protected $extConf = NULL;

	/**
	* liveTimeSeconds
	*
	* @var int
	*/
	protected $liveTimeSeconds = NULL;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
		$this->cryptUtility = new CryptUtility();
	}

	/**
	 * Find a user (eg. look up the user record in database when a login is sent)
	 *
	 * @return mixed User array or FALSE
	 */
	public function getUser() {
		$user = false;
		
		$liveTimeSeconds = $GLOBALS['TYPO3_CONF_VARS']['FE']['lifetime'] ? $GLOBALS['TYPO3_CONF_VARS']['FE']['lifetime'] : $GLOBALS['TYPO3_CONF_VARS']['FE']['sessionDataLifetime'];
		if( empty($liveTimeSeconds) ) $liveTimeSeconds = 60;
		
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['sfgz_feloginrsaauth']);
		
		$user = $this->getUser_preauthLink();
		if( is_array($user) ) return $user;

		if ($this->login['status'] != 'login' || empty($this->login['uident']) ) return false;
		if (empty($this->login['uident_text']) ) return false;

		$now = time();
		$neutralCounter = $this->extConf['clear_pass'] ? array( 'expires'=>$now , 'counter'=>0 , $this->extConf['passname']=>$this->cryptUtility->encrypt($this->login['uident_text'])) :  array( 'expires'=>$now , 'counter'=>0);
		
		// set counter for external auth
		$aLogcounter = $GLOBALS['TSFE']->fe_user->getKey('ses','sfgzfeloginrsaauth_logindata');
		if( $aLogcounter['expires'] <= $now ){ $aLogcounter = $neutralCounter ;}
		$logcounter = 1 + $aLogcounter['counter'];
		$expiredate = $now + $liveTimeSeconds ;
		$GLOBALS['TSFE']->fe_user->setKey('ses', 'sfgzfeloginrsaauth_logindata',  array( 'expires'=> $expiredate , 'counter'=>$logcounter ) );
		
		// is there a user with matching username?
		$user = $this->fetchUserRecord( $this->login['uname'] ); // get the fe_user from typo3
		if(!is_array($user)) return false;

		// INTERNAL AUTHENTICATION
		$isAuth = $this->compareUident( $user, $this->login);
		
		if( $isAuth ){
				$GLOBALS['TSFE']->fe_user->setKey('ses', 'sfgzfeloginrsaauth_logindata',  $neutralCounter );
				$GLOBALS["TSFE"]->fe_user->sesData_change = true;
				$GLOBALS["TSFE"]->fe_user->storeSessionData();	
				return $user;
		}
		
		//EXTERNAL AUTHENTICATION OF LOGIN DATA:
		$errormessage = '';

		if( $logcounter > $this->extConf['maxFeLoginTrialsApi']){
				if($this->extConf['maxFeLoginTrialsApi'] > 0) $errormessage .= '<p>Bereits "'.($logcounter-1).'" Versuche misslungen, kein weiterer Loginversuch &uuml;ber zertifizierte Auth-API</p>';
		}elseif( $this->extConf['maxFeLoginTrialsApi'] ){
				$isAuth = $this->authAgainstAPI( $this->login['uname']  , $this->login['uident_text'] , $this->extConf['urlApi'] );
				if( $isAuth ){
						$GLOBALS['TSFE']->fe_user->setKey('ses', 'sfgzfeloginrsaauth_logindata',  $neutralCounter );
						$GLOBALS["TSFE"]->fe_user->sesData_change = true;
						$GLOBALS["TSFE"]->fe_user->storeSessionData();	
						// logged in via API, change fe_users password to password from API
						$user['password'] = $this->login['uident_text'];
						return $user;
				}
		}

		if( $logcounter > $this->extConf['maxFeLoginTrialsWebmail']){
				if($this->extConf['maxFeLoginTrialsWebmail'] > 0) $errormessage .=  '<p>Bereits "'.($logcounter-1).'" Versuche misslungen, kein weiterer Loginversuch &uuml;ber Webmail</p>';
		}elseif( $this->extConf['maxFeLoginTrialsWebmail'] ){
				$isAuth = $this->authAgainstZimbra( $user['email']  , $this->login['uident_text'] ,  str_replace( '_USEREMAIL_' , $user['email'] , $this->extConf['urlWebmail'] ) );
				if( $isAuth ){
						$GLOBALS['TSFE']->fe_user->setKey('ses', 'sfgzfeloginrsaauth_logindata',  $neutralCounter );
						$GLOBALS["TSFE"]->fe_user->sesData_change = true;
						$GLOBALS["TSFE"]->fe_user->storeSessionData();	
						// logged in via API, change fe_users password to password from API
						$user['password'] = $this->login['uident_text'];
						return $user;
				}
		}

		//  hack for LOGIN-BY-LINK
		$isAuth = $this->authFromLink( $user);
		if($isAuth){
				$GLOBALS['TSFE']->fe_user->setKey('ses', 'sfgzfeloginrsaauth_logindata',  $neutralCounter );
				$GLOBALS["TSFE"]->fe_user->sesData_change = true;
				$GLOBALS["TSFE"]->fe_user->storeSessionData();	
				return $user;
		}
		// END hack for login-by-link
	      
		return false;
	}

	/**
	 * Find a user (eg. look up the user record in database when a login is sent)
	 *
	 * @return mixed User array or FALSE
	 */
	public function getUser_preauthLink() {
			
			$account = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('account');
			if( empty($account) ) return false;
			
			$user = $this->fetchUserRecord( $account ); // get the fe_user from typo3
			if(!$user) return false;
			
			if( $this->authUser_preauthLink( $account ) == false ) return false;
			
			return $user;
	}

	/**
	 * Authenticate a user (Check various conditions for the user that might invalidate its authentication, eg. password match, domain, IP, etc.)
	 *
	 * @param array $user Data of user.
	 *
	 * @return integer >= 200: User authenticated successfully.
	 *                         No more checking is needed by other auth services.
	 *                 >= 100: User not authenticated; this service is not responsible.
	 *                         Other auth services will be asked.
	 *                 > 0:    User authenticated successfully.
	 *                         Other auth services will still be asked.
	 *                 <= 0:   Authentication failed, no more checking needed
	 *                         by other auth services.
	 */
	public function authUser(array $user) {
			$account = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('account');
			if( $account ) return $this->authUser_preauthLink( $account );

			$OK = 100;
			if ($this->login['uident'] && $this->login['uname'] && $user != false ){
					$OK = $this->compareUident( $user, $this->login ); // true if login-data matched
					//  hack for LOGIN-BY-LINK
					if( $OK < 200 ) $OK = $this->authFromLink( $user );
			}
			return $OK;
	}
	
	/**
	 * Authenticate a user over a link (login-URL)
	 *
	 * @param string $account username
	 * @return integer
	 */
	public function authUser_preauthLink( $account ) {
			$toleranceInMinutes = 10;
			
			$request['account'] = $account;
			
			$OK = 100;
			// refused, no username given!
			if( empty($request['account']) ) return $OK;
			
			$request['role'] = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('role');
			$request['school'] = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('school');
			// timestamp is in milliseconds!
			$request['timestamp'] = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('timestamp');

			$reqPreauth = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('preauth');

// 			$secretString = '92b67cd576543d393335176024e8a5955e07c18c';
			$secretString = $this->extConf['preauthKey'] ;
			$calculatedToken = hash_hmac('sha1', implode( '|' , $request ) , $secretString );
			
			$OK = ( strtolower( $calculatedToken ) == strtolower( $reqPreauth ) ) ? 200 : -1;
			
			if( $OK == 200 ){
				$toleranceInSeconds = $toleranceInMinutes * 60;
				$creationTimeInMinutes = $request['timestamp'] / 60000 ; // transform milliseconds to minutes
				$timeBeforeThenMinutes = ( time() - $toleranceInSeconds ) / 60;
				// refused if timestamp to old!
				if( $creationTimeInMinutes < $timeBeforeThenMinutes ) $OK = -1;
				$timeInTwentyMinutes = ( time() + ( 2* $toleranceInSeconds ) ) / 60;
				// refused if timestamp to far in future!
				if( $creationTimeInMinutes > $timeInTwentyMinutes ) $OK = -1;
			}
			return $OK;
	}
	
	/**
	 * Authenticate a user over a link (login-URL)
	 *
	 * @param array $user Data of user.
	 * @return integer
	 */
	public function authFromLink(array $user) {
			$login = $this->login;
			$login['uident_text'] = $this->login['uident'];
			$login['uident'] = $this->cryptUtility->encrypt($this->login['uident']);
			return $this->compareUident( $user, $login);
	}
	
	/**
	 * authenticate against Zimbra by calling the Calendar
	 *
	 * @param string $userEmail username with following [at]domain.ch
	 * @param string $password plain password
	 * 
	 * @return mixed TRUE or FALSE
	 */
	function authAgainstZimbra( $userEmail , $password , $urlName ){
// 		if( $this->login['uident'] == 'P4r4m373r!' ) return 200;
	  //$urlName = "https://tcs.tam.ch/home/_USEREMAIL_/Calendar?fmt=json";
	  //$urlNameWithEmail = str_replace( '_USEREMAIL_' , $userEmail , $urlName );
	  $ch = curl_init();
	  curl_setopt($ch,CURLOPT_URL,$urlName);
	  curl_setopt($ch, CURLOPT_USERPWD, $userEmail.':'.$password);
	  curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false); 
	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	  $result = curl_exec($ch);
	  curl_close($ch);
	  $res = false;
	  if(substr( $result, 1 , 7 ) == '"appt":' && !empty($userEmail) ) { $res = true; }
	  return $res;
	}
	
	/**
	 * authenticate against IntranetConnector API 
	 * needs certificate from subdirectory
	 *
	 * @param string $username username without following [at]domain.ch
	 * @param string $password plain password
	 * 
	 * @return mixed TRUE or FALSE
	 */
	function authAgainstAPI( $username , $password , $urlName){
	      //     CURLOPT_SSL_VERIFYHOST values: (from http://unitstep.net/blog/2009/05/05/using-curl-in-php-to-access-https-ssltls-protected-sites/)
	      //     0: Don’t check the common name (CN) attribute
	      //     1: Check that the common name attribute at least exists
	      //     2: Check that the common name exists and that it matches the host name of 
	      //$urlName = "https://77.109.129.155/api.php";
	      $certPath = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sfgz_feloginrsaauth').'sv1/lib/iconn.crt';
	      $ch = curl_init();
	      curl_setopt($ch,CURLOPT_URL,$urlName);
	      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
	      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	      curl_setopt($ch, CURLOPT_CAINFO, $certPath);
	      curl_setopt($ch, CURLOPT_POST, true); 
	      curl_setopt($ch, CURLOPT_POSTFIELDS, array( 'username'=>$username , 'password'=>$password )); 
	      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	      $result = curl_exec($ch);

	      $res = false ;
	      if ($result === false || empty($username) ) { echo 'curl-request: error! '.curl_error($ch);
		    //$db['code'] = 'curl-request: error! '.curl_error($ch);
		    $res = false ;
	      }else{
		    $db = json_decode($result, true );
		    if( $db['username'] == $username ) $res = true ;
	      }
	      curl_close($ch);
	      return $res;
	}
}
?>
