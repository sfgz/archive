<?php
require_once( dirname(__FILE__) .  '/html2pdf.php');


class mffPDF extends \FPDF
{
    var $MyTitle = "";   // variable indicating whether a new group was requested
    var $MyPageGroup = 0;   // variable indicating whether a new group was requested

    Public function StartPageGroup()
    {
        $this->MyPageGroup=1;
    }
    Public function AddPageGroup()
    {
        $this->MyPageGroup+=1;
    }
    Public function Header() {
	// Logo
	$this->Image( __DIR__ . '/logo.png' ,$this->lMargin,6,150);
	// Line break
	$this->Ln(5);
    }

    // Page footer
    Public function Footer() {
    }
    Public function MyFooter($myTitle='') {
	// -15 = Position at 1.5 cm from bottom
	$Y = $this->GetY();
	$this->SetY(-10);

	$this->SetFont('Helvetica','I',8);
	// Page number
	$footertext = !empty($myTitle) ? '/'.$myTitle : '' ;
	$this->Cell(0,10, 'Seite '.$this->MyPageGroup.$footertext ,0,0, 'C' );
	$this->Cell(0,10, date('d.m.Y') ,0,1, 'R' );
	$this->SetY($Y);
    }
}
// Written by Larry Stanbery - 20 May 2004
// "freeware" -- same license as FPDF
// creates "page groups" -- groups of pages with page numbering
// total page numbers are represented by aliases of the form {nbX}


class PdfPageGroup extends \mffPDF
{
    var $NewPageGroup;   // variable indicating whether a new group was requested
    var $PageGroups;     // variable containing the number of pages of the groups
    var $CurrPageGroup;  // variable containing the alias of the current page group

    // create a new page group; call this before calling AddPage()
    function StartPageGroup()
    {
        $this->NewPageGroup=true;
        $this->MyPageGroup=1;
    }

    // current page in the group
    function GroupPageNo()
    {
        return $this->PageGroups[$this->CurrPageGroup];
    }

    // alias of the current page group -- will be replaced by the total number of pages in this group
    function PageGroupAlias()
    {
        return $this->CurrPageGroup;
    }

    function _beginpage($orientation,$size)
    {
        parent::_beginpage($orientation,'');
        if($this->NewPageGroup)
        {
            // start a new group
            $n = sizeof($this->PageGroups)+1;
            $alias = "{nb$n}";
            $this->PageGroups[$alias] = 1;
            $this->CurrPageGroup = $alias;
            $this->NewPageGroup=false;
        }
        elseif($this->CurrPageGroup)
            $this->PageGroups[$this->CurrPageGroup]++;
    }

    function _putpages()
    {
        $nb = $this->page;
        if (!empty($this->PageGroups))
        {
            // do page number replacement
            foreach ($this->PageGroups as $k => $v)
            {
                for ($n = 1; $n <= $nb; $n++)
                {
                    $this->pages[$n]=str_replace($k, $v, $this->pages[$n]);
                }
            }
        }
        parent::_putpages();
    }

    // Page footer
    function Footer() {
	// -15 = Position at 1.5 cm from bottom
	$this->SetY(-10);

	$this->SetFont('Helvetica','I',8);
	// Page number
	$this->Cell(0,10, 'Seite '.$this->GroupPageNo().'/'.$this->PageGroupAlias().', gedruckt am: '.date('d.m.Y H:i:s') ,0,0,'C');
    }
    function MyFooter($myTitle='') {
	// -15 = Position at 1.5 cm from bottom
	$Y = $this->GetY();
	$this->SetY(-10);

	$this->SetFont('Helvetica','I',8);
	// Page number
	$this->Cell(0,10, $myTitle ,0,1,'R');
	$this->SetY($Y);
    }
}

// Handle special IE contype request
if(isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT']=='contype')
{
	header('Content-Type: application/pdf');
	exit;
}

?>
