<?php

	/** Copyright 2000-2010 par Laurent Minguet  **/
	/** http://prgm.spipu.net/php_qrcode	**/

	$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
	if (!$msg) die('parameter "msg" fehlt'); //$msg = "http://megaui.net/fukuchi/works/qrencode/index.en.html";


	$err = isset($_GET['err']) ? $_GET['err'] : '';
	if (!in_array($err, array('L', 'M', 'Q', 'H'))) $err = 'L';
	
	require_once('/home/httpd/vhosts/medienformfarbe.ch/private/scripts/qrcode/qrcode.class.php');
	
	$qrcode = new QRcode(utf8_encode($msg), $err);
	//$qrcode->disableBorder(); // Border is always 4 (40px)
	$qrcode->displayPNG(185);

