
plugin.tx_mfflsb_template {
  view {
    # cat=plugin.tx_mfflsb_template/file; type=string; label=Path to template root (FE)
    templateRootPath = EXT:mff_lsb/Resources/Private/Templates/
    # cat=plugin.tx_mfflsb_template/file; type=string; label=Path to template partials (FE)
    partialRootPath = EXT:mff_lsb/Resources/Private/Partials/
    # cat=plugin.tx_mfflsb_template/file; type=string; label=Path to template layouts (FE)
    layoutRootPath = EXT:mff_lsb/Resources/Private/Layouts/
  }
  persistence {
    # cat=plugin.tx_mfflsb_template//a; type=string; label=Default storage PID
    storagePid =
  }
}

plugin.tx_mfflsb_survey {
  view {
    # cat=plugin.tx_mfflsb_survey/file; type=string; label=Path to template root (FE)
    templateRootPath = EXT:mff_lsb/Resources/Private/Templates/
    # cat=plugin.tx_mfflsb_survey/file; type=string; label=Path to template partials (FE)
    partialRootPath = EXT:mff_lsb/Resources/Private/Partials/
    # cat=plugin.tx_mfflsb_survey/file; type=string; label=Path to template layouts (FE)
    layoutRootPath = EXT:mff_lsb/Resources/Private/Layouts/
  }
  persistence {
    # cat=plugin.tx_mfflsb_survey//a; type=integer; label=Default storage PID
    storagePid =
  }
  settings {
    # cat=plugin.tx_mfflsb_survey/b/b; type=string; label=URL of LimeSurvey Server
    lsBaseUrl = http://umfragen.verarbeitung.ch
    # cat=plugin.tx_mfflsb_survey/b/c; type=string; label=LimeSurvey users Username
    lsUsername = admin
    # cat=plugin.tx_mfflsb_survey/b/c; type=string; label=LimeSurvey users Password
    lsPassword = parameter
  }
}
