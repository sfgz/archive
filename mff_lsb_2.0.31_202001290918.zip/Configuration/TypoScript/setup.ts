
plugin.tx_mfflsb_template = USER_INT
plugin.tx_mfflsb_template {
	view {
		templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
		templateRootPaths.1 = {$plugin.tx_mfflsb_template.view.templateRootPath}
		partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
		partialRootPaths.1 = {$plugin.tx_mfflsb_template.view.partialRootPath}
		layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
		layoutRootPaths.1 = {$plugin.tx_mfflsb_template.view.layoutRootPath}
	}
	persistence {
		storagePid = {$plugin.tx_mfflsb_template.persistence.storagePid}
		#recursive = 1
	}
	settings {
		keymap {
				mandatory {
					0 = N
					1 = Y
				}
				format {
					0 = A
					1 = G
					2 = S
				}
				type {
					1 = T
					2 = Q
					3 = F
					4 = X
				}
		}
		limesurvey_maxlength_question_title = 20
		upload_dir = uploads/tx_mfflsb/documents/
		fill_confirmation_data = 0
		show_questiontype_in_preview = 1
		# map Typo3 Properties to LimeSurvey Xml Fields 
		# lsXmlGroup.lsXmlField = typo3dbTable.dbField
		defaultPropertiesLimeSurveyXml {
				surveys.language = de
				surveys.assessments = Y
				surveys.showwelcome = N
				surveys.anonymized = N
				surveys.showprogress = N
				surveys.template = mff_default
				surveys.adminemail = ##ADMINEMAIL##
				surveys.admin = ##ADMIN##
				surveys_languagesettings.surveyls_language = de
		}
		mapPropertiesToLimeSurveyXml {
				surveys.sid = uid
				surveys.format = page_format
				surveys.printanswers = printanswers
				surveys_languagesettings.surveyls_survey_id = uid
				surveys_languagesettings.surveyls_title = raw_title
				surveys_languagesettings.surveyls_description = description
				surveys_languagesettings.surveyls_welcometext = welcome_text
				surveys_languagesettings.surveyls_endtext = end_text
		}
		specchars {
				laquo = 171
				raquo = 187
				copy = 169
				registered = 174
				at = 64
		}
		empty_subquests {
				1 = 1
				2 = 0
				3 = 0
				4 = 1
		}
		lsFieldKeywords {
				set_as_blank  = SET_BLANK
				set_as_title_only = NOT_SET
		}
		lsBaseFields {
				LimeSurveyDocType = Survey
				DBVersion = 178
				languages {
						language = de
				}
		}
		lsFields {
			answers {
				qid =
				code =
				answer =
				sortorder =
				assessment_value =
				language = de
				scale_id = 0
			}
			groups {
				gid = 
				sid = 998
				group_name = 
				group_order =
				description = SET_BLANK
				language = de
				randomization_group = SET_BLANK
				grelevance = SET_BLANK
			}
			questions {
				qid =
				parent_qid = 0
				sid = 998
				gid =
				type =
				title =
				question =
				preg = SET_BLANK
				help = SET_BLANK
				other = N
				mandatory = 
				question_order =
				language = de
				scale_id = 0
				same_default = 0
				relevance = 1
				label_input_columns = 5
				text_input_columns = 7
			}
			subquestions {
				qid = 
				parent_qid = 
				sid = 998
				gid = 
				type = T
				title = 
				question = 
				preg = NOT_SET
				help = NOT_SET
				other = N
				mandatory = 
				question_order = 
				language = de
				scale_id = 0
				same_default = 0
				relevance = NOT_SET
			}
			question_attributes {
				qid = 
				attribute = 
				value = 
				language = NOT_SET
			}
			surveys {
				sid = 314315
				admin = Administrator
				expires = 
				startdate = 
				adminemail = daten@sfgz.ch
				anonymized = N
				faxto = SET_BLANK
				format = A
				savetimings = N
				template = mff_weiterbildung
				language = de
				additional_languages = SET_BLANK
				datestamp = N
				usecookie = N
				allowregister = N
				allowsave = N
				autonumber_start = 0
				autoredirect = N
				allowprev = Y
				printanswers = Y
				ipaddr = N
				refurl = N
				publicstatistics = N
				publicgraphs = N
				listpublic = N
				htmlemail = Y
				sendconfirmation = N
				tokenanswerspersistence = N
				assessments = Y
				usecaptcha = D
				usetokens = N
				bounce_email = umfragen@sfgz.ch
				attributedescriptions = NOT_SET
				emailresponseto = SET_BLANK
				emailnotificationto = SET_BLANK
				tokenlength = 15
				showxquestions = Y
				showgroupinfo = G
				shownoanswer = Y
				showqnumcode = X
				bouncetime = NOT_SET
				bounceprocessing = N
				bounceaccounttype = NOT_SET
				bounceaccounthost = NOT_SET
				bounceaccountpass = NOT_SET
				bounceaccountencryption = NOT_SET
				bounceaccountuser = NOT_SET
				showwelcome = Y
				showprogress = N
				questionindex = NOT_SET
				navigationdelay = 0
				nokeyboard = N
				alloweditaftercompletion = Y
				googleanalyticsstyle = 0
				googleanalyticsapikey = SET_BLANK
			}
			surveys_languagesettings {
				surveyls_survey_id = 998
				surveyls_language = de
				surveyls_title = 
				surveyls_description = 
				surveyls_welcometext = 
				surveyls_endtext = 
				surveyls_url =  = SET_BLANK
				surveyls_urldescription = SET_BLANK
				surveyls_email_invite_subj = 
				surveyls_email_invite = 
				surveyls_email_remind_subj = 
				surveyls_email_remind = 
				surveyls_email_register_subj = 
				surveyls_email_register = 
				surveyls_email_confirm_subj = 
				surveyls_email_confirm = 
				surveyls_dateformat = 1
				surveyls_attributecaptions = NOT_SET
				email_admin_notification_subj = 
				email_admin_notification = 
				email_admin_responses_subj = 
				email_admin_responses = 
				surveyls_numberformat = 1
				attachments = NOT_SET
			}
		}
		spider {
				radius = 288
				text_inset {
					x = -20
					y = -10
				}
				image_position {
					left = 50
					top = 15
				}
		}
		use_pdf_basics = 0
# 
# page-headlines in array HeaderTexts
# 
# options for parts of layout:
# layout.report
# - abstract summary 
# - aggregation analyse:textarea,text,matrix
# - spider
# layout.sinlges
# - intro summaryForSingle
# - Single textarea,text,matrix,label 
# 
# status views options:
# - nodata handout empty: PdfPrintout->pdfTemplate nodata+usersurvey
# - printout handout with data: PdfPrintout->pdfTemplate printout+usersurvey
# - report with data and answers PdfReport->pdfReport pdf_basic+usersurvey
# 
# configuration select:
# - Grundbildung pdf_basics.0.report+printout+nodata+usersurvey
# - Kurse pdf_basics.1.report+printout+nodata+usersurvey
# - Lehrgaenge pdf_basics.2.report+printout+nodata+usersurvey
#
		pdf_basics.0 {
			index = 0
			FilenamePrefix = Auswertung_
			FilenameBody = ##KURS_KLASSE##_##KURS_NAME##_##START_DATUM##
			FilenameReplacing {
				search{
					0 = .
					1 = /
					2 = :
					3 = ,
					4 = +
				}
				replace {
					0 = -
					1 = -
					2 = -
					3 = _
					4 = _
				}
			}
			Creator = http://umfragen.sfgz.ch
			Title = Unterrichtsbeurteilung
			Subject = Online-Version der «Auswertung Unterrichtsbeurteilung Lernende»
			Author = BfGZ, ###USER_NAME###
			TopMargin = 33
			LeftMargin = 21.5
			RightMargin = 9
			BottomMargin = 15
			docuwidth = 210
			cellwidthPoints = 8
			lfeed = 5
			slfeed = 5
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			HeaderText = Lernenden-Feedback | Auswertung
			HeadLine.rows = 125.5 , 8 , 8 , 8 , 8 , 22
			HeadLine.method = grundbildungHeader
			FooterTopLeft = Lernenden-Feedback vom ##START_DATUM##
			FooterTopRight = ##KURS_NAME## bei ##LEITUNG_NAME##
			FooterBottomLeft = __C__ Schule für Gestaltung Zürich | Gedruckt am __DATE__
			FooterBottomRight = Seite __PAGE__ | ##KURS_KLASSE##
			matrixTitle = 
			summaColumnLabels {
				2 = Erreicht
				4 = Note
				6 = Erreicht/Note
				7 = Bemerkung
			}
			layout {
				report {
					data = 
					1.0 = Summary
					1.1 = Analyse:Matrix,Text-title,Textarea-title
					2.0 = Spider
					3.0 = Analyse:Text
					4.0 = Analyse:Textarea
				}
				singles {
					data = usersurvey
					4.2 = Singles
				}
			}
			SummaryTitle = Zusammenfassung
			SummaryLineConf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			SummaryRows {
				0 {
					width = 25,68,5.5,16,65
					0.0 = leitungname,##LEITUNG_NAME##
					0.1 = 
					0.2 = startdate,##START_DATUM##
					1.0 = kursklasse,##KURS_KLASSE##
					1.1 = 
					1.2 = kursname,##KURS_NAME##
				}
				2 {
					width = 25,68
					0.0 = Methode,##TEMPLATE_NAME##
				}
				1 {
					width = 32,7,4,43,7
					align = L,C,e,L,C,e,L,C
					0.0 = participcount,##ANZAHL_TEILNEHMENDE##
					0.1 = 
					0.2 = responsescount,##ANZAHL_ANTWORTEN##
				}
			}
		}

		pdf_basics.1 < plugin.tx_mfflsb_template.settings.pdf_basics.0
		pdf_basics.1 {
			index = 1
			FilenameBody = ##KURS_KLASSE##_##KURS_NAME##_##SEMESTER##
			Title = 3.5.01.02 FO Auswertung Kursbewertung
			Subject = Auswertung der Bewertungen durch Teilnehmende
			TopMargin = 33
			LeftMargin = 18
			RightMargin = 20
			lfeed = 5
			slfeed = 5
			fsize = 9
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			HeaderText = Auswertung Kursbewertung
			HeaderTexts {
				3.4 = Unterrichtsentwicklung Kurse evaluieren
				4.3 = 3.5.1.2
				4.4 = Auswertung Kursbewertung
				5.5 = Anzahl Teilnehmende
			}
			HeadLine.rows = 78,7,1,15,71
			HeadLine.method = weiterbildungHeader
			FooterTopLeft = Kursbewertung
			FooterBottomLeft = __C__ Schule für Gestaltung Zürich | Gedruckt am __DATE__
			FooterTopRight = Kurs ##KURS_KLASSE## bei ##LEITUNG_NAME##
			FooterBottomRight = ##ANZAHL_ANTWORTEN## Personen | Seite __PAGE__
			FirstPageFooter.0 = 
			FirstPageFooter.1 = 
			FirstPageFooter.2 = 
			layout.report.1.1 = Analyse:Matrix,Textarea-title
			layout.report.1.2 = Footer
			layout.report.2.0 >
			matrixTitle = A Auswertung
			ReportFooter.fsize = 9.5
			ReportFooter.lines_min = 8
			ReportFooter.lines_max = 20
			ReportFooter.line_conf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			ReportFooter.spacing = 5
			ReportFooter.cols.0.title = B Analyse
			ReportFooter.cols.1.title = C Interpretation
			ReportFooter.rows.0 = Kopie der Auswertung bitte innerhalb von 14 Tagen nach Abschluss des Kurses an das
			ReportFooter.rows.1 = Sekretariat Weiterbildung. Original an der nächsten Mitarbeiterbeurteilung vorlegen.
			SummaryTitle = 
			SummaryRows {
				0 > 
				1 > 
				2 > 
				5 {
					width = 34,138
					0.0 = kursklasse,##KURS_KLASSE##-##SEMESTER## ##KURS_NAME##
				}
				6 {
					width = 34,66,1,37,34
					0.0 = leitungname,##LEITUNG_NAME##
					0.1 = 
					0.2 = semester_datum,##SEMESTER## / ##START_DATUM##
				}
				7 {
					width = 34,66,1,41,30
					1.0 = responsescount,##ANZAHL_ANTWORTEN##
					1.1 = 
					1.2 >
				}
			}
			
		}
		
		pdf_basics.2 < plugin.tx_mfflsb_template.settings.pdf_basics.1
		pdf_basics.2 {
			index = 2
			Title = 3.5.01.02 FO Auswertung Semesterbewertungen
			fontFamilyHead = Helvetica
			fontFamilyFoot = Helvetica
			lfeed = 5
			slfeed = 5
			fsize = 9
			HeaderText = Auswertung Semesterbewertungen
			HeaderTexts {
				3.3 = 3.5.2
				3.4 = Unterrichtsentwicklung Lehrgänge evaluieren
				4.3 = 3.5.2.2
				4.4 = Auswertung Semesterbewertungen
				5.5 = Anzahl Teilnehmende
			}
			FooterTopLeft = Semesterbewertung
			FooterTopRight = ##KURS_KLASSE## | ##LEITUNG_NAME##
			FooterBottomRight =  Seite __PAGE__
			matrixTitle = A Auswertung
			layout.report.1.1 = Analyse:Matrix,Textarea-title
			layout.report.1.2 = Footer
			layout.report.2.0 >
			SummaryRows.7.1.0 = responsescount,##ANZAHL_ANTWORTEN##
			SummaryRows.7.1.1 >
			SummaryRows.7.1.2 >
			ReportFooter.fsize = 9.5
			ReportFooter.lines_min = 8
			ReportFooter.lines_max = 20
			ReportFooter.line_conf {
				width = 0.15
				color = 0,0,0
				dash = 0.15 , 0.6
			}
			ReportFooter.spacing = 5
			ReportFooter.cols.0.title = B Analyse
			ReportFooter.cols.1.title = C Interpretation
			ReportFooter.rows.0 = Kopie der Auswertung bitte innerhalb von 14 Tagen der Lehrgangsleitung zustellen. Original an der nächs-
			ReportFooter.rows.1 = ten Mitarbeiterbeurteilung vorlegen. In digitaler oder analoger Form sechs Jahre lang aufbewahren.
			FirstPageFooter.0 = 
			FirstPageFooter.1 = 
			FirstPageFooter.2 = 
		}
# pdf_dynamic overrides pdf_basics. 
# For 'printout' and 'nodata' only, 
# The config for 'reports' (with answers) will not be touched.
		pdf_dynamic.0 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.0
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.0
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.0
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					Subject = «Fragebogen Unterrichtsbeurteilung Lernende»
					FooterBottomRight =  ##KURS_KLASSE##
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Lernenden-Feedback
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					HeaderText = Lernenden-Feedback | Fragebogen
					SummaryTitle = ##TEMPLATE_NAME##
					SummaryRows.1 >
					SummaryRows.2 >
					cellwidthPoints = 8
				}
		}
		pdf_dynamic.1 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.1
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.1
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.1
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					SummaryTitle = 
					Subject = «Fragebogen Kursbewertung Teilnehmer/innen»
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
					SummaryRows.6.0.2 = semester_datum,##SEMESTER## / 
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Kursbewertung
					SummaryRows.5.0.0 = kursklasse,
					SummaryRows.6.0.2 = semester_datum,
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					SummaryTitle = 
					SummaryRows.6.0.2 = semester_datum,##SEMESTER##
					SummaryRows.7.1 >
					HeaderText = Fragebogen Kursbewertung
					cellwidthPoints = 8
					matrixTitle =
				}
		}
		pdf_dynamic.2 {
				printout < plugin.tx_mfflsb_template.settings.pdf_basics.2
				nodata < plugin.tx_mfflsb_template.settings.pdf_basics.2
				usersurvey < plugin.tx_mfflsb_template.settings.pdf_basics.2
				printout {
					pdfDynamicIndex = printout
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					Subject = «Fragebogen Semesterbewertungen Teilnehmer/innen»
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Semesterbewertung
					BottomMargin = 10.5
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				nodata {
					pdfDynamicIndex = nodata
					FilenamePrefix = Vorlage_
					FilenameBody = ##TEMPLATE_NAME##
					Subject = «Fragebogen Semesterbewertungen Teilnehmer/innen»
					FooterTopLeft = 
					FooterTopRight = 
					FooterBottomLeft = __C__ Schule für Gestaltung Zürich
					FooterBottomRight = Gedruckt am __DATE__ | Semesterbewertung
					SummaryRows.5.0.0 = kursklasse,
					SummaryRows.6.0.2 = semester_datum,
					cellwidthPoints = 12
					layout.singles.4.1 = SingleSummary
				}
				usersurvey {
					pdfDynamicIndex = usersurvey
					HeaderText = Fragebogen Semesterbewertungen
					SummaryTitle = 
					SummaryRows.6.0.2 = semester_datum,##SEMESTER##
					SummaryRows.7.1 >
					cellwidthPoints = 8
					matrixTitle =
				}
		}
		
		pdf_basics.0.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.printout
		pdf_basics.0.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.nodata
		pdf_basics.0.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.0.usersurvey
		
		pdf_basics.1.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.printout
		pdf_basics.1.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.nodata
		pdf_basics.1.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.1.usersurvey

		pdf_basics.2.printout < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.printout
		pdf_basics.2.nodata < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.nodata
		pdf_basics.2.usersurvey < plugin.tx_mfflsb_template.settings.pdf_dynamic.2.usersurvey
	}
}

plugin.tx_mfflsb_survey = USER_INT
plugin.tx_mfflsb_survey {
  view {
    templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
    templateRootPaths.1 = {$plugin.tx_mfflsb_survey.view.templateRootPath}
    partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
    partialRootPaths.1 = {$plugin.tx_mfflsb_survey.view.partialRootPath}
    layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
    layoutRootPaths.1 = {$plugin.tx_mfflsb_survey.view.layoutRootPath}
  }
  persistence {
    storagePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
	classes{
		Mff\MffLsb\Domain\Model\UserSurvey {
			newRecordStoragePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
		}
	}
  }
  settings < plugin.tx_mfflsb_template.settings
  settings {
      lsBaseUrl = {$plugin.tx_mfflsb_survey.settings.lsBaseUrl}
      lsUsername = {$plugin.tx_mfflsb_survey.settings.lsUsername}
      lsPassword = {$plugin.tx_mfflsb_survey.settings.lsPassword}
      urlpath = /survey/index/sid/
      shortpath = /unterricht/
      # token auch in der Datei .htaccess unterhalb umfragen.xx.ch anpassen!
      token = pin
      anonymous {
				token = klasse
				firstname = Anonyma
				lastname = Nonames
				email = daten@sfgz.ch
				usesleft = 100
				used = 0
      }
      useroptions.sumtypes = 6
      autoupdate_after_minutes = 0
      barcode_size = 7
      particip.examples {
			1 {
				name = Eva Roth
				email = eva.roth@blau.ch
			}
			2 {
				name = Joseph-Marie_Charles Jacquard
				email = jac@gelb.com
			}
      }
  }
}

plugin.tx_mfflsb_remote = USER_INT
plugin.tx_mfflsb_remote {
	view {
			templateRootPaths.0 = EXT:mff_lsb/Resources/Private/Templates/
			templateRootPaths.1 = {$plugin.tx_mfflsb_survey.view.templateRootPath}
			partialRootPaths.0 = EXT:mff_lsb/Resources/Private/Partials/
			partialRootPaths.1 = {$plugin.tx_mfflsb_survey.view.partialRootPath}
			layoutRootPaths.0 = EXT:mff_lsb/Resources/Private/Layouts/
			layoutRootPaths.1 = {$plugin.tx_mfflsb_survey.view.layoutRootPath}
	}
	persistence {
			storagePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
			classes{
				Mff\MffLsb\Domain\Model\UserSurvey {
					newRecordStoragePid = {$plugin.tx_mfflsb_survey.persistence.storagePid}
				}
			}
	}
## sumtypes: 1=none, 2=nurProzent, 4=nurNote, 6=ProzUndNote
	settings < plugin.tx_mfflsb_survey.settings
	settings {
			anonymous_accounts {
					10 = .nn
					20 = ref
			}
			useroptions.sumtypes = 2
			useroptions.foreignTimetable = 1
			useroptions.listlength = 10
			useroptions.period = 1
			useroptions.manualmailcopy = 2
			useroptions.default_black_copy = 1
			useroptions.default_black_copy_reminder = 0
			firstname_lastname = 1
			anonymous.token = kurs
			remind_daysleft = 25
			days_before_start = 0
			days_after_end = 10
			use_pdf_basics = 1
			display {
				sendHtmLink {
					success = Email mit Link gesendet
					error = Email mit Link konnte nicht gesendet werden
					wrap = <pre>|</pre>
				}
				sendPdfData {
					success = Email mit Auswertung gesendet
					error = Email mit Auswertung konnte nicht gesendet werden
					wrap = <div style="text-align:center"><pre>|</pre></div>
				}
				sendPdfHandout {
					success = Email mit Vorlage gesendet
					error = Email mit Vorlage konnte nicht gesendet werden
					wrap = <pre>|</pre>
				}
			}
			mail {
				unlock = 1
				fix_invitation_from = weiterbildung@sfgz.ch
				use_fix_invitation = 0 
				presentation.link_label = Link pr&auml;sentieren
				pdf_request.link_label = Auswertung anfordern
				sender_adress = umfragen@sfgz.ch
				sender_text.subject = Auswertung der Unterrichtsbeurteilung (##KURS## | ##FACH##)
				sender_text.body = Guten Tag ##NAME## <br /> Im Anhang befindet sich die Auswertung der Umfrage  "##KURS## | ##FACH##"
				sender_footer.0 = <p style="font-family:Helvetica,Arial,sans-serif;font-size:85%;font-style:italic;">
				sender_footer.1 = Diese Nachricht wurde &uuml;ber Email angefordert und automatisch generiert. 
				sender_footer.2 = Ignorieren Sie sie, falls Sie diese Auswertung nicht selbst angefordert haben,
				sender_footer.3 = oder kontaktieren Sie die Administration der Umfrage: ##ADMIN_NAME##, ##ADMIN_EMAIL##.
				sender_footer.4 = </p>
				reminder_text.subject = Erinnerung
				reminder_text.body = Diese Erinnerung wurde automatisch erstellt, weil ihre Umfrage noch nicht beantwortet wurde. Bitte denken Sie daran, die Umfrage in den n&auml;chsten Tagen durchzuf&uuml;hren.<br /><br />
				printout_reminder_text.subject = 
				printout_reminder_text.body = 
				logo {
						path = typo3conf/ext/mffdesign/Resources/Public/images/
						imagename = logo.svg
						image_width = 280
						wrap_image = <br /><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
						wrap_signature_neutral (
								<br><span style="color:#333;font-size:10pt;font-family:Helvetica,Arial,sans-serif;">
								<b>Schule für Gestaltung Zürich</b><br>Weiterbildungssekretariat<br>Ausstellungsstrasse 104<br>8090 Zürich
								#telephone#</span><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
						)
						wrap_signature (
								<br><span style="color:#333;font-size:10pt;font-family:Helvetica,Arial,sans-serif;">
								<b>Schule für Gestaltung Zürich<br>#title##vorname# #nachname#</b><br>#fachbereich##fachbereiche#Ausstellungsstrasse 104<br>8090 Zürich
								#telephone#</span><p><a href="http://www.sfgz.ch" style="text-decoration:none;color:#333;">|</a></p>
						)
				}
				notification_subject.0 = Maildämon hat 1 Nachricht gesendet
				notification_subject.1 = Maildämon hat ##EX## Nachrichten gesendet
			}
	}
}

# JS  einbinden
page.includeJSFooter.lsb_helpers = EXT:mff_lsb/Resources/Public/script/mfflsb_helper.js

json_survey = PAGE
json_survey {
  config {
    disableAllHeaderCode = 1
    debug = 0
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1489891401
  10 = COA_INT
  10 {
   10 = RECORDS
   10 {
      tables = tt_content
      source = {GP:cnt}
      source.insertData = 1
      source.insertData.intval = 1
   }
  }
}

distant_survey = PAGE
distant_survey {
	headerData.1110 = COA_INT
	headerData.1110 {
		wrap = <title>|</title>
			10 = USER_INT
			10 {
				userFunc = Mff\MffLsb\Utility\DisplayInvitaionUtility->showObjectTitle
			}
	}
	shortcutIcon = typo3conf/ext/mffdesign/Resources/Public/images/favicon.ico
	config {
		debug = 0
		no_cache = 1
	}
	typeNum = 43

	5 = COA_INT
	5.wrap = <div id="container">|</div>
	
	5.10 = COA_INT
	5.10.wrap (
		<div id="container_header">
			<div id="header_top">
				<div id="header_top_left">
				|
				</div>
			</div>
		</div><!-- /container_header -->
	)
	5.10.10 = IMAGE
	5.10.10 {
		file =typo3conf/ext/mffdesign/Resources/Public/images/logo.svg
		params = alt="sfgz-logo"
	}
	
	5.20 = COA_INT
	5.20.wrap (
		<div id="container_content">
			<div id="content">
				<div id="content_main">
				|
				</div>
			</div>
		</div><!-- /container_content -->
	)
	5.20.10 = USER_INT
	5.20.10 {
		userFunc = Mff\MffLsb\Utility\DisplayInvitaionUtility->showObjectData
	}
   
	includeCSS.cssfile1 = typo3conf/ext/mffdesign/Resources/Public/css/general.css
	includeCSS.cssfile3 = typo3conf/ext/mffdesign/Resources/Public/css/decor.css
	includeCSS.cssfile2 = typo3conf/ext/mffdesign/Resources/Public/css/print.css
	includeCSS.cssfile2.media = print
}



# [globalVar = GP:type=43]
# config.noPageTitle = 2
# [global]

[globalVar = GP:type=1489891401]
    tt_content.list.20.stdWrap.prefixComment = 
    tt_content.stdWrap.prefixComment =
    tt_content.stdWrap.innerWrap.cObject.default = 
    lib.stdheader >
[global]

plugin.tx_mfflsb._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }
    .listbox {
        clear:left;margin:2px 0 15px 0;padding:6px;background-color:#FFF;border-radius:4px;border:1px solid #555;width:auto;float:left;
    }
    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }
	.blackhover A:hover {color:#000;text-decoration:none;opacity:0.5;}
    .tx-mff-lsb table {
        border-collapse:separate;
        border-spacing:2px 3px; 
    }

    .tx-mff-lsb table th {
        font-weight:bold;
    }

    .tx-mff-lsb table td {
        /* vertical-align:top; */
    }

    .typo3-messages .message-error {
        color:red;
    }

    .typo3-messages .message-ok {
        color:green;
    }
    DIV.tx-mff-lsb .editform input[type=text] {
	 width:580px;
    }
    BODY DIV.tx-mff-lsb H1, #content DIV.tx-mff-lsb H1, #content_main DIV.tx-mff-lsb H1 {
	font-size:11pt;
	font-weight:bold;
	background:#ddd;
	color:black;
	padding:4px 3px 1px 3px;
	margin:0;
	border:1px solid #888;
	border-bottom:1px solid #d0d0d0;
	border-right:1px solid #bbb;
	border-radius:3px 0 5px 0px;
	cursor:pointer;
    }
    #content_main DIV.tx-mff-lsb H1:hover {
	color:#888;
    }
    BODY DIV.tx-mff-lsb H1.maintitle, #content DIV.tx-mff-lsb H1.maintitle, #content_main DIV.tx-mff-lsb H1.maintitle {
	background:black;
	color:#ffffff;
	padding:0px 3px 0px 3px;
	cursor:auto;
	border:0;
	border-radius:0;
    }
    .question_edit { border-bottom:0px solid #aaa;margin:0;padding:0px;}
    BODY DIV.tx-mff-lsb H2 {
	font-size:10pt;border:1px solid #000;font-weight:bold;color:white;background:black;padding:1px 3px 0px 18px;
    }
    BODY DIV.tx-mff-lsb .question_edit H2 { font-size:115%;border:0;background:white;color:black;padding:0.5em 0 0 0;text-decoration:underline;}
    .question_edit H3 { font-size:108%;padding:0.1em 0 0 0;}
    .question_edit H4 { font-size:100%;padding:0.1em 0 0 0;color:#555;}
    SPAN.required {font-style:italic;font-weight:bold;color:#888;padding:2px 3px;}
    DIV.editdatble {padding:5px 0;}
    .tx-mff-lsb TABLE.tx_mfflsb  {
	border: 0px solid #333;
	border-collapse:separate;
        border-spacing:0px; 
    }
    TABLE.tx_mfflsb A, TABLE.tx_mfflsb A:visited {color:#333;font-weight:normal;}
    TABLE.tx_mfflsb TR.sel A, TABLE.tx_mfflsb TR.sel A:visited {color:#009ee0;font-weight:normal;}
    .tx-mff-lsb TABLE.tx_mfflsb th {
		background-color:#eee;
		color:#666;
		border-top: 1px #888 solid;
		border-bottom: 1px #bbb solid;
		text-align:left;
		vertical-align:top;
		padding:2px 5px 1px 3px;
		font-style:italic;
	}
    .tx-mff-lsb TABLE.tx_mfflsb th:first-child { border-left:1px solid #e0e0e0; }
    .tx-mff-lsb TABLE.tx_mfflsb th:last-child { border-right:1px solid #f0f0f0; }
    .tx-mff-lsb TABLE.tx_mfflsb td {
		color:#666;
		border-left: 1px #EFEFEF solid;
		border-bottom: 1px #aaa dotted;
		border-top: 0;
		text-align:left;
		vertical-align:top;
		padding:3px 5px;
    }
    .tx-mff-lsb TABLE.tx_mfflsb td:first-child { border-left:0; }
    DIV.analyse {
	page-break-inside:avoid;
    }
    TABLE.analyse {
	page-break-inside:avoid;
	border: 1px solid #333;
	border-collapse:separate;
        border-spacing:0px;
        margin:0 0 2ex 0;
        background:#fff;
    }
    TABLE.analyse TD { border-left: 1px solid #333; }
    TABLE.analyse TD:first-child { border-left:0; }
    TABLE.analyse TD { border-top:1px dotted #aaa; }
    TABLE.analyse TR:first-child TD { border-top:0; }
    TABLE.analyse TR:nth-child(1) TD { border-top:1px solid #000; }
    TABLE.analyse TR.total TD { border-top:2px solid #000; }
    /* TABLE.analyse TR.total TD { border-left:1px solid #aaa; } */
    TABLE.analyse TR.total TD:nth-child(2) { border-left:1px solid #000; }
    TABLE.analyse TD.headrow { vertical-align:bottom; padding:2px 3px; font-size:95%;}
    TABLE.analyse THEAD TD.label { vertical-align:bottom; }
    TABLE.analyse TD.label { padding-left:18px;text-indent:-15px; text-align:left;width:42em; }
    TABLE.analyse TD.label.nth_row { padding-left:18px; text-indent:0px; text-align:left;width:42em; }
    TABLE.analyse TD.fullwidth { padding-left:2px; text-align:left;width:63em; }
    TABLE.analyse TD.rightwidth { width:21em; }
    TABLE.analyse TD.prozent, TABLE.analyse TD.punkte { text-align:center;  width:1px; }
    TABLE.analyse TD.note { text-align:left;padding-left:5px; }
    TABLE.analyse.standard TD.prozent, TABLE.analyse.standard TD.punkte { vertical-align:bottom;  }
    TABLE.analyse.standard TD.note { vertical-align:bottom; }
    TABLE.analyse TR.total TD.label, TABLE.analyse TR.total TD.punkte { font-style:italic; }
    TABLE.analyse TR.total TD.label, TABLE.analyse TR.total TD.prozent { font-style:italic; }
    TABLE.analyse TR.total TD.prozent, TABLE.analyse TR.total TD.note { padding-left:3px;padding-right:3px;font-weight:bold;border-left:1px solid #000; }
    TABLE.analyse TR.total.subtotal TD { border-width:1px;}
    TABLE.analyse TR.total.subtotal TD.punkte,
    TABLE.analyse TR.total.subtotal TD.prozent,
    TABLE.analyse TR.total.subtotal TD.note { font-style:normal; font-weight:normal; }
    TABLE.analyse TR.notalone TD.note, 
    TABLE.analyse TR.notalone TD.punkte, 
    TABLE.analyse TR.notalone TD.prozent { font-size:80%; color:#555;  border-width:1px; vertical-align:bottom; }
    TABLE.analyse TR.blankcell TD { border: 1px olid #CCC; border-width:1px 0 0 0; }
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.prozent, 
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.punkte, 
    .tx-mff-lsb TABLE.analyse.grouped TR.isalone TD.note {
    vertical-align:middle; 
    }
    
    .handwritten {font-family:courier;}
    .isboldX {font-weight:bold;}
    .isbold- {color:#888;}
    DIV.singles {
	    page-break-inside:avoid;
	    background:#ffc;
	    padding:2ex;
	    padding-bottom:0;
	    margin:5px 2px;
	    border:1px dotted #AAA;
    }
    A.black, A:visited.black {color:black}
    A.black:hover {color:#555;}
    A.add_record.black {color:black}
    A.add_record.black:hover {color:#555;}
    .page {padding:4px;margin-right:2px;border:1px solid #333;border-radius:3px;}
    TABLE.surveyedit {border-spacing:5px 5px; }
    .preview .obsolete { color:#888; }
    .isvisible_1 {}
    .isvisible_0 {display:none;}
    TABLE.nowrap TD {white-space:nowrap;overflow:visible;}
    TABLE.tx_mfflsb input[type=xxcheckbox]{
	position: relative;
	vertical-align: middle;
	bottom: 1px;
    }
    .tx-mff-lsb TABLE.editform TD:first-child {vertical-align:bottom;font-size:95%;}
    #container_header { margin:0 auto; width:45%;min-width:250px;padding:15px 15px 0 15px; text-align:center;}
    #header_top { border-radius:4px 4px 0 0; background:#fff; padding:8px 8px 0 8px;margin:0; }
    #header_top IMG { width:100%; }
    #container_content { margin:0 auto; width:45%;min-width:250px;padding:0 15px 15px 15px;text-align:left; }
    #content_main { border-radius:0 0 4px 4px; background:#fff; padding:0 8px 8px 8px;margin:0; }

)
