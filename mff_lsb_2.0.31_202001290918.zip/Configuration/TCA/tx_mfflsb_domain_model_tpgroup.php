<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup',
        'label' => 'group_name',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
		'sorting' => 'sorting'
        ],
		'searchFields' => 'group_name,group_description,report_partials,report_header_vertical,report_hide_header, tp_group_question',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_tpgroup.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'group_name, group_description, report_partials, report_header_vertical, report_hide_header, tp_group_question',
    ],
    'types' => [
		'1' => ['showitem' => 'group_name, group_description, report_partials, report_header_vertical, report_hide_header, tp_group_question'],
    ],
    'columns' => [
        'group_name' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.group_name',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
			],
	    ],
	    'group_description' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.group_description',
	        'config' => [
			    'type' => 'text',
			    'cols' => 40,
			    'rows' => 15,
			    'eval' => 'trim'
			]
	    ],
	    'report_partials' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.report_partials',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpgroup.report_partials.selopt.1', ''],
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpgroup.report_partials.selopt.2', ''],
			        ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpgroup.report_partials.selopt.3', ''],
			    ],
			    'size' => 3,
			    'maxitems' => 3,
			    'cols' => 'inline'
			],
	    ],
	    'report_header_vertical' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.report_header_vertical',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	    ],
	    'report_hide_header' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.report_hide_header',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	    ],
	    'tp_group_question' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpgroup.tp_group_question',
	        'config' => [
			    'type' => 'inline',
			    'foreign_table' => 'tx_mfflsb_domain_model_tpquestion',
			    'foreign_field' => 'tpgroup',
			    'foreign_sortby' => 'sorting',
			    'maxitems' => 9999,
			    'appearance' => [
			        'collapseAll' => 1,
			        'levelLinksPosition' => 'top',
			        'showSynchronizationLink' => 1,
			        'showPossibleLocalizationRecords' => 1,
			        'useSortable' => 1,
			        'showAllLocalizationLink' => 1
			    ],
			],
	    ],
        'tpsurvey' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'sorting' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
