<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsubquestion',
        'label' => 'question',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
		'sorting' => 'sorting'
        ],
		'searchFields' => 'question,editable,optional',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_tpsubquestion.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'question,editable,optional',
    ],
    'types' => [
		'1' => ['showitem' => 'question,editable,optional'],
    ],
    'columns' => [
        'question' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsubquestion.question',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
	'editable' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsubquestion.editable',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	],
	'optional' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsubquestion.optional',
	        'config' => [
			    'type' => 'check',
			    'items' => [
			        '1' => [
			            '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
			        ]
			    ],
			    'default' => 0
			]
	],
        'tpquestion' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
        'sorting' => [
            'config' => [
                'type' => 'passthrough',
            ],
        ],
    ],
];
