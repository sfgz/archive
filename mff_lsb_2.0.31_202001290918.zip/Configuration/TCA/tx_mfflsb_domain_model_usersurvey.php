<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey',
        'label' => 'template_label',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
		'enablecolumns' => [
        ],
		'searchFields' => 'user_tp_survey,template_name,start_date,expire_days,remote_days,deletion_date,template_xml,course_name,subject,user_uid,enquirer_type,klasse_uid,fach_uid,semester_uid,remote_key,enquirer_uid,enquirer_email,enquirer_name,particip_type,particip_count,particip_mails,responses_count,responses_updated,responses_field,template_group_options,survey_uid,survey_state,mail_state',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_usersurvey.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'user_tp_survey, template_name, start_date,expire_days,remote_days,deletion_date,template_xml, course_name, subject, user_uid, enquirer_type, klasse_uid,fach_uid,semester_uid,remote_key,enquirer_uid, enquirer_email, enquirer_name, particip_type, particip_count, particip_mails, responses_count, responses_updated, responses_field, template_group_options,survey_uid,survey_state,mail_state',
    ],
    'types' => [
		'1' => ['showitem' => 'user_tp_survey, template_name, start_date,expire_days,remote_days,deletion_date,template_xml, course_name, subject, user_uid, enquirer_type, klasse_uid,fach_uid,semester_uid,remote_key,enquirer_uid, enquirer_email, enquirer_name, particip_type, particip_count, particip_mails, responses_count, responses_updated, responses_field, template_group_options,survey_uid,survey_state,mail_state'],
    ],
    'columns' => [
		'crdate' => [
			'exclude' => 1,
			'label' => 'Creation date',
			'config' => [
				'type' => 'none',
				'format' => 'date',
				'eval' => 'date',
			]
		],
		'template_name' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.template_name',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim'
			],
	    ],
        'template_label' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.template_label',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
		],
	],
        'confirm_file' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.confirm_file',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
		],
	],
	'template_xml' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.template_xml',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 15,
			'eval' => 'trim'
		    ]
	],
	'course_name' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.course_name',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim,required'
		    ],
	],
	'subject' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.subject',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim,required'
		    ],
	],
	'start_date' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.start_date',
	    'config' => [
			'dbType' => 'date',
			'type' => 'input',
			'size' => 7,
			'eval' => 'required,date',
			'default' => '0000-00-00'
		    ],
	],
	'expire_days' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.expire_days',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim,required'
		    ],
	],
	'remote_days' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.remote_days',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'deletion_date' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.deletion_date',
	    'config' => [
			'dbType' => 'date',
			'type' => 'input',
			'size' => 7,
			'eval' => 'required,date',
			'default' => '0000-00-00'
		    ],
	],
	'user_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.user_uid',
	    'config' => [
			'type' => 'select',
			'items' => array( array('keine Person', 0)),
			'renderType' => 'selectSingle',
			'foreign_table_where' => ' AND fe_users.email !="" ',
			'foreign_table' => 'fe_users',
			'minitems' => 0,
			'maxitems' => 1,
		    ],
	],
	'enquirer_type' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_type',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_type.selopt.0', 0],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_type.selopt.1', 1]
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => ''
		    ],
	],
	'semester_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.semester_uid',
	    'config' => [
			'type' => 'select',
			'items' => array( array('kein Semester', 0)),
			'renderType' => 'selectSingle',
			'foreign_table' => 'tx_mffplan_domain_model_periods',
			'minitems' => 0,
			'maxitems' => 1,
		    ],
	],
	'klasse_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.klasse_uid',
	    'config' => [
			'type' => 'input',
			'size' => 10,
			'eval' => 'trim'
		    ],
	],
	'fach_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.fach_uid',
	    'config' => [
			'type' => 'input',
			'size' => 10,
			'eval' => 'trim'
		    ],
	],
	'remote_key' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.remote_key',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'enquirer_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_uid',
	    'config' => [
			'type' => 'select',
			'items' => array( array('keine Person', 0)),
			'renderType' => 'selectSingle',
			'foreign_table_where' => ' AND fe_users.email !="" ',
			'foreign_table' => 'fe_users',
			'minitems' => 0,
			'maxitems' => 1,
		    ],
	],
	'enquirer_email' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_email',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'enquirer_name' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.enquirer_name',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'particip_type' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.particip_type',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.particip_type.selopt.0', 0],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.particip_type.selopt.1', 1]
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => ''
		    ],
	],
	'particip_count' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.particip_count',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'particip_mails' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.particip_mails',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 15,
			'eval' => 'trim'
		    ]
	],
	'responses_count' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.responses_count',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ]
	],
	'responses_updated' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.responses_updated',
	    'config' => [
			'dbType' => 'datetime',
			'type' => 'input',
			'size' => 12,
			'eval' => 'datetime',
			'default' => '0000-00-00 00:00:00'
		    ],
	],
	'responses_field' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.responses_field',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 15,
			'eval' => 'trim'
		    ]
	],
	'template_group_options' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.template_group_options',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 15,
			'eval' => 'trim'
		    ]
	],
	'user_tp_survey' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.user_tp_survey',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'foreign_table' => 'tx_mfflsb_domain_model_tpsurvey',
			'minitems' => 0,
			'maxitems' => 1,
		    ],
	],
	'survey_uid' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.survey_uid',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'survey_state' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.survey_state',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ],
	],
	'mail_state' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_usersurvey.mail_state',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.0', 0],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.1', 1],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.2', 2],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.3', 3],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.4', 4],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_usersurvey.mail_state.selopt.5', 5]
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => ''
		    ],
	],
    ],
];
