<?php
return [
    'ctrl' => [
        'title'	=> 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey',
        'label' => 'template_name',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'sortby' => 'sorting',
		'enablecolumns' => [
            'disabled' => 'hidden',
        ],
		'searchFields' => 'template_name,page_format,raw_title,description,welcome_text,end_text,printanswers,pdf_settings,notifysubject,notifytext,handouttext,importanttext,template_xml,tp_survey_group',
        'iconfile' => 'EXT:mff_lsb/Resources/Public/Icons/tx_mfflsb_domain_model_tpsurvey.gif'
    ],
    'interface' => [
		'showRecordFieldList' => 'hidden,versteckt, template_name, page_format, raw_title, description, welcome_text, end_text, printanswers,pdf_settings,notifysubject,notifytext,handouttext,importanttext,template_xml, tp_survey_group',
    ],
    'types' => [
		'1' => ['showitem' => 'versteckt, template_name, page_format, raw_title, description, welcome_text, end_text,printanswers,pdf_settings,notifysubject,notifytext,handouttext,importanttext,template_xml, tp_survey_group'],
    ],
    'columns' => [
	'hidden' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
	'versteckt' => [
            'exclude' => false,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/locallang_core.xlf:labels.enabled'
                    ]
                ],
            ],
        ],
        'template_name' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.template_name',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
		],
	],
        'template_label' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.template_label',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
		],
	],
        'confirm_file' => [
	        'exclude' => false,
	        'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.confirm_file',
	        'config' => [
			    'type' => 'input',
			    'size' => 30,
			    'eval' => 'trim,required'
		],
	],
	'page_format' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.page_format',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.page_format.selopt.0', 0],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.page_format.selopt.1', 1],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.page_format.selopt.2', 2],
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => ''
		    ],
	],
	'raw_title' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.raw_title',
	    'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim,required'
		    ],
	],
	'description' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.description',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 1,
			'eval' => 'trim'
		    ]
	],
	'welcome_text' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.welcome_text',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 2,
			'eval' => 'trim'
		    ]
	],
	'end_text' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.end_text',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 1,
			'eval' => 'trim'
		    ],
	],
	'printanswers' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.printanswers',
	    'config' => [
			'type' => 'input',
			'size' => 2,
			'eval' => 'trim,required'
		    ]
	],
	'notifysubject' => [
		'exclude' => false,
		'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.notifysubject',
		'config' => [
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		    ]
	],
	'notifytext' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.notifytext',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 2,
			'eval' => 'trim'
		    ]
	],
	'handouttext' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.handouttext',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 2,
			'eval' => 'trim'
		    ]
	],
	'importanttext' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.importanttext',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 2,
			'eval' => 'trim'
		    ]
	],
	'template_xml' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.template_xml',
	    'config' => [
			'type' => 'text',
			'cols' => 40,
			'rows' => 3,
			'eval' => 'trim'
		    ]
	],
	'pdf_settings' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.pdf_settings',
	    'config' => [
			'type' => 'select',
			'renderType' => 'selectSingle',
			'items' => [
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.pdf_settings.selopt.0', 0],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.pdf_settings.selopt.1', 1],
			    ['LLL:EXT:mff_lsb/Resources/Private/Language/locallang.xlf:tx_mfflsb_domain_model_tpsurvey.pdf_settings.selopt.2', 2],
			],
			'size' => 1,
			'maxitems' => 1,
			'eval' => ''
		    ],
	],
	'tp_survey_group' => [
	    'exclude' => false,
	    'label' => 'LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mfflsb_domain_model_tpsurvey.tp_survey_group',
	    'config' => [
			'type' => 'inline',
			'foreign_table' => 'tx_mfflsb_domain_model_tpgroup',
			'foreign_field' => 'tpsurvey',
			'foreign_sortby' => 'sorting',
			'maxitems' => 9999,
			'appearance' => [
			    'collapseAll' => 0,
			    'levelLinksPosition' => 'top',
			    'showSynchronizationLink' => 1,
			    'showPossibleLocalizationRecords' => 1,
			    'useSortable' => 1,
			    'showAllLocalizationLink' => 1
			],
	    ],
	],
    ],
];
