<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpSubquestionTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\TpSubquestion
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\TpSubquestion();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getQuestionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getQuestion()
        );

    }

    /**
     * @test
     */
    public function setQuestionForStringSetsQuestion()
    {
        $this->subject->setQuestion('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'question',
            $this->subject
        );

    }
}
