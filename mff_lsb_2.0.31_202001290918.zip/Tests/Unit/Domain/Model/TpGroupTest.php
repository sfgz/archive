<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpGroupTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\TpGroup
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\TpGroup();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getGroupNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getGroupName()
        );

    }

    /**
     * @test
     */
    public function setGroupNameForStringSetsGroupName()
    {
        $this->subject->setGroupName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'groupName',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getGroupDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getGroupDescription()
        );

    }

    /**
     * @test
     */
    public function setGroupDescriptionForStringSetsGroupDescription()
    {
        $this->subject->setGroupDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'groupDescription',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getReportPartialsReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setReportPartialsForIntSetsReportPartials()
    {
    }

    /**
     * @test
     */
    public function getReportHideHeaderReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getReportHideHeader()
        );

    }

    /**
     * @test
     */
    public function setReportHideHeaderForBoolSetsReportHideHeader()
    {
        $this->subject->setReportHideHeader(true);

        self::assertAttributeEquals(
            true,
            'reportHideHeader',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getTpGroupQuestionReturnsInitialValueForTpQuestion()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getTpGroupQuestion()
        );

    }

    /**
     * @test
     */
    public function setTpGroupQuestionForObjectStorageContainingTpQuestionSetsTpGroupQuestion()
    {
        $tpGroupQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();
        $objectStorageHoldingExactlyOneTpGroupQuestion = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneTpGroupQuestion->attach($tpGroupQuestion);
        $this->subject->setTpGroupQuestion($objectStorageHoldingExactlyOneTpGroupQuestion);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneTpGroupQuestion,
            'tpGroupQuestion',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function addTpGroupQuestionToObjectStorageHoldingTpGroupQuestion()
    {
        $tpGroupQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();
        $tpGroupQuestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupQuestionObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($tpGroupQuestion));
        $this->inject($this->subject, 'tpGroupQuestion', $tpGroupQuestionObjectStorageMock);

        $this->subject->addTpGroupQuestion($tpGroupQuestion);
    }

    /**
     * @test
     */
    public function removeTpGroupQuestionFromObjectStorageHoldingTpGroupQuestion()
    {
        $tpGroupQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();
        $tpGroupQuestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupQuestionObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($tpGroupQuestion));
        $this->inject($this->subject, 'tpGroupQuestion', $tpGroupQuestionObjectStorageMock);

        $this->subject->removeTpGroupQuestion($tpGroupQuestion);

    }
}
