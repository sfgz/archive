<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpSurveyTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\TpSurvey
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\TpSurvey();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getTemplateNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTemplateName()
        );

    }

    /**
     * @test
     */
    public function setTemplateNameForStringSetsTemplateName()
    {
        $this->subject->setTemplateName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'templateName',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getPageFormatReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setPageFormatForIntSetsPageFormat()
    {
    }

    /**
     * @test
     */
    public function getOwnQuestionsGroupReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getOwnQuestionsGroup()
        );

    }

    /**
     * @test
     */
    public function setOwnQuestionsGroupForStringSetsOwnQuestionsGroup()
    {
        $this->subject->setOwnQuestionsGroup('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'ownQuestionsGroup',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getDaysExpireReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setDaysExpireForIntSetsDaysExpire()
    {
    }

    /**
     * @test
     */
    public function getRawTitleReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getRawTitle()
        );

    }

    /**
     * @test
     */
    public function setRawTitleForStringSetsRawTitle()
    {
        $this->subject->setRawTitle('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'rawTitle',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getDescriptionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getDescription()
        );

    }

    /**
     * @test
     */
    public function setDescriptionForStringSetsDescription()
    {
        $this->subject->setDescription('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'description',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getWelcomeTextReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getWelcomeText()
        );

    }

    /**
     * @test
     */
    public function setWelcomeTextForStringSetsWelcomeText()
    {
        $this->subject->setWelcomeText('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'welcomeText',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getEndTextReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getEndText()
        );

    }

    /**
     * @test
     */
    public function setEndTextForStringSetsEndText()
    {
        $this->subject->setEndText('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'endText',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getTemplateXmlReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTemplateXml()
        );

    }

    /**
     * @test
     */
    public function setTemplateXmlForStringSetsTemplateXml()
    {
        $this->subject->setTemplateXml('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'templateXml',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getTpSurveyGroupReturnsInitialValueForTpGroup()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getTpSurveyGroup()
        );

    }

    /**
     * @test
     */
    public function setTpSurveyGroupForObjectStorageContainingTpGroupSetsTpSurveyGroup()
    {
        $tpSurveyGroup = new \Mff\MffLsb\Domain\Model\TpGroup();
        $objectStorageHoldingExactlyOneTpSurveyGroup = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneTpSurveyGroup->attach($tpSurveyGroup);
        $this->subject->setTpSurveyGroup($objectStorageHoldingExactlyOneTpSurveyGroup);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneTpSurveyGroup,
            'tpSurveyGroup',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function addTpSurveyGroupToObjectStorageHoldingTpSurveyGroup()
    {
        $tpSurveyGroup = new \Mff\MffLsb\Domain\Model\TpGroup();
        $tpSurveyGroupObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyGroupObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($tpSurveyGroup));
        $this->inject($this->subject, 'tpSurveyGroup', $tpSurveyGroupObjectStorageMock);

        $this->subject->addTpSurveyGroup($tpSurveyGroup);
    }

    /**
     * @test
     */
    public function removeTpSurveyGroupFromObjectStorageHoldingTpSurveyGroup()
    {
        $tpSurveyGroup = new \Mff\MffLsb\Domain\Model\TpGroup();
        $tpSurveyGroupObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyGroupObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($tpSurveyGroup));
        $this->inject($this->subject, 'tpSurveyGroup', $tpSurveyGroupObjectStorageMock);

        $this->subject->removeTpSurveyGroup($tpSurveyGroup);

    }
}
