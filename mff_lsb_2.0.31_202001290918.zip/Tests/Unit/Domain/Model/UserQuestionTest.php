<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class UserQuestionTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\UserQuestion
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\UserQuestion();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getUserQuestionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getUserQuestion()
        );

    }

    /**
     * @test
     */
    public function setUserQuestionForStringSetsUserQuestion()
    {
        $this->subject->setUserQuestion('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'userQuestion',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getUserTpQuestionReturnsInitialValueForTpQuestion()
    {
        self::assertEquals(
            null,
            $this->subject->getUserTpQuestion()
        );

    }

    /**
     * @test
     */
    public function setUserTpQuestionForTpQuestionSetsUserTpQuestion()
    {
        $userTpQuestionFixture = new \Mff\MffLsb\Domain\Model\TpQuestion();
        $this->subject->setUserTpQuestion($userTpQuestionFixture);

        self::assertAttributeEquals(
            $userTpQuestionFixture,
            'userTpQuestion',
            $this->subject
        );

    }
}
