<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpQuestionTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\TpQuestion
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\TpQuestion();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getQuestionReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getQuestion()
        );

    }

    /**
     * @test
     */
    public function setQuestionForStringSetsQuestion()
    {
        $this->subject->setQuestion('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'question',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getHideTitleReturnsInitialValueForBool()
    {
        self::assertSame(
            false,
            $this->subject->getHideTitle()
        );

    }

    /**
     * @test
     */
    public function setHideTitleForBoolSetsHideTitle()
    {
        $this->subject->setHideTitle(true);

        self::assertAttributeEquals(
            true,
            'hideTitle',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getQuestionTypeReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setQuestionTypeForIntSetsQuestionType()
    {
    }

    /**
     * @test
     */
    public function getUserCopiesReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setUserCopiesForIntSetsUserCopies()
    {
    }

    /**
     * @test
     */
    public function getAnswersReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getAnswers()
        );

    }

    /**
     * @test
     */
    public function setAnswersForStringSetsAnswers()
    {
        $this->subject->setAnswers('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'answers',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getTpQuestionSubquestionReturnsInitialValueForTpSubquestion()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getTpQuestionSubquestion()
        );

    }

    /**
     * @test
     */
    public function setTpQuestionSubquestionForObjectStorageContainingTpSubquestionSetsTpQuestionSubquestion()
    {
        $tpQuestionSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();
        $objectStorageHoldingExactlyOneTpQuestionSubquestion = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneTpQuestionSubquestion->attach($tpQuestionSubquestion);
        $this->subject->setTpQuestionSubquestion($objectStorageHoldingExactlyOneTpQuestionSubquestion);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneTpQuestionSubquestion,
            'tpQuestionSubquestion',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function addTpQuestionSubquestionToObjectStorageHoldingTpQuestionSubquestion()
    {
        $tpQuestionSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();
        $tpQuestionSubquestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionSubquestionObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($tpQuestionSubquestion));
        $this->inject($this->subject, 'tpQuestionSubquestion', $tpQuestionSubquestionObjectStorageMock);

        $this->subject->addTpQuestionSubquestion($tpQuestionSubquestion);
    }

    /**
     * @test
     */
    public function removeTpQuestionSubquestionFromObjectStorageHoldingTpQuestionSubquestion()
    {
        $tpQuestionSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();
        $tpQuestionSubquestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionSubquestionObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($tpQuestionSubquestion));
        $this->inject($this->subject, 'tpQuestionSubquestion', $tpQuestionSubquestionObjectStorageMock);

        $this->subject->removeTpQuestionSubquestion($tpQuestionSubquestion);

    }
}
