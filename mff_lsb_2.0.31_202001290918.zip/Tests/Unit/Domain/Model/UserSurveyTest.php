<?php
namespace Mff\MffLsb\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class UserSurveyTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Domain\Model\UserSurvey
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Mff\MffLsb\Domain\Model\UserSurvey();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getTemplateNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTemplateName()
        );

    }

    /**
     * @test
     */
    public function setTemplateNameForStringSetsTemplateName()
    {
        $this->subject->setTemplateName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'templateName',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getTemplateXmlReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getTemplateXml()
        );

    }

    /**
     * @test
     */
    public function setTemplateXmlForStringSetsTemplateXml()
    {
        $this->subject->setTemplateXml('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'templateXml',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getCourseNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getCourseName()
        );

    }

    /**
     * @test
     */
    public function setCourseNameForStringSetsCourseName()
    {
        $this->subject->setCourseName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'courseName',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getUserUidReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getUserUid()
        );

    }

    /**
     * @test
     */
    public function setUserUidForStringSetsUserUid()
    {
        $this->subject->setUserUid('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'userUid',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getEnquirerTypeReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setEnquirerTypeForIntSetsEnquirerType()
    {
    }

    /**
     * @test
     */
    public function getEnquirerUidReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getEnquirerUid()
        );

    }

    /**
     * @test
     */
    public function setEnquirerUidForStringSetsEnquirerUid()
    {
        $this->subject->setEnquirerUid('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'enquirerUid',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getEnquirerEmailReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getEnquirerEmail()
        );

    }

    /**
     * @test
     */
    public function setEnquirerEmailForStringSetsEnquirerEmail()
    {
        $this->subject->setEnquirerEmail('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'enquirerEmail',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getEnquirerNameReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getEnquirerName()
        );

    }

    /**
     * @test
     */
    public function setEnquirerNameForStringSetsEnquirerName()
    {
        $this->subject->setEnquirerName('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'enquirerName',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getParticipTypeReturnsInitialValueForInt()
    {
    }

    /**
     * @test
     */
    public function setParticipTypeForIntSetsParticipType()
    {
    }

    /**
     * @test
     */
    public function getParticipCountReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getParticipCount()
        );

    }

    /**
     * @test
     */
    public function setParticipCountForStringSetsParticipCount()
    {
        $this->subject->setParticipCount('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'participCount',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getParticipMailsReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getParticipMails()
        );

    }

    /**
     * @test
     */
    public function setParticipMailsForStringSetsParticipMails()
    {
        $this->subject->setParticipMails('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'participMails',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getSelfAssesmentReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getSelfAssesment()
        );

    }

    /**
     * @test
     */
    public function setSelfAssesmentForStringSetsSelfAssesment()
    {
        $this->subject->setSelfAssesment('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'selfAssesment',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getResponsesUpdatedReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getResponsesUpdated()
        );

    }

    /**
     * @test
     */
    public function setResponsesUpdatedForDateTimeSetsResponsesUpdated()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setResponsesUpdated($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'responsesUpdated',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getResponsesFieldReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getResponsesField()
        );

    }

    /**
     * @test
     */
    public function setResponsesFieldForStringSetsResponsesField()
    {
        $this->subject->setResponsesField('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'responsesField',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getUserTpSurveyReturnsInitialValueForTpSurvey()
    {
        self::assertEquals(
            null,
            $this->subject->getUserTpSurvey()
        );

    }

    /**
     * @test
     */
    public function setUserTpSurveyForTpSurveySetsUserTpSurvey()
    {
        $userTpSurveyFixture = new \Mff\MffLsb\Domain\Model\TpSurvey();
        $this->subject->setUserTpSurvey($userTpSurveyFixture);

        self::assertAttributeEquals(
            $userTpSurveyFixture,
            'userTpSurvey',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function getUserSurveyQuestionReturnsInitialValueForUserQuestion()
    {
        $newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        self::assertEquals(
            $newObjectStorage,
            $this->subject->getUserSurveyQuestion()
        );

    }

    /**
     * @test
     */
    public function setUserSurveyQuestionForObjectStorageContainingUserQuestionSetsUserSurveyQuestion()
    {
        $userSurveyQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();
        $objectStorageHoldingExactlyOneUserSurveyQuestion = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $objectStorageHoldingExactlyOneUserSurveyQuestion->attach($userSurveyQuestion);
        $this->subject->setUserSurveyQuestion($objectStorageHoldingExactlyOneUserSurveyQuestion);

        self::assertAttributeEquals(
            $objectStorageHoldingExactlyOneUserSurveyQuestion,
            'userSurveyQuestion',
            $this->subject
        );

    }

    /**
     * @test
     */
    public function addUserSurveyQuestionToObjectStorageHoldingUserSurveyQuestion()
    {
        $userSurveyQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();
        $userSurveyQuestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['attach'])
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyQuestionObjectStorageMock->expects(self::once())->method('attach')->with(self::equalTo($userSurveyQuestion));
        $this->inject($this->subject, 'userSurveyQuestion', $userSurveyQuestionObjectStorageMock);

        $this->subject->addUserSurveyQuestion($userSurveyQuestion);
    }

    /**
     * @test
     */
    public function removeUserSurveyQuestionFromObjectStorageHoldingUserSurveyQuestion()
    {
        $userSurveyQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();
        $userSurveyQuestionObjectStorageMock = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->setMethods(['detach'])
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyQuestionObjectStorageMock->expects(self::once())->method('detach')->with(self::equalTo($userSurveyQuestion));
        $this->inject($this->subject, 'userSurveyQuestion', $userSurveyQuestionObjectStorageMock);

        $this->subject->removeUserSurveyQuestion($userSurveyQuestion);

    }
}
