<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpGroupControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\TpGroupController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\TpGroupController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllTpGroupsFromRepositoryAndAssignsThemToView()
    {

        $allTpGroups = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $tpGroupRepository->expects(self::once())->method('findAll')->will(self::returnValue($allTpGroups));
        $this->inject($this->subject, 'tpGroupRepository', $tpGroupRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('tpGroups', $allTpGroups);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenTpGroupToTpGroupRepository()
    {
        $tpGroup = new \Mff\MffLsb\Domain\Model\TpGroup();

        $tpGroupRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupRepository->expects(self::once())->method('add')->with($tpGroup);
        $this->inject($this->subject, 'tpGroupRepository', $tpGroupRepository);

        $this->subject->createAction($tpGroup);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenTpGroupToView()
    {
        $tpGroup = new \Mff\MffLsb\Domain\Model\TpGroup();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('tpGroup', $tpGroup);

        $this->subject->editAction($tpGroup);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenTpGroupInTpGroupRepository()
    {
        $tpGroup = new \Mff\MffLsb\Domain\Model\TpGroup();

        $tpGroupRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupRepository->expects(self::once())->method('update')->with($tpGroup);
        $this->inject($this->subject, 'tpGroupRepository', $tpGroupRepository);

        $this->subject->updateAction($tpGroup);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenTpGroupFromTpGroupRepository()
    {
        $tpGroup = new \Mff\MffLsb\Domain\Model\TpGroup();

        $tpGroupRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpGroupRepository->expects(self::once())->method('remove')->with($tpGroup);
        $this->inject($this->subject, 'tpGroupRepository', $tpGroupRepository);

        $this->subject->deleteAction($tpGroup);
    }
}
