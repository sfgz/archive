<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpSubquestionControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\TpSubquestionController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\TpSubquestionController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllTpSubquestionsFromRepositoryAndAssignsThemToView()
    {

        $allTpSubquestions = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $tpSubquestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $tpSubquestionRepository->expects(self::once())->method('findAll')->will(self::returnValue($allTpSubquestions));
        $this->inject($this->subject, 'tpSubquestionRepository', $tpSubquestionRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('tpSubquestions', $allTpSubquestions);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenTpSubquestionToTpSubquestionRepository()
    {
        $tpSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();

        $tpSubquestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSubquestionRepository->expects(self::once())->method('add')->with($tpSubquestion);
        $this->inject($this->subject, 'tpSubquestionRepository', $tpSubquestionRepository);

        $this->subject->createAction($tpSubquestion);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenTpSubquestionToView()
    {
        $tpSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('tpSubquestion', $tpSubquestion);

        $this->subject->editAction($tpSubquestion);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenTpSubquestionInTpSubquestionRepository()
    {
        $tpSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();

        $tpSubquestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSubquestionRepository->expects(self::once())->method('update')->with($tpSubquestion);
        $this->inject($this->subject, 'tpSubquestionRepository', $tpSubquestionRepository);

        $this->subject->updateAction($tpSubquestion);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenTpSubquestionFromTpSubquestionRepository()
    {
        $tpSubquestion = new \Mff\MffLsb\Domain\Model\TpSubquestion();

        $tpSubquestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSubquestionRepository->expects(self::once())->method('remove')->with($tpSubquestion);
        $this->inject($this->subject, 'tpSubquestionRepository', $tpSubquestionRepository);

        $this->subject->deleteAction($tpSubquestion);
    }
}
