<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpQuestionControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\TpQuestionController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\TpQuestionController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllTpQuestionsFromRepositoryAndAssignsThemToView()
    {

        $allTpQuestions = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $tpQuestionRepository->expects(self::once())->method('findAll')->will(self::returnValue($allTpQuestions));
        $this->inject($this->subject, 'tpQuestionRepository', $tpQuestionRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('tpQuestions', $allTpQuestions);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenTpQuestionToTpQuestionRepository()
    {
        $tpQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();

        $tpQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionRepository->expects(self::once())->method('add')->with($tpQuestion);
        $this->inject($this->subject, 'tpQuestionRepository', $tpQuestionRepository);

        $this->subject->createAction($tpQuestion);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenTpQuestionToView()
    {
        $tpQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('tpQuestion', $tpQuestion);

        $this->subject->editAction($tpQuestion);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenTpQuestionInTpQuestionRepository()
    {
        $tpQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();

        $tpQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionRepository->expects(self::once())->method('update')->with($tpQuestion);
        $this->inject($this->subject, 'tpQuestionRepository', $tpQuestionRepository);

        $this->subject->updateAction($tpQuestion);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenTpQuestionFromTpQuestionRepository()
    {
        $tpQuestion = new \Mff\MffLsb\Domain\Model\TpQuestion();

        $tpQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpQuestionRepository->expects(self::once())->method('remove')->with($tpQuestion);
        $this->inject($this->subject, 'tpQuestionRepository', $tpQuestionRepository);

        $this->subject->deleteAction($tpQuestion);
    }
}
