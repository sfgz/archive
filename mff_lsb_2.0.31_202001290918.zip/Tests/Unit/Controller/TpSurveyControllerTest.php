<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class TpSurveyControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\TpSurveyController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\TpSurveyController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllTpSurveysFromRepositoryAndAssignsThemToView()
    {

        $allTpSurveys = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\TpSurveyRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $tpSurveyRepository->expects(self::once())->method('findAll')->will(self::returnValue($allTpSurveys));
        $this->inject($this->subject, 'tpSurveyRepository', $tpSurveyRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('tpSurveys', $allTpSurveys);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenTpSurveyToTpSurveyRepository()
    {
        $tpSurvey = new \Mff\MffLsb\Domain\Model\TpSurvey();

        $tpSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\TpSurveyRepository::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyRepository->expects(self::once())->method('add')->with($tpSurvey);
        $this->inject($this->subject, 'tpSurveyRepository', $tpSurveyRepository);

        $this->subject->createAction($tpSurvey);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenTpSurveyToView()
    {
        $tpSurvey = new \Mff\MffLsb\Domain\Model\TpSurvey();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('tpSurvey', $tpSurvey);

        $this->subject->editAction($tpSurvey);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenTpSurveyInTpSurveyRepository()
    {
        $tpSurvey = new \Mff\MffLsb\Domain\Model\TpSurvey();

        $tpSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\TpSurveyRepository::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyRepository->expects(self::once())->method('update')->with($tpSurvey);
        $this->inject($this->subject, 'tpSurveyRepository', $tpSurveyRepository);

        $this->subject->updateAction($tpSurvey);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenTpSurveyFromTpSurveyRepository()
    {
        $tpSurvey = new \Mff\MffLsb\Domain\Model\TpSurvey();

        $tpSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\TpSurveyRepository::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $tpSurveyRepository->expects(self::once())->method('remove')->with($tpSurvey);
        $this->inject($this->subject, 'tpSurveyRepository', $tpSurveyRepository);

        $this->subject->deleteAction($tpSurvey);
    }
}
