<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class UserSurveyControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\UserSurveyController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\UserSurveyController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllUserSurveysFromRepositoryAndAssignsThemToView()
    {

        $allUserSurveys = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\UserSurveyRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $userSurveyRepository->expects(self::once())->method('findAll')->will(self::returnValue($allUserSurveys));
        $this->inject($this->subject, 'userSurveyRepository', $userSurveyRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('userSurveys', $allUserSurveys);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenUserSurveyToUserSurveyRepository()
    {
        $userSurvey = new \Mff\MffLsb\Domain\Model\UserSurvey();

        $userSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\UserSurveyRepository::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyRepository->expects(self::once())->method('add')->with($userSurvey);
        $this->inject($this->subject, 'userSurveyRepository', $userSurveyRepository);

        $this->subject->createAction($userSurvey);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenUserSurveyToView()
    {
        $userSurvey = new \Mff\MffLsb\Domain\Model\UserSurvey();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('userSurvey', $userSurvey);

        $this->subject->editAction($userSurvey);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenUserSurveyInUserSurveyRepository()
    {
        $userSurvey = new \Mff\MffLsb\Domain\Model\UserSurvey();

        $userSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\UserSurveyRepository::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyRepository->expects(self::once())->method('update')->with($userSurvey);
        $this->inject($this->subject, 'userSurveyRepository', $userSurveyRepository);

        $this->subject->updateAction($userSurvey);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenUserSurveyFromUserSurveyRepository()
    {
        $userSurvey = new \Mff\MffLsb\Domain\Model\UserSurvey();

        $userSurveyRepository = $this->getMockBuilder(\Mff\MffLsb\Domain\Repository\UserSurveyRepository::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $userSurveyRepository->expects(self::once())->method('remove')->with($userSurvey);
        $this->inject($this->subject, 'userSurveyRepository', $userSurveyRepository);

        $this->subject->deleteAction($userSurvey);
    }
}
