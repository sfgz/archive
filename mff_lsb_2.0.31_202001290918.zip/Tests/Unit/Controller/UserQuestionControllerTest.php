<?php
namespace Mff\MffLsb\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Daniel Rueegg <colormixture@verarbeitung.ch>
 */
class UserQuestionControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Mff\MffLsb\Controller\UserQuestionController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Mff\MffLsb\Controller\UserQuestionController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllUserQuestionsFromRepositoryAndAssignsThemToView()
    {

        $allUserQuestions = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $userQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $userQuestionRepository->expects(self::once())->method('findAll')->will(self::returnValue($allUserQuestions));
        $this->inject($this->subject, 'userQuestionRepository', $userQuestionRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('userQuestions', $allUserQuestions);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function createActionAddsTheGivenUserQuestionToUserQuestionRepository()
    {
        $userQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();

        $userQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['add'])
            ->disableOriginalConstructor()
            ->getMock();

        $userQuestionRepository->expects(self::once())->method('add')->with($userQuestion);
        $this->inject($this->subject, 'userQuestionRepository', $userQuestionRepository);

        $this->subject->createAction($userQuestion);
    }

    /**
     * @test
     */
    public function editActionAssignsTheGivenUserQuestionToView()
    {
        $userQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('userQuestion', $userQuestion);

        $this->subject->editAction($userQuestion);
    }

    /**
     * @test
     */
    public function updateActionUpdatesTheGivenUserQuestionInUserQuestionRepository()
    {
        $userQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();

        $userQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['update'])
            ->disableOriginalConstructor()
            ->getMock();

        $userQuestionRepository->expects(self::once())->method('update')->with($userQuestion);
        $this->inject($this->subject, 'userQuestionRepository', $userQuestionRepository);

        $this->subject->updateAction($userQuestion);
    }

    /**
     * @test
     */
    public function deleteActionRemovesTheGivenUserQuestionFromUserQuestionRepository()
    {
        $userQuestion = new \Mff\MffLsb\Domain\Model\UserQuestion();

        $userQuestionRepository = $this->getMockBuilder(\::class)
            ->setMethods(['remove'])
            ->disableOriginalConstructor()
            ->getMock();

        $userQuestionRepository->expects(self::once())->method('remove')->with($userQuestion);
        $this->inject($this->subject, 'userQuestionRepository', $userQuestionRepository);

        $this->subject->deleteAction($userQuestion);
    }
}
