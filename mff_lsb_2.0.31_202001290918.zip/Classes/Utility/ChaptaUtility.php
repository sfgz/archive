<?php
namespace Mff\MffLsb\Utility;

use \DateTime;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/***************************************************************
 *
 * Class ChaptaUtility
 *  Steps:
 *  - display a chapta, store result and accesses with key uid in sssion data
 *  - verify against session data, this returns...
 *  -- 0 if never accessed or error FIXME
 *  -- 1 if continuing is granted
 *  -- TODO higher number on error: amount of errors +1.
 *  - TODO display a time value with the delate seconds if maximum of errors is reached
 *  - TODO display a countdown and reload the page after a specified time
 * 
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

 
class ChaptaUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* sessionKey
	*
	* @var string
	*/
	protected $sessionKey = 'chapta';

	/**
	* encyclop
	*
	* @var array
	*/
	protected $encyclop = [
		'operators' => [ 'minus' , 'plus' ],
		'numbers' => [ 'Null' , 'Fünf' , 'Zehn' , 'Fünfzehn' , 'Zwanzig' , 'Fünfundzwanzig' , 'Dreissig' , 'Fünfunddreissig' , 'Vierzig' , 'Fünfundvierzig' , 'Fünfzig' , 'Fünfundfünfzig' , 'Sechzig' , 'Fünfundsechzig' , 'Siebzig' , 'FünfundSiebzig' , 'Achtzig' , 'FünfundAchzig' ]
	];
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct(  )
	{
			
	}

	/**
	* verifyInput
	*
	* @param int $surveyUid
	* @return int
	*/
	Public function verifyInput( $surveyUid )
	{
			$ergebnis = GeneralUtility::_POST('ergebnis');
			if( $ergebnis === NULL ||  $ergebnis == '' || !is_numeric(trim($ergebnis)) ) return 0; // empty input or first access
			
            $aVariables = $GLOBALS['TSFE']->fe_user->getKey('ses', $this->sessionKey );
            
            if( !isset($aVariables[$surveyUid]['result']) )return 0; // never stored nor accessed but input clicked again?

			$returnCode = 0;

            // successfulll
			if( $aVariables[$surveyUid]['result'] == $ergebnis ) {
                unset($aVariables[$surveyUid]);
                $returnCode = 1;
                
			}elseif( !isset($aVariables[$surveyUid]['errors']) ) {
                // not successfull the first access
                $aVariables[$surveyUid]['errors'] = 1;
                $returnCode = 2;
                
			}else{
                // not successfull repeated time 
                $aVariables[$surveyUid]['errors'] +=1;
                $returnCode = 1 + $aVariables[$surveyUid]['errors'];
			}
			
            $GLOBALS['TSFE']->fe_user->setKey('ses', $this->sessionKey , $aVariables );
            
			return $returnCode;
	}
	

	/**
	* displayChapter
	*
	* @param int $surveyUid
	* @param string $md5remKey
	* @return string
	*/
	Public function displayChapter( $surveyUid , $md5remKey ){
				
				$aVariables = $this->createVariables($surveyUid);

				$form = '<p>';
				$form .= ' Wie viel ergibt ';
				$form .= '' . $this->encyclop['numbers'][$aVariables['basis']/5] . ' ';
				$form .= '' . $this->encyclop['operators'][ $aVariables['functionIndex'] ] . ' ';
				$form .= '' . $this->encyclop['numbers'][$aVariables['einfluss']/5] . '?';
				$form .= '<br />Bitte Resultat als Zahl angeben.';
				$form .= '</p>';

				$form .= $this->getDownloadForm( $surveyUid , $md5remKey );
				$form .= '<p>Diese Massname hindert Roboter <br />am auslösen von Emails.</p>';
				
 				$output = '<div style="text-align:center;margin-left:20px;">' . $form . '</div>';
                return $output;
	
	}
	
	/**
	* getDownloadForm
	*
	* @param int $surveyUid
	* @param string $md5remKey
	* @return string
	*/
	private function getDownloadForm( $surveyUid , $md5remKey )
	{
				$output = '<form name="listSurvey" id="chapta_form" action="/" method="post">';
				
				$output .= '<p>';
				$output .= '<input type="hidden" name="type" value="43" >';
				$output .= '<input type="hidden" name="uid" value="' . $surveyUid . '" >';
				$output .= '<input type="hidden" name="fmt" value="s" >';
				$output .= '<input type="text" name="ergebnis" >';
				$output .= '<input type="hidden" name="remKey" value="' . $md5remKey . '" >';
				$output .= '</p>';

				$output .= '<p>';
				$output .= '<input type="submit" value="PDF senden" class="pdf" onclick="hideAfterUsage();" />';
				$output .= '</p>';
				
				$output .= '</form>';

				// hide form after usage to prevent back action
				$output .= '<script>';
				$output .= 'function hideAfterUsage() { var x = document.getElementById("chapta_form"); if (x.style.display === "none") { x.style.display = "block"; } else {x.style.display = "none"; }}';
				$output .= '</script>';
				
                return $output;
	}

	/**
	* createVariables
	*
	* @param int $surveyUid
	* @return array
	*/
	private function createVariables( $surveyUid )
	{
            $aVariables = [ 'basis' => (mt_rand( 4 , 15 ) * 5), 'functionIndex' => mt_rand( 0 , 1 ) , 'einfluss' => (mt_rand( 1 , 3 ) * 5) ];
            $aVariables['result'] = $aVariables['functionIndex'] ? $aVariables['basis'] + $aVariables['einfluss'] : $aVariables['basis'] - $aVariables['einfluss'] ;
				
            $aOldVariables = $GLOBALS['TSFE']->fe_user->getKey('ses', 'chapta' );
            $increasedError = isset($aOldVariables[$surveyUid]['errors']) ? $aOldVariables[$surveyUid]['errors']+1 : 0;
            $aOldVariables[$surveyUid] = ['result'=>$aVariables['result'] , 'errors'=> $increasedError ];
            $GLOBALS['TSFE']->fe_user->setKey('ses', 'chapta' , $aOldVariables );
			$aVariables['errors'] = $increasedError;
			return $aVariables;
	}
	
}
