<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * Class PdfWriterUtility
 * 
 */

class PdfReportUtility extends PdfUtility {

	/**
	* settings
	*
	* @var array
	*/
	Public $settings = array();

	/**
	* trigger
	*
	* @var array
	*/
	Public $trigger = array( 'page' => false );

	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	Public function __construct( $settings = array() ) {
		$this->settings = $settings;
		parent::__construct();
	}
	
	/**
	 * pdfReport
	 * 
	 * @return array
	 */
	 Protected function renderLayout() {
		// usersurvey only printout
		foreach( $this->data['CONFIG']['layout'] as $parts => $partRow ){
				foreach( $partRow as $pageNr => $page ){
						if( $pageNr == 'data' && !isset($layoutConf[$parts]) ){
								$layoutConf[$parts] =  !empty( $page ) ? $this->data['CONFIG'][$page] : $this->data['CONFIG'];
						}elseif( is_numeric($pageNr) && !isset($sort[$parts]) ) { 
								$sort[$parts] = $pageNr; 
						}
				}
				if( !isset($layoutConf[$parts]) ) $layoutConf[$parts] = $this->data['CONFIG'];
		}
		asort($sort);
		foreach( array_keys($sort) as $parts ){
  				$this->initializePdf( $layoutConf[$parts] );
//   				echo '<hr>';print_r($this->data['CONFIG']['layout'][$parts]);
				foreach( $this->data['CONFIG']['layout'][$parts] as $pageNr => $page ){
						if( !is_array($page) ){ continue; }
						$this->trigger['page'] = true;
						ksort($page);
						foreach( $page as $cNr => $capter ){
								$aAnalyseConf = explode( ':' , $capter);
								$method = 'report' . ucfirst($aAnalyseConf[0]);
								if( $method == 'reportAnalyse' ){
										foreach($this->data['QUESTIONS']['groups'] as $gix=>$group){
												$this->reportAnalyse($group , $aAnalyseConf[1] );
										}
								}elseif( $method == 'reportSpider' ){
										foreach($this->data['QUESTIONS']['groups'] as $gix=>$group){
												$this->reportSpider($group);
										}
								}elseif( method_exists( $this , $method ) ){
										$this->$method();
								}
						}
				}
		}
	}
	
	/**
	 * pdfReport
	 * 
	 * @param array $data
	 * @param string $type
	 * @return array
	 */
	Public function pdfReport(  $data , $type = 'D' ) {
		$this->data = $data;
		if( !count($this->data['QUESTIONS']['groups']) ) return false;

		$this->SetAuthor( ($this->data['QUESTIONS']['survey']['leitungname']) );
		$this->StartPageGroup();
//		$this->initializePdf( $this->data['CONFIG'] );
		$this->renderLayout();
// 		// AUSWERTUNG - report
// 		$this->initializePdf( $this->data['CONFIG'] );
// 		$this->reportSummary();
// 		$aAnalyseConf = explode( ':' , $this->data['CONFIG']['layout']['report'][1][1] );
// 		foreach($this->data['QUESTIONS']['groups'] as $gix=>$group){
// 				if( $group['reportPartials'][1] == 1 ) {
// 					$this->reportAnalyse($group , $aAnalyseConf[1] );
// 				}
// 				if( $group['reportPartials'][4] == 4 ) {
// 					$this->reportSpider($group);
// 				}
// 		}
// 		
// 		// EINZELBEWERTUNG - singles
// 		$this->initializePdf( $this->data['CONFIG']['usersurvey'] );
// 		$this->reportSingles();
		
	    $rawDocumentName = $this->data['CONFIG']['FilenamePrefix'] . $this->data['CONFIG']['FilenameBody'];
	    $downloadFileName = str_replace( $this->data['CONFIG']['FilenameReplacing']['search'] , $this->data['CONFIG']['FilenameReplacing']['replace'] , $rawDocumentName ).'.pdf';
		if( 'D' == $type ) {
				echo $this->Output( urlencode($downloadFileName) , 'D' );
				exit();
		}elseif( 'S' == $type ){
				return $this->Output( urlencode($downloadFileName) , 'S' );
		}
	}
	
	/**
	 * reportSingleSummary
	 * 
	 * @return void
	 */
	 Protected function reportSingleSummary() {
		return $this->reportSummary( true );
	}
	
	/**
	 * reportSummary
	 * 
	 * @param boolean $single
	 * @return void
	 */
	 Protected function reportSummary( $single = false ) {
		$config = $single ? $this->data['CONFIG']['usersurvey'] : $this->data['CONFIG'];
 		$this->HeaderText = $config['HeaderText'] ;
		if( $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}

		if( !empty($config['SummaryTitle']) ) {
				$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
				$this->Cell( 0 , $this->pageConf['lfeed'] , $config['SummaryTitle'] , 'B' , 1 , 'L' );
				$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
				$this->Ln( $this->pageConf['lfeed'] );
		}
		
		$this->replacePatternWithValues();
		
		$aDrawColor = explode( ',' , $this->data['CONFIG']['SummaryLineConf']['color'] );
		$aDash = explode( ',' , $config['SummaryLineConf']['dash'] );
		$this->SetLineWidth( $config['SummaryLineConf']['width'] );
		$this->SetDrawColor($aDrawColor[0],$aDrawColor[1],$aDrawColor[2]);
 		$this->SetDash( $aDash[0] , $aDash[1] );
 		
		$this->reportSummaryRows($config);
		$this->Ln( $this->pageConf['slfeed'] );
		
		$this->setDefaultLineAttributes();
		
		return true;
	}
	
	/**
	 * reportSummary
	 * 
	 * @param array $config its $this->data['CONFIG'] or $this->data['CONFIG']['usersurvey']
	 * @return void
	 */
	 Protected function reportSummaryRows($config) {
			// label width is given by wordlength, max per column in group
			// width of value has to be evaluated: pageWidth - sum( label-widths ) / 100 * $aColWidthInPercent[ $cNr ]
			if( !is_array($config['SummaryRows']) ) return;
			$config['index'] += 0;
			$pageSpace = $this->pageConf['docuwidth'] - ( $this->pageConf['LeftMargin'] + $this->pageConf['RightMargin'] );
			$lineHeight = 1 * $this->pageConf['lfeed'];
			foreach( $config['SummaryRows'] as $cGrp ){
 					if( !is_array($cGrp) ) continue;
 					if( !count($cGrp) ) continue;
					$aColAlign = array();
					$widthConf = $cGrp['width'];
					unset($cGrp['width']);
 					if( is_array($widthConf) ) continue;
					$aColWidth = explode( ',' , $widthConf );
					if( isset($cGrp['align']) ) {
							$alignConf = $cGrp['align'];
							unset($cGrp['align']);
							$aColAlign = explode( ',' , $alignConf );
					}
					$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					foreach( $cGrp as $rNr => $gRow ){
							if( !is_array($gRow) ) continue;
							$fieldsPerRowIndex = 0 ;
							foreach( $gRow as $cNr => $sColumn ){
								// add a tiny line as spacer AFTER each row, except the last row. Therefore we put this here instead of loops-foot
								if($ln) $this->Ln( $this->pageConf['slfeed'] );
								$ln = count($gRow)-1 == $cNr ? 1 : 0;
								if( empty($sColumn) ){
										// draw empty space
										$contentWidth = $aColWidth[$fieldsPerRowIndex];
										if( count($aColAlign) ){
											$cAlign = $aColAlign[$fieldsPerRowIndex] == 'e' ? '' : $aColAlign[$fieldsPerRowIndex] ;
										}else{
											$cAlign = 'L';
										}
										$fieldsPerRowIndex+=1;
										$this->Cell( $contentWidth , $lineHeight , '' , '' , $ln , $cAlign );
								}else{
										$aColSplit = explode( ',' , $sColumn );
										if( count($aColSplit) > 1 ){
												// draw label
												$labelKey = array_shift( $aColSplit );
												$rawValues = implode( ',' , $aColSplit );
												$labelValue = empty($labelKey) ? '' : $this->encode( $this->getLocalLang( $labelKey , 'report.label.' , $config ) );
												$labelWidth = $aColWidth[$fieldsPerRowIndex]-1;
												if( count($aColAlign) ){
													$cAlign = $aColAlign[$fieldsPerRowIndex] == 'e' ? '' : $aColAlign[$fieldsPerRowIndex] ;
												}else{
													$cAlign = 'L';
												}
												$fieldsPerRowIndex+=1;
												$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
												$this->Cell( $labelWidth , $lineHeight , $labelValue . ':' , '' , 0 , $cAlign );
												$this->SetX( $this->GetX() + 1 );
												$contentValue = empty($rawValues) ? '' : str_replace( array_keys($this->data['replacements']) , $this->data['replacements'] , $rawValues );
										}else{
												$contentValue = empty($sColumn) ? '' : str_replace( array_keys($this->data['replacements']) , $this->data['replacements'] , $sColumn );
										}
										// draw cellcontent
										$contentWidth = $aColWidth[$fieldsPerRowIndex];
										if( count($aColAlign) ){
											$cAlign = $aColAlign[$fieldsPerRowIndex] == 'e' ? '' : $aColAlign[$fieldsPerRowIndex] ;
										}else{
											$cAlign = 'L';
										}
										$fieldsPerRowIndex+=1;
										$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
										$this->Cell( $contentWidth , $lineHeight , $contentValue , 'B' , $ln , $cAlign );
								}
// 								if($ln) $this->Ln( round( $this->pageConf['lfeed'] / 2 , 1 ) ); draw this spacer at start of loop
							}
					}
			}
	}
	
	/**
	 * getLocalLang
	 * localLang with optional index
	 * 
	 * @param string $fieldname
	 * @param string $prefix
	 * @param array $config its $this->data['CONFIG'] or $this->data['CONFIG']['usersurvey']
	 * @return string
	 */
	 Protected function getLocalLang( $fieldname , $prefix = 'report.label.' ,$config) {
		$localizedString = LocalizationUtility::translate( $prefix.$fieldname , 'mff_lsb' );
		if( !empty($localizedString) ) return $localizedString;

		$localizedString = LocalizationUtility::translate( $prefix.$fieldname . '.' . $config['index'] , 'mff_lsb' );
		if( !empty($localizedString) ) return $localizedString;
		
		if( isset($this->data['replacements'][ '__' . $fieldname . '__' ]) ) return $this->data['replacements'][ '__' . $fieldname . '__' ];
		
		return $fieldname ;
	}
	
	/**
	 * setDefaultLineAttributes
	 * 
	 * @return void
	 */
	 Protected function setDefaultLineAttributes() {
		$this->SetLineWidth( $this->pageConf['lineSmall'] );
		$this->SetDrawColor(0,0,0);
 		$this->SetDash( 1 , 0 );
	}
	
	/**
	 * reportAnalyse
	 * 
	 * @param array $group
	 * @param string $options optional
	 * @return void
	 */
	 Protected function reportAnalyse( $group , $options = '') { 
		if( $group['reportPartials'][1] != 1 ) return false;
		// (settings->pdf_basics.0.layout.report.1.1 = Analyse:) Matrix,Text-Title,Textarea-Title
		$aReturnContents = array();
		$rawOpts = explode( ',' , $options );
		foreach($rawOpts as $optGrp){
			$aOptPair = explode( '-' , trim($optGrp) );
			$aReturnContents[ucfirst(trim($aOptPair[0])).'_title'] = 1;
			if( count($aOptPair)==1 ){
				$aReturnContents[ucfirst(trim($aOptPair[0]))] = 1;
			}
		}
 		$this->pageConf['cellwidthReportDescription'] = $this->getCellWidthForGroup($group);
 		$this->HeaderText = $this->pageConf['HeaderText'] ;
		$this->SetLineWidth( $this->pageConf['lineSmall'] );

		foreach($group['questions'] as $qix=>$question){
		      if( ( $question['question_type'] == 1 && isset($aReturnContents['Textarea_title']) ) ||
					(is_array($question['subquestions']) && $question['question_type'] == 2 && isset($aReturnContents['Text_title']) )||
					(is_array($question['subquestions']) && $question['question_type'] == 3 && isset($aReturnContents['Matrix']) ) ){
					$thereIsWork = 1;
					break;
		      }
		}
		if( isset($thereIsWork) && $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}
		
		$sumColWidth = $this->getSummaColsCellWidthForGroup($group);
		
		foreach($group['questions'] as $qix=>$question){
		      if( 
					( $question['question_type'] == 1 && isset($aReturnContents['Textarea_title']) ) || 
					( is_array($question['subquestions']) && $question['question_type'] == 2 && isset($aReturnContents['Text_title']) )
		      ){ // TITLE for Textarea AND Text, question as textlabel for textarea (1) and textfields (2)
					if( $this->GetY() > $this->pageConf['dokuHeight'] - ($this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) {
							$this->AddPage();
					}
					$sumwidth = $this->data['CONFIG']['sumtypes'] == 6 ? 2*$this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
					if( isset($aReturnContents['Text']) || isset($aReturnContents['Textarea'])) $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					$this->Cell( $this->pageConf['docuwidth'] - ($sumwidth+$this->pageConf['LeftMargin']+$this->pageConf['RightMargin']) , $this->pageConf['lfeed'] ,  $question['question'] , 'LTBR' , 0 , 'L' );
					$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
					$this->Cell( 0 , $this->pageConf['lfeed'] , 'Anzahl: ' . count($question['responses']) , 'TBR' , 1 , 'L' );
					if( !isset($aReturnContents['Text']) && !isset($aReturnContents['Textarea'])) $this->Ln($this->pageConf['slfeed']);
		      }
		      if( $question['question_type'] == 1 && isset($aReturnContents['Textarea']) ){ // Textarea
					$x = $this->GetX();
					$multiCellWidth = $this->pageConf['cellwidthReportDescription'] + $sumColWidth;
					if( count($question['responses']) ){
						$nrWidth = round( $this->GetStringWidth('Nr. 99' ) , 1 ) + 2;
						foreach($question['responses'] as $resNum=>$resText){
							$this->Cell( $nrWidth , $this->pageConf['lfeed'] , 'Nr. ' . $resNum , 'T' , 0 , 'L' );
							$this->SetFont( 'courier' , '' , $this->pageConf['fsize'] );
							$this->MultiCell( $multiCellWidth - $nrWidth , $this->pageConf['lfeed'] , $resText , 'T' ,  'L' );
							$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
							$this->Ln( $this->pageConf['lfeed'] );
						}
					}
					$this->Ln( $this->pageConf['lfeed'] );
					continue;
		      }
			  if( !is_array($question['subquestions']) ) continue;
		      if( $question['question_type'] == 2 && isset($aReturnContents['Text']) ){
					$this->SetLineWidth(0.15);
					$this->SetDrawColor(0,0,0);
					$this->SetDash( 0.05 , 0.95 );
					$labelWidth = 0;
					foreach($question['subquestions'] as $code => $docuSubquest){
						$wdt = $this->GetStringWidth( $docuSubquest['question'] );
						if( $wdt > $labelWidth ) $labelWidth = $wdt;
					}
					$labelWidth += 2;
					if(is_array($question['responses'])){
							foreach($question['responses'] as $rix => $responsetext){
								$indexString = 'Nr. ' . $rix;
								$indexWidth = 2 + $this->GetStringWidth( $indexString );
								$posX = $indexWidth + $this->GetX();
								$this->Cell( 0 , floor($this->pageConf['lfeed']/2) , '' , '' , 1 , 'L' );
								$this->Cell( $indexWidth , $this->pageConf['lfeed'] , $indexString , '' , 0 , 'L' );
								foreach($question['subquestions'] as $code => $docuSubquest){
									$this->SetX( $posX );
									$this->Cell( $labelWidth , $this->pageConf['lfeed'] , $docuSubquest['question'] , '' , 0 , 'L' );
									$this->SetFont( 'courier' , '' , $this->pageConf['fsize'] );
									$this->Cell( 0 , $this->pageConf['lfeed'] ,$question['responses'][$rix][$code], 'B' , 1 , 'L' );
									$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
								}
							}
					}
					$this->setDefaultLineAttributes();
//					$this->Ln( $this->pageConf['lfeed'] );$this->Ln( $this->pageConf['slfeed'] );
		      }elseif( $question['question_type'] == 3 && isset($aReturnContents['Matrix']) ){
		      
					$showSummaryFooter = $this->reportAnalyse_matrixBody( $group , $question );
					if( empty($showSummaryFooter) ) continue;
					
					// summas-rows
					$this->SetFont( $this->pageConf['fontfamily'] , 'I' , $this->pageConf['fsize'] );
					$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , 'Summen' , 'LBR' , 0 , 'L' );
					
					$responseSummas = $group['report_hide_header'] ? $group['groups']['sums']['responses'] : $question['responses'];
					if(is_array($responseSummas)){
							foreach($responseSummas as $resNum=>$numCount){
								$this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , $numCount , 'RTB' , 0 , 'C' );
							}
					}

					// optional summas-rows-collummns
					$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					if( $this->data['CONFIG']['sumtypes'] == 6 ){ 
							$this->Cell( $this->pageConf['cellwidthSumma']+4 , $this->pageConf['lfeed'] , $question['response_prc'].'%' , 'LB' , 0 , 'C'  );
							$this->Cell( $this->pageConf['cellwidthSumma']-4 , $this->pageConf['lfeed'] , round($question['response_note'],1) , 'BR' , 0 , 'C'  );
					}elseif( $this->data['CONFIG']['sumtypes'] >=2 ){
							$txtArr = array( 2=>$question['response_prc'].'%' , 4=>round($question['response_note'],1) );
							$this->Cell( $this->pageConf['cellwidthSummas'] , $this->pageConf['lfeed'] , $txtArr[$this->data['CONFIG']['sumtypes']] , 'LBR' , 0 , 'C' );
					}
					$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
					
					$this->Ln( $this->pageConf['lfeed'] + $this->pageConf['slfeed'] );
			  }
		}
		return true;
	}

	/**
	 * reportAnalyse_matrixBody
	 * in printout-mode this returns only question-type matrix (3)
	 * 
	 * @param array $group
	 * @param array $question
	 * @return boolean
	 */
	 Protected function reportAnalyse_matrixBody( $group , $question ) {
			$showSummaryFooter = 1;
			if(  is_array($question['originassessments']) && ( empty($group['report_hide_header']) || $question['type_index'] == 1 ) ){
					if($group['report_header_vertical']){
							$this->report_verticalHead($question , $group['report_hide_header'] );
					}else{
							$this->report_horizontalHead( $question , $group['report_hide_header'] );
					}
					$this->Ln( $this->pageConf['lfeed'] );
			}

			$iterator = 0;
			foreach($question['subquestions'] as $sqix=>$subquestion){
				$titleOfQuestion = (!$group['report_hide_header'] || $iterator) ? '' : $question['question'];
				if( $this->GetY() > $this->pageConf['dokuHeight'] - ($this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) { $this->AddPage(); }
				$this->reportAnalyse_subquestions( $subquestion , $titleOfQuestion );
				++$iterator;
			}
			
			// only draw footer-row if last question in type-group
			if( $group['report_hide_header'] && $question['type_index'] != $question['type_maxindex'] ) $showSummaryFooter = 0;
			if( empty($showSummaryFooter) ) return false;
			
			// only draw footer-row if more than 1 subquestion
			if( $iterator < 2 ) {
					$this->Ln( $this->pageConf['lfeed'] );
						return false;
			}
			return $showSummaryFooter;
	}
	
	/**
	 * reportAnalyse_subquestions
	 * 
	 * @param array $subquestion
	 * @param string $question
	 * @return void
	 */
	 Protected function reportAnalyse_subquestions( $subquestion , $question='' ) {
		if($question){
		      // evaluate whether a pagebreak is affored or not
		      $objHeight = $this->pageConf['lfeed']; // question
		      $objHeight += $this->pageConf['lfeed']; // first subquestion
		      $objHeight += $this->pageConf['BottomMargin']; // margin
		      $objHeight += 2*$this->pageConf['lfeed']; // footer
		      $maxYPosToStart = $this->pageConf['dokuHeight'] - $objHeight;
		      if( $this->GetY() > $maxYPosToStart ) $this->AddPage();
		}
		
		$x = $this->GetX();
		$y = $this->GetY();
		// Description / Question
		if($question){
		      $this->setXY( $x , $y+0.4 );
		      $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		      $this->Write( $this->pageConf['lfeed'] , $question );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		      $this->setXY( $x , $y);
		      $drawQuestion = "\n" . $subquestion['question'];
		}else{
		      $drawQuestion = $subquestion['question'];
		}
		$this->MultiCell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $drawQuestion , 'LTBR' , 'L' );
		$x2 = $this->GetX();
		$y2 = $this->GetY();
		// if multicell caused a page-break, adjust y2
		if( $y2 < $y ) $y = $this->TopY;
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y );
		$cellheight = $y2-$y;
		
		foreach($subquestion['responses'] as $resNum=>$numCount){
		    $this->Cell( $this->pageConf['cellwidthPoints'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LTR' , 0  ); // spacer above values
		}
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y2 -$this->pageConf['lfeed'] );
		
		// assessment-points collummns
		foreach($subquestion['responses'] as $resNum=>$numCount){
		    $this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , $numCount , 'LBR' , 0 , 'C' );
		}

		// optional summas collummns
		if( $this->data['CONFIG']['sumtypes'] == 6 ){
		    // summas-collummns
		    $x3 = $this->GetX();
		    
		    // top Border for high-misured summas-collummns
		    $this->setXY( $x3 , $y );
		    $this->Cell( $this->pageConf['cellwidthSumma']+4 , $y2-$y-$this->pageConf['lfeed'] , '' , 'LT' , 0  );
		    $this->Cell( $this->pageConf['cellwidthSumma']-4 , $y2-$y-$this->pageConf['lfeed'] , '' , 'RT' , 0  );
		    
		    $this->setXY( $x3 , $y2 - $this->pageConf['lfeed'] );
		    $this->Cell( $this->pageConf['cellwidthSumma']+4 , $this->pageConf['lfeed'] , $subquestion['response_prc'].'%' , 'LB' , 0 , 'C'  );
		    $this->Cell( $this->pageConf['cellwidthSumma']-4 , $this->pageConf['lfeed'] , round($subquestion['response_note'],1) , 'RB' , 0 , 'C'  );
		    
		}elseif( $this->data['CONFIG']['sumtypes'] >=2 ){
		    // summa-collummn
		    $txtArr = array( 2=>$subquestion['response_prc'].'%' , 4=>round($subquestion['response_note'],1) );
		    $x3 = $this->GetX();
		    
		    $this->setXY( $x3 , $y );
		    $this->Cell( $this->pageConf['cellwidthSummas'] , $this->pageConf['lfeed'] , $txtArr[ $this->data['CONFIG']['sumtypes'] ] , 'LR' , 0 , 'C'  );

		    // bottom Border for high summa-collummn
		    $this->setXY( $x3 , $y + $this->pageConf['lfeed'] );
		    $this->Cell( $this->pageConf['cellwidthSummas'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LBR' , 0  );
		    
		}
		$this->setXY( $x , $y2 );
	}
	
	/**
	 * report_horizontalHead
	 * 
	 * @param array $question
	 * @param boolean $hideLabel
	 * @param boolean $hideSumRowTitle
	 * @return void
	 */
	 Protected function report_horizontalHead( $question , $hideLabel = 0 , $hideSumRowTitle = false ) {
		$x0 = $this->GetX();
		$assWidth = $this->pageConf['cellwidthPoints'] * count($question['originassessments']);
		$sumWidth = $this->data['CONFIG']['sumtypes'] >= 6 ? 2 * $this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
		$breakLine = $this->data['CONFIG']['sumtypes'] == 1 ? 1 : 2;
		
		// evaluate whether a pagebreak is affored or not
		$objHeight = $hideSumRowTitle ? 0 : $this->pageConf['lfeed']; // label over all responses
		$objHeight += $this->pageConf['lfeed']; // label for each response
		$objHeight += $this->pageConf['lfeed']; // first subquestion
		$objHeight += $this->pageConf['lfeed']; // total-row, empty row or second subquestion
		$objHeight += $this->pageConf['BottomMargin']; // margin
		$objHeight += 2*$this->pageConf['lfeed']; // footer
		$maxYPosToStart = $this->pageConf['dokuHeight'] - $objHeight;
		if( $this->GetY() > $maxYPosToStart ) { $this->AddPage(); }//else{ $this->Ln($this->pageConf['lfeed']); }
		
		if($this->pageConf['matrixTitle']){
				$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
				$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $this->pageConf['matrixTitle'] , 'B' , 0 , 'L' );
				$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
				$this->pageConf['matrixTitle'] = '';
		}
		
		// Label for points-collummns
		if( !$hideSumRowTitle ){
				$this->Ln($this->pageConf['lfeed']);
				$this->SetXY( $x0 + $this->pageConf['cellwidthReportDescription'] , $this->GetY()- $this->pageConf['lfeed'] );
				$this->Cell( $assWidth , $this->pageConf['lfeed'] , 'Anzahl Antworten' , 'TLR' , $breakLine , 'C' );
		}
		
		// Question-Title
		$titleValue = $hideLabel ? '' : $question['question'];
		$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		$this->SetX( $x0  );
		if( !empty($titleValue) ) {
				$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $titleValue , 'LTBR' , 0 , 'L' );
		}else{
				$this->SetX( $x0 + $this->pageConf['cellwidthReportDescription'] );
		}
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		
		// Labels for Answer-Options
		foreach($question['originassessments'] as $assIx=>$origAss){
		      $this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , $origAss['answer'] , 'TBR' , 0 , 'C');
		}
		
		// Label for summas-collummns
		if( $this->data['CONFIG']['sumtypes'] >=2 ){ // Prozent | Note | Summen
		      $this->SetFont( $this->pageConf['fontfamily'] , 'I' , $this->pageConf['fsize'] );
		      $txtArr = $this->data['QUESTIONS']['survey']['settings']['summaColumnLabels'];
		      $this->Cell( $sumWidth , $this->pageConf['lfeed'] , $txtArr[$this->data['CONFIG']['sumtypes']] , '1' , 0 , 'C' );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		}
		$this->SetX( $x0  );
	}
	
	/**
	 * report_verticalHead
	 * 
	 * @param array $question
	 * @param boolean $hideLabel
	 * @param boolean $hideSumRowTitle
	 * @return void
	 */
	 Protected function report_verticalHead( $question , $hideLabel = false , $hideSumRowTitle = false ) {
		$padding = array( 'left'=>1 , 'right'=>1.5 );
		$sumWidth = $this->data['CONFIG']['sumtypes'] >= 6 ? 2 * $this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
		$breakLine = $this->data['CONFIG']['sumtypes'] == 1 ? 1 : 0;
		
		$oAss = $this->verticalHead_getMaxWordlength($question['originassessments']);
		$strWdth = $padding['left'] + $padding['right'] + $oAss['maxWordlength'];
		
		// evaluate whether a pagebreak is affored or not
//		$objHeight = $hideSumRowTitle ? 0 : $this->pageConf['lfeed']; // label over all responses
		$objHeight = $this->pageConf['lfeed']; // label over all responses
		$objHeight += $strWdth; // label for each response
		$objHeight += $this->pageConf['lfeed']; // first subquestion
		$objHeight += $this->pageConf['lfeed']; // total-row, empty row or second subquestion
		$objHeight += $this->pageConf['BottomMargin']; // margin
		$objHeight += 2*$this->pageConf['lfeed']; // footer
		$maxYPosToStart = $this->pageConf['dokuHeight'] - $objHeight;
		if( $this->GetY() > $maxYPosToStart ) $this->AddPage();

		$x0 = $this->GetX();
		$y0 = $this->GetY();

		if($this->pageConf['matrixTitle']){
				$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
				$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $this->pageConf['matrixTitle'] , 'B' , 0 , 'L' );
				$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
				$this->pageConf['matrixTitle'] = '';
		}
		// Label for points-collummns
		if( !$hideSumRowTitle ){
		      $this->SetX( $x0+$this->pageConf['cellwidthReportDescription'] );
		      $this->Cell( $this->pageConf['cellwidthPoints'] * count($oAss['aQuestWords']) , $this->pageConf['lfeed'] , 'Anzahl Antworten' , 'TLR' , $breakLine , 'C' );
		}else{
		      if($breakLine){
			  $this->Ln($this->pageConf['lfeed']);
		      }else{
			  $this->SetX( ($x0+$this->pageConf['cellwidthReportDescription']) + ($this->pageConf['cellwidthPoints'] * count($oAss['aQuestWords'])) );
		      }
		}
		
		// Label for summas-collummns
		if( $this->data['CONFIG']['sumtypes'] >=2 ){
		     // $txtArr = array( 2=>'Erreicht' , 4=>'Note' , 6=>'Erreicht / Note' );
		      $txtArr = $this->data['QUESTIONS']['survey']['settings']['summaColumnLabels'];
		      $sx = $this->GetX();
		      $sy = $this->GetY();
 		      $this->SetXY( $sx, $sy + $strWdth );
		      $this->SetFont( $this->pageConf['fontfamily'] , 'I' , $this->pageConf['fsize'] );
		      $this->Cell( $sumWidth , $this->pageConf['lfeed'] , $txtArr[$this->data['CONFIG']['sumtypes']] , '1' , 0 , 'C' );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		}
		
		// Question-Title
		$titleValue = $hideLabel ? '' : $question['question'];
		$y = $y0 + $strWdth + $this->pageConf['lfeed'];
		$this->SetY( $y - $this->pageConf['lfeed'] );
		$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		if( !empty($titleValue) ) {
				$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $titleValue , 'LTBR' , 0 , 'L' );
		}else{
				$this->SetX( $x0 + $this->pageConf['cellwidthReportDescription'] );
		}
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );

		// Labels for Answer-Options
		$x = $this->GetX();
// 			    $this->Line( $x0 , $y0 , $x0  , $y );
// 			    $this->Line( $x0 , $y0 , $x  , $y0 );
		foreach($question['originassessments'] as $assIx=>$origAss){
		      $this->Line( $x , $y , $x  , $y-$strWdth );
		      $this->Line( $x , $y-$strWdth , $x + $this->pageConf['cellwidthPoints']  , $y-$strWdth );
		      $this->Line( $x , $y , $x + $this->pageConf['cellwidthPoints']  , $y );
		      if( count($oAss['aQuestWords'][$assIx]) != 2 ){
			    $this->RotatedText( $x + 5 , $y - $padding['left'] , $origAss['answer'] , 90 );
		      }else{
			    foreach( $oAss['aQuestWords'][$assIx] as $i => $word ) {
				$this->RotatedText( $x + 3.5 + ($i*3) , $y - $padding['left'] , $word , 90 );
			    }
		      }
		      $x += $this->pageConf['cellwidthPoints'];
		}
		$this->Line( $x , $y , $x  , $y-$strWdth );
	}
	
	/**
	 * verticalHead_getMaxWordlength
	 * 
	 * @param array $aOriginassessments
	 * @return array
	 */
	 Protected function verticalHead_getMaxWordlength( $aOriginassessments ) {
	      $wordlength = array();
	      foreach($aOriginassessments as $assIx=>$origAss){
		    $aQuestWords[$assIx] = $this->verticalHead_splitSentenceInTwoParts( $origAss['answer'] );
		    foreach( $aQuestWords[$assIx] as $i => $word ) { $wordlength[] = $this->GetStringWidth($word); }
	      }
	      return array( 'aQuestWords' => $aQuestWords  , 'maxWordlength' => max($wordlength) );
	}
	
	/**
	 * reportAnalyse
	 * 
	 * @param string $sentence
	 * @return array
	 */
	 Protected function verticalHead_splitSentenceInTwoParts( $sentence ) {
	      $trmSent = trim($sentence);
	      $firstPos = strpos( $trmSent , ' ' );
	      if( !$firstPos ) return array( $trmSent );
	      $strLngth = strlen($trmSent);
	      // loop thru blank-spaces and evaluate smallest Differnence
	      $oldDiff = $strLngth;
	      for( $x = 0 ; $x < $strLngth ; ++$x ){
		    if( ' ' != substr( $trmSent , $x , 1 ) ) continue;
		    $iDiff = $strLngth - ( 2 * $x );
		    $diff = sqrt( $iDiff  * $iDiff );
		    if( $diff <= $oldDiff ) {
			  $oldDiff = $diff;
		    } else {
			  $oldX = ( $strLngth - $oldDiff ) / 2;
			  $str1 = substr( $trmSent , 0 , $oldX );
			  $str2 = substr( $trmSent , $oldX + 1 );
			  return array( $str1 , $str2 );
		    }
	      }
	      $str1 = substr( $trmSent , 0 , $firstPos );
	      $str2 = substr( $trmSent , $firstPos + 1 );
	      return array( $str1 , $str2 );
	}
	
	/**
	 * reportSpider
	 * 
	 * @return void
	 */
	 Protected function reportSpider($group) {
		if( !is_array($group['spider']) ) return;
		if( !is_array($group['spider']['rays']) ) return;
		if( $group['reportPartials'][4] != 4 ) return;
		
		$xOffset = 25;
		$addToRadius = 12;
		$pageWidth = 160;//$this->pageConf['docuwidth'] - ($this->pageConf['LeftMargin'] + $this->pageConf['RightMargin']);
		
		$origHeaderText = $this->HeaderText;
		$this->HeaderText .= ' Spider';
		if( $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}
		$this->HeaderText = $origHeaderText;
		
		$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		$this->Cell( 0 , $this->pageConf['lfeed'] , $group['group_name'] , 'B' , 1 , 'L' );
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		
		$this->Ln( $this->pageConf['lfeed'] );
		$this->Cell( 0 , $this->pageConf['lfeed'] , 'Blau: Selbstbewertung' , 0 , 1 , 'L' );
		$yOffest = $this->GetY() + 2*$this->pageConf['lfeed'];
		
		// draw scale
		if( $this->data['CONFIG']['sumtypes'] == 2 || $this->data['CONFIG']['sumtypes'] == 6 ){
		      $scale = '&sc=1';
		}else{
		      $scale = '&sc=0';
		}
		
		$pxWidth = 2*$addToRadius + $group['spider']['dim']['w'];
		$pxToCm = $pageWidth / $pxWidth ;
		
		$image = $this->settings['baseUrl'].'typo3conf/ext/mff_lsb/Resources/Public/PHP/spiderimage.php?r='.$group['spider']['dim']['x'].'&v='.$group['spider']['responses'].'&v2='.$group['spider']['selfassessment'].$scale;
		$this->Image( $image , $xOffset+5 , $yOffest , $pageWidth , 0 , 'PNG' );
		
		foreach($group['spider']['rays'] as $qix=>$question){
		      $this->SetXY( $question['x']*$pxToCm+$xOffset , $question['y']*$pxToCm+$yOffest );
		      $this->Cell( $this->GetStringWidth($question['question']) , $this->pageConf['lfeed'] , $question['question'] , '' , 1 , 'C' );
		      // show scale and percentage
		      if( $this->data['CONFIG']['sumtypes'] == 2 || $this->data['CONFIG']['sumtypes'] == 6 ){
			    $this->SetX( $question['x']*$pxToCm+$xOffset );
			    $this->Cell( $this->GetStringWidth($question['question']) , $this->pageConf['lfeed'] , $question['response_prc'] . '%' , '' , 0 , 'C' );
		      }
		}
		// set carriage X to zero with a linebreak
		$this->Ln( 0 );
		
	}

	/**
	 * reportFooter
	 * 
	 * @param boolean $short
	 * @return void
	 */
	 Public function reportFooter() {
		if( !count($this->data['CONFIG']['ReportFooter']) ) return;
		$cnf = $this->data['CONFIG']['ReportFooter'];
		
		if( $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}
		
		$spaceToUse = $this->pageConf['dokuHeight'] - ($this->pageConf['BottomMargin'] + $this->getY() );
		$lines = floor( $spaceToUse / $this->pageConf['lfeed'] );
		$lines -= count($cnf['rows']) ;
 		$lines -= 2; // title + space at end
		
		if( $lines > $cnf['lines_max'] ) {
				$lines = $cnf['lines_max'];
		}elseif( $lines < $cnf['lines_min'] ) {
				$lines = $cnf['lines_max']; 
				$this->addPage();
		}
		
		$width = $this->pageConf['docuwidth'] - ( $this->pageConf['LeftMargin'] + $this->pageConf['RightMargin'] ) ;
		$stegweite = 5;
		$colCount = count($cnf['cols']) ;
		$alleStege = $colCount > 1 ? ( $colCount - 1 ) * $stegweite : 0;
		$halfwidth = $colCount > 1 ? floor( ( $width-$alleStege ) / $colCount ) : $width;
		$stegweite = ( $width - ($colCount * $halfwidth) ) / ( $colCount - 1 );
		
		$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		
		foreach( $cnf['cols'] as $col )	$cols[] = $col;
		
		foreach( $cnf['cols'] as $i => $col ){
				if( $i+1 < $colCount ){
						$this->Cell( $halfwidth , $this->pageConf['lfeed'] , $col['title'] , 'B' , 0  );
						$this->SetX( $this->GetX() + $stegweite );
				}else{
						$this->Cell( $halfwidth , $this->pageConf['lfeed'] , $col['title'] , 'B' , 1  );
				}
		}
// 		$this->Cell( $halfwidth , $this->pageConf['lfeed'] , 'B Analyse' , 'B' , 0  );
// 		$this->Cell( $stegweite , $this->pageConf['lfeed'] , '' , '' , 0  );
// 		$this->Cell( $halfwidth , $this->pageConf['lfeed'] , 'C Interpretation' , 'B' , 1  );

		$aDrawColor = explode( ',' , $cnf['line_conf']['color'] );
		$aDash = explode( ',' , $cnf['line_conf']['dash'] );
		$this->SetLineWidth( $cnf['line_conf']['width'] );
		$this->SetDrawColor($aDrawColor[0],$aDrawColor[1],$aDrawColor[2]);
 		$this->SetDash( $aDash[0] , $aDash[1] );
		for( $line = 0 ; $line < $lines ; ++$line ){
// 				$this->Cell( $halfwidth , $this->pageConf['lfeed'] , '' , 'B' , 0  );
// 				$this->Cell( $stegweite , $this->pageConf['lfeed'] , '' , '' , 0  );
// 				$this->Cell( $halfwidth , $this->pageConf['lfeed'] , '' , 'B' , 1  );
				foreach( $cnf['cols'] as $i => $col ){
						if( $i+1 < $colCount ){
								$this->Cell( $halfwidth , $this->pageConf['lfeed'] , '' , 'B' , 0  );
								$this->SetX( $this->GetX() + $stegweite );
						}else{
								$this->Cell( $halfwidth , $this->pageConf['lfeed'] , '' , 'B' , 1  );
						}
				}
		}
		$this->setDefaultLineAttributes();
		$this->Ln( $this->pageConf['lfeed'] );
		
		$this->SetFont( $this->pageConf['fontfamily'] , 'IB' , $cnf['fsize']  );
		foreach( $cnf['rows'] as $textrow){
				$this->Cell( 0 , $this->pageConf['lfeed'] , $textrow , '' , 1 );
		}
		$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		$this->Ln( $this->pageConf['lfeed'] );
	}
	
	/**
	 * reportSingles
	 * 
	 * @return void
	 */
	 Protected function reportSingles() {
		$sumtypes = $this->data['CONFIG']['sumtypes'];
		$this->data['CONFIG']['sumtypes'] = 1; // no summary-columns
		
		if( !is_array($this->data['QUESTIONS']['singles']) )return;
		if( !count($this->data['QUESTIONS']['singles']) )return;
		
		foreach($this->data['QUESTIONS']['groups'] as $gix=>$group){
		      $cellwidthReportDescription[$gix] = $this->getCellWidthForGroup($group);
		};
		
		if( $this->trigger['page'] ){
			$followpage = 1;
			$this->trigger['page'] = false;
		}else{ 
			$followpage = 0;
		}
		
		foreach($this->data['QUESTIONS']['singles'] as $docuIx => $answerDocu){
			if($followpage) $this->AddPage();
			$followpage = 1;
			$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
			$this->Cell( 0 , $this->pageConf['lfeed'] , 'Einzelbewertung Nr. ' . $docuIx , 'B' , 1 , 'L' );
			$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
			foreach($answerDocu as $gix => $docuGroup){
			    if( $this->data['QUESTIONS']['groups'][$gix]['reportPartials'][2] != 2 ) continue;
 				$this->pageConf['cellwidthReportDescription'] = $cellwidthReportDescription[$gix];
			    $sumColWidth = $this->pageConf['cellwidthReportDescription'] + $this->getSummaColsCellWidthForGroup( $this->data['QUESTIONS']['groups'][$gix] );
			    foreach($docuGroup['questions'] as $qix => $docuQuest){
					$originalQuestion = $this->data['QUESTIONS']['groups'][$gix]['questions'][ $qix ];
					if( $docuQuest['question_type'] == 3 ){
						if( !is_array($docuQuest['subquestions']) ) continue;
						if( 
						empty($docuGroup['group']['report_hide_header']) || $originalQuestion['type_index'] == 1
						){
							if( $docuGroup['group']['report_header_vertical'] ){
							$this->report_verticalHead( $docuQuest , $docuGroup['group']['report_hide_header'] , true );
							}else{
							$this->report_horizontalHead( $docuQuest , $docuGroup['group']['report_hide_header'] , true );
							}
							$this->Ln( $this->pageConf['lfeed'] );
						}
						if( $docuGroup['group']['report_hide_header'] ){
							$drawQuestion = $docuQuest['question'] ;
						}else{
							$drawQuestion = '';
						}
						$iterator = 0;
						foreach($docuQuest['subquestions'] as $code => $docuSubquest){
							$titleOfQuestion = $iterator ? '' : $drawQuestion;
							$this->reportSingle_subquestions( $docuSubquest , $titleOfQuestion );
							++$iterator;
						}
						
					}elseif( $docuQuest['question_type'] == 2 ){ // text field
						if( !is_array($docuQuest['subquestions']) ) continue;
						$this->Ln($this->pageConf['lfeed']);
						$this->SetLineWidth(0.15);
						$this->SetDrawColor(0,0,0);
						$this->SetDash( 0.05 , 0.95 );
						$this->Cell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['question'] , '' , 1 , 'L' );
						$labelWidth = 0;
						foreach($docuQuest['subquestions'] as $code => $docuSubquest){
							$wdt = $this->GetStringWidth( $docuSubquest['question'] );
							if( $wdt > $labelWidth ) $labelWidth = $wdt;
						}
						$labelWidth += 2;
						foreach($docuQuest['subquestions'] as $code => $docuSubquest){
							$this->Cell( $labelWidth , $this->pageConf['lfeed'] , $docuSubquest['question'] , '' , 0 , 'L' );
							$this->Cell( $sumColWidth-$labelWidth , $this->pageConf['lfeed'] ,$docuSubquest['response'], 'B' , 1 , 'L' );
						}
						$this->Ln( $this->pageConf['lfeed'] );
						$this->setDefaultLineAttributes();
				  
					}elseif( $docuQuest['question_type'] == 1 ){ // textarea
						if( $this->GetY() > $this->pageConf['dokuHeight'] - (3*$this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) {
							$this->AddPage();
						}else{
							$this->Ln($this->pageConf['lfeed']);
						}
						$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
						$this->Cell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['question'] , '' , 1 , 'L' );
						$this->SetFont( 'courier' , '' , $this->pageConf['fsize'] );
						$this->MultiCell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['response'] , 'B' ,  'L' );
						$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
						$this->Ln($this->pageConf['lfeed']);
					}else{ // labeltext
						$this->Ln($this->pageConf['lfeed']);
						$this->Cell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['question'] , '' , 1 , 'L' );
					}
			    }
			}
		}
		$this->data['CONFIG']['sumtypes'] = $sumtypes;
	}
	
	/**
	 * reportSingle_subquestions
	 * 
	 * @param array $subquestion
	 * @param string $question
	 * @return void
	 */
	 Protected function reportSingle_subquestions($subquestion,$question='') {
		if($question){
		      // evaluate whether a pagebreak is affored or not
		      $objHeight = $this->pageConf['lfeed']; // question
		      $objHeight += $this->pageConf['lfeed']; // first subquestion
		      $objHeight += $this->pageConf['BottomMargin']; // margin
		      $objHeight += 2*$this->pageConf['lfeed']; // footer
		      $maxYPosToStart = $this->pageConf['dokuHeight'] - $objHeight;
		      if( $this->GetY() > $maxYPosToStart ) $this->AddPage();
		}
		
		$x = $this->GetX();
		$y = $this->GetY();
		// Description / Question
		if($question){
		      $this->setXY( $x , $y+0.4 );
		      $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		      $this->Write( $this->pageConf['lfeed'] , $question );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		      $this->setXY( $x , $y);
		      $drawQuestion = "\n" . $subquestion['question'];
		}else{
		      $drawQuestion = $subquestion['question'];
		}
		$this->MultiCell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $drawQuestion , 'LTBR' , 'L' );
		$y2 = $this->GetY();
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y );
		// assessment-points collummns
		if( count($subquestion['responses']) ){
		
		      // top Border for high assessment-points collummns
		      foreach($subquestion['responses'] as $resNum=>$numCount){
			  $this->Cell( $this->pageConf['cellwidthPoints'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LTR' , 0  );
		      }
		      $this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y2-$this->pageConf['lfeed'] );
		      
		      // data-rows
		      foreach($subquestion['responses'] as $ix=>$val){
			    $this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , $val , 'LBR' , 0 , 'C' );
		      }
		      
		      // bottom Border for high assessment-points collummns
// 		      $this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y + $this->pageConf['lfeed'] );
// 		      foreach($subquestion['responses'] as $resNum=>$numCount){
// 			  $this->Cell( $this->pageConf['cellwidthPoints'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LBR' , 0  );
// 		      }
		      
		}
		$this->setXY( $x , $y2 );
	}
	
	/**
	 * getCellWidthForGroup
	 * 
	 * @param array $group
	 * @return void
	 */
	 Protected function getCellWidthForGroup( $group ) {
		$maxSumWidth = $this->getSummaColsCellWidthForGroup($group);
		return $this->pageConf['docuwidth'] - ($this->pageConf['LeftMargin']+$this->pageConf['RightMargin']+$maxSumWidth) ;
	}
	
	/**
	 * getSummaColsCellWidthForGroup
	 * 
	 * @param array $group
	 * @return void
	 */
	 Protected function getSummaColsCellWidthForGroup( $group ) {
		$sumColWidth = array();
		foreach($group['questions'] as $qix=>$question){
		      if( !is_array($question['originassessments']) || $question['question_type'] != 3 ) continue;
		      $sumColWidth[$qix] = $this->pageConf['cellwidthPoints'] * count( $question['originassessments'] );
		      if( $this->data['CONFIG']['sumtypes'] >= 6 ){
			    $sumColWidth[$qix] += 2*$this->pageConf['cellwidthSumma'];
		      }elseif($this->data['CONFIG']['sumtypes'] >= 2){
			    $sumColWidth[$qix] += $this->pageConf['cellwidthSummas'];
		      }
		}
		if( !count($sumColWidth) ) return false;
		return  max($sumColWidth);
	}

}
