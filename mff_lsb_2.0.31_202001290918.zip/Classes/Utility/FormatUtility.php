<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * Class FormatUtility
 */

class FormatUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* config
	* umlauds are Ä,Ë,Ï,Ö,Ü,ä,ë,ï,ö,ü
	*
	* @var array
	*/
	Protected $config = array(
			'umlaud_charsets' => array(196,203,207,214,220,228,235,239,246,252)
	);

	/**
	* data
	*
	* @var array
	*/
	Public $data = array();
	
	/**
	* __construct
	*
	* @param array $initConfig optional
	* @return void
	*/
	public function __construct( $initConfig = array() ) {
			if( count( $initConfig ) ) $this->setConfig( $initConfig );
	}

	/**
	* smartCrop
	* this method crops strings respecting length of replacement chars and umlauds
	* 
	* If the returned string including replacement-chars would be equal or longer than the original,
	* it will return the original string.
	* 
	* only in case of respectWord = false:
	* If a string would get cropped at the position of a umlaud, 
	* it will return the whole umlaud instead of cutting the char.
	*
	* @param string $string 
	* @param int $length 
	* @param string $replaceString optional
	* @param bool $respectWord optional
	* @return string
	*/
	public function smartCrop( $string , $length , $replaceString = '...' , $respectWord = true ) {
	
	      $originalLength = strlen( $string );
	      
	      $repStrLength = empty( $replaceString ) ? 0 : strlen( $replaceString );
	      
	      if( $length > $originalLength - $repStrLength ) return $string;
	      
	      if( $respectWord ){
	      
				if( strpos( ' ' . $string , ' ' , $length  ) == 0 ) return $string;
				
				$firstBlank = $length + strpos( $string , ' ' , $length  );
				
				$croppedString = substr( $string , 0 , $firstBlank-1 );
				
	      }else{

				foreach( $this->config['umlaud_charsets'] as $chNr ){
						if( strpos( $string , chr($chNr) ) == $length-1 ){ $length += 1; break; }
				}
				
				$croppedString = substr( $string , 0 , $length );
				
	      }
	      
	      $crpStrLength = strlen($croppedString);
	      
	      if( substr( $string , $crpStrLength , 1 ) == ' ' ) $croppedString .= ' ';
	      
	      if( $crpStrLength < $originalLength ) $croppedString .= $replaceString;
	      
	      return $croppedString ;
	}
	
	/**
	 * setConfig
	 *
	 * @param array $config
	 * @return void
	 */
	Private function setConfig( $config ) {
	
		foreach( $config as $field => $content ){
		
				if( isset( $this->config[ $field ] ) ) {
				
						$this->config[ $field ] = $content;
						
				}
				
		}
		
	}
	
	/**
	 * getConfig
	 *
	 * @return array
	 */
	Private function getConfig() {
	
		return $this->config;
		
	}

// 	Public function setArray(  $replacement , $key ){
// 			if( is_array($replacement[$key]) ){ // usersurvey , SummaryRows ... SummaryRows , 0
// 				foreach( $replacement[$key] as $optNam => $optVal){
// 					$this->setArray( $replacement[$key] , $optNam );
// 				}
// 			}else{
// 				$this->data[$key] = $replacement[$key];
// 			}
// 			return $config[$key];
// 	}

}

