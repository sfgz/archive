<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class FileUploadUtility
 */

class FileUploadUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * hints
	 * 
	 * @var array
	 */
	public $hints = array( 'OK'=>array() , 'ERROR'=>array() );
	
	/**
	 * uploadDir
	 * 
	 * @var string
	 */
	public $uploadDir = 'uploads/tx_mfflsb/';
	
	/**
	 * uploadFieldName
	 * 
	 * @var string
	 */
	public $uploadFieldName = 'dateiname';

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
		$this->uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( ltrim($this->uploadDir , '/') ) , '/' ) . '/';
	}
	
	/**
	 * handles file deletion 
	 *
	 * @param string $fileName
	 * @return void
	 */
	public function deleteFile( $fileName ) {
		if( file_exists($this->uploadDir.$fileName) ) @unlink($this->uploadDir.$fileName);
	}
	
	/**
	 * handles file upload and deletion 
	 * returns string with filename, if action successful
	 *
	 * @param string $extKeyPlgNam
	 * @param string $uploadFieldName
	 * @return string
	 */
	public function uploadCsvFile( $extKeyPlgNam = 'tx_mffimport_user_mffimportiscontrol' , $uploadFieldName = '' ) {
		if( !empty( $uploadFieldName ) ) $this->uploadFieldName = $uploadFieldName;
		$fileName = '';
		if ($_FILES[$extKeyPlgNam]['tmp_name'][$this->uploadFieldName]) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name'][$this->uploadFieldName];
			if( empty($fileName) ){
				$this->hints['ERROR'][]='Datei "'.$_FILES[$extKeyPlgNam]['tmp_name'][$this->uploadFieldName].'" nicht hochgeladen.';
				return;
			}
			if( file_exists($this->uploadDir.$fileName) ) @unlink($this->uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name'][$this->uploadFieldName] , $this->uploadDir.$fileName );
			$this->hints['OK'][]='Datei "'.$fileName.'" hochgeladen.';
		}//else{
		//	$this->hints['ERROR'][]='Datei "'.$_FILES[$extKeyPlgNam]['tmp_name'][$this->uploadFieldName].'" nicht hochgeladen.';
		//}
		return $fileName;
	}
}