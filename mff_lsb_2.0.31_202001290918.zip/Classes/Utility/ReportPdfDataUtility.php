<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ReportPdfDataUtility
 */

class ReportPdfDataUtility extends \Mff\MffLsb\Utility\ReportDataUtility {

	/**
	* surveyDB
	*
	* @var array
	*/
	public $surveyDB = array();

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	* pdf_charset
	*
	* @var string
	*/
	public $pdf_charset = 'ISO-8859-15';
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 * @inject
	 */
	protected $frontendUserRepository = NULL;

	protected $timezone = NULL;
	
      /**
	* PDFDataForReports
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function PDFDataForReports(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
		$answers = json_decode($userSurvey->getResponsesField(),true);
		$templateGroupOptions = $this->repairMacCharset( $userSurvey->getTemplateGroupOptions() );
		$aQst = $this->questionsFieldToArray( $templateGroupOptions );
		$aSortGroups = $this->getReportValues($aQst , $answers);
		$aEnrichedSurveysQuestions = $this->appendSurveyOptions( $userSurvey , $aSortGroups );
		$reportData = $this->getPdfReportValues( $aEnrichedSurveysQuestions );
		return $reportData;
	}
      /**
	* PDFDataForReports
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param boolean $noData delivers an empty Form with own Questions but no Values 
	* @return void
	*/
	public function PDFDataForPrintouts(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $noData = false ){
		$templateGroupOptions = $this->repairMacCharset( $userSurvey->getTemplateGroupOptions());
		$aQst = $this->questionsFieldToArray( $templateGroupOptions );
		$aQst = $this->deleteEmptyRows($aQst);
 		$aSortGroups = $this->getReportValues($aQst , array());
		$aEnrichedSurveysQuestions = $this->appendSurveyOptions( $userSurvey , $aSortGroups );
		$aEnrichedSurveysQuestions['survey'] = $this->replaceSettingsForEmptyReport( $aEnrichedSurveysQuestions['survey'] , $noData );
		$reportData = $this->getPdfReportValues( $aEnrichedSurveysQuestions );
		return $reportData;
	}

    /**
	* PDFDataForConfirmations
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function PDFDataForConfirmations(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
	      $themas = array();
	      $startDate = $userSurvey->getStartDate();
	      $endDate = new \DateTime("@".$startDate->format('U'));
	      $expireDays = $userSurvey->getExpireDays();
	      $endDate->add(new \DateInterval('P'.$expireDays.'D'));
	      $klasse = $userSurvey->getCourseName();
	      $templateGroupOptions = $this->repairMacCharset( $userSurvey->getTemplateGroupOptions() );
	      $aQst = $this->questionsFieldToArray( $templateGroupOptions );
	      $aSortGroups = $this->getReportValues($aQst , $answers);
	      if(is_array($aSortGroups['groups'])){
		    foreach($aSortGroups['groups'] as $grp){
			  if(!is_array($grp['questions'])) continue;
			  foreach($grp['questions'] as $qix=>$quest){
				if( $quest['question_type'] == 1 && count($quest['subquestions']) == 1 ){
				}else{
				      $themas[$qix] = iconv( 'utf-8' , $this->pdf_charset , $quest['question'] );
				}
				if(!is_array($quest['subquestions'])) continue;
				foreach($quest['subquestions'] as $sub){
				      $themas[$qix] .= "\n" . iconv( 'utf-8' , $this->pdf_charset , $sub['question'] );
				}
			  }
		    }
	      }
	      $sThemen = count($themas) ? implode( "\n\n" , $themas ) : '';
	      
	      $fields = array(
		  'Datum Durchfuehrung' => $userSurvey->getStartDate()->format('d.m.Y'),
		  'Datum Besprechung6' => $endDate->format('d.m.Y'),
		  'Klasse 2'   => $klasse,
		  'Themen5'   => $sThemen
	      );
		return $fields;
	}
	
	/**
	* replaceSettingsForEmptyReport
	* cpoy values from 'printout' or 'nodata' to pdf-config
	*
	* @param array $surveySettings
	* @param boolean $noData delivers an empty Form with (own) Questions but no Values 
	* @return array
	*/
	public function replaceSettingsForEmptyReport( $surveySettings , $noData ){
		$surveySettings['responsescount'] = '';
		$config = $surveySettings['settings'];
		if($noData){
		      if( is_array($surveySettings['settings']['nodata']) ){
					$surveySettings['settings'] = $config['nodata'];
					$surveySettings['settings']['usersurvey'] = $config['usersurvey'];
		      }
		      $surveySettings['startdate'] = '';
		      $surveySettings['leitungname'] = '';
		      $surveySettings['kursklasse'] = '';
		      $surveySettings['kursname'] = '';
		      $surveySettings['participcount'] = '';
		      $surveySettings['surveyuid'] = '';
		}elseif( is_array($surveySettings['settings']['printout']) ){
					$surveySettings['settings'] = $config['printout'];
					$surveySettings['settings']['usersurvey'] = $config['usersurvey'];
		}
		return $surveySettings;
	}
	
	/**
	 * getPdfReportValues
	 * 
	 * @param array $aEnrichedSurveysQuestions
	 * @return array
	 */
	public function getPdfReportValues( $aEnrichedSurveysQuestions ) { 
	      // encoding questions and answers (responses)
	      $encSurvey = $this->encodeArray($aEnrichedSurveysQuestions , true );

	      // assemble replacing-values
	      $rp = array(
		    '##START_DATUM##' =>  $aEnrichedSurveysQuestions['survey']['startdate'],
		    '##USER_NAME##' => $aEnrichedSurveysQuestions['survey']['username'] ,
		    '##LEITUNG_NAME##' => $aEnrichedSurveysQuestions['survey']['leitungname'] ,
		    '##KURS_KLASSE##' => $aEnrichedSurveysQuestions['survey']['kursklasse'] ,
		    '##KURS_NAME##' => $aEnrichedSurveysQuestions['survey']['kursname'],
		    '##ANZAHL_ANTWORTEN##' => $aEnrichedSurveysQuestions['survey']['responsescount'],
			'##ANZAHL_TEILNEHMENDE##' => $aEnrichedSurveysQuestions['survey']['participcount'],
			'##SEMESTER##' => $aEnrichedSurveysQuestions['survey']['semester'],
		    '##TEMPLATE_NAME##' => $aEnrichedSurveysQuestions['survey']['templatename']
	      );
	      foreach( $this->settings['specchars'] as $charStr => $charNr ) {
		    $rp[ '__' . $charStr . '__' ] = chr($charNr);
		    $rp[ '&' . $charStr . ';' ] = chr($charNr);
	      }

// 	      $aEnrichedSurveysQuestions['survey']['settings']['filename'] = $aEnrichedSurveysQuestions['survey']['settings']['FilenamePrefix'] . $aEnrichedSurveysQuestions['survey']['settings']['FilenameBody'];

	      // encoding and replacing settings
 	      $rawSettingsFromTs = $aEnrichedSurveysQuestions['survey']['settings'];
	      $rawSettingsFromTs['filename'] = $rawSettingsFromTs['FilenamePrefix'] . $rawSettingsFromTs['FilenameBody'];
	      $settingsFromTs = $this->encodeReplaceArray( $rawSettingsFromTs , $rp );

	      $settingsFromTs['sumtypes'] = $this->settings['useroptions']['sumtypes'];
	      $settingsFromTs['specchars'] = $this->settings['specchars'];
// 	      $settingsFromTs['FilenameBody']=$this->encodeReplaceArray( $settingsFromTs['FilenameBody'] , array('##'=>'-') );;
	      // create FOOTER-text
	      $footer = array();
	      $pageTextWidth = $settingsFromTs['docuwidth'] - ($settingsFromTs['LeftMargin'] + $settingsFromTs['RightMargin']);
	      if(is_array($settingsFromTs['FirstPageFooter'])){
		    foreach($settingsFromTs['FirstPageFooter'] as $ix=>$row){
			  $footer['FirstPageFooter'.$ix] = array( 'condition'=>'first_page_only' , 'content'=>$row , 'width'=>0 , 'align'=>'L' , 'ln'=>1 );
		    }
	      }
	      $footer['FooterTopLeft'] = array( 'condition'=>'' , 'content'=>$settingsFromTs['FooterTopLeft'] , 'width'=>'auto' , 'align'=>'L' , 'ln'=>0 );
	      $footer['FooterTopRight'] = array( 'condition'=>'' , 'content'=>$settingsFromTs['FooterTopRight'] , 'width'=>$pageTextWidth , 'align'=>'R' , 'ln'=>1 );
	      $footer['FooterBottomLeft'] = array( 'condition'=>'' , 'content'=>$settingsFromTs['FooterBottomLeft'] , 'width'=>'auto' , 'align'=>'L' , 'ln'=>0 );
	      $footer['FooterBottomRight'] = array( 'condition'=>'' , 'content'=>$settingsFromTs['FooterBottomRight'] , 'width'=>$pageTextWidth , 'align'=>'R' , 'ln'=>1 );
	      
	      // bind data together in one array
	      $data = array(
		      'CONFIG' => $settingsFromTs,
		      'QUESTIONS' => $encSurvey,
		      'FOOTER' => $footer
	      );
	      return $data;
	}
	
	/**
	 * deleteEmptyOptionalRows
	 * 
	 * @param array $aSurveysQuestionsGroups
	 * @return array
	 */
	public function deleteEmptyOptionalRows( $aSurveysQuestionsGroups ) {
	    foreach($aSurveysQuestionsGroups as $gid=>$grRows){
		  foreach($grRows['questions'] as $qKey=>$qRows){
			if( $this->settings['empty_subquests'][ $qRows['question_type'] ] ){ //  text-area + label have 1 subquestion
			      // the value from textareas subquestion 
			      // has been copied to question before in TemplateDataUtility->questionsFieldToArray()
			      if(empty($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['question'])) {
				    unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]);
			      }else{
				    // if subquest say optional+editable then unset subquestion, 
				    // no matter whether subquestion its empty or not
				    if( is_array($qRows['subquestions']) ){
					  foreach($qRows['subquestions'] as $sqKey=>$sqRows){
						if( $sqRows['optional'] && $sqRows['editable'] ) {
						      unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]);
						}
					  }
					  // if no subquest anymore then delete question
					  if( !count($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions']) ){
						 unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]);
					  }
					  // do the usually unset-work on needless subquestions for text-area + label
					  unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions']);
				    }else{
					  // if no subquest then delete question
					  unset($aSurveysQuestionsGroups[$gid]['questions']);
				    }
			      }
			}else{
			      // if subquest say optional+editable then unset subquestion, 
			      // no matter whether subquestion its empty or not
			      if( is_array($qRows['subquestions']) ){
				    foreach($qRows['subquestions'] as $sqKey=>$sqRows){
					  if( $sqRows['optional'] && $sqRows['editable'] ) {
						unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]);
					  }
				    }
			      }
			      // if no subquest then delete question
			      if(!count($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'])) unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]);
			}
		  }
		  // if no question then delete group
		  if(!count($aSurveysQuestionsGroups[$gid]['questions'])) unset($aSurveysQuestionsGroups[$gid]);
	    }
	    return $aSurveysQuestionsGroups;
	}
	      
	/**
	* encode
	*
	* @param string $string
	* @return string
	*/
	public function encode( $string ){
	    return iconv( 'utf-8' , $this->pdf_charset ,  $this->repairMacCharset($string) );
	}
	
	/**
	 * encodeArray
	 * 
	 * @param array $arrayToEncode
	 * @param boolean $transformHtmlChars
	 * @return array
	 */
	public function encodeArray( $arrayToEncode , $transformHtmlChars = false ) { 
		if( is_array($arrayToEncode) ){
		    foreach($arrayToEncode as $ix=>$subarray) $arrayToEncode[$ix] = $this->encodeArray( $subarray , $transformHtmlChars );
		    return $arrayToEncode;
		}else{
		    if ( $transformHtmlChars ) return str_replace( "<br />" , "\n" , $this->encode( $arrayToEncode ) );
		    return $this->encode( $arrayToEncode );
		}
	}
	
	/**
	 * encodeReplaceArray
	 * 
	 * @param array $arrayToEncode
	 * @param array $aReplacement
	 * @return array
	 */
	public function encodeReplaceArray( $arrayToEncode , $aReplacement ) { 
		if( is_array($arrayToEncode) ){
		    foreach($arrayToEncode as $ix=>$subarray) $arrayToEncode[$ix] = $this->encodeReplaceArray( $subarray , $aReplacement );
		    return $arrayToEncode;
		}else{
		    return $this->encode( str_replace( array_keys($aReplacement) , $aReplacement , $arrayToEncode ) );
		}
	}
	

}
