<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PhpArrayToXmlUtility
 */

class PhpArrayToXmlUtility implements \TYPO3\CMS\Core\SingletonInterface {


    public static function generateValidXmlFromArray($array, $node_block='document') {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>';

        $xml .= "\n<" . $node_block . ">\n";
        $xml .= self::generateXmlFromArray($array, $node_name);
        $xml .= "</" . $node_block . ">\n";

        return $xml;
    }

    public static function generateXmlFromArray($array, $node_name  = '' , $loopCount = 0) {
        $xml = '';

        if (is_array($array) || is_object($array)) {
            foreach ($array as $key=>$value) {
		$addNode = is_array($value) && isset($value[0]) ? 0 : 1;
                if (is_numeric($key)) {
                    $key =  $loopCount == 1 ? $node_name .'s' : $node_name;
                }else{
		    $node_name = $key;
                }
                // tabs for padding left
		if( $addNode ) $xml .= str_repeat( "\t" , $loopCount );
		// set empty value 
                if( !is_array($value) && empty($value) ){
		      $xml .= "<" . $key . "/>";
                }else{
		      $xmlValue = self::generateXmlFromArray($value, $node_name , $addNode + $loopCount );
		      if( $addNode ) {
			  // set opening element-name-tag
			  $xml .= ( $xmlValue == $key && !is_array($value) ) ? "<fieldname>" : "<" . $key . ">";
			  // if node linebreak
			  if( is_array($value) ) $xml .= "\n";
		      }
		      // set string value or array as 'substrings'
		      $xml .=  $xmlValue ;
		      if( $addNode ) {
			  // if node tabs for padding left
			  if( is_array($value) ) $xml .= str_repeat( "\t" , $loopCount );
			  // set closing element-name-tag
			  $xml .= ( $xmlValue == $key && !is_array($value) ) ? "</fieldname>" : "</" . $key . ">";
		      }
                }
		if( $addNode ) $xml .= "\n";
            }
        } else {
//             $xml = htmlspecialchars($array, ENT_QUOTES);
//            $xml = self::wrapValueAsCdata($array);
            $xml = $array;
        }

        return $xml;
    }

}
