<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PdfPrintoutUtility
 * 
 */

class PdfPrintoutUtility extends \Mff\MffLsb\Utility\PdfReportUtility {
	
	/**
	 * pdfReport
	 * 
	 * @param array $data
	 * @param string $type
	 * @return array
	 */
	Public function pdfTemplate(  $data , $type = 'D' ) {
		$this->data = $data;
		
		if( !count($this->data['QUESTIONS']['groups']) ) return false;

		$this->data['CONFIG']['sumtypes'] = 6; // 6 summary-column
		$this->data['QUESTIONS']['survey']['settings']['summaColumnLabels'] = array( 2=>'Summen' , 4=>'Summen' , 6=>'Summen');
 		
		$this->SetAuthor( ($this->data['QUESTIONS']['survey']['leitungname']) );
		$this->StartPageGroup();

		$this->renderLayout();
		
	    $rawDocumentName = $this->data['CONFIG']['FilenamePrefix'] . $this->data['CONFIG']['FilenameBody'];
	    $downloadFileName = str_replace( $this->data['CONFIG']['FilenameReplacing']['search'] , $this->data['CONFIG']['FilenameReplacing']['replace'] , $rawDocumentName ).'.pdf';
		if( 'D' == $type ) {
				echo $this->Output( urlencode($downloadFileName) , 'D' );
				exit();
		}elseif( 'S' == $type ){
				return $this->Output( urlencode($downloadFileName) , 'S' );
		}
	}

	/**
	 * reportAnalyse
	 * in printout-mode this returns only question-type matrix (3)
	 * 
	 * @param array $group
	 * @param string $options optional
	 * @return void
	 */
	 Protected function reportAnalyse($group , $options = '') {
		if( $group['reportPartials'][1] != 1 ) return false;
		$aReturnContents = array();
		$rawOpts = explode( ',' , $options );
		foreach($rawOpts as $optGrp){
			$aOptPair = explode( '-' , trim($optGrp) );
			$aReturnContents[trim($aOptPair[0]).'_title'] = 1;
			if( count($aOptPair)==1 ){
				$aReturnContents[trim($aOptPair[0])] = 1;
			}
		}
		if( !isset($aReturnContents['Matrix']) ) return false;
		$this->pageConf['cellwidthReportDescription'] = $this->getCellWidthForGroup($group);
 		$this->HeaderText = $this->pageConf['HeaderText'] ;
		$this->SetLineWidth( $this->pageConf['lineSmall'] );

		if( $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}
		
		$sumColWidth = $this->getSummaColsCellWidthForGroup($group);
		
		foreach($group['questions'] as $qix=>$question){
		      if( 
					( $question['question_type'] == 1 && isset($aReturnContents['Textarea_title']) ) || 
					( is_array($question['subquestions']) && $question['question_type'] == 2 && isset($aReturnContents['Text_title']) )
		      ){ // TITLE for Textarea AND Text, question as textlabel for textarea (1) and textfields (2)
					if( $this->GetY() > $this->pageConf['dokuHeight'] - ($this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) {
							$this->AddPage();
					}
					$sumwidth = $this->data['CONFIG']['sumtypes'] == 6 ? 2*$this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
					if( isset($aReturnContents['Text']) || isset($aReturnContents['Textarea'])) $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					$this->Cell( $this->pageConf['docuwidth'] - ($sumwidth+$this->pageConf['LeftMargin']+$this->pageConf['RightMargin']) , $this->pageConf['lfeed'] ,  $question['question'] , 'LTBR' , 0 , 'L' );
					$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
					$this->Cell( 0 , $this->pageConf['lfeed'] , 'Anzahl: ' , 'TBR' , 1 , 'L' );
					$this->Ln( $this->pageConf['slfeed'] );
		      }
			if( !is_array($question['subquestions']) || $question['question_type'] != 3 ) continue; // no Subquestions or Textanswer
			$showSummaryFooter = $this->reportAnalyse_matrixBody( $group , $question );
			if( empty($showSummaryFooter) ) continue;
			
			// summas-rows
			$this->SetFont( $this->pageConf['fontfamily'] , 'I' , $this->pageConf['fsize'] );
			$this->Cell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , 'Summen' , 'LRB' , 0 , 'L' );
			
			if(is_array($question['responses'])){
					foreach($question['responses'] as $resNum=>$numCount){ // NO VALUES!
						$this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , '' , 'RTB' , 0 , 'C' );
					}
			}

			// summas-rows-collummns
			if( $this->data['CONFIG']['sumtypes'] >=2 ){
					$width = $this->data['CONFIG']['sumtypes'] > 5 ? 2*$this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
					$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					$this->Cell( $width , $this->pageConf['lfeed'] , '' , 'LRB' , 0 , 'C' );
					$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
			}
			$this->Ln( $this->pageConf['lfeed'] + $this->pageConf['slfeed'] );
		}
	}

// 	/**
// 	 * reportAnalyse_matrixBody
// 	 * in printout-mode this returns only question-type matrix (3)
// 	 * 
// 	 * @param array $group
// 	 * @param array $question
// 	 * @return boolean
// 	 */
// 	Private function no_reportAnalyse_matrixBody( $group , $question ) {
// 			$showSummaryFooter = 1;
// 			if( is_array($question['originassessments']) && ( empty($group['report_hide_header']) || $question['type_index'] == 1 ) ){
// 				if($group['report_header_vertical']){
// 					$this->report_verticalHead($question , $group['report_hide_header'] , false );
// 				}else{
// 					$this->report_horizontalHead( $question , $group['report_hide_header'] , false );
// 				}
// 				$this->Ln( $this->pageConf['lfeed'] );
// 			}
// 			$iterator = 0;
// 			if( $group['report_hide_header'] ){
// 				foreach($question['subquestions'] as $sqix=>$subquestion){
// 						$titleOfQuestion = $iterator ? '' : $question['question'];
// 						if( $this->GetY() > $this->pageConf['dokuHeight'] - ($this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) { $this->AddPage(); }
// 						$this->reportAnalyse_subquestions($subquestion,$titleOfQuestion);
// 						++$iterator;
// 				}
// 				// only draw footer-row if last question in type-group
// 				if( $question['type_index'] != $question['type_maxindex'] ) $showSummaryFooter = 0;
// 			}else{
// 				foreach($question['subquestions'] as $sqix=>$subquestion){
// 					if( $this->GetY() > $this->pageConf['dokuHeight'] - ($this->pageConf['lfeed'] + $this->pageConf['BottomMargin']) ) { $this->AddPage(); }
// 					$this->reportAnalyse_subquestions($subquestion);
// 					++$iterator;
// 				}
// 			}
// 			if( empty($showSummaryFooter) ) return false;
// 			// only draw footer-row if more than 1 subquestion
// 			if( $iterator < 2 ) {
// 					$this->Ln( $this->pageConf['lfeed'] );
// 						return false;
// 			}
// 			return $showSummaryFooter;
// 	}
	
	/**
	 * reportAnalyse_subquestions
	 * 
	 * @param array $subquestion
	 * @param string $question empty if header is shown
	 * @return void
	 */
	 Protected function reportAnalyse_subquestions( $subquestion , $question='' ) {
		$x = $this->GetX();
		$y = $this->GetY();
		// Description / Question
		if($question){ //hide header
		      $this->setXY( $x , $y+0.4 );
		      $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		      $this->Write( $this->pageConf['lfeed'] , $question );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		      $this->setXY( $x , $y);
		      $drawQuestion = "\n" . $subquestion['question'];
		}else{
		      $drawQuestion = $subquestion['question'];
		}
		$this->MultiCell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $drawQuestion , 'LTBR' , 'L' );
		$x2 = $this->GetX();
		$y2 = $this->GetY();
		// if multicell caused a page-break, adjust y2
		if( $y2 < $y ) $y = $this->TopY;
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y );
		$cellheight = $y2-$y;
		
		// top Border for high-misured assessment-points collummns
		foreach($subquestion['responses'] as $resNum=>$numCount){
		    $this->Cell( $this->pageConf['cellwidthPoints'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LTR' , 0  );
		}
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y2 -$this->pageConf['lfeed'] );
		
		// assessment-points collummns
		foreach($subquestion['responses'] as $resNum=>$numCount){ // EMPTY VALUE!
		    $this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , '' , 'LBR' , 0 , 'C' );
		}
		if( $this->data['CONFIG']['sumtypes'] >=2 ){
		    $width = $this->data['CONFIG']['sumtypes'] > 5 ? 2*$this->pageConf['cellwidthSumma'] : $this->pageConf['cellwidthSummas'];
		    // summa-collummn
		    $x3 = $this->GetX();
		    
		    $this->setXY( $x3 , $y );
		    $this->Cell( $width , $this->pageConf['lfeed'] , '' , 'LTR' , 0 , 'C'  );

		    // bottom Border for high-misured summa-collummn
		    $this->setXY( $x3 , $y + $this->pageConf['lfeed'] );
		    $this->Cell( $width , $y2-$y-$this->pageConf['lfeed'] , '' , 'LBR' , 0  );
		}
		$this->setXY( $x , $y2 );
	}
	
	/**
	 * reportSingles
	 * 
	 * @return void
	 */
	 Protected function reportSingles() {
		$sumtypes = $this->data['CONFIG']['sumtypes'];
		$this->data['CONFIG']['sumtypes'] = 1; // no summary-columns
		
		foreach($this->data['QUESTIONS']['groups'] as $gix=>$group){
		      $cellwidthReportDescription[$gix] = $this->getCellWidthForGroup($group);
		};
		
		if( $this->trigger['page'] ){
			$this->AddPage();
			$this->trigger['page'] = false;
		}
		
		foreach($this->data['QUESTIONS']['groups'] as $gix => $group){
		      $docuGroup = array('group'=>$group);
		      if( $this->data['QUESTIONS']['groups'][$gix]['reportPartials'][2] != 2 ) continue;
		      
		      $this->pageConf['cellwidthReportDescription'] = $cellwidthReportDescription[$gix];
		      $sumColWidth = $this->pageConf['cellwidthReportDescription'] + $this->getSummaColsCellWidthForGroup( $this->data['QUESTIONS']['groups'][$gix] );
		      foreach($group['questions'] as $qix => $docuQuest){
			    $originalQuestion = $this->data['QUESTIONS']['groups'][$gix]['questions'][ $qix ];
			    if( $docuQuest['question_type'] == 3 ){ // matrix
					if( !is_array($docuQuest['subquestions']) ) continue;
					if( 
					    empty($docuGroup['group']['report_hide_header']) || $originalQuestion['type_index'] == 1
					){
					      if( $docuGroup['group']['report_header_vertical'] ){
						    $this->report_verticalHead( $docuQuest , $docuGroup['group']['report_hide_header'] , true );
					      }else{
						    $this->report_horizontalHead( $docuQuest , $docuGroup['group']['report_hide_header'] , true );
					      }
					      $this->Ln( $this->pageConf['lfeed'] );
					}
					if( $docuGroup['group']['report_hide_header'] ){
					      $drawQuestion = $docuQuest['question'] ;
					}else{
					      $drawQuestion = '';
					}
					$iterator = 0;
					foreach($docuQuest['subquestions'] as $code => $docuSubquest){
						$titleOfQuestion = $iterator ? '' : $drawQuestion;
						$this->reportSingle_subquestions( $docuSubquest , $titleOfQuestion );
						++$iterator;
					}
					if( empty($docuGroup['group']['report_hide_header']) ) $this->Ln( $this->pageConf['lfeed'] );
				  
			    }elseif( $docuQuest['question_type'] == 2 ){ // text field
					if( !is_array($docuQuest['subquestions']) ) continue;
					$this->Ln($this->pageConf['lfeed']);
					$this->SetLineWidth(0.15);
					$this->SetDrawColor(0,0,0);
					$this->SetDash( 0.05 , 0.95 );
					$this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
					$this->Cell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['question'] , '' , 1 , 'L' );
					$this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
					foreach($docuQuest['subquestions'] as $code => $docuSubquest){
						$this->Cell( $sumColWidth , $this->pageConf['lfeed']*2 , $docuSubquest['question'] , '' , 1 , 'L' );
						$this->Cell( $sumColWidth , 0 , '' , 'B' , 1 , 'L' );
					}
					$this->Ln( $this->pageConf['lfeed'] );
					$this->setDefaultLineAttributes();
				  
			    }elseif( $docuQuest['question_type'] == 1 ){ // textarea
				  $objHeight = $this->pageConf['BottomMargin'] + ( (1+6+2) * $this->pageConf['lfeed'] );
				  $maxYPosToStart = $this->pageConf['dokuHeight'] - $objHeight;
				  if( $this->GetY() > $maxYPosToStart ) $this->AddPage();
				  $this->Ln($this->pageConf['lfeed']);
				  $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
				  $this->Cell( $sumColWidth , 0 , $docuQuest['question'] , '' , 1 , 'L' );
				  $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
				  $this->SetLineWidth(0.15);
				  $this->SetDrawColor(0,0,0);
				  $this->SetDash( 0.05 , 0.95 );
				  $this->Cell( $sumColWidth , 2*$this->pageConf['lfeed'] , '' , 'B' , 1 , 'L' );
				  $this->Cell( $sumColWidth , 2*$this->pageConf['lfeed'] , '' , 'B' , 1 , 'L' );
				  $this->Cell( $sumColWidth , 2*$this->pageConf['lfeed'] , '' , 'B' , 1 , 'L' );
				  $this->setDefaultLineAttributes();
				  $this->Ln($this->pageConf['lfeed']);
			    }else{ // labeltext
				  $this->Ln($this->pageConf['lfeed']);
				  $this->Cell( $sumColWidth , $this->pageConf['lfeed'] , $docuQuest['question'] , '' , 1 , 'L' );
			    }
		      }
		}
		$this->data['CONFIG']['sumtypes'] = $sumtypes;
	}
	
	/**
	 * reportSingle_subquestions
	 * 
	 * @param array $subquestion
	 * @param string $question
	 * @return void
	 */
	 Protected function reportSingle_subquestions($subquestion,$question='') {
		  $x = $this->GetX();
		  $y = $this->GetY();
		// Description / Question
		if($question){
		      $this->setXY( $x , $y+0.4 );
		      $this->SetFont( $this->pageConf['fontfamily'] , 'B' , $this->pageConf['fsize'] );
		      $this->Write( $this->pageConf['lfeed'] , $question );
		      $this->SetFont( $this->pageConf['fontfamily'] , '' , $this->pageConf['fsize'] );
		      $this->setXY( $x , $y);
		      $drawQuestion = "\n" . $subquestion['question'];
		}else{
		      $drawQuestion = $subquestion['question'];
		}
		$this->MultiCell( $this->pageConf['cellwidthReportDescription'] , $this->pageConf['lfeed'] , $drawQuestion , 'LTBR' , 'L' );
		$y2 = $this->GetY();
		$this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y );
		// assessment-points collummns
		if( count($subquestion['responses']) ){
		
		      // top Border for high assessment-points collummns
		      foreach($subquestion['responses'] as $resNum=>$numCount){
			  $this->Cell( $this->pageConf['cellwidthPoints'] , $y2-$y-$this->pageConf['lfeed'] , '' , 'LTR' , 0  );
		      }
		      $this->setXY( $x + $this->pageConf['cellwidthReportDescription'] , $y2-$this->pageConf['lfeed'] );
		      
		      // data-rows
		      foreach($subquestion['responses'] as $ix=>$val){ // EMPTY VALUE!
			    $this->Cell( $this->pageConf['cellwidthPoints'] , $this->pageConf['lfeed'] , '' , 'LBR' , 0 , 'C' );
		      }
		      
		}
		$this->setXY( $x , $y2 );
	}
	

}
