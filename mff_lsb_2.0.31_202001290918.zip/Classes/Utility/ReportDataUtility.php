<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ReportDataUtility
 */

class ReportDataUtility extends \Mff\MffLsb\Utility\TemplateDataUtility {

	/**
	* surveyDB
	*
	* @var array
	*/
	public $surveyDB = array();

	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	* pdf_charset
	*
	* @var string
	*/
	public $pdf_charset = 'ISO-8859-15';
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 */
	protected $frontendUserRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;

	protected $timezone = NULL;

	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings = array() ) {
		$this->loadRepositorySettings();
		if( count($settings) )$this->settings = $settings;

		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(FALSE);
		$querySettings->setStoragePageIds( array($this->settings['teacherPid']) );
		$this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
		$this->frontendUserRepository->setDefaultQuerySettings( $querySettings );
		$this->timezone =  new \DateTimeZone('Europe/Zurich');

	      $storage['timetableStoragePid'] = $this->fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
	      $storage['stundenplanStoragePid'] = $this->fullsettings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
	      $ttQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $ttQuerySettings->setRespectStoragePage(FALSE);
	      $ttQuerySettings->setStoragePageIds( $storage );
	      $this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($ttQuerySettings);
	}
	
	/**
	 * getReportValues
	 * 
	 * @param array aSurveysQuestionsGroups
	 * @param array $answers
	 * @return array
	 */
	public function getReportValues( $aSurveysQuestionsGroups , $answers = array() ) {
	    $aCleanSurveysQuestions = $this->deleteEmptyRows( $aSurveysQuestionsGroups );
	    $aEnrichedSurveysQuestions['groups'] = $this->appendResponseValues( $aCleanSurveysQuestions , $answers );
	    $aEnrichedSurveysQuestions['groups'] = $this->appendSpiderData( $aEnrichedSurveysQuestions['groups'] , $answers ) ;
	    $aEnrichedSurveysQuestions['singles'] = $this->getSingleResponses( $aCleanSurveysQuestions , $answers );
	    return $aEnrichedSurveysQuestions;
	}
	
	/**
	 * deleteEmptyRows
	 * 
	 * @param array $aSurveysQuestionsGroups
	 * @return array
	 */
	public function deleteEmptyRows( $aSurveysQuestionsGroups ) {
	    foreach($aSurveysQuestionsGroups as $gid=>$grRows){
		  foreach($grRows['questions'] as $qKey=>$qRows){
			if( $this->settings['empty_subquests'][ $qRows['question_type'] ] ){ // e.g. textfield and label
			      // the value from textareas subquestion 
			      // has already been copied to the question before in TemplateDataUtility->questionsFieldToArray()
			      // if question-field is empty then unset whole question, else unset subquestion
			      if(empty($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['question'])) {
				    unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]);
			      }else{
				    unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions']);
			      }
			}else{
			      // unset empty subquestions
			      if( is_array($qRows['subquestions']) ){
				    foreach($qRows['subquestions'] as $sqKey=>$sqRows){
					  if( '' == trim($sqRows['question'])) {
						unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]);
					  }
				    }
			      }
			      // if no subquest then delete question
			      if(!count($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'])) unset($aSurveysQuestionsGroups[$gid]['questions'][$qKey]);
			}
		  }
		  // if no question then delete group
		  if(!count($aSurveysQuestionsGroups[$gid]['questions'])) unset($aSurveysQuestionsGroups[$gid]);
	    }
	    return $aSurveysQuestionsGroups;
	}
	
	/**
	 * appendSurveyOptions
	 * 
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param array $data
	 * @return array
	 */
	public function appendSurveyOptions( \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey , $data ) {
			$SURVEY_SID = $userSurvey->getSurveyUid();
			foreach($data['groups'] as $grp){
				$data['survey']['editablequestions']+=$grp['editableQuestions'];
				if($grp['reportPartials'][4] == 4) $data['survey']['reportspider']+=1;
			}
			if(
				( $data['survey']['reportspider'] && $this->settings['selfassessment_while_active'] ) || 
				( empty($SURVEY_SID) && ( $data['survey']['reportspider'] || $data['survey']['editablequestions'] > 0 ) )
			) {
				$data['survey']['iseditable'] = 1;
			}else{
				$data['survey']['iseditable'] = 0;
			}
			
			$pdfSettingsNr = $this->settings['use_pdf_basics'];
			$objTpSurvey = $userSurvey->getUserTpSurvey();
			if( $objTpSurvey ){
					$pdfSettingsNr = $objTpSurvey->getPdfSettings();
			}
			$data['survey']['settings'] = $this->settings['pdf_basics'][ empty($pdfSettingsNr) ? 0 : $pdfSettingsNr ];

			$semester = '';
			$dbPeriodUid = $userSurvey->getSemesterUid();
			if(!empty($dbPeriodUid)){
					$oPeriod = $this->periodsRepository->findByUid($dbPeriodUid);
					if($oPeriod) $semester = $oPeriod->getSemester();
			}
			
			$startDate = $userSurvey->getStartDate();
			$startDate->setTimeZone($this->timezone); 
			//$expireDays = $userSurvey->getExpireDays();
			$data['survey']['startdate'] = $startDate->format('d.m.Y');
			$data['survey']['username'] = $this->getEditornameFromFieldValues( $userSurvey ) ;
			$data['survey']['leitungname'] = $this->getEnquirerFromFieldValues( $userSurvey ) ;
			$data['survey']['kursklasse'] = $userSurvey->getCourseName() ;
			$data['survey']['kursname'] = $userSurvey->getSubject() ;
			$data['survey']['responsescount'] = $userSurvey->getResponsesCount() ;
			$data['survey']['participcount'] = $userSurvey->getParticipCount() ;
			$data['survey']['templatename'] = $userSurvey->getTemplateName() ;
			$data['survey']['surveyuid'] =  $SURVEY_SID;
			$data['survey']['semester'] =  $semester;
			$xmlFieldValue = $userSurvey->getTemplateXml();
			$aXmlSurvey = json_decode( $xmlFieldValue , true);
			$rp = array(
				'##START_DATUM##' =>  $data['survey']['startdate'],
				'##USER_NAME##' => $data['survey']['username'] ,
				'##LEITUNG_NAME##' => $data['survey']['leitungname'] ,
				'##KURS_KLASSE##' => $data['survey']['kursklasse'] ,
				'##KURS_NAME##' => $data['survey']['kursname'] ,
				'##ANZAHL_ANTWORTEN##' => $data['survey']['responsescount'],
				'##ANZAHL_TEILNEHMENDE##' => $data['survey']['participcount'],
				'##SEMESTER##' => $data['survey']['semester'],
				'##TEMPLATE_NAME##' => $data['survey']['templatename']
			);
			$data['survey']['rawtitle'] = str_replace( array_keys($rp) , $rp , $aXmlSurvey['surveys_languagesettings']['surveyls_title']);
// 			$data['survey']['settings']['FilenameBody'] = str_replace( array_keys($rp) , $rp , $data['survey']['settings']['FilenameBody']);
			return $data;
	}
	
	/**
	 * appendSpiderData
	 * 
	 * @param array $aEnrichedSurveysQuestionsGroups
	 * @param array $answers
	 * @return array
	 */
	public function appendSpiderData( $aEnrichedSurveysQuestionsGroups , $answers ) {
	    $aSpider = $this->getSpiderData( $aEnrichedSurveysQuestionsGroups , $answers );
	    if( !is_array($aSpider) ) return $aEnrichedSurveysQuestionsGroups;
	    foreach($aSpider as $gid=>$spiderGroup){
		$aEnrichedSurveysQuestionsGroups[$gid]['spider'] = $spiderGroup;
	    }
	    return $aEnrichedSurveysQuestionsGroups;
	}
	
	/**
	 * getSpiderData
	 * get responses and returns them for Spider-Image
	 * 
	 * @param array aSurveysQuestionsGroups
	 * @param array $answers
	 * @return array
	 */
	public function getSpiderData( $aSurveysQuestionsGroups , $answers ) {
	      // first create the frame for answers
	      // then get self-assessment_value
	      // then get responses
	      // at last build the link-options strings val and val2
	    
	    foreach($aSurveysQuestionsGroups as $gid=>$grRows){
		  if( $grRows['reportPartials'][4] != 4 )continue; // report only if spider is provided
		  $matrixQuestion[$gid]['group_name'] = $grRows['group_name'];
		  $stepIx = 0;
		  foreach($grRows['questions'] as $qKey=>$qRows){
			if( $qRows['question_type'] != 3 )continue; // report only matrix-questions
			if( !is_array($qRows['subquestions']) )continue;
			$maxAssVal = 0;
			foreach($qRows['originassessments'] as $code => $origAssRow){
			      if($origAssRow['assessment_value'] > $maxAssVal) $maxAssVal = $origAssRow['assessment_value'];
			}
			foreach($qRows['subquestions'] as $sqKey=>$sqRows){
			      $matrixQuestion[$gid]['selfAssessmentArr'][$qKey][$sqKey] = $sqRows['self_assessment']/10;
			      if(is_array($answers['responses'])){
				  foreach($answers['responses'] as $rix => $responseRow){
				      if(isset( $responseRow[ $qKey ][ $sqKey ] )){
					    $assessment_value = $qRows['originassessments'][ $responseRow[ $qKey ][ $sqKey ] ]['assessment_value'];
					    $sum[$gid][$qKey]['response_sum'] += $assessment_value-1;
					    $sum[$gid][$qKey]['response_max'] += $maxAssVal-1;
				      }
				  }
			      }
			}
			if( $sum[$gid][$qKey]['response_max'] ){
			      $response_prc = $sum[$gid][$qKey]['response_sum'] * 100 / $sum[$gid][$qKey]['response_max'];
			      $matrixQuestion[$gid]['rays'][$qKey]['response_prc'] = round($response_prc);
			}
			      $matrixQuestion[$gid]['rays'][$qKey]['question'] = $qRows['question'];
			      $matrixQuestion[$gid]['self_num'][$qKey] = round( array_sum($matrixQuestion[$gid]['selfAssessmentArr'][$qKey])  /  count($matrixQuestion[$gid]['selfAssessmentArr'][$qKey]) ,2)-1;
			      $matrixQuestion[$gid]['response_num'][$qKey] = round( ( count($qRows['originassessments']) -1 ) * $response_prc / 100 ,2);
			++$stepIx;
			$aStep2qKey[ $stepIx ] = $qKey;
		  }
		  if( count($matrixQuestion[$gid]['response_num']) ) $matrixQuestion[$gid]['responses'] = implode(',' , $matrixQuestion[$gid]['response_num']);
		  if( count($matrixQuestion[$gid]['self_num']) ) $matrixQuestion[$gid]['selfassessment'] = implode(',' , $matrixQuestion[$gid]['self_num']);
		  
	    }
	    if( !count($matrixQuestion) ) return;
	    $textXinset = $this->settings['spider']['text_inset']['x'];
	    $textYinset = $this->settings['spider']['text_inset']['y'];
	    $spiderUtility = new \Mff\MffLsb\Utility\SpiderImageUtility(array('r'=>$this->settings['spider']['radius']));
	    $spiderUtility->conf['outerRadius'] = $this->settings['spider']['radius'];
	    $spiderUtility->conf['offset'] = 20;
	    $dim = array( 'x'=>$spiderUtility->conf['x'] , 'y'=>$spiderUtility->conf['y'] );
	    foreach($matrixQuestion as $gid=>$grmatrixRows){
		  $rays = count($matrixQuestion[$gid]['selfAssessmentArr']);
		  $mainRadius = $spiderUtility->conf['outerBorder'] + $spiderUtility->conf['outerRadius'] + $spiderUtility->conf['raytipLength'];
		  $slice = 360 / $rays;
		  for($step=1,$grd=0;$grd<=360;$grd+=$slice,++$step){
		      if( !isset($matrixQuestion[$gid]['rays'][ $aStep2qKey[$step] ]['question'] ) ) continue;
		      $matrixQuestion[$gid]['rays'][ $aStep2qKey[$step] ]['x'] = $spiderUtility->conf['x']+$spiderUtility->xDiff( $mainRadius-$textXinset , $grd );
		      $matrixQuestion[$gid]['rays'][ $aStep2qKey[$step] ]['y'] = $spiderUtility->conf['y']-$spiderUtility->yDiff( $mainRadius-$textYinset , $grd );
		  }
		  $matrixQuestion[$gid]['dim'] = $dim;
		  $matrixQuestion[$gid]['dim']['offset'] = $spiderUtility->conf['offset'];
		  $matrixQuestion[$gid]['dim']['h'] = ($dim['y']) * 2;
		  $matrixQuestion[$gid]['dim']['w'] = ($dim['x']) * 2;
	    }
	    
	    return $matrixQuestion;
	}
	
	/**
	 * appendResponseValues
	 * 
	 * @param array aSurveysQuestionsGroups
	 * @param array $answers
	 * @return array
	 */
	public function appendResponseValues( $aSurveysQuestionsGroups , $answers ) {
	    $aSurveysQuestionsGroups = $this->appendQuestionTypeGroup($aSurveysQuestionsGroups);
	    foreach($aSurveysQuestionsGroups as $gid=>$grRows){
		  foreach($grRows['questions'] as $qKey=>$qRows){
			if( $this->settings['empty_subquests'][ $qRows['question_type'] ] ){
			      if(is_array($answers['responses'])){
				  foreach($answers['responses'] as $rix => $responseRow){
				      if(!empty( $responseRow[ $qKey ] )){
					    // text-answer
// 					    $words = explode( ' ' , $responseRow[ $qKey ] );
					    $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['responses'][$rix] = $responseRow[ $qKey ];//str_replace( "\n" , "<br />" , $responseRow[ $qKey ]);
				      }
				  }
			      }
			}else{
			      if( is_array($qRows['subquestions']) ){
				    $maxAssVal = 0;
				    $isAssessment = is_array($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments']) ? 1 : 0;
				    if($isAssessment){foreach($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments'] as $code => $origAssRow){
					  if($origAssRow['assessment_value'] > $maxAssVal) $maxAssVal = $origAssRow['assessment_value'];
					  $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['responses'][$origAssRow['assessment_value']]=0;
				    }}
				    foreach($qRows['subquestions'] as $sqKey=>$sqRows){
					  if($isAssessment){foreach($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments'] as $code => $origAssRow){
						$aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses'][$origAssRow['assessment_value']]=0;
					  }}
					  if(is_array($answers['responses'])){
					      foreach($answers['responses'] as $rix => $responseRow){
						  if(isset( $responseRow[ $qKey ][ $sqKey ] )){
							if($isAssessment){
							      $assessment_value = $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments'][ $responseRow[ $qKey ][ $sqKey ] ]['assessment_value'];
							      $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses'][$assessment_value] += 1;
							      $sum[$gid][$qKey]['subquestions'][$sqKey]['response_sum'] += $assessment_value-1;
							      $sum[$gid][$qKey]['subquestions'][$sqKey]['response_max'] += $maxAssVal-1;
							      $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['response_prc'] = round($sum[$gid][$qKey]['subquestions'][$sqKey]['response_sum'] * 100 / $sum[$gid][$qKey]['subquestions'][$sqKey]['response_max'],1);
							      $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['response_note'] = 1+round(0.05*$sum[$gid][$qKey]['subquestions'][$sqKey]['response_sum'] * 100 / $sum[$gid][$qKey]['subquestions'][$sqKey]['response_max'],1);
							      $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['responses'][$assessment_value] += 1;
							      $sum[$gid][$qKey]['response_sum'] += $assessment_value-1;
							      $sum[$gid][$qKey]['response_max'] += $maxAssVal-1;
							      $groupSum[$gid]['responses'][$assessment_value] += 1;
							      $groupSum[$gid]['response_sum'] += $assessment_value-1;
							      $groupSum[$gid]['response_max'] += $maxAssVal-1;
							}else{
							      $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['responses'][$rix][$sqKey] = $responseRow[ $qKey ][ $sqKey ];
							}
						  }
					      }
					  }
				    }
				    if( is_array($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses']) ){
				    foreach($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses'] as $respKey=>$respVal){
					  if( !isset($groupSum[$gid]['responses'][$respKey]) ){
						$groupSum[$gid]['responses'][$respKey]=0;
					  }
				    }
				    }
				    if( $sum[$gid][$qKey]['response_max'] ){
					  $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['response_prc'] = round($sum[$gid][$qKey]['response_sum'] * 100 / $sum[$gid][$qKey]['response_max'],1);
					  $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['response_note'] = 1+round(0.05*$aSurveysQuestionsGroups[$gid]['questions'][$qKey]['response_prc'],1);
				    }
			      }
			}
		  }
		  if($groupSum[$gid]['response_max']){
			$groupSum[$gid]['response_prc'] = round( 100 * $groupSum[$gid]['response_sum'] / $groupSum[$gid]['response_max'],1);
			$groupSum[$gid]['response_note'] = 1+round(0.05*$groupSum[$gid]['response_prc'],1);
			$aSurveysQuestionsGroups[$gid]['groups']['sums'] = $groupSum[$gid];
		  }
	    }
	    return $aSurveysQuestionsGroups;
	}
	
	/**
	 * appendQuestionTypeGroup
	 * groupByQuestionType
	 * 
	 * @param array $aSurveysQuestionsGroups
	 * @return array
	 */
	public function appendQuestionTypeGroup( $aSurveysQuestionsGroups ) {
	    foreach($aSurveysQuestionsGroups as $gid=>$grRows){
		  $typeGroupIx = array();
		  $questionsTypeGroupIndex = array();
		  foreach($grRows['questions'] as $qKey=>$qRows){
			// set the counter for typeGroups
			if( !isset($typeGroupIx[ $qRows['question_type'] ]) ){
			    // first question with this type in SurveyGroup
			    $typeGroupIx[ $qRows['question_type'] ] = 1;
			    $lastType = $qRows['question_type'];
			    $questionsTypeGroupIndex[ $qRows['question_type'] ][$typeGroupIx[ $qRows['question_type'] ]] = 0;
			}elseif( $lastType != $qRows['question_type'] ){
			    // last question was from other ype, 
			    // first question with this type in typeGroup (but not first in Survey)
			    ++$typeGroupIx[ $qRows['question_type'] ];
			    $lastType = $qRows['question_type'];
			}
			// set the counter for specific question in typeGroup
			++$questionsTypeGroupIndex[ $qRows['question_type'] ][$typeGroupIx[ $qRows['question_type'] ]];
			$aSurveysQuestionsGroups[$gid]['questions'][$qKey]['type_index'] = $questionsTypeGroupIndex[ $qRows['question_type'] ][$typeGroupIx[ $qRows['question_type'] ]];
			$aSurveysQuestionsGroups[$gid]['questions'][$qKey]['type_group'] = $typeGroupIx[ $qRows['question_type'] ];
		  }
		  foreach($grRows['questions'] as $qKey=>$qRows){
			$aSurveysQuestionsGroups[$gid]['questions'][$qKey]['type_maxindex'] = $questionsTypeGroupIndex[ $qRows['question_type'] ][ $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['type_group'] ];
		  }
	    }
	    return $aSurveysQuestionsGroups;
	}
	      
	
	/**
	 * getSingleResponses
	 * get responses by questions
	 * 
	 * @param array aSurveysQuestionsGroups
	 * @param array $answers
	 * @return array
	 */
	public function getSingleResponses( $aSurveysQuestionsGroups , $answers ) {
	    if(is_array($answers['responses'])){
		foreach($answers['responses'] as $rix => $responseRow){
		      foreach($aSurveysQuestionsGroups as $gid=>$grRows){
			    if( $grRows['reportPartials'][2] != 2 )continue; // report only if detail-view is providet
			    $singleResponse[$rix][$gid]['group'] = $grRows;
			    unset($singleResponse[$rix][$gid]['group']['questions']);
			    foreach($grRows['questions'] as $qKey=>$qRows){
				  $singleResponse[$rix][$gid]['questions'][$qKey] = $qRows;
				  if( $this->settings['empty_subquests'][ $qRows['question_type'] ] ){
					if(!empty( $responseRow[ $qKey ] )){
					      // text-answer
					      $singleResponse[$rix][$gid]['questions'][$qKey]['response'] = $responseRow[ $qKey ];//str_replace( "\n" , "<br />" ,$responseRow[ $qKey ]);
					}
				  }else{
					if( is_array($qRows['subquestions']) ){
					      foreach($qRows['subquestions'] as $sqKey=>$sqRows){
						    $isAssessment = is_array($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments']) ? 1 : 0;
						    if($isAssessment){foreach($aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments'] as $code => $origAssRow){
							  $singleResponse[$rix][$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses'][$origAssRow['assessment_value']]='-';
						    }}
						    if(isset( $responseRow[ $qKey ][ $sqKey ] )){
							  if( 2 == $qRows['question_type'] ){
							      if(!empty($responseRow[ $qKey ][ $sqKey ]))$singleResponse[$rix][$gid]['questions'][$qKey]['subquestions'][$sqKey]['response'] = $responseRow[ $qKey ][ $sqKey ];
							  }else{
							      $assessment_value = $aSurveysQuestionsGroups[$gid]['questions'][$qKey]['originassessments'][ $responseRow[ $qKey ][ $sqKey ] ]['assessment_value'];
							      $singleResponse[$rix][$gid]['questions'][$qKey]['subquestions'][$sqKey]['responses'][$assessment_value] = 'X';
							  }
						    }
					      }
					}
				  }
			    }
		      }
		}
	    }
	    return $singleResponse;
	}
	      
	/**
	* getEditornameFromFieldValues
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return string
	*/
	public function getEditornameFromFieldValues(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
		$editor_name = 'unbekannt';
		$user_uid = $userSurvey->getUserUid();
		if( $user_uid ) $feUser = $this->frontendUserRepository->findByUid($user_uid);
		if( $feUser ) $editor_name = $feUser->getFirstName() . ' ' . $feUser->getLastName();
		return trim( $editor_name );
	}
	      
	/**
	* getEmailFromFieldValues
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return string
	*/
	public function getEmailFromFieldValues(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
		$editor_email = 'unbekannt';
		$user_uid = $userSurvey->getUserUid();
		if( $user_uid ) $feUser = $this->frontendUserRepository->findByUid($user_uid);
		if( $feUser ){
			$editor_email = $feUser->getEmail();
			if( filter_var($editor_email, FILTER_VALIDATE_EMAIL) ) return trim( $editor_email );
		}
		return $editor_email;
	}
	      
	/**
	* getEnquirerFromFieldValues
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return string
	*/
	public function getEnquirerFromFieldValues(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){

	      $enquirer_type = $userSurvey->getEnquirerType();

	      // User-controlled - selbstverwaltet
	      if( $enquirer_type != 1 ) return $this->getEditornameFromFieldValues($userSurvey);

	      // Client - Klienten
	      $enquirer_name = $userSurvey->getEnquirerName();
	      if(empty($enquirer_name)){
		    $enquirer_uid = $userSurvey->getEnquirerUid();
		    $feUser = $this->frontendUserRepository->findByUid($enquirer_uid);
		    $enquirer_name = $feUser->getFirstName() . ' ' . $feUser->getLastName();
	      }
	      
	      return trim( $enquirer_name );
	}
	

}
