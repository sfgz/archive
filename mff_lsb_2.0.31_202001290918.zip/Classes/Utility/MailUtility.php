<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

use TYPO3\CMS\Core\Utility\GeneralUtility;
 
/**
 * Class MailUtility
 */

class MailUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 */
	protected $frontendUserRepository = NULL;

	/**
	* settings
	* 
	* @var array
	*/
	protected $settings = array();

	/**
	* interim
	* 
	* @var array
	*/
	public $interim = array();

	/**
	 * typoScriptService
	 *
	 * @var \TYPO3\CMS\Core\SingletonInterface
	 */
	protected $typoScriptService = NULL;

	/**
	 * userSurveyController
	 *
	 * @var \Mff\MffLsb\Controller\UserSurveyController
	 */
	protected $userSurveyController = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	protected $timezone = NULL;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
		$this->timezone =  new \DateTimeZone('Europe/Zurich');
	      $this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	    
	      $this->userSurveyController = new \Mff\MffLsb\Controller\UserSurveyController();
	      $this->userSurveyController->initialize_basics();
	      
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']);
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      $this->settings['token'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']['anonymous.']['token'];
	      
	      $this->reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
	      
		  $this->persistenceManager = GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");

	      $storage['timetableStoragePid'] = $fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
	      $ttQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $ttQuerySettings->setRespectStoragePage(FALSE);
	      $ttQuerySettings->setStoragePageIds( $storage );
		  $this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($ttQuerySettings);

	      $teacherStorage['teacherPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $querySettings->setStoragePageIds( $teacherStorage );
	      $this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
	      $this->frontendUserRepository->setDefaultQuerySettings( $querySettings );
	}
    
	/**
	* sendMessageLinkAndUpdate
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function sendLinkAndUpdate( $userSurvey ){
			$userSurvey->setMailState( 2 );
			$this->userSurveyRepository->update( $userSurvey );
			$this->persistenceManager->persistAll();
			$success = $this->sendHtmLink( $userSurvey );
			if($success){
				$userSurvey->setMailState( 3 );
				$this->userSurveyRepository->update( $userSurvey );
				$this->persistenceManager->persistAll();
			}
			return $success;
	}
     
	/**
	* sendHandoutAndUpdate
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function sendHandoutAndUpdate( $userSurvey ){
			$userSurvey->setMailState( 7 );
			$this->userSurveyRepository->update( $userSurvey );
			$this->persistenceManager->persistAll();
			$success = $this->sendPdfHandout( $userSurvey );
			if($success){
				$userSurvey->setMailState( 8 );
				$this->userSurveyRepository->update( $userSurvey );
				$this->persistenceManager->persistAll();
			}
			return $success;
	}
     
	/**
	* sendReminderAndUpdate
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function sendReminderAndUpdate( $userSurvey ){
			$userSurvey->setMailState( 4 );
			$this->userSurveyRepository->update( $userSurvey );
			$this->persistenceManager->persistAll();
			$success = $this->sendHtmReminder( $userSurvey );
			if($success){
				$userSurvey->setMailState( 5 );
				$this->userSurveyRepository->update( $userSurvey );
				$this->persistenceManager->persistAll();
			}
			return $success;
	}
 	
	/**
	* sendHtmReminder
	* called from externaly
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function sendHtmReminder( $userSurvey ){
			// store the default value for later
			$useNeutralMailsender = $this->settings['mail']['use_fix_invitation'];
			$mailBccSetting = $this->settings['useroptions']['default_black_copy'];
			
			// change values explicit for reminder and call mailfunction
			$this->settings['mail']['use_fix_invitation'] = 1;
			$this->settings['useroptions']['default_black_copy'] = $this->settings['useroptions']['default_black_copy_reminder'];
			$result = $this->sendHtmLink( $userSurvey , $this->settings['mail']['reminder_text'] );
			
			// reset origin values and return result of mailjob
			$this->settings['mail']['use_fix_invitation'] = $useNeutralMailsender;
			$this->settings['useroptions']['default_black_copy'] = $mailBccSetting;
			return $result;
	}
	
	/**
	* sendHtmLink
	* called from externaly
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param array $additionalText optional Text to merge
	* @return void
	*/
	public function sendHtmLink( $userSurvey , $additionalText = array() ){
	    $onErrorReturn = str_replace( '|' , $this->settings['display']['sendHtmLink']['error'] , $this->settings['display']['sendHtmLink']['wrap']);
	    // we need baseUrl for link to page in the mail message
	    if( empty($this->settings['baseUrl']) ){ return  $onErrorReturn; }
	    // get substitution values from survey and paths from settings
	    $sr = $this->getEmailData( $userSurvey );
	    
	    // enrich substitution variable with reminder-text in case there are embedded by method $this->sendHtmReminder
		if( isset($additionalText['body']) ) $sr['##ADDITIONAL_TEXT##'] = $additionalText['body'];
		if( isset($additionalText['subject']) ) $sr['##ADDITIONAL_TITLE##'] = trim($additionalText['subject']) . ' '; 
	    
	    // emit sender (from Email)
	    $fromEmail = $sr['##SENDER_EMAIL##'];
		
		// manipulate recipient-adress 
	    if( $this->settings['mail']['unlock'] == 1 ){
				$recipient = $sr['##MAILTO##']; // if unlocked send to recipient!
	    }else{
				$recipient = $sr['##ADMIN_EMAIL##']; // if locked send to creator of survey
	    }
	    
	    // validate emailadress
		if( !filter_var($fromEmail, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;
		if( !filter_var($recipient, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;
	    
	    // get invitation-text from template
	    $templObj = $userSurvey->getUserTpSurvey();
	    if( !$templObj ) return $onErrorReturn;
	    
	    // set strings
	    $subject = $templObj->getNotifysubject();
	    $subject = str_replace( array_keys($sr) , $sr , $subject ) ;
	    
	    $body = $templObj->getNotifytext();
	    $body .= $templObj->getImportanttext();
	    $body .= str_replace( '|' , $this->settings['mail']['logo']['imagename'] , $this->settings['mail']['logo']['wrap_signature'] );
		$body = str_replace( array_keys($sr) , $sr , $body ); 

		// create mailData
	    $mailData = array(
				'Subject' => $subject,
				'Body' => $body,
				'From' => $fromEmail,
				'To' => $recipient,
				'Images' => array( $this->settings['mail']['logo']['imagename'] => $this->settings['mail']['logo']['path'] )
	    );
	    if( $sr['##ADMIN_EMAIL##'] != $fromEmail && filter_var($sr['##ADMIN_EMAIL##'], FILTER_VALIDATE_EMAIL) ){
				$mailData['ReplyTo'] = array( $sr['##ADMIN_EMAIL##'] => $sr['##ADMIN_NAME##'] );
				$mailData['ReturnPath'] = $sr['##ADMIN_EMAIL##'];
	    }
		// append BlackCopy if settings.default_black_copy == 1 AND there is a real admin-adress
		if( $this->settings['useroptions']['default_black_copy'] ){
				$mailData['Bcc'] = $sr['##ADMIN_EMAIL##'];
		}
		
		// send the mesage
	    $this->sendWithAttatchment($mailData);
	    
	    // return message for frontend: 'Email mit Link gesendet'
	    return str_replace( '|' , $this->settings['display']['sendHtmLink']['success'] , $this->settings['display']['sendHtmLink']['wrap']);
 	}
 	
	/**
	* sendPdfHandout
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @param array $additionalText optional Text to merge
	* @return void
	*/
	public function sendPdfHandout( $userSurvey , $additionalText = array() ){
	    $onErrorReturn = str_replace( '|' , $this->settings['display']['sendPdfHandout']['error'] , $this->settings['display']['sendPdfHandout']['wrap']);
	    // do not first look up for new answers and update survey
		// $this->userSurveyController->updateSurveyFromApi($userSurvey);
	    // evaluate pdf-content
		$reportData = $this->reportUtility->PDFDataForPrintouts( $userSurvey , $onErrorReturn );
	    if( !is_array($reportData) ){ return  $onErrorReturn; }
	    // create pdf-filecontent
		$pdfUtility = new \Mff\MffLsb\Utility\PdfPrintoutUtility( $this->settings );
  		$pdfString = $pdfUtility->pdfTemplate( $reportData , 'S' ); 

	    // get substitution values from survey and paths from settings
	    $sr = $this->getEmailData( $userSurvey );
	    
	    // enrich substitution variable with reminder-text in case there are embedded by nethod $this->sendHtmReminder
		if( isset($additionalText['body']) ) $sr['##ADDITIONAL_TEXT##'] = $additionalText['body'];
		if( isset($additionalText['subject']) ) $sr['##ADDITIONAL_TITLE##'] = trim($additionalText['subject']) . ' '; 
	    
	    // emit sender (from Email)
	    $fromEmail = $sr['##SENDER_EMAIL##'];
	    
		// manipulate subject, message and recipient-adress ( sender-adress from TsConfig )
	    if( $this->settings['mail']['unlock'] == 1 ){
				$recipient = $sr['##MAILTO##']; // if unlocked send to recipient!
	    }else{
				$recipient = $sr['##ADMIN_EMAIL##']; // if locked send to creator of survey
	    }

	    // validate emailadress
		if( !filter_var($fromEmail, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;
		if( !filter_var($recipient, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;

		$rawDocumentName = $reportData['CONFIG']['FilenamePrefix'] . $reportData['CONFIG']['FilenameBody'];
	    $replacedDocuname = str_replace( array_keys($sr) , $sr , $rawDocumentName );
	    $dokuname = urlencode( str_replace( $reportData['CONFIG']['FilenameReplacing']['search'] , $reportData['CONFIG']['FilenameReplacing']['replace'] , $replacedDocuname ) );
	    
	    // get invitation-text from template
	    $templObj = $userSurvey->getUserTpSurvey();
	    if( !$templObj ) return $onErrorReturn;
	    
	    // set strings
	    $subject = $templObj->getNotifysubject();
	    $subject = str_replace( array_keys($sr) , $sr , $subject );
	    
	    $body = $templObj->getHandouttext();
	    $body .= $templObj->getImportanttext();
	    $body .= str_replace( '|' , $this->settings['mail']['logo']['imagename'] , $this->settings['mail']['logo']['wrap_signature'] );
		$body = str_replace( array_keys($sr) , $sr , $body );

		// send mail with attatched pdf-string and return notification
	    $mailData = array(
				'Subject' => $subject,
				'Body' => $body,
				'From' => $fromEmail,
				'To' => $recipient,
				'Images' => array( $this->settings['mail']['logo']['imagename'] => $this->settings['mail']['logo']['path'] ),
				'Attatchments' => array( $dokuname.'.pdf' => $pdfString )
	    );
	    if( $sr['##ADMIN_EMAIL##'] != $fromEmail && filter_var($sr['##ADMIN_EMAIL##'], FILTER_VALIDATE_EMAIL) ){
				$mailData['ReplyTo'] = array( $sr['##ADMIN_EMAIL##'] => $sr['##ADMIN_NAME##'] );
				$mailData['ReturnPath'] = $sr['##ADMIN_EMAIL##'];
	    }
		// append BlackCopy if settings.default_black_copy == 1 AND there is a real admin-adress
		if( $this->settings['useroptions']['default_black_copy'] ){
				$mailData['Bcc'] = $sr['##ADMIN_EMAIL##'];
		}
		
	    $this->sendWithAttatchment($mailData);
	    return str_replace( '|' , $this->settings['display']['sendPdfHandout']['success'] , $this->settings['display']['sendPdfHandout']['wrap']);
	}
 	
	/**
	* sendPdfData
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function sendPdfData( $userSurvey ){
	    $onErrorReturn = str_replace( '|' , $this->settings['display']['sendPdfData']['error'] , $this->settings['display']['sendPdfData']['wrap']);
	    // first look up for new answers and update survey
		$this->userSurveyController->updateSurveyFromApi($userSurvey);
	    // evaluate pdf-content
	    $reportData = $this->reportUtility->PDFDataForReports( $userSurvey  );
	    if( !is_array($reportData) ){ return  $onErrorReturn; }
	    // create pdf-filecontent
	    $pdfUtility = new \Mff\MffLsb\Utility\PdfReportUtility( $this->settings );
	    $pdfString = $pdfUtility->pdfReport( $reportData , 'S' ); 
	    
	    // get substitution values from survey
	    $sr = $this->getEmailData( $userSurvey );

	    // set strings
	    $subject = $this->settings['mail']['sender_text']['subject'];
	    $subject = str_replace( array_keys($sr) , $sr , $subject );
	    
	    $body = $this->settings['mail']['sender_text']['body'];

	    $rawFooter = str_replace( '|' , $this->settings['mail']['logo']['imagename'] , $this->settings['mail']['logo']['wrap_image'] );
	    $footer = str_replace( array_keys($sr) , $sr , $rawFooter );
	    
	    if( is_array($this->settings['mail']['sender_footer']) ) $footer.= implode( ' ' , $this->settings['mail']['sender_footer'] );
	    
	    // get invitation-text from template
	    $templObj = $userSurvey->getUserTpSurvey();
	    if( $templObj ) $body .= "\n<br />" . $templObj->getImportanttext();
		$body .=  $footer;
		$body = str_replace( array_keys($sr) , $sr , $body  );
	    
		// manipulate subject, message and recipient-adress ( sender-adress from TsConfig )
	    if( $this->settings['mail']['unlock'] == 1 ){
				$recipient = $sr['##MAILTO##'];
	    }else{
				$recipient = $sr['##ADMIN_EMAIL##'];
	    }
	    
	    $fromEmail = $this->settings['mail']['sender_adress'];
	    
	    // validate emailadress
		if( !filter_var($fromEmail, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;
		if( !filter_var($recipient, FILTER_VALIDATE_EMAIL) ) return $onErrorReturn;

		$rawDocumentName = $reportData['CONFIG']['FilenamePrefix'] . $reportData['CONFIG']['FilenameBody'];
	    $replacedDocuname = str_replace( array_keys($sr) , $sr , $rawDocumentName );
	    $dokuname = urlencode( str_replace( $reportData['CONFIG']['FilenameReplacing']['search'] , $reportData['CONFIG']['FilenameReplacing']['replace'] , $replacedDocuname ) );

		// send mail with attatched pdf-string and return notification
	    $mailData = array(
				'Subject' => $subject,
				'Body' => $body,
				'From' => $fromEmail,
				'To' => $recipient,
				'Images' => array( $this->settings['mail']['logo']['imagename'] => $this->settings['mail']['logo']['path'] ),
				'Attatchments' => array( $dokuname.'.pdf' => $pdfString )
	    );
	    if( filter_var($sr['##ADMIN_EMAIL##'], FILTER_VALIDATE_EMAIL) ){
				$mailData['ReplyTo'] = array( $sr['##ADMIN_EMAIL##'] => $sr['##ADMIN_NAME##'] );
				$mailData['ReturnPath'] = $sr['##ADMIN_EMAIL##'];
	    }
	    $this->sendWithAttatchment($mailData);
	    return str_replace( '|' , $this->settings['display']['sendPdfData']['success'] , $this->settings['display']['sendPdfData']['wrap']);
 	}
	
	/**
	 * sendWithAttatchment
	 * used by sendmailAction() in AnlassController
	 *
	 * @param array $mailData
	 * @return void
	 */
	public function sendWithAttatchment( $mailData ) {
	      $mail = GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');
	      if( is_array($mailData['Attatchments']) ){
				foreach( $mailData['Attatchments'] as $dateiname=> $output){
					$attachment = \Swift_Attachment::newInstance($output, $dateiname , 'application/pdf');
					$mail->attach($attachment);
				}
	      }
	      if( is_array($mailData['Images']) ){
				$imageDir = rtrim($this->settings['baseUrl']  , '/' ) . '/';
				$embedImage = array();
				foreach( $mailData['Images'] as $dateiname => $imagePath){
					$absPath = GeneralUtility::getFileAbsFileName(rtrim($imagePath, '/' ) . '/' . $dateiname);
					$embedImage[$dateiname] = '<img width="'.$this->settings['mail']['logo']['image_width'].'px" src="' . $mail->embed(\Swift_Image::fromPath($absPath)) . '" alt="logo" />';
				}
				if( count($embedImage) ){
							$mailData['Body'] = str_replace( array_keys($embedImage) , $embedImage , $mailData['Body'] );
				}
	      }
	      $mail->setBody( $mailData['Body'] , 'text/html' );
	      $mail->setSubject( $mailData['Subject'] );
	      $mail->setFrom( $mailData['From'] );
	      $mail->setTo( $mailData['To'] );
	      if( count($this->interim) ) foreach( $this->interim as $adresstype => $adress ) $mailData[$adresstype] = $adress;
	      if( isset($mailData['ReturnPath']) && !empty($mailData['ReturnPath']) && filter_var($mailData['ReturnPath'], FILTER_VALIDATE_EMAIL)) $mail->setReturnPath( $mailData['ReturnPath'] );
	      if( isset($mailData['ReplyTo']) && !empty($mailData['ReplyTo']) && filter_var($mailData['ReplyTo'], FILTER_VALIDATE_EMAIL)) $mail->setReplyTo( $mailData['ReplyTo'] );
	      if( isset($mailData['Cc']) && !empty($mailData['Cc']) && filter_var($mailData['Cc'], FILTER_VALIDATE_EMAIL)) $mail->setCc( $mailData['Cc'] );
	      if( isset($mailData['Bcc']) && !empty($mailData['Bcc']) && filter_var($mailData['Bcc'], FILTER_VALIDATE_EMAIL)) $mail->setBcc( $mailData['Bcc'] );
	      $mail->send();
	      
	      unset($this->interim);
	      return true;
	}
 	
	/**
	* getEmailData
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return array
	*/
	public function getEmailData( $userSurvey ){

	    $remKey = $userSurvey->getRemoteKey();
	    if(empty($remKey)){
			$userUid = $userSurvey->getUserUid( $userUid );
			$remKey = md5( $userUid . '-' . microtime(true) );
			$userSurvey->setRemoteKey( $remKey );
			$this->userSurveyRepository->update($userSurvey);
			$this->persistenceManager->persistAll();
	    }
		$md5remKey = md5( $remKey );
	    
	    $urlToPublish = $this->settings['baseUrl'] . '?type=43&amp;fmt=p&amp;uid='.$userSurvey->getUid().'&amp;remKey='.$md5remKey;
	    $linkToPublish = '<a href="' . $urlToPublish.'" class="pdf">'.$this->settings['mail']['presentation']['link_label'].'</a>';
	    
	    $urlForMail = $this->settings['baseUrl'] . '?type=43&amp;fmt=s&amp;uid='.$userSurvey->getUid().'&amp;remKey='.$md5remKey;
	    $linkForMail = '<a href="' .$urlForMail .'" class="pdf">'.$this->settings['mail']['pdf_request']['link_label'].'</a>';
	    $urlForSurvey = $this->settings['lsBaseUrl'] . '/'.$this->settings['token'].'/'.$userSurvey->getSurveyUid();
	    $linkForSurvey = '<a href="' .$urlForSurvey .'" class="">'.$urlForSurvey.'</a>';

	    $klasse = $userSurvey->getCourseName();
	    $fach = $userSurvey->getSubject();
	    $enquirerName = $userSurvey->getEnquirerName();
	    $enquirerEmail = $userSurvey->getEnquirerEmail();
	    
	    $userUid = $userSurvey->getUserUid();
	    $oUser = $this->frontendUserRepository->findByUid($userUid);
	    $adminVorname = $oUser->getFirstname();
	    $adminNachname = $oUser->getLastname();
	    $adminName = trim($oUser->getFirstname() . ' ' . $oUser->getLastname());
	    $adminTitel = $oUser->getTitle();
	    $adminEmail = $oUser->getEmail();
	    $adminAbteilung = $oUser->getCompany();
	    $adminAbteil2 = $oUser->getCity();
	    $adminPhone = $oUser->getTelephone();
	    
		$startDate = $userSurvey->getStartDate();
		$startDate->setTimeZone($this->timezone);
		
		$expireDays = $userSurvey->getExpireDays();
		$endDate = new \DateTime( $startDate->format('Y-m-d H:i:s') , $this->timeZone );
		$endDate->add(new \DateInterval('P'.$expireDays.'D'));
		if( $this->settings['days_before_start'] ) $startDate->add(new \DateInterval('P1D'));
		if( $this->settings['days_after_end'] ) $endDate->sub(new \DateInterval('P1D'));
		// guess the additional day to startday has to be added after creating enddate
		// and the substractional day for enddate has to be done before creating remoteDays
		$remoteDays = $userSurvey->getRemoteDays();
		$remoteDate = new \DateTime( $endDate->format('Y-m-d H:i:s') , $this->timeZone );
		$remoteDate->add(new \DateInterval('P'.$remoteDays.'D'));
	    
	    $dbPeriodUid = $userSurvey->getSemesterUid();
		$oPeriod = $this->periodsRepository->findByUid($dbPeriodUid);
		$semester = $oPeriod->getSemester();
	    $sr = array( "\n"=>'<br />',
			'##ADMIN_COMPANY##'=>$adminAbteilung,
			'##ADMIN_EMAIL##'=> filter_var($adminEmail, FILTER_VALIDATE_EMAIL) ? $adminEmail : $this->settings['mail']['sender_adress'],
			'##ADMIN_NAME##'=>$adminName,
			'##NAME##'=>$enquirerName,
			'#vorname#'=> $adminVorname,
			'#nachname#'=> $adminNachname,
			'#fachbereich#'=> !empty($adminAbteilung) ? $adminAbteilung . '<br />' : '',
			'#fachbereiche#'=> !empty($adminAbteil2) ? $adminAbteil2 . '<br />' : '',
			'#title#'=> !empty($adminTitel) ? $adminTitel . '<br />' : '',
			'#telephone#'=> !empty($adminPhone) ? $adminPhone . '<br />' : '',
			'##SEMESTER##'=>$semester,
			'##KURS##'=>$klasse, 
			'##FACH##'=>$fach,
			'##MAILTO##'=>$enquirerEmail,
			'##LINK_TO_PUBLISH##'=>$linkToPublish,
			'##DATE_START##'=> $startDate->format('d.m.Y'),
			'##DATE_END##'=> $endDate->format('d.m.Y'),
			'##SEND_PDF##'=>$linkForMail, 
			'##DATE_UNTIL_SEND_PDF##'=> $remoteDate->format('d.m.Y'), 
			'##LINK_TO_RUN##'=>$linkForSurvey , 
			'##ADDITIONAL_TITLE##'=>'' , 
			'##ADDITIONAL_TEXT##'=>'' 
	    );
	    // emit sender (from Email)
		$sr['##SENDER_EMAIL##'] = $sr['##ADMIN_EMAIL##'];
		if( $this->settings['mail']['use_fix_invitation'] && $this->settings['mail']['fix_invitation_from'] ){
				$tsFromEmail = $this->settings['mail']['fix_invitation_from'];
				if( filter_var($tsFromEmail, FILTER_VALIDATE_EMAIL) ){ 
					$sr['##SENDER_EMAIL##'] = $tsFromEmail; 
					$this->settings['mail']['logo']['wrap_signature'] = $this->settings['mail']['logo']['wrap_signature_neutral'];
				}
		}
	    
	    return $sr;
 	}
    
	/**
	* getFrontendUserRepository
	*
	* @return array
	*/
	public function getFrontendUserRepository(){
			return $this->frontendUserRepository;
	}
    
	/**
	* getSettings
	*
	* @return array
	*/
	public function getSettings(){
			return $this->settings;
	}
    
	/**
	* getUserSurveyController
	*
	* @return array
	*/
	public function getUserSurveyController(){
			return $this->userSurveyController;
	}
    

// 	/**
// 	* downloadData
// 	* old fashion, unsecure cause everybody could download, when he has the link
// 	*
// 	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
// 	* @return void
// 	*/
// 	public function downloadData( $userSurvey ){
// 		$this->userSurveyController->updateSurveyFromApi($userSurvey);
// 
// 	    $reportData = $this->reportUtility->PDFDataForReports( $userSurvey  );
// 	    if( !is_array($reportData) ) return 'no data';
// 
// 	    $pdfUtility = new \Mff\MffLsb\Utility\PdfReportUtility( $this->settings );
// 	    $pdfUtility->pdfReport( $reportData , 'D' ); 
//  	}

}

