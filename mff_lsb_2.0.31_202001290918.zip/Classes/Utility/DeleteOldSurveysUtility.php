<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * Class DeleteOldSurveysUtility
 */

class DeleteOldSurveysUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	 * persistenceManager
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 */
	protected $persistenceManager = NULL;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']);
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      $this->settings['token'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']['anonymous.']['token'];
	      
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings($querySettings);
	      
		  $this->persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
	      $this->mailUtility = GeneralUtility::makeInstance(\Mff\MffLsb\Utility\MailUtility::class);
	}

	public function execute(){
	    return $this->deleteOldSurveysNow();
	}

	/**
	* displayInvitation
	*
	* @param int $unixDateNow optional
	* @return void
	*/
	public function deleteOldSurveysNow( $unixDateNow = 0 ){
	
		if( empty($unixDateNow) ) $unixDateNow = time();

		$unixDateTonight = mktime( 23,0,0 , date('n',$unixDateNow) , date('j',$unixDateNow) , date('Y',$unixDateNow) );
		
	    $objListDelete = $this->userSurveyRepository->findByDeletionDate( $unixDateTonight );

	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    
	    foreach($objListDelete as $userSurvey) {
				$result = $lsObjUtility->deactivateLsFromUserSurvey( $userSurvey );
				$this->userSurveyRepository->remove($userSurvey);
		}
		
		$this->persistenceManager->persistAll();

		return count($objListDelete);

 	}


}

