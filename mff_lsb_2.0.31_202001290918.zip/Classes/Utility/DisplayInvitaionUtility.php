<?php
namespace Mff\MffLsb\Utility;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class DisplayInvitaionUtility
 */

class DisplayInvitaionUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	*/
	protected $userSurveyRepository = null;

	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( ) {
	      $this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
/*	      
	      $this->remoteSurveyController = new \Mff\MffLsb\Controller\RemoteSurveyController();
	      $this->remoteSurveyController->initialize_basics();
	      $this->settings = $this->remoteSurveyController->getSettings();*/

	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']);
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      // this token is also defined in file .htaccess which is located under the URL stored in settings['lsBaseUrl'] ( eg. https://umfragen.sfgz.ch/.htaccess )
	      $this->settings['token'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']['anonymous.']['token'];
	      
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings($this->querySettings);
	      
	      $this->mailUtility = GeneralUtility::makeInstance(\Mff\MffLsb\Utility\MailUtility::class);
	      $this->chaptaUtility = GeneralUtility::makeInstance(\Mff\MffLsb\Utility\ChaptaUtility::class);
	}
    
	/**
	* showObjectTitle
	*
	* @return void
	*/
	public function showObjectTitle(){
		$errorMessage = 'Fehler, keine Aktion. ';
		
	    $md5remKey = GeneralUtility::_GP('remKey');
	    if( empty($md5remKey) ) return 'Kein Schl&uuml;ssel. ' . $errorMessage;
	    
	    $format = GeneralUtility::_GP('fmt');
	    if( 'p' == strtolower($format) ) {
				return 'Link zur Umfrage';
	    }elseif( 's' == strtolower($format) ){
				return 'Auswertung senden...';
	    }elseif( 'l' == strtolower($format) ){
				return 'Links senden...';
	    }
	    return $errorMessage;
	}
    
	/**
	* showObjectData
	*
	* @return void
	*/
	public function showObjectData(){
		$errorMessage = 'Vielleicht wurde die Seite mit einem unvollst&auml;ndigen Link aufgerufen.';
	    
	    $surveyUid = GeneralUtility::_GP('uid');;
	    if(empty($surveyUid)) return 'Keine uid angegeben. ' . $errorMessage . GeneralUtility::_POST('type') ;
	    
	    $userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
	    if(!$userSurvey) return 'Keine Umfrage gefunden. ' . $errorMessage;
	    
	    $md5remKey = GeneralUtility::_GP('remKey');
	    if( empty($md5remKey) ) return 'Kein Schl&uuml;ssel. ' . $errorMessage;
	    
		if( $md5remKey != md5( $userSurvey->getRemoteKey() ) ){ return  'Schl&uuml;ssel stimmen nicht &uuml;berein. ' . $errorMessage;}

		$format = GeneralUtility::_GP('fmt');
	    if( 'p' == strtolower($format) ) {
				return $this->displayInvitation( $userSurvey );
	    }elseif( 's' == strtolower($format) ){
				
				$ergebnis = $this->chaptaUtility->verifyInput( $surveyUid );
				if( $ergebnis != 1 ) return $this->chaptaUtility->displayChapter( $surveyUid , $md5remKey );
				
				$uxStartDate = $userSurvey->getStartDate()->format('U');
				$daysFromStartToRemoteEnd = $userSurvey->getExpireDays() + $userSurvey->getRemoteDays();
				$endRemoteDatum = $uxStartDate + ( $daysFromStartToRemoteEnd * (3600*24) );
				if( $endRemoteDatum < time() ) return '<b>Die Zugriffszeit ist abgelaufen. Kein Report gesendet!</b>';
				return $this->mailUtility->sendPdfData( $userSurvey );
	    }
	    return 'Keine Aktion. ' . $errorMessage;
	}

	/**
	* displayDownloadChapter
	*
	* @return void
	*/
	private function displayDownloadChapter( $surveyUid , $md5remKey ){
				
				$aVariables = [ 'basis' => (mt_rand( 4 , 15 ) * 5), 'functionIndex' => mt_rand( 0 , 1 ) , 'einfluss' => (mt_rand( 1 , 3 ) * 5) ];
				$result = $aVariables['functionIndex'] ? $aVariables['basis'] + $aVariables['einfluss'] : $aVariables['basis'] - $aVariables['einfluss'] ;
				$secret = 2;
				
				$aOldVariables = $GLOBALS['TSFE']->fe_user->getKey('ses', 'chapta' );
				$increasedError = isset($aOldVariables[$surveyUid]['errors']) ? $aOldVariables[$surveyUid]['errors']+1 : 0;
				$aOldVariables[$surveyUid] = ['result'=>$result , 'errors'=> $increasedError ];
				$GLOBALS['TSFE']->fe_user->setKey('ses', 'chapta' , $aOldVariables );

				$aFunctions = [ 'minus' , 'plus' ];
				$aFifeWords = [ 'Null' , 'Fünf' , 'Zehn' , 'Fünfzehn' , 'Zwanzig' , 'Fünfundzwanzig' , 'Dreissig' , 'Fünfunddreissig' , 'Vierzig' , 'Fünfundvierzig' , 'Fünfzig' , 'Fünfundfünfzig' , 'Sechzig' , 'Fünfundsechzig' , 'Siebzig' , 'FünfundSiebzig' , 'Achtzig' , 'FünfundAchzig' ];
				
				$sFunction = $aFunctions[ $aVariables['functionIndex'] ];
				
				$output = '<div style="text-align:center;" class="attention"> In Arbeit... einen Moment bitte. ';
				$output .= '<br />Eilige wenden sich an daniel&nbsp;.&nbsp;rueegg [ at ] sfgz . c h ';
				$output .= '<p>Bitte Resultat als Zahl angeben: <br /> ';
				$output .= ' Wie viel ergibt ';
				$output .= '' . $aFifeWords[$aVariables['basis']/5] . ' ' . $sFunction . ' ' . $aFifeWords[$aVariables['einfluss']/5] . '?';
				$output .= '</p>';

				$output .= $this->getDownloadForm( $surveyUid , $md5remKey );
				
				$output .= '</div>';
                return $output;
	
	}
	

	/**
	* getDownloadForm
	*
	* @return string
	*/
	private function getDownloadForm( $surveyUid , $md5remKey ){
	    $aVariables = $GLOBALS['TSFE']->fe_user->getKey('ses', 'chapta' );
	    $result = isset($aVariables[$surveyUid]['result']) ? $aVariables[$surveyUid]['result'] : 0;
				$output = '<form name="listSurvey" id="user_survey" action="/" method="post">';
				$output .= 'fe_user ' . $result . '<p>';
				$output .= '<input type="hidden" name="type" value="43" >';
				$output .= '<input type="hidden" name="uid" value="' . $surveyUid . '" >';
				$output .= '<input type="hidden" name="fmt" value="s" >';
				$output .= '<input type="text" name="ergebnis" >';
				$output .= '<input type="hidden" name="remKey" value="' . $md5remKey . '" >';
				$output .= '</p><p>';
				$output .= '<input type="submit" value="PDF herunterladen" class="pdf" />';
				$output .= '</p>';
				$output .= '</form>';
				$output .= '<p>Diese Massname hindert Roboter am auslösen von Emails.</p>';
                return $output;
	}

	/**
	* displayInvitation
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function displayInvitation( $userSurvey ){

	    $uriForSurvey =  $this->settings['lsBaseUrl'] . '/'.$this->settings['token'].'/'.$userSurvey->getSurveyUid();
	    $conf = array('extTarget'=>'_blank','parameter'=>$uriForSurvey);
		$linkForSurvey = $this->cObj->TypoLink($uriForSurvey,$conf);

		$uriForQrCode =  $this->settings['baseUrl'] . '/typo3conf/ext/mff_lsb/Resources/Public/PHP/qrcode.php?b=0&amp;s='.$this->settings['barcode_size'].'&msg=' . $uriForSurvey;
		
		$uxStartDate = $userSurvey->getStartDate()->format('U');
		$dtStartDate = $userSurvey->getStartDate()->format('d.m.Y');
		
		$endDatum = $uxStartDate + ( $userSurvey->getExpireDays() * (3600*24) );
		$now = time();
		
			$objTpSurvey = $userSurvey->getUserTpSurvey();
			$pdfSettingsNr = $this->settings['use_pdf_basics'];
			if( $objTpSurvey ){
					$pdfSettingsNr = $objTpSurvey->getPdfSettings();
					if( empty($pdfSettingsNr) ){
						$pdfSettingsNr = $this->settings['use_pdf_basics'];
					}
			}
			if(empty($pdfSettingsNr)) $pdfSettingsNr = 0;
			$templateRelatedPdfSettings = $this->settings['pdf_basics'][ $pdfSettingsNr ];
		
		$warning = '';
		if( $uxStartDate > $now && date('d.m.Y',$now) != $dtStartDate ){
				$error = 'toearly';
		}elseif( $endDatum < $now && date('d.m.Y',$now) != date('d.m.Y' , $endDatum ) ){
				$error = 'tolate';
		}
		if( isset($error) ){
				$indiStyle = array( 'toearly'=>'background:#ee0;' , 'tolate'=>'background:#fa0;' );
				$style = $indiStyle[$error].'font-size:150%;border:1px solid #f00;padding:3px;margin:0 13px;border-radius:2px;';
				$warntext = LocalizationUtility::translate('display.invitation.error.' . $error , 'mff_lsb');
				$warning = '<div style="padding-top:5px;"><div style="'.$style.'">'.$warntext.'</div></div>';
		}
		
		$datefrom = LocalizationUtility::translate('display.label.datefrom.' . $pdfSettingsNr , 'mff_lsb');
		$enquirer = LocalizationUtility::translate('display.label.enquirer.' . $pdfSettingsNr , 'mff_lsb');
		$course = LocalizationUtility::translate('display.label.course.' . $pdfSettingsNr , 'mff_lsb');
		$subject = LocalizationUtility::translate('display.label.subject.' . $pdfSettingsNr , 'mff_lsb');
		
	    $titleOfSurvey = '
	    <div style="width:auto;padding-top:8px;white-space:nowrap;overflow:visible;">
		<table cellpadding="13" cellspacing="0" >
		  <tr><td>
		      <img alt="qrc" src="'.$uriForQrCode.'">
		  </td>
		  <td style="vertical-align:top;">
			<table style="line-height:120%;font-size:130%;">
			<tbody>
			<tr><td colspan="2">' . $userSurvey->getTemplateName().'</td></tr>
			<tr><td>'.$datefrom.':   </td><td><b>' . $dtStartDate.'</b></td></tr>
			<tr><td>'.$enquirer.':  </td><td><b>' . $userSurvey->getEnquirerName().'</b> </td></tr>
			<tr><td>'.$course.':      </td><td><b>' . $userSurvey->getCourseName().'</b> </td></tr>
			<tr><td style="vertical-align:top;">'.$subject.':        </td><td style="white-space:normal;"><b>' . $userSurvey->getSubject().'</b></td></tr>
			</tbody></table>
		 </td></tr>
		  <tr><td colspan="2">
			<div style="font-size:20pt;margin:0;">
					<span style="border-bottom:1px solid #5b1" class="blackhover">
					'.$linkForSurvey.'
					</span>
			</div>
		 </td></tr>
		 </table>
	    </div>
	    ';
	    return  $warning. ''.$titleOfSurvey.'';

 	}


}

