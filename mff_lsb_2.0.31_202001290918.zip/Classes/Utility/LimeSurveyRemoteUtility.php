<?php
namespace Mff\MffLsb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class LimeSurveyRemoteUtility
 */

class LimeSurveyRemoteUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* options
	*
	* @var array
	*/
	Public $options = array( 'skipFromAnswers'=>array('id','submitdate','lastpage','startlanguage') );
	
	/**
	* __construct
	*
	* @param array $settings
	* @return void
	*/
	public function __construct( $settings = array() ) {
		$this->settings = $settings;
		$pathToLsJsonLib = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'EXT:mff_contrib/Resources/Private/PHP/jsonRPCClient' );
		require_once $pathToLsJsonLib.'/jsonRPCClient.php';
	}
	
	public function initiateRPCClient( ){
 	    $this->myJSONRPCClient = new \JsonRPCClient( $this->settings['lsBaseUrl'].'/index.php/admin/remotecontrol' );
	    $this->sessionKey = $this->myJSONRPCClient->get_session_key( $this->settings['lsUsername'], $this->settings['lsPassword'] );
	}
	public function releaseRPCClient( ){
	    $this->myJSONRPCClient->release_session_key( $this->sessionKey );
	}
	public function create_SurveyByFile( $newSurveyName , $fileContent ){
	    $umfrage_id = $this->myJSONRPCClient->import_survey( $this->sessionKey, base64_encode($fileContent) , 'lss' , $newSurveyName );
	    if( is_array($umfrage_id) ) return false; // an error recourred, eg. [status] => 'no permission'
	    $this->myJSONRPCClient->activate_tokens(  $this->sessionKey,$umfrage_id );
	    return $umfrage_id;
	}
	public function activate_survey( $surveyID ){
	    $this->myJSONRPCClient->activate_survey( $this->sessionKey , $surveyID );
	}
	
// 	public function edit_survey( $aSurveySettings , $surveyID ){
// 	    $this->myJSONRPCClient->set_survey_properties( $this->sessionKey , $surveyID , $aSurveySettings );
// 	}
	
	public function set_surveyFields( $aSurveyLocaleData , $surveyID ){
	    // examples for aSurveyLocaleData: admin, adminemail, expires Y-m-d H:i:s, bounce_email
		$result[] = $this->myJSONRPCClient->set_survey_properties( $this->sessionKey , $surveyID , $aSurveyLocaleData['surveys'] );
	    // examples for aSurveyLocaleData: surveyls_title, surveyls_welcometext, surveyls_email_invite , surveyls_email_remind 
	    if( isset($aSurveyLocaleData['surveys_languagesettings']) ) $result[] = $this->myJSONRPCClient->set_language_properties( $this->sessionKey , $surveyID , $aSurveyLocaleData['surveys_languagesettings'] , 'de' );
	    return $result;
	}
	
	public function get_surveyFields( $aSurveyLocaleData , $surveyID ){
	    if( isset($aSurveyLocaleData['surveys']) ) $result['surveys'] = $this->myJSONRPCClient->get_survey_properties( $this->sessionKey , $surveyID , $aSurveyLocaleData  );
	    if( isset($aSurveyLocaleData['surveys_languagesettings']) ) $result['surveys_languagesettings'] = $this->myJSONRPCClient->get_language_properties( $this->sessionKey , $surveyID , $aSurveyLocaleData , 'de' );
	    return $result;
	}
	public function delete_survey( $surveyID ){
	    $this->myJSONRPCClient->delete_survey( $this->sessionKey , $surveyID );
	}
	public function set_group_properties( $aGroupData , $groupID ){
	    // optiond for $aGroupData: description, language, group_name, randomization_group, group_order, grelevance
	    $this->myJSONRPCClient->set_group_properties( $this->sessionKey , $groupID , $aGroupData );
	}
	public function set_participant_properties( $surveyID , $token , $aTokenData){
	    return $this->myJSONRPCClient->set_participant_properties( $this->sessionKey , $surveyID , $token , $aTokenData );
	}
	public function add_participants( $participantData , $surveyID ){
	    $createTokenKey = false;
	    $newPartData = $this->myJSONRPCClient->add_participants( $this->sessionKey, $surveyID , $participantData ,$createTokenKey  );
	    foreach(array_keys($newPartData) as $k){
		if(is_numeric($k))$participantData[$k]['token'] = $newPartData[$k]['token'];
	    }
	    $this->participiantList = $participantData;
	    return $participantData;
	}
	public function invite_participants( $surveyID ){
	   $this->myJSONRPCClient->invite_participants( $this->sessionKey , $surveyID );
	}
	public function remind_participants( $surveyID , $iMinDaysBetween=1 ){
	   $this->myJSONRPCClient->remind_participants( $this->sessionKey , $surveyID , $iMinDaysBetween );
	}
	public function delete_participants( $aTokenIDs , $surveyID ){
	    foreach(array_keys($aTokenIDs) as $k){ unset($this->participiantList[$k]); }
	    return $this->myJSONRPCClient->delete_participants( $this->sessionKey , $surveyID , $aTokenIDs );
	}
 	public function list_allParticipants( $surveyID ){
 	    $participiantList = $this->list_participants( $surveyID , 1 );
 	    $this->participiantList = $this->list_participants( $surveyID , 0 , $participiantList );
 	    return $this->participiantList;
	}
	public function list_participants( $surveyID , $is_used=0 , $participiantList=array() ){
	    // $is_used=1 starts width onlyUnused=FALSE and gets all
	    // $is_used=0 starts width onlyUnused=TRUE and gets only unused Tasks
 	    $unusedParticipantData = $this->myJSONRPCClient->list_participants( $this->sessionKey , $surveyID , 0 , 250 , empty($is_used) );
	    foreach(array_keys($unusedParticipantData) as $k){
		$tid = $unusedParticipantData[$k]['tid'];
		$participiantList[$tid]['tid'] = $tid;
		$participiantList[$tid]['token'] = $unusedParticipantData[$k]['token'] ;
		foreach($unusedParticipantData[$k]['participant_info'] as $fld=>$cnt) $participiantList[$tid][$fld] = $cnt;
		$participiantList[$tid]['used'] = $is_used;
	    }
 	    return $participiantList;
	}
	
	public function get_responses( $surveyID ){
	      $aSummary = array('responses'=>array());
	      $aResponses = $this->export_responses($surveyID);
	      $skippedFields = array_flip($this->options['skipFromAnswers']);
	      if(is_array($aResponses['responses'])){
		    foreach($aResponses['responses'] as $respContainer){
			  foreach($respContainer as $response) {
				foreach($response as $longfield => $assessmentValue) {
				      if(!isset( $response['id'] )) continue;
				      if(isset( $skippedFields[$longfield] )) continue;
				      if(empty($assessmentValue)) continue;
				      $aRealKey = explode( '[' , str_replace( ']' , '' , $longfield) );
				      if( count($aRealKey) == 1 ){
					    $aSummary['responses'][$response['id']][$aRealKey[0]] = $assessmentValue;
				      }else{
					    $aSummary['responses'][$response['id']][$aRealKey[0]][$aRealKey[1]] = $assessmentValue;
				      }
				}
			  }
		    }
			$z=0;
			foreach($aSummary['responses'] as $sortResp){ ++$z;$outResp['responses'][$z] = $sortResp; }
	      }
	      return $outResp;
	}
	public function export_responses( $surveyID ){
	    $richRawData = $this->myJSONRPCClient->export_responses( $this->sessionKey , $surveyID , 'json' , null,'complete', 'code', 'short');
	    // NEW since 2.05+ change in /application/libraries/BigData.php
	    $from = array( '<string>' , '</string>' );
	    $to = array( '' , '' );
	    $rawData = str_replace( $from , $to ,  $richRawData );
	    //
	    if(isset($rawData['status'])){return;}
	    $larr=json_decode(base64_decode($rawData) , true );
	    return $larr;
	}
	public function get_summary( $surveyID ){
	    return $this->myJSONRPCClient->get_summary( $this->sessionKey , $surveyID , 'all' );
	}

	public function list_questions( $surveyID ){
	    // $quarr = array(
	    // 		z=>array( id=>array( qid , language ) , title , type , question )
	    // )
	    $qarr =  $this->myJSONRPCClient->list_questions( $this->sessionKey , $surveyID );
	    
	    $inDB = array();
	    $subDB = array();
	    $outDB = array();
	    $grpProp=array();
	    foreach($qarr as $ix=>$questRs){
		$qid = $questRs['id']['qid'];
		$ansOpt= $this->myJSONRPCClient->get_question_properties( $this->sessionKey , $questRs['id']['qid'] , array('question_order','gid','answeroptions','parent_qid') );
		    $GID = $ansOpt['gid'];
		    if(!isset($grpProp[$GID])){
			$prop = $this->myJSONRPCClient->get_group_properties( $this->sessionKey , $GID , array('gid','group_order','group_name') );
			$grpProp[$GID] = $prop['group_order'];
			$grpName[$GID] = $prop['group_name'];
			$grpDB[$GID] = $prop;
		    }
		    $order = 10000 + $ansOpt['question_order'];
		    if(empty($ansOpt['parent_qid'])){ // normal question
			$inDB[$GID][$order][$qid]['title'] = $questRs['title'];
			$inDB[$GID][$order][$qid]['type'] = $questRs['type'];
			$inDB[$GID][$order][$qid]['question'] = $questRs['question'];
			$inDB[$GID][$order][$qid]['description'] = $grpName[$GID];
		    }else{ // subquestion
			$subDB[$GID][ $ansOpt['parent_qid'] ][$order][$qid]['title'] = $questRs['title'];
			$subDB[$GID][ $ansOpt['parent_qid'] ][$order][$qid]['question'] = $questRs['question'];
		    }
		    if(is_array($ansOpt['answeroptions'])){
			foreach($ansOpt['answeroptions'] as $ansCode=>$ansRow){
			    $inDB[$GID][$order][$qid]['answers'][$ansCode] = $ansRow['answer'];
			    $inDB[$GID][$order][$qid]['assessments'][$ansCode] = $ansRow['assessment_value'];
			}
		    }
	    }
	    asort($grpProp);
	    foreach($grpProp as $gid=>$srt){
		$inGrp = $inDB[$gid];
		$outDB['groups']=$grpDB[$gid];
		ksort($inGrp);
		foreach($inGrp as $rows){
		    foreach($rows as $qid=>$row){
			$outDB['questions'][$gid][$qid]=$row;
			if(!is_array($subDB[$gid][$qid]))continue;
			ksort($subDB[$gid][$qid]);
			foreach($subDB[$gid][$qid] as $o=>$orow){
			    foreach($orow as $ssid=>$subRow){$outDB['questions'][$gid][$qid]['subquestion'][$ssid]=$subRow;}
			}
		    }
		}
	    }
	    return $outDB;
	}
}
