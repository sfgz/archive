<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpSubquestionController
 */
class TpSubquestionController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * tpSubquestionRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpSubquestionRepository
     * @inject
     */
    protected $tpSubquestionRepository = null;
    
    protected $objectManager ;

    public function initializeAction() {
	  $this->contentObj = $this->configurationManager->getContentObject();
	  $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	  $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	  $storage = explode( ',' , $this->contentObj->data['pages'] );
	  $storage['storagePidTemplate'] = $fullsettings['plugin.']['tx_mfflsb_template.']['persistence.']['storagePid'];
	  $this->settings['storage'] = implode( ',' , $storage );
    }
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $tpSubquestions = $this->tpSubquestionRepository->findAll();
        $this->view->assign('tpSubquestions', $tpSubquestions);
        $this->view->assign('contentUid', $this->contentObj->data['uid'] );
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * action create
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $newTpSubquestion
     * @return void
     */
    public function createAction(\Mff\MffLsb\Domain\Model\TpSubquestion $newTpSubquestion)
    {
        $this->addFlashMessage('The object was created. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpSubquestionRepository->add($newTpSubquestion);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion
     * @ignorevalidation $tpSubquestion
     * @return void
     */
    public function editAction(\Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion)
    {
        $this->view->assign('tpSubquestion', $tpSubquestion);
        $pageType = 0;
        if($this->request->hasArgument('pageType')){
	      $pageType=$this->request->getArgument('pageType');
        }else{
	      $pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        }
        $this->view->assign('pageType', $pageType);
	$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
        if($contentUid) $this->view->assign('contentUid', $contentUid );
        if($this->request->hasArgument('sid')){
	      $this->view->assign('sid',$this->request->getArgument('sid') );
        }
    }

    /**
     * action update
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion
     * @return void
     */
    public function updateAction(\Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion)
    {
        $this->addFlashMessage('The object was updated. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpSubquestionRepository->update($tpSubquestion);
	$pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        if( $pageType != 95 ) $this->redirect('list');
	$forwardingArguments['tpSubquestion'] = $tpSubquestion;
	$forwardingArguments['pageType'] = $pageType;
//         if($this->request->hasArgument('sid')){
// 	    $forwardingArguments['tpSurvey'] = $this->request->getArgument('sid');
// 	    $this->forward('edit', 'TpSurvey', 'MffLsb', $forwardingArguments);
//         }
	$this->forward('edit', NULL, NULL, $forwardingArguments);
    }

    /**
     * action delete
     *
     * @param \Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion
     * @return void
     */
    public function deleteAction(\Mff\MffLsb\Domain\Model\TpSubquestion $tpSubquestion)
    {
        $this->addFlashMessage('The object was deleted. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpSubquestionRepository->remove($tpSubquestion);
        $this->redirect('list');
    }
}
