<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpSurveyController
 */
class TpSurveyController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {
    /**
     * tpSurveyRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
     * @inject
     */
    protected $tpSurveyRepository = null;
    
    /**
     * tpGroupRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpGroupRepository
     * @inject
     */
    protected $tpGroupRepository = null;
    
    protected $objectManager ;

    /**
      * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
      */
    protected $persistenceManager = NULL;

    /**
      * initializeAction
      *
      */
    public function initializeAction() {
	  $this->contentObj = $this->configurationManager->getContentObject();
	  $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	  $this->persistenceManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $this->fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($this->fullsettings['plugin.']['tx_mfflsb_template.']['settings.']);
	      $this->settings['baseUrl'] = $this->fullsettings['config.']['baseURL'];
	      $pluginStoragePid = $this->fullsettings['plugin.']['tx_mfflsb_template.' ]['persistence.']['storagePid'];
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setStoragePageIds( array( 'storagePid_template'=>$pluginStoragePid ) );
	      $this->tpSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSurveyRepository');
	      $this->tpSurveyRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpGroupRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpGroupRepository');
	      $this->tpGroupRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpQuestionRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpQuestionRepository');
	      $this->tpQuestionRepository->setDefaultQuerySettings($this->querySettings);
	      $this->tpSubquestionRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSubquestionRepository');
	      $this->tpSubquestionRepository->setDefaultQuerySettings($this->querySettings);
	      
	      $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $userQuerySettings->setRespectStoragePage(FALSE);
	      $userQuerySettings->setStoragePageIds( array( $this->fullsettings['plugin.']['tx_mfflsb_remote.' ]['persistence.']['storagePid'] ) );
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings( $userQuerySettings );
    }
	
    /**
     * action list
     *
     * @return void
     */
    public function listAction() {
		if( $this->request->hasArgument('dupliz') ){
			$uidToDupliz = $this->request->getArgument('dupliz');
			$tpSurvey = $this->tpSurveyRepository->findByUid( $uidToDupliz );
			$operationsUtility = new \Mff\MffLsb\Utility\TemplateOperationsUtility();
			$newSurvey = $operationsUtility->duplicateTpSurvey( $tpSurvey );
			$this->addFlashMessage('Die Vorlage #' . $tpSurvey->getUid() . ' wurde dupliziert zu #'.$newSurvey->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
        $tpSurveys = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , false , true );
        $this->view->assign('tpSurveys', $tpSurveys);
        $this->view->assign('contentUid', $this->contentObj->data['uid'] );
        
		// Get the data from content-object (contains the tt_content fields)
		$data = $this->configurationManager->getContentObject()->data;
		// Append flexform values
		$this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
		// get external div if set, else set default for list
		$externalDiv = !empty($data['external_div']) ? $data['external_div'] : 'templateGroupOptionsInListDiv'; 
		$this->view->assign('externalDiv', $externalDiv );
	    
        if($this->request->hasArgument('deAndActivate')){
	      $uidToChangeActivityState = $this->request->getArgument('deAndActivate');
	      $tpSurvey = $this->tpSurveyRepository->findByUid( $uidToChangeActivityState );
	      if(!$tpSurvey) {echo '! '.$uidToChangeActivityState ;return;}
	      $hideIt = $tpSurvey->isVersteckt() == true ? 0 : 1;
	      $tpSurvey->setVersteckt( $hideIt );
	      $this->tpSurveyRepository->update($tpSurvey);
        }
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction() {
		$newTpSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\TpSurvey');
		$newTpSurvey->setPdfSettings( $this->settings['use_pdf_basics'] );
		$this->view->assign('newTpSurvey', $newTpSurvey );
		$this->view->assign('settings', $this->settings );

    }

    /**
     * action create
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $newTpSurvey
     * @return void
     */
    public function createAction(\Mff\MffLsb\Domain\Model\TpSurvey $newTpSurvey) {
        $this->addFlashMessage('The object was created. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpSurveyRepository->add($newTpSurvey);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey
     * @ignorevalidation $tpSurvey
     * @return void
     */
    public function editAction(\Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey) {
        $aXmlData = json_decode($tpSurvey->getTemplateXml() ,true);
        $this->view->assign('xmlData', $aXmlData );
        
        $this->view->assign('tpSurvey', $tpSurvey);
        $pageType = 0;
        if($this->request->hasArgument('pageType')){
	      $pageType=$this->request->getArgument('pageType');
        }else{
	      $pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        }
        $this->view->assign('pageType', $pageType);
        
		$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
        if($contentUid) $this->view->assign('contentUid', $contentUid );
    }

    /**
     * action update
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey
     * @return void
     */
    public function updateAction(\Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey) {
			$fileploader = new \Mff\MffLsb\Utility\FileUploadUtility();
			$neueDatei = $fileploader->uploadCsvFile( 'tx_mfflsb_template' , 'dateiname' );
			$aCreateRecords = array();
			$aTemplateXml = array();
			if( count($fileploader->hints['OK']) ){
				// if file upload was successfull read data in 2 arrays, 
				// $aTemplateXml - store surveys data in the field TmplateXml 
				// $aCreateRecords - create question-rescords
				$xmlPhpUtility = new \Mff\MffLsb\Utility\XmlToPhpArrayUtility();
				$fullFilePathName = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($fileploader->uploadDir . $neueDatei );
				$aTemplateXml = $xmlPhpUtility->readFromFile( $fullFilePathName , true );
				$aCreateRecords = $xmlPhpUtility->limeSurveyArrToFlatDbArr( $aTemplateXml );
				$fileploader->deleteFile($neueDatei);
				$this->addFlashMessage( implode( ', ' , $fileploader->hints['OK']) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}elseif( count($fileploader->hints['ERROR']) ){
				// file upload was NOT successfull:
				$this->addFlashMessage( implode( ', ' , $fileploader->hints['ERROR']) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}else{
				// no file upload registered - read surveys data from the field TmplateXml 
				$aTemplateXml = json_decode($tpSurvey->getTemplateXml() , true);
			}
			
			// store changed or new values in xml-field
			if(count($aTemplateXml)){
				// fill array with values from typoscript
				foreach( $this->settings['defaultPropertiesLimeSurveyXml'] as $section => $overrideField ){
				foreach( $overrideField as $xmlName => $value ){
					$aTemplateXml[$section]['rows']['row'][$xmlName] = $value ;
				}
				}
				// fill array with values from typo3-database
				foreach( $this->settings['mapPropertiesToLimeSurveyXml'] as $section => $overrideField ){
				foreach( $overrideField as $xmlName => $dbField ){ 
					$atoms = explode( '_' , $dbField );
					foreach($atoms as $i=>$w){ $atoms[$i] = ucFirst($w); }
					$method = 'get' . implode($atoms);
					if( method_exists($tpSurvey,$method) ) $aTemplateXml[$section]['rows']['row'][$xmlName] =  $tpSurvey->$method() ;
				}
				}
				$welcomeText = $tpSurvey->getWelcomeText();
				$aTemplateXml['surveys']['rows']['row']['showwelcome'] = empty($welcomeText) ? 'N' : 'Y';
				$dataToSave['surveys'] = $aTemplateXml['surveys'];
				$dataToSave['surveys_languagesettings'] = $aTemplateXml['surveys_languagesettings'];
				
				$tpSurvey->setTemplateXml( json_encode( $dataToSave ) );
			}
			
			$this->tpSurveyRepository->update($tpSurvey);
			$this->persistenceManager->persistAll();
			$this->addFlashMessage('The object was updated. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			
			$operationsUtility = new \Mff\MffLsb\Utility\TemplateOperationsUtility($this->settings);
			// if file is uploadet create new recordsets for groups, questions and subquestions
			if( is_array($aCreateRecords['groups']) ) {
				if( $operationsUtility->addQuestionsToSurvey( $tpSurvey , $aCreateRecords ) ){
					$this->addFlashMessage('Questions created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				}
			}
			// duplicate the whole template
			if( $this->request->hasArgument('dupliz') ){
				$newSurvey = $operationsUtility->duplicateTpSurvey( $tpSurvey );
				$this->addFlashMessage('Die Vorlage #' . $tpSurvey->getUid() . ' wurde dupliziert zu #'.$newSurvey->getUid().'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
			$this->persistenceManager->persistAll();

			$pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
				if( $pageType != 95 ) $this->redirect('list');
			$forwardingArguments['tpSurvey'] = $tpSurvey;
			$forwardingArguments['pageType'] = $pageType;
			$this->forward('edit', NULL, NULL, $forwardingArguments);
			// redirect uebergibt vollstdg object, aber pageType geht verloren
			// forward uebergibt neue sub-objects nicht, aber pageType stimmt
    }

    /**
     * action delete
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey
     * @ignorevalidation $tpSurvey
     * @return void
     */
    public function deleteAction(\Mff\MffLsb\Domain\Model\TpSurvey $tpSurvey) {
        $userSurveys = $this->userSurveyRepository->findByUserTpSurvey( $tpSurvey->getUid() );
        if( count($userSurveys) ){
			$tpSurvey->setVersteckt(1);
			$this->tpSurveyRepository->update($tpSurvey);
			$this->addFlashMessage('Die Vorlage wird noch verwendet und kann nicht entfernt werden. Sie wird stattdessen versteckt. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        }else{
			$this->addFlashMessage('Die Vorlage wurde gelöscht. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
			$this->tpSurveyRepository->remove($tpSurvey);
        }
		$this->redirect('list');
    }

    /**
    * Action printout
    *
    * @return void
    */
    public function printoutAction() {
			// Get the data from content-object (contains the tt_content fields)
			// Append flexform values
			$data = $this->configurationManager->getContentObject()->data;
			$this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
			$externalDiv = !empty($data['external_div']) ? $data['external_div'] : 'templateGroupOptionsDiv'; 
			$this->view->assign('externalDiv', $externalDiv );
			
			if ($this->request->hasArgument('download')) {
				$dwnResult = $this->handleDownloads( $this->request->getArgument('download') );
				$this->addFlashMessage($dwnResult, '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
			$ReturnRawQueryResult = false;
			$ignoreHidden = false;
			$tpSurveys = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , $ReturnRawQueryResult, $ignoreHidden );
			$this->view->assign('Surveytemplates', $tpSurveys);
			$this->view->assign('contentUid', $this->contentObj->data['uid'] );
			$this->view->assign('manual_settings', $this->settings);
    }

    /**
    * Action printout
    *
    * @return void
    */
    public function handleDownloads( $dwonloadType ) {
	  if( $dwonloadType == 'vorlage_leer' ){
		  $templateUid = $this->request->getArgument('tpSurvey');
		  $tpSurvey = $this->tpSurveyRepository->findByUid($templateUid);
		  $reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
		  $xmlDb = $reportUtility->showObjectData( $templateUid );
		  $templateGroupOptions = $reportUtility->repairMacCharset( json_encode($xmlDb['question']) );
		  $aQst = $reportUtility->questionsFieldToArray( $templateGroupOptions );
		  $aQst = $reportUtility->deleteEmptyOptionalRows($aQst);
		  $aSortGroups = $reportUtility->getReportValues( $aQst );
		  
		  $pdfSettingsNr = $tpSurvey->getPdfSettings();
		  $use_pdf_basics = empty($pdfSettingsNr) ? 0 : $pdfSettingsNr;
		  $aSortGroups['survey']['settings'] = $this->settings['pdf_basics'][ $use_pdf_basics ];
		  $aSortGroups['survey']['templatename'] = $tpSurvey->getTemplateName() ;
		  
		  $aSortGroups['survey'] = $reportUtility->replaceSettingsForEmptyReport( $aSortGroups['survey'] , 1 );
		  
		  unset( $aSortGroups['singles'] );
		  $aSortGroups['template'] = $tpSurvey; // ? used?
		  
		  $reportData = $reportUtility->getPdfReportValues( $aSortGroups );
		  
		  $pdfUtility = new \Mff\MffLsb\Utility\PdfPrintoutUtility( $this->settings );
		  $pdfUtility->pdfTemplate( $reportData ); // causes exit();
	  }else{
		  $uploadDir = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( ltrim($this->settings['upload_dir'] , '/') ) , '/' ) . '/';
		  $file_url = $uploadDir.$dwonloadType;
		  $downloadFileName = 'Vorgehen_Durchfuehrungsbestaetigung.pdf';
		  if( file_exists($file_url) && !empty($dwonloadType) && is_file($file_url) ){
			header('Content-Type: application/force-download');
			header('Content-Type: application/pdf');
			header("Content-Transfer-Encoding: Binary");
			header("Content-disposition: attachment; filename=".$downloadFileName);
			readfile($file_url);
			exit();
		  }
	  }
	  return 'herunterladen misslungen';
    }
}
