<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpGroupController
 */
class TpGroupController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * tpGroupRepository
     *
     * @var \Mff\MffLsb\Domain\Repository\TpGroupRepository
     * @inject
     */
    protected $tpGroupRepository = null;
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction()
    {
        $tpGroups = $this->tpGroupRepository->findAll();
        $this->view->assign('tpGroups', $tpGroups);
    }

    /**
     * action new
     *
     * @return void
     */
    public function newAction()
    {

    }

    /**
     * action create
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $newTpGroup
     * @return void
     */
    public function createAction(\Mff\MffLsb\Domain\Model\TpGroup $newTpGroup)
    {
        $this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpGroupRepository->add($newTpGroup);
        $this->redirect('list');
    }

    /**
     * action edit
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $tpGroup
     * @ignorevalidation $tpGroup
     * @return void
     */
    public function editAction(\Mff\MffLsb\Domain\Model\TpGroup $tpGroup)
    {
        $this->view->assign('tpGroup', $tpGroup);
        $pageType = 0;
        if($this->request->hasArgument('pageType')){
	      $pageType=$this->request->getArgument('pageType');
        }else{
	      $pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        }
        $this->view->assign('pageType', $pageType);
	$contentUid = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('cnt');
        if($contentUid) $this->view->assign('contentUid', $contentUid );
        if($this->request->hasArgument('sid')){
	      $this->view->assign('sid',$this->request->getArgument('sid') );
        }
        $iReportPartials = $tpGroup->getReportPartials();
        $aReportPartials['spider'] = ($iReportPartials >= 4 ) ? 1 : 0;
        $aReportPartials['einzelfragen'] = ($iReportPartials - ($aReportPartials['spider']*4) >= 2 ) ? 1 : 0;
        $aReportPartials['auswertung'] = ($iReportPartials - ( ($aReportPartials['spider']*4) + ($aReportPartials['einzelfragen']*2)) >=1 ) ? 1 : 0;
	$this->view->assign('aReportPartials',$aReportPartials );
    }

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		if ($this->request->hasArgument('tpGroup')) {
			$bel = $this->request->getArgument('tpGroup');
			if(!empty($bel['reportPartials'])) {
			      $this->arguments->getArgument('tpGroup')->getPropertyMappingConfiguration()->skipProperties('reportPartials');
			}
		}
	}

    /**
     * action update
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $tpGroup
     * @return void
     */
    public function updateAction(\Mff\MffLsb\Domain\Model\TpGroup $tpGroup)
    {
        $this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
		if ($this->request->hasArgument('tpGroup')) {
			$bel = $this->request->getArgument('tpGroup');
			if(!empty($bel['reportPartials'])) {
			      $tpGroup->setReportPartials( array_sum($bel['reportPartials']) );
			}
		}
        $this->tpGroupRepository->update($tpGroup);
//         $this->redirect('list');
	$pageType = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET('type');
        if( $pageType != 95 ) $this->redirect('list');
	$forwardingArguments['tpGroup'] = $tpGroup;
	$forwardingArguments['pageType'] = $pageType;
//         if($this->request->hasArgument('sid')){
// 	    $forwardingArguments['tpSurvey'] = $this->request->getArgument('sid');
// 	    $this->forward('edit', 'TpSurvey', 'MffLsb', $forwardingArguments);
//         }
	$this->forward('edit', NULL, NULL, $forwardingArguments);
    }

    /**
     * action delete
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $tpGroup
     * @return void
     */
    public function deleteAction(\Mff\MffLsb\Domain\Model\TpGroup $tpGroup)
    {
        $this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
        $this->tpGroupRepository->remove($tpGroup);
        $this->redirect('list');
    }
}
