<?php
namespace Mff\MffLsb\Controller;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * RemoteSurveyController
 */
class RemoteSurveyController extends \Mff\MffLsb\Controller\UserSurveyController
{
	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	* @inject
	*/
	protected $userSurveyRepository = null;

	/**
	* tpSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\TpSurveyRepository
	* @inject
	*/
	protected $tpSurveyRepository = null;

	/**
	* classtemplateRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\ClasstemplateRepository
	*/
	protected $classtemplateRepository = null;

	/**
	 * timetableRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TimetableRepository
	 */
	protected $timetableRepository = NULL;

	/**
	 * stundenplanRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\StundenplanRepository
	 */
	protected $stundenplanRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository
	 */
	protected $frontendUserRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;
    
    protected $objectManager ;
	
    public function initializeAction() {
		$this->initialize_basics();
		$this->initialize_useroptions();
		if( !$this->request->hasArgument('action') && $this->settings['startlayout'] == 2 )  $this->forward('list', NULL, NULL, array( 'action' => 'list' ) );
    }
	
    public function initialize_basics() {
	      date_default_timezone_set( 'Europe/Zurich' );
	      $this->GmtZone = new \DateTimeZone('GMT');
 	      $this->timeZone = new \DateTimeZone('Europe/Zurich');
//	      $this->timeZone = new \DateTimeZone('GMT');
	      
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
 	      $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $this->contentObj = $this->configurationManager->getContentObject();
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $templateStoragePid['templateStoragePid'] = $fullsettings['plugin.']['tx_mfflsb_template.']['persistence.']['storagePid'];
	      $storage['timetableStoragePid'] = $fullsettings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
	      $storage['stundenplanStoragePid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
// 	      $this->typoScriptService = new \TYPO3\CMS\Extbase\Service\TypoScriptService();
// 	      $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray($fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']);
		  if(!$this->settings['autoupdate_after_minutes'])$this->settings['autoupdate_after_minutes']=1;
	      $this->settings['storagePid'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['persistence.']['storagePid'];
	      $this->settings['teacherPid'] = $fullsettings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
	      $this->settings['baseUrl'] = $fullsettings['config.']['baseURL'];
	      $this->settings['token'] = $fullsettings['plugin.']['tx_mfflsb_remote.']['settings.']['anonymous.']['token'];
	      
	      $userQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $userQuerySettings->setRespectStoragePage(FALSE);
	      $userQuerySettings->setStoragePageIds( array( $this->settings['storagePid'] ) );
	      $this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
	      $this->userSurveyRepository->setDefaultQuerySettings( $userQuerySettings );

	      $feUserQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $feUserQuerySettings->setRespectStoragePage(FALSE);
	      $feUserQuerySettings->setStoragePageIds( array($this->settings['teacherPid']) );
	      $this->frontendUserRepository = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Domain\\Repository\\FrontendUserRepository');
	      $this->frontendUserRepository->setDefaultQuerySettings( $feUserQuerySettings );
	      
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(FALSE);
	      $querySettings->setStoragePageIds( $templateStoragePid );
	      $this->tpSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\TpSurveyRepository');
	      $this->tpSurveyRepository->setDefaultQuerySettings( $querySettings );
	      $this->classtemplateRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\ClasstemplateRepository');
	      $this->classtemplateRepository->setDefaultQuerySettings( $querySettings );

	      $ttQuerySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $ttQuerySettings->setRespectStoragePage(FALSE);
	      $ttQuerySettings->setStoragePageIds( $storage );
	      $this->timetableRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\TimetableRepository');
	      $this->timetableRepository->setDefaultQuerySettings($ttQuerySettings);
	      $this->stundenplanRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\StundenplanRepository');
	      $this->stundenplanRepository->setDefaultQuerySettings($ttQuerySettings);
	      $this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($ttQuerySettings);
    }
    
    /**
     * action list
     *
     * @return void
     */
    public function listAction(){
	    
	    $aPeriods = $this->periodsRepository->findAll();
	    $this->view->assign('periods', $aPeriods );
	    $period = $this->getActualPeriod($aPeriods);
	    $this->view->assign('period', $period );
	    
	    $foreignTimetable = $this->chooseTimetableRepository();
	    $this->view->assign('foreignTimetable', $foreignTimetable );
	    
	    $dateField = array( 'startDate'=>1 , 'deletionDate'=>1 );
	    $plural = array( true=>'e' , false=>'' );
	    $remoteSurvey = array(); 
	    $mailCopyCodes = array( 0 => '' , 1 => 'Cc' , 2 => 'Bcc' );
	    if($this->request->hasArgument('sendLink')){ // sendLink listAction from editform (submit-button)
			$surveyUid = $this->request->getArgument('sendLink');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$mailStatus = $userSurvey->getMailState();
			$MailUtility = new \Mff\MffLsb\Utility\MailUtility();
			if($mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]) $MailUtility->interim[$mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]] = $GLOBALS['TSFE']->fe_user->user['email'];
			if( $mailStatus  <=2 ) {
					$success = $MailUtility->sendLinkAndUpdate( $userSurvey );
			}elseif( $mailStatus <=5 ){
					$success = $MailUtility->sendReminderAndUpdate( $userSurvey );
			}elseif( $mailStatus <=7 ){
					$success = $MailUtility->sendHandoutAndUpdate( $userSurvey );
			}elseif( $mailStatus ==8 ){
					$success = $MailUtility->sendPdfHandout( $userSurvey , $this->settings['mail']['printout_reminder_text'] );
			}
			if($success){
				$this->persistenceManager->persistAll();
				$this->addFlashMessage(  $success , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
				$this->addFlashMessage(  'Link nicht gesendet!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
	    }elseif($this->request->hasArgument('sendPdfData')){
			$surveyUid = $this->request->getArgument('sendPdfData');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$MailUtility = new \Mff\MffLsb\Utility\MailUtility();
			if($mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]) $MailUtility->interim[$mailCopyCodes[ $this->settings['useroptions']['manualmailcopy'] ]] = $GLOBALS['TSFE']->fe_user->user['email'];
			$success = $MailUtility->sendPdfData( $userSurvey );
			if($success){
				$this->addFlashMessage(  $success , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
				$this->addFlashMessage(  'Email nicht gesendet!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
	    }
	    
	    if($this->request->hasArgument('editSurvey')){ // updateAction from editform (submit-button)
			$editSurvey = $this->request->getArgument('editSurvey');
			$remoteSurvey = $this->listEditUpdate($editSurvey);
	    }elseif($this->request->hasArgument('checkedSurvey')){ // update batchEditAction from checkboxes in list-form (submit-button)
			$editSurvey = $this->request->getArgument('checkedSurvey');
			$remoteSurvey = $this->listBatchUpdate($editSurvey);
	    }elseif($this->request->hasArgument('userSurvey')){ // editAction link in list
			$surveyUid =  $this->request->getArgument('userSurvey');
			if( $this->request->hasArgument('dupliz') ){
				$editSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
				$newRemoteSurvey = $this->duplicateSurvey( $editSurvey );
				$remoteSurvey = $this->listEditor( $newRemoteSurvey->getUid() );
			}else{
				$remoteSurvey = $this->listEditor($surveyUid);
			}
	    }elseif($this->request->hasArgument('downloadReport')){ // editAction download link in list
			$surveyUid =  $this->request->getArgument('downloadReport');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$this->updateSurveyFromApi($userSurvey);
			$this->persistenceManager->persistAll();
			$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
			$reportData = $reportUtility->PDFDataForReports( $userSurvey  );
			if( !is_array($reportData) ) {
					$this->addFlashMessage(  'Keine Daten zum herunterladen gefunden!' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}else{
					$pdfUtility = new \Mff\MffLsb\Utility\PdfReportUtility( $this->settings );
					$pdfUtility->pdfReport( $reportData , 'D' ); 
			}
	    }elseif($this->request->hasArgument('downloadPrintout')){ // editAction download link in list
			$surveyUid =  $this->request->getArgument('downloadPrintout');
			$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			$reportUtility = new \Mff\MffLsb\Utility\ReportPdfDataUtility( $this->settings );
			$noData = false;
			$reportData = $reportUtility->PDFDataForPrintouts( $userSurvey , $noData  );
			$pdfUtility = new \Mff\MffLsb\Utility\PdfPrintoutUtility( $this->settings );
			$pdfUtility->pdfTemplate( $reportData ); // causes exit();
		}
	    
	    $userSurveys = $this->getSurveysList($period);
	    $enrichedUserSurveys = $this->enrichSurveysWithData($userSurveys , $remoteSurvey );
	    $this->view->assign('userSurveys', $enrichedUserSurveys);
	    
	    if ($this->request->hasArgument('download')) $this->downloadListAsExcel($enrichedUserSurveys);
	    
	    $data = $this->getFlexformData();
	    $this->view->assign('data', $data);
	    $this->view->assign('settings', $this->settings );
	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );
    }
    
    /**
     * downloadListAsExcel
     *
     * @param array $enrichedUserSurveys
     * @return void
     */
    public function downloadListAsExcel($enrichedUserSurveys){
  				if( !is_array( $enrichedUserSurveys ) ) return false;
  				$aMailstates = array( 0=>'nie Mail senden',1=>'Link senden',2=>'(sendend...)',3=>'Gesendet',4=>'(erinnernd...)',5=>'Erinnert',6=>'Kopiervorlage senden',7=>'(am Vorlage senden...)',8=>'Vorlage gesendet');
  				foreach($enrichedUserSurveys as $uid => $fs){
						if(!isset($fs['survey']))continue;
						$userSurvey = $fs['survey'];
						$oStartDate = $userSurvey->getStartDate();
						if($oStartDate) $uxStartDate = $oStartDate->format('U');
						$endDate = $uxStartDate + ( $userSurvey->getExpireDays() * (3600*24) );
						$dbPeriodUid = $userSurvey->getSemesterUid();
						$oPeriod = $this->periodsRepository->findByUid($dbPeriodUid);
						$semester = $oPeriod->getSemester();
						$userUid = $userSurvey->getUserUid();
						$oUser = $this->frontendUserRepository->findByUid($userUid);
						$adminName = trim($oUser->getFirstname() . ' ' . $oUser->getLastname());
						$objUpdated = $userSurvey->getResponsesUpdated();
						$dateUpdated = $objUpdated ? $objUpdated->format('d.m.Y') : '';
						$startDatum = !empty($uxStartDate) ? date('d.m.Y',$uxStartDate):'';
						$endDatum = !empty($endDate) ? date('d.m.Y',$endDate):'';
						$sortStartDatum = !empty($uxStartDate) ? date('ymd',$uxStartDate):'';
						$sortEndDatum = !empty($endDate) ? date('ymd',$endDate):'';
						$sortAbgerufen = $objUpdated ? $objUpdated->format('ymd') : '';
						$mailState = $userSurvey->getMailState();
						$anlaesseGefilter[] = array(
								'surveyUid' => $userSurvey->getSurveyUid() ,
								'mailStatus'=> $aMailstates[ $mailState ],
								'Antworten'=> $userSurvey->getResponsesCount(),
								'abgerufenAm'=> $dateUpdated,
								'startDatum'=> $startDatum,
								'endDatum'=> $endDatum,
								'nameDozent'=> $userSurvey->getEnquirerName(),
								'emailDozent' => $userSurvey->getEnquirerEmail(),
								'Kurs'=> $userSurvey->getCourseName(),
								'Fach'=> $userSurvey->getSubject(),
								'Semester'=>$semester,
								'Admin'=>$adminName,
								'sortMailStatus'=> $mailState,
								'sortStart'=> $sortStartDatum,
								'sortEnd'=> $sortEndDatum,
								'sortAbgerufen'=> $sortAbgerufen,
								'uid' => $userSurvey->getUid() , 
						);
  				}
  				if( !count( $anlaesseGefilter ) ) return false;
				$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
				$downloader->downloadAsXls( array('Umfragen'=>$anlaesseGefilter), 'Umfragen_' . date('ymd_Hi') . '.xlsx');
				return;
    }
    
    /**
     * getTacherList
     *
     * @return void
     */
    public function getTacherList(){
	    $objBearbeiter = $this->frontendUserRepository->findByPid( $this->settings['teacherPid'] );
	    foreach( $objBearbeiter  as $objUser ){
		    $firstName = $objUser->getFirstName();
		    $lastName = $objUser->getLastName();
		    $aBearbeiter[$objUser->getEmail()] = trim( $lastName . ' ' . $firstName );
	    }
	    asort($aBearbeiter);
	    return $aBearbeiter;
    }

    /**
     * getInvitationSenderAdressByUserSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @param boolean $asString optional, default returns object or array
     * @return void
     */
    public function getInvitationSenderAdressByUserSurvey($userSurvey , $asString = false ){
		// from TsConf
		$clearEmail = $this->settings['mail']['fix_invitation_from'];
		if( $this->settings['mail']['use_fix_invitation'] && filter_var($clearEmail, FILTER_VALIDATE_EMAIL) ){
				$emailBearbeiter = $asString ? $clearEmail : array( 'email' => $clearEmail );
				return $emailBearbeiter;
		}
		
		// from recordset userSurvey
		if($userSurvey) {
			$userUid = $userSurvey->getUserUid();
			if( $userUid ) $feUserObj = $this->frontendUserRepository->findByUid($userUid);
			if( $feUserObj ){
				$clearEmail = $feUserObj->getEmail();
				$emailBearbeiter = $asString ? $clearEmail : $feUserObj;
				if( filter_var( $clearEmail , FILTER_VALIDATE_EMAIL) ) return $emailBearbeiter;
			}
		}
		
		$clearEmail = $this->settings['mail']['sender_adress'];
		$emailBearbeiter = $asString ? $clearEmail : array( 'email' => $clearEmail );
		if( filter_var( $clearEmail , FILTER_VALIDATE_EMAIL) ) return $emailBearbeiter;
		
		return false;
    }
    
    /**
     * listEditor
     *
     * @param int $surveyUid
     * @return void
     */
    public function listEditor($surveyUid){
	    if( !$surveyUid ) return array();
	    
	    $remoteSurvey['chk'][$surveyUid] = 1;
	    
	    if($this->request->hasArgument('abort'))return $remoteSurvey;
	    
		$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
		
		$emailBearbeiter = $this->getInvitationSenderAdressByUserSurvey($userSurvey);
		
		$this->view->assign('userSurvey', $userSurvey);
		$this->view->assign('bearbeiter' , $this->getTacherList() );
		$this->view->assign('emailBearbeiter' , $emailBearbeiter );
		$this->view->assign('manualdate' , $this->getDatesFromTimespan($userSurvey) );
		$this->view->assign('md5RemoteKey' , md5($userSurvey->getRemoteKey()) );
	    return $remoteSurvey;
		
		$toRefresh = $this->isUpdateAffored($userSurvey, true); // $this->settings['autoupdate_after_minutes'] must be > 0
		if( $toRefresh ) $this->updateSurveyFromApi($userSurvey);
	    return $remoteSurvey;
    }
    
    /**
     * getDatesFromTimespan
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    public function getDatesFromTimespan($userSurvey){
		  $dtTo = new \DateTime($userSurvey->getStartDate()->format('Y-m-d'));
		  $dtTo->add(new \DateInterval('P'.$userSurvey->getExpireDays().'D'));
		  $dtRemote = new \DateTime($dtTo->format('Y-m-d'));
		  $dtRemote->add(new \DateInterval('P'.$userSurvey->getRemoteDays().'D'));
		  $aSurveys = array(
		      'endDate'=>$dtTo->format('U'),
		      'remoteDate'=>$dtRemote->format('U')
		  );
		  return $aSurveys;
    }
    
    /**
     * listBatchUpdate
     *
     * @param array $editSurvey
     * @return void
     */
    public function listBatchUpdate($editSurvey){
	    if( !is_array($editSurvey['chk']) ) return array();
	    $dateField = array( 'startDate'=>1 , 'deletionDate'=>1 );
	    $plural = array( true=>'e' , false=>'' );
	    foreach($editSurvey['chk'] as $surveyUid=>$sel) if( $sel ) $remoteSurvey['chk'][$surveyUid] = $sel;
	    if( !is_array($remoteSurvey['chk']) ) return array();
		$data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
	    if( $this->request->hasArgument('delete') ){
			foreach($remoteSurvey['chk'] as $surveyUid=>$sel) {
			      $userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
					$result = $this->deleteDistantLimeSurvey($userSurvey);
			      if($result) $this->userSurveyRepository->remove($userSurvey);
			}
			$this->persistenceManager->persistAll();
			$this->addFlashMessage(  count($remoteSurvey['chk']) . ' Objekt'.$plural[ $remoteSurvey['chk'] != 1 ].' gel&ouml;scht. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }elseif( $this->request->hasArgument('ok') && $this->request->hasArgument('edit') ){// batchEditAction update
		  $editfields = array();
		  $rawEditfields = $this->request->getArgument('edit');
		  foreach ($rawEditfields as $key => $value ) { if( !empty($value) ) $editfields[$key]=$value;}
		  if( count($editfields) ){
			foreach($remoteSurvey['chk'] as $surveyUid=>$sel) {
			      $userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
			      foreach ($editfields as $key => $value ) {
				    if( isset( $dateField[ $key ] ) ){
					  $userSurvey->_setProperty( $key ,  new \DateTime(date('Y-m-d',strtotime($value)).'T06:00:00' , $this->timeZone) );
				    }else{
					  if( 'mailState' == $key) $value-=10;
					  $userSurvey->_setProperty( $key , $value );
				    }
			      }
			      if( !empty($data['user_uid']) ) $userSurvey->setUserUid($data['user_uid']);
			      $this->userSurveyRepository->update($userSurvey);
			}
			$updatedSurveys = array_sum($remoteSurvey['chk']);
			$this->addFlashMessage(  $updatedSurveys. ' Objekt'.$plural[ $updatedSurveys != 1 ].' gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$this->persistenceManager->persistAll();
			$this->view->assign('editfields', $editfields);
		  }
	    }
	    return $remoteSurvey;
    }
    
    /**
     * listEditUpdate
     *
     * @param array $editSurvey
     * @return void
     */
    public function listEditUpdate($editSurvey){
	    if( !count($editSurvey) ) return array();
	    $surveyUid =  $editSurvey['uid'];
	    
	    if(!$surveyUid) return array();
		$remoteSurvey['chk'][$surveyUid] = 1;
		if($this->request->hasArgument('abort')) return $remoteSurvey;
		$userSurvey = $this->userSurveyRepository->findByUid( $surveyUid );
		
	    if(!$userSurvey) return array();
		$data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
		  
		if( $this->request->hasArgument('ok') || $this->request->hasArgument('dupliz') ){
				$dateField = array( 'startDate'=>1 , 'deletionDate'=>1 );
				$dateToIntField = array( 'endDate'=> 'expireDays' , 'abrufDatum'=> 'remoteDays'  );
				foreach ($editSurvey as $key => $value ) {
						if( isset( $dateToIntField[ $key ] ) ) continue;
						if( isset( $dateField[ $key ] ) ){
							$usaDate = strtotime($this->getUSformattedDateString($value));
							$userSurvey->_setProperty( $key ,  new \DateTime(date('Y-m-d',$usaDate).'T06:00:00' , $this->timeZone) );
						}else{
							$userSurvey->_setProperty( $key , $value );
						}
				}
				if( !empty( $editSurvey['endDate'] ) ){
						$usaDate = strtotime($this->getUSformattedDateString($editSurvey['endDate']));
						$dtStart = new \DateTime( date( 'Y-m-d' , $userSurvey->getStartDate()->format('U') ) );
						$dtStart->setTimeZone( $this->timeZone );
// 						if( $dtStart->format('d.m.Y') == date('d.m.Y') ) $dtStart->add(new \DateInterval('P1D'));
						$dtEnd = new \DateTime( date( 'Y-m-d' , $usaDate ) );
						$dtEnd->setTimeZone( $this->timeZone );
						$interval = date_diff($dtStart, $dtEnd)->format('%a');
						$userSurvey->setExpireDays( $interval );
				}
				$surveyState = $userSurvey->getSurveyState();
				$enqMail = $userSurvey->getEnquirerEmail();
				if( !empty($enqMail) ){
						if( filter_var($enqMail, FILTER_VALIDATE_EMAIL) ){
								$surveyUid = $userSurvey->getSurveyUid();
								if( $surveyState == 2 && $surveyUid > 0 ){
									// UPDATE  LimeSurvey
									$result = $this->updateDistantLimeSurvey($userSurvey);
									$this->addFlashMessage('LimeSurvey '.$result['action'].'d.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
								}elseif( $surveyState < 2  ){
									// CREATE  LimeSurvey
									$this->createDistantLimeSurvey($userSurvey);
									$this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
								}
						}else{
								$userSurvey->setEnquirerEmail('');
						}
				}
				if( !empty($data['user_uid']) ) $userSurvey->setUserUid($data['user_uid']);
				$this->userSurveyRepository->update($userSurvey);
				$this->persistenceManager->persistAll();
				$this->addFlashMessage('Das Objekt wurde gespeichert. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		if( $this->request->hasArgument('dupliz') ){
				$userSurvey = $this->duplicateSurvey( $userSurvey );
		}
		$this->view->assign('userSurvey', $userSurvey);
		$this->view->assign('bearbeiter' , $this->getTacherList() );
		$emailBearbeiter = $this->getInvitationSenderAdressByUserSurvey($userSurvey);
		$this->view->assign('emailBearbeiter' , $emailBearbeiter );
		$this->view->assign('manualdate' , $this->getDatesFromTimespan($userSurvey) );
		$this->view->assign('md5RemoteKey' , md5($userSurvey->getRemoteKey()) );
	    return $remoteSurvey;
    }

    
    /**
     * createDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    public function createDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $result = $lsObjUtility->createLsFromUserSurvey( $userSurvey );
	    $userSurvey->setSurveyState(2);
	    $userSurvey->setSurveyUid($result['survey_uid']);
	    $userSurvey->setResponsesField( '' ); // delete old answers, if existing
    }
    
    /**
     * deleteDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    public function deleteDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $result = $lsObjUtility->deactivateLsFromUserSurvey( $userSurvey );
	    $userSurvey->setSurveyState(0);
	    $userSurvey->setSurveyUid(0);
	    $userSurvey->setResponsesCount( '' );
	    return $result;
    }
    
    /**
     * updateDistantLimeSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
     * @return void
     */
    public function updateDistantLimeSurvey($userSurvey){
	    $lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
	    $isExpired = $this->isSurveyExpiredByDate( $userSurvey );
	    if($isExpired){
		  $lastUpDate = $userSurvey->getResponsesUpdated();
		  $expireDays = 1+$userSurvey->getExpireDays();
		  $startDate = $userSurvey->getStartDate();
		  $enddate = new \DateTime( $startDate->format('Y-m-d H:i:s') );
		  $enddate->add(new \DateInterval('P'.$expireDays.'D'));
		  $enddate->setTimeZone($this->timeZone);
		  if( $lastUpDate && $lastUpDate->format('U') < $enddate->format('U') ) {$isExpired=0;}
	    }
	    $result = $lsObjUtility->updateLsFromUserSurvey( $userSurvey , $isExpired );
	    return $result;
    }
    
    /**
     * action dispo
     *
     * @return void
     */
    public function dispoAction()
    {
        $aPeriods = $this->periodsRepository->findAll();
        $this->view->assign('periods', $aPeriods );
		$period = $this->getActualPeriod($aPeriods);
        $this->view->assign('period', $period );
        
        $foreignTimetable = $this->chooseTimetableRepository();
        $this->view->assign('foreignTimetable', $foreignTimetable );

        $rawQueryResult = $this->getCourses($foreignTimetable,$period);
        
        $aKurzklassen = $this->coursesToShortclass( $rawQueryResult );
        $aClassTemplates = $this->handleClasstemplates( $aKurzklassen );
        // look up for empty values
        $emptyTemplate = 0;
        foreach( $aClassTemplates as $classTemplate ) if(empty($classTemplate['template_uid'])) ++$emptyTemplate;
        $this->view->assign('classTemplateHeight', $emptyTemplate ? 'auto' : '0px' );
        $this->view->assign('kurzklassen', $aClassTemplates );

        if($this->request->hasArgument('manuelleVorlage')){
				$manuelleVorlageWahl = $this->request->getArgument('manuelleVorlage');
				$this->view->assign('manuelleVorlageWahl', $manuelleVorlageWahl );
        }else{
				$manuelleVorlageWahl = 0;
        }
        if($this->request->hasArgument('createRemoteSurvey')){
	      $remoteSurvey = $this->request->getArgument('createRemoteSurvey');
        }
        foreach( $rawQueryResult as $ix=>$courseRow){
	      $enrichedQueryResult[$ix] = $courseRow;
	      $enrichedQueryResult[$ix]['template_uid'] = !empty($manuelleVorlageWahl) ? $manuelleVorlageWahl : $aClassTemplates[ $courseRow['kurzbezeichnung'] ]['template_uid'];
	      $enrichedQueryResult[$ix]['checked'] = $remoteSurvey['chk'][ $ix ];
	      $courseSum += empty($enrichedQueryResult[$ix]['template_uid']) ? 0 : 1;
        }
        $this->view->assign('courseSum', $courseSum );
        
        if( isset($remoteSurvey['chk']) ){
	      $plural = array( true=>'e' , false=>'' );
	      if($this->request->hasArgument('create') && array_sum($remoteSurvey['chk'])){
		    $newUids = array();
		    foreach( $remoteSurvey['chk'] as $ix=>$isCheched){
			    if(empty($isCheched))continue;
			    if(empty($enrichedQueryResult[$ix]['template_uid']))continue;
			    $newUids[] = $this->createSurvey($enrichedQueryResult[$ix] , $period );
		    }
		     $this->addFlashMessage( count($newUids) . ' Objekt'.$plural[ count($newUids) != 1 ].' erstellt. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	      }
		}
			
		$userSurveys = $this->getSurveysList($period);
		foreach($userSurveys as $ix => $oSurvey) {
			$dbEnquirerUid = $oSurvey->getEnquirerUid();
			$dbFachUid = $oSurvey->getFachUid();
			$dbCourseName = $oSurvey->getCourseName();
			$dbPeriod = $oSurvey->getSemesterUid();
			$addedSurveys[ $dbEnquirerUid.'_'. $dbFachUid .'_'. $dbCourseName .'_'. $dbPeriod][$ix]=$oSurvey;
		}
			if(is_array($enrichedQueryResult)){
			foreach( $enrichedQueryResult as $ix=>$courseRow){
				$sIdx = $courseRow['plan_teacher'].'_'.$courseRow['subject_id'].'_'.$courseRow['Klasse'].'_'.$period;
				$enrichedQueryResult[$ix]['surveys'] = $addedSurveys[$sIdx];
			}
			}
			$this->view->assign('courses', $enrichedQueryResult );
			
		$tpSurveys = $this->tpSurveyRepository->findByPidS( $this->contentObj->data['pages'] , true, false );
		foreach( $tpSurveys as $ix=>$template){
			$surveyTemplates[$template['uid']] = $template['template_label'];
		}
		$this->view->assign('Surveytemplates', $surveyTemplates);
	    $this->view->assign('contentUid', $this->contentObj->data['uid'] );
	    $this->view->assign('settings', $this->settings );
	   
	}


	/**
	* action delete
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return void
	*/
	public function deleteAction(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey) {
	    $this->deleteDistantLimeSurvey($userSurvey);
	    $this->addFlashMessage('The object was deleted. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
	    $this->userSurveyRepository->remove($userSurvey);
	    $this->redirect('list');
	}

	/**
	* getSurveysList
	*
	* @param int $period
	* @return void
	*/
	public function getSurveysList($period=0) {
	    if( !$period ){
		  $aPeriods = $this->periodsRepository->findAll();
		  $period = $this->getActualPeriod($aPeriods);
	    }
	    return $this->userSurveyRepository->findByPidAndSemesterUid( $this->settings['storagePid'] , $period);
	}

	/**
	* createSurvey
	*
	* @param array $aRemoteSurvey
	* @param int $period
	* @return void
	*/
	public function createSurvey($aRemoteSurvey , $period ){
		  // Append flexform values
		  $this->configurationManager->getContentObject()->readFlexformIntoConf($data['pi_flexform'], $data);
			  
		  $data['user_uid'] = $GLOBALS['TSFE']->fe_user->user['uid'];
		  $userUid = empty($data['user_uid']) ? 0 : $data['user_uid'];
	    
		  $templateObj = $this->tpSurveyRepository->findByUid($aRemoteSurvey['template_uid']);
	    
		  $templateDataUtility = new \Mff\MffLsb\Utility\TemplateDataUtility();
		  $xmlDb = $templateDataUtility->showObjectData( $aRemoteSurvey['template_uid'] );

		  $newUserSurvey = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\UserSurvey');
		  $newUserSurvey->setPid( $this->settings['storagePid'] );
		  $newUserSurvey->setCruserId( $userUid );
		  $newUserSurvey->setUserUid( $userUid );
		  $newUserSurvey->setRemoteKey( md5( $userUid . '-' . microtime(true) ) );
		  $newUserSurvey->setUserTpSurvey( $templateObj );
		  $newUserSurvey->setTemplateName( $templateObj->getTemplateName() );
		  $newUserSurvey->setTemplateLabel( $templateObj->getTemplateLabel() );
		  $newUserSurvey->setConfirmFile( $templateObj->getConfirmFile() );
		  $newUserSurvey->setTemplateXml( json_encode( $xmlDb['survey'] ) );
		  $newUserSurvey->setTemplateGroupOptions( json_encode( $xmlDb['question'] ) );
		  
		  $newUserSurvey->setParticipType( 0 ); // anonyme | email
		  $newUserSurvey->setParticipCount( 99 ); // anonyme | email
		  $newUserSurvey->setEnquirerType( 1 ); // user | remote
		  $newUserSurvey->setCourseName( $aRemoteSurvey['Klasse'] );
		  $newUserSurvey->setSubject( $aRemoteSurvey['fachbezeichnung'] );
		  
		  $newUserSurvey->setFachUid( $aRemoteSurvey['subject_id'] );
		  $newUserSurvey->setSemesterUid( $period );
		  $newUserSurvey->setRemoteDays( $this->settings['remote_days'] );
		  $newUserSurvey->setMailState( 1 ); // none | wait | process | done
		  $newUserSurvey->setSurveyState( 1 ); // none | wait | active
		  $newUserSurvey->setEnquirerUid( $aRemoteSurvey['plan_teacher'] );
            if( $this->settings['firstname_lastname'] ){
                    $aUsersFullname = explode( ' ' , $aRemoteSurvey['user'] );
                    if( count($aUsersFullname) == 2 ){
							$enquirerName =  $aUsersFullname[1] . ' ' . $aUsersFullname[0];
                    }elseif( count($aUsersFullname) == 3 ){
							$enquirerName =  $aUsersFullname[2] . ' ' . $aUsersFullname[0] . ' ' . $aUsersFullname[1];
                    }else{
							$enquirerName = $aRemoteSurvey['user'];
                    }
            }else{
                    $enquirerName = $aRemoteSurvey['user'];
            }        
		  $newUserSurvey->setEnquirerName( $enquirerName );
		  if( filter_var($aRemoteSurvey['email'], FILTER_VALIDATE_EMAIL) ) $newUserSurvey->setEnquirerEmail( $aRemoteSurvey['email'] );

		  $dtStart = new \DateTime( date( 'Y-m-d 05:00:00' , $aRemoteSurvey['plan_start'] ) , $this->timeZone );
		  if( $this->settings['days_before_start'] ) $dtStart->sub(new \DateInterval('P' . $this->settings['days_before_start'] . 'D'));
		  $dtEnd = new \DateTime( date( 'Y-m-d 05:00:00' , $aRemoteSurvey['plan_ende'] ) , $this->timeZone );
		  if( $this->settings['days_after_end'] ) $dtEnd->add(new \DateInterval('P' . $this->settings['days_after_end'] . 'D'));

		  $interval = date_diff($dtStart, $dtEnd)->format('%a');
		  $newUserSurvey->setExpireDays( $interval );
//		  $newUserSurvey->setStartDate( $this->repairDateTime($dtStart) );
		  $newUserSurvey->setStartDate( $dtStart );
		  $newUserSurvey->setDeletionDate( $dtEnd );
		  $delDate = $newUserSurvey->getDeletionDate();
		  $delDate->add(new \DateInterval('P1Y'));
		  $delDate->add(new \DateInterval('P1D'));
		  
		  $this->userSurveyRepository->add($newUserSurvey);
		  
		  $this->persistenceManager->persistAll();
		  $uid = $newUserSurvey->getUid();
		  $enqMail = $newUserSurvey->getEnquirerEmail();
		  if( filter_var($enqMail, FILTER_VALIDATE_EMAIL) ){
			// CREATE  LimeSurvey
			$this->createDistantLimeSurvey($newUserSurvey);
			$this->userSurveyRepository->update($newUserSurvey);
			$this->persistenceManager->persistAll();
			$this->addFlashMessage('LimeSurvey Umfrage aktiviert.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		  }
 		  $msg = $newUserSurvey->getStartDate()->format('d.m.Y') . ' ' . date( 'Y-m-d' , $aRemoteSurvey['plan_start'] ) . ' | ' . $aRemoteSurvey['template_uid'] . ' | ' . $aRemoteSurvey['Klasse'] . ' | ' . $aRemoteSurvey['fachbezeichnung']  . ' | ' . $aRemoteSurvey['user']  . ' ('.$aRemoteSurvey['plan_teacher'].')';
 		  return $uid;
	}
	      
	/**
	* getEnquirerEmailFromFieldValues
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @return string
	*/
	public function getEnquirerEmailFromFieldValues(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){

	      // Client - Klienten
	      $enquirer_email = $userSurvey->getEnquirerEmail();
	      if(empty($enquirer_email)){
		    $enquirer_uid = $userSurvey->getEnquirerUid();
		    $feUser = $this->frontendUserRepository->findByUid($enquirer_uid);
		    $enquirer_email = $feUser->getEmail();
	      }
	      
	      return trim( $enquirer_email );
	}
	
	/**
	* enrichSurveysWithData
	*
	* @return void
	*/
	public function enrichSurveysWithData($userSurveys , $remoteSurvey = array() ) {
	    $enrichedSurveys = $this->enrichSurveysWithState($userSurveys);
	    $enrichedUserSurveys = array();
	    foreach($enrichedSurveys as $newSurvey){
				$dtTo = new \DateTime($newSurvey->getStartDate()->format('Y-m-d'));
				$dtTo->add(new \DateInterval('P'.$newSurvey->getExpireDays().'D'));
				$dtRemote = new \DateTime($dtTo->format('Y-m-d'));
				$dtRemote->add(new \DateInterval('P'.$newSurvey->getRemoteDays().'D'));
				$uid = $newSurvey->getUid();
				$aSurveys = array(
					'chk'=> isset($remoteSurvey['chk'][$uid]) ? $remoteSurvey['chk'][$uid]:0,
					'crDate'=>$newSurvey->getCrdate(),
					'endDate'=>$dtTo->format('U'),
					'remoteDate'=>$dtRemote->format('U'),
					'overdue'=>$dtTo->format('U') <= time()
				);
				$enrichedUserSurveys[$uid] = array( 'survey' => $newSurvey , 'additional' => $aSurveys );
	    }
	    return $enrichedUserSurveys;
	}
	
	/**
	 * chooseTimetableRepository
	 * 
	 * @return void
	 */
	public function chooseTimetableRepository() {
		$userObj = $GLOBALS['TSFE']->fe_user;
		$foreignTimetable = 0;
		if( $this->request->hasArgument('foreignTimetable') && $this->request->hasArgument('ok') ){
			$foreignTimetable = $this->request->getArgument('foreignTimetable');// NULL | 1 | 2
			if($userObj){
				$myData = $userObj->getKey('user', 'useroptions');
				$myData['foreignTimetable'] = $foreignTimetable;
				$userObj->setKey("user","useroptions", $myData);
				$userObj->sesData_change = true;
				$userObj->storeSessionData();
			}
		}else{
			if($userObj){
				$myData = $userObj->getKey('user', 'useroptions');
				if( $myData['foreignTimetable'] ) $foreignTimetable = $myData['foreignTimetable'] ;
			}
		}
		if( !$foreignTimetable ){
			$foreignTimetable = $this->settings['foreignTimetable']+2;
		}
		return $foreignTimetable;
	}
	
	
	/**
	 * getTimetableRepository
	 * 
	 * @param bool $forceExternalTable
	 * @return void
	 */
	public function getTimetableRepository($forceExternalTable=false) {
		  if( !$forceExternalTable ){
			$foreignTimetable = $this->settings['useroptions']['foreignTimetable'];
		  }else{
			$foreignTimetable = $forceExternalTable-1;
		  }
		  return $foreignTimetable ? $this->timetableRepository : $this->stundenplanRepository;
	}
    
	/**
	* getActualPeriod
	*
	* @return void
	*/
	public function getActualPeriod($aPeriods){
			$userObj = $GLOBALS['TSFE']->fe_user;
			if($this->request->hasArgument('period')){
				$period = $this->request->getArgument('period');
				if($userObj){
					$myData = $userObj->getKey('user', 'useroptions');
					$myData['period'] = $period;
					$userObj->setKey("user","useroptions", $myData);
					$userObj->sesData_change = true;
					$userObj->storeSessionData();
				}
			}else{
					if($userObj){
						$myData = $userObj->getKey('user', 'useroptions');
						if( $myData['period'] ) $period = $myData['period'] ;
					}
					if(!isset($period)){
						$jetzt = time();
						foreach( $aPeriods as $aPer) {
							if( $aPer->getDavorBis()->format('U') <= $jetzt && $aPer->getDanachAb()->format('U') >= $jetzt){
								$aktPeriode = $aPer; break;
							}
						}
						$period = ($aktPeriode) ? $aktPeriode->getUid() : 0;
					}
			}
			return $period;
	}

	/**
	* coursesToShortclass
	*
	* @param array $rawQueryResult
	* @return void
	*/
	public function coursesToShortclass( $rawQueryResult ){
	    $aKurzklassen = array();
	    if($this->request->hasArgument('remoteSurvey')){
		  $remoteSurvey = $this->request->getArgument('remoteSurvey');
		  $userTpSurvey = $remoteSurvey['userTpSurvey'];
		  foreach( $rawQueryResult as $row ){
			$aKurzklassen[$row['kurzbezeichnung']] = array( 'kurzbezeichnung' => $row['kurzbezeichnung'] , 'template_uid' => $userTpSurvey[ $row['kurzbezeichnung'] ] );
		  }
	    }else{
		  foreach( $rawQueryResult as $row ){
 			$aKurzklassen[$row['kurzbezeichnung']] = array( 'kurzbezeichnung' => $row['kurzbezeichnung'] , 'template_uid' => '' );
		  }
	    }
	    @ksort($aKurzklassen);
	    return $aKurzklassen;
	}

	/**
	* getCourses
	*
	* @param int $foreignTimetable
	* @param int $period
	* @return void
	*/
	public function getCourses( $foreignTimetable , $period){
	    $grpQueryResult = array();
	    $sortFlatQueryResult = array();
	    $flatQueryResult = array();
	    $rawQueryResult = array();
	    $aAnonymous = array_flip( $this->settings['anonymous_accounts']);

	    $aTtRep = $foreignTimetable == 3 ? array(0=>1,1=>0) : array(0=>$foreignTimetable);
	    foreach($aTtRep as $ttIdx) $timetableRepository[$ttIdx] = $this->getTimetableRepository($ttIdx);
	    
	    foreach($aTtRep as $ttIdx) {
		  $rawQueryResult[$ttIdx]['klasse'] = $timetableRepository[$ttIdx]->findBySemesterGroupByKlasseTeacherFiltered( $period , array( 'fachbereich'=>$this->settings['fachbereich']) );
		  $rawQueryResult[$ttIdx]['kurs'] = $timetableRepository[$ttIdx]->findBySemesterGroupByKursregelTeacherFiltered( $period , array( 'fachbereich'=>$this->settings['fachbereich']) );
	    }
	    foreach($rawQueryResult as $ttIdx => $qTable ) {
		  foreach($qTable as $tIx => $qows ) {
			foreach( $qows as $klasseTeacher ){
			    $klasse = str_replace(' ','_',$klasseTeacher['Klasse']);
			    $id = $klasseTeacher['plan_teacher'] . '_' . $klasse . '_' . $klasseTeacher['subject_id'] ;
			    $flatQueryResult[ $id ] = $klasseTeacher;
			    $sortArr[ $id ] = $klasseTeacher['plan_start'] . '_' . $klasse. '_' .$klasseTeacher['plan_teacher'];
			}
		  }
	    }
	    if( is_array($sortArr) ){
		  @asort($sortArr);
		  foreach($sortArr as $ix => $six ) {
		      $sortFlatQueryResult[$ix] = $flatQueryResult[$ix];
		  }
	    }
	    
	    if( is_array($sortFlatQueryResult) ){
		  foreach( $sortFlatQueryResult as $klasseTeacher ){
			$idx = $klasseTeacher['plan_teacher'] . '_' . str_replace(' ','_',$klasseTeacher['Klasse']);
			if( isset( $aAnonymous[ $klasseTeacher['username'] ]) ){
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ] = $klasseTeacher;
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ]['anonymous'] = $klasseTeacher['subject_id'];
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ]['email'] ='';
			}else{
			      $idx .= '_0';
			      if( isset( $grpQueryResult[ $idx ] ) ){
					$grpQueryResult[ $idx ]['fachbezeichnung'] .= ', '.$klasseTeacher['fachbezeichnung'];
					$grpQueryResult[ $idx ]['plan_ende'] = $klasseTeacher['plan_ende'];
			      }else{
					$grpQueryResult[ $idx ] = $klasseTeacher;
					$grpQueryResult[ $idx ]['anonymous'] = 0;
			      }
			}
		  }
	    }
	    return $grpQueryResult;
	}

	/**
	* handleClasstemplates
	*
	* @param array $classList
	* @return void
	*/
	public function handleClasstemplates( $classList ){
	    // get stored values from Database
	    $clsTemplates = $this->classtemplateRepository->findAll();
	    foreach( $clsTemplates as $clsRow ){
		  $shortclass = $clsRow->getShortclass();
		  $tpsurvey = $clsRow->getTpsurvey();
		  $dbClasses[$shortclass] = $clsRow;
	    }
	    // edit or create new
	    $changes = 0;
	    $aTitle= array( false=>'Bitte eine Vorlage auswählen.' , true=>'Vorlage bestimmen oder abwählen.' );
	    $sPrependOption = 'Vorlage wählen...' ;
	    foreach( $classList as $template ){
		  $shortclass = $template['kurzbezeichnung'];
		  if(isset( $dbClasses[ $shortclass ] )){
			if( empty($template['template_uid']) ){
			    $userTpSurvey='';
			    if($this->request->hasArgument('remoteSurvey')){
				$inFromForm = $this->request->getArgument('remoteSurvey');
				$userTpSurvey = $inFromForm['userTpSurvey'];
			    }
			    $shortclassFromDb = $dbClasses[ $shortclass ]->getShortclass();
			    if(isset($userTpSurvey[ $shortclassFromDb ])){
				$this->classtemplateRepository->remove($dbClasses[ $shortclass ]);
				$changes +=1;
			    }else{
			      $classList[$shortclass]['template_uid'] = $dbClasses[ $shortclass ]->getTpsurvey();
			      $classList[$shortclass]['kurzbezeichnung'] = $shortclassFromDb;
			    }
			}elseif( $template['template_uid'] != $dbClasses[ $shortclass ]->getTpsurvey() ){
			    $dbClasses[ $shortclass ]->setTpsurvey($template['template_uid']);
			    $this->classtemplateRepository->update($dbClasses[ $shortclass ]);
			    $changes +=1;
			}
		  }else{
		      if($template['template_uid']){
			    $newClasstemplate = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\MffLsb\Domain\Model\Classtemplate');
			    $newClasstemplate->setShortclass($template['kurzbezeichnung']);
			    $newClasstemplate->setTpsurvey($template['template_uid']);
			    $this->classtemplateRepository->add( $newClasstemplate );
			    $changes +=1;
		      }
		  }
		  $classList[$shortclass]['selectTitle'] = $aTitle[ !empty($template['template_uid']) ];
		  $classList[$shortclass]['prependOptionLabel'] = $sPrependOption;
	    }
	    
	    
	    if( $changes ){
		  $this->persistenceManager->persistAll();
		  if( !$this->request->hasArgument('create') ) $this->addFlashMessage('Gespeichert, '.$changes.' Änderung(en).', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }elseif($this->request->hasArgument('remoteSurvey') && !$this->request->hasArgument('create') ){
		  $this->addFlashMessage('Keine Änderungen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
	    }
	    
	    return $classList;
	}

}
