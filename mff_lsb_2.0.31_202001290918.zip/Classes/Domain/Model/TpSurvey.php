<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpSurvey
 */
class TpSurvey extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * templateName
     *
     * @var string
     * @validate NotEmpty
     */
    protected $templateName = '';

    /**
     * templateLabel
     *
     * @var string
     */
    protected $templateLabel = '';

    /**
     * confirmFile
     *
     * @var string
     */
    protected $confirmFile = '';

    /**
     * pageFormat
     *
     * @var int
     */
    protected $pageFormat = 0;

    /**
     * daysExpire
     *
     * @var int
     */
    protected $daysExpire = 0;

    /**
     * rawTitle
     *
     * @var string
     * @validate NotEmpty
     */
    protected $rawTitle = '';

    /**
     * description
     *
     * @var string
     */
    protected $description = '';

    /**
     * welcomeText
     *
     * @var string
     */
    protected $welcomeText = '';

    /**
     * endText
     *
     * @var string
     */
    protected $endText = '';

    /**
     * templateXml
     *
     * @var string
     */
    protected $templateXml = '';
    
    /**
      * versteckt
      *
      * @var bool
      */
    protected $versteckt = FALSE;

    /**
     * printanswers
     *
     * @var string
     */
    protected $printanswers = '';

    /**
     * notifysubject
     *
     * @var string
     */
    protected $notifysubject = '';

    /**
     * notifytext
     *
     * @var string
     */
    protected $notifytext = '';

    /**
     * handouttext
     *
     * @var string
     */
    protected $handouttext = '';

    /**
     * importanttext
     *
     * @var string
     */
    protected $importanttext = '';

    /**
     * pdfSettings
     *
     * @var int
     */
    protected $pdfSettings = '';

    /**
     * tpSurveyGroup
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpGroup>
     * @cascade remove
     */
    protected $tpSurveyGroup = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->tpSurveyGroup = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the templateName
     *
     * @return string $templateName
     */
    public function getTemplateName()
    {
        return $this->templateName;
    }

    /**
     * Sets the templateName
     *
     * @param string $templateName
     * @return void
     */
    public function setTemplateName($templateName)
    {
        $this->templateName = $templateName;
    }

    /**
     * Returns the templateLabel
     *
     * @return string $templateLabel
     */
    public function getTemplateLabel()
    {
        return $this->templateLabel;
    }

    /**
     * Sets the templateLabel
     *
     * @param string $templateLabel
     * @return void
     */
    public function setTemplateLabel($templateLabel)
    {
        $this->templateLabel = $templateLabel;
    }

    /**
     * Returns the confirmFile
     *
     * @return string $confirmFile
     */
    public function getConfirmFile()
    {
        return $this->confirmFile;
    }

    /**
     * Sets the confirmFile
     *
     * @param string $confirmFile
     * @return void
     */
    public function setConfirmFile($confirmFile)
    {
        $this->confirmFile = $confirmFile;
    }

    /**
     * Returns the pageFormat
     *
     * @return int $pageFormat
     */
    public function getPageFormat()
    {
        return $this->pageFormat;
    }

    /**
     * Sets the pageFormat
     *
     * @param int $pageFormat
     * @return void
     */
    public function setPageFormat($pageFormat)
    {
        $this->pageFormat = $pageFormat;
    }

    /**
     * Returns the daysExpire
     *
     * @return int $daysExpire
     */
    public function getDaysExpire()
    {
        return $this->daysExpire;
    }

    /**
     * Sets the daysExpire
     *
     * @param int $daysExpire
     * @return void
     */
    public function setDaysExpire($daysExpire)
    {
        $this->daysExpire = $daysExpire;
    }

    /**
     * Returns the rawTitle
     *
     * @return string $rawTitle
     */
    public function getRawTitle()
    {
        return $this->rawTitle;
    }

    /**
     * Sets the rawTitle
     *
     * @param string $rawTitle
     * @return void
     */
    public function setRawTitle($rawTitle)
    {
        $this->rawTitle = $rawTitle;
    }

    /**
     * Returns the description
     *
     * @return string $description
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Sets the description
     *
     * @param string $description
     * @return void
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * Returns the welcomeText
     *
     * @return string $welcomeText
     */
    public function getWelcomeText()
    {
        return $this->welcomeText;
    }

    /**
     * Sets the welcomeText
     *
     * @param string $welcomeText
     * @return void
     */
    public function setWelcomeText($welcomeText)
    {
        $this->welcomeText = $welcomeText;
    }

    /**
     * Returns the endText
     *
     * @return string $endText
     */
    public function getEndText()
    {
        return $this->endText;
    }

    /**
     * Sets the endText
     *
     * @param string $endText
     * @return void
     */
    public function setEndText($endText)
    {
        $this->endText = $endText;
    }

    /**
     * Returns the templateXml
     *
     * @return string $templateXml
     */
    public function getTemplateXml()
    {
        return $this->templateXml;
    }

    /**
     * Sets the templateXml
     *
     * @param string $templateXml
     * @return void
     */
    public function setTemplateXml($templateXml)
    {
        $this->templateXml = $templateXml;
    }

    /**
     * Returns the printanswers
     *
     * @return string $printanswers
     */
    public function getPrintanswers()
    {
        return $this->printanswers;
    }

    /**
     * Sets the printanswers
     *
     * @param string $printanswers
     * @return void
     */
    public function setPrintanswers($printanswers)
    {
        $this->printanswers = $printanswers;
    }

    /**
     * Returns the notifytext
     *
     * @return string $notifytext
     */
    public function getNotifytext()
    {
        return $this->notifytext;
    }

    /**
     * Sets the notifytext
     *
     * @param string $notifytext
     * @return void
     */
    public function setNotifytext($notifytext)
    {
        $this->notifytext = $notifytext;
    }

    /**
     * Returns the handouttext
     *
     * @return string $handouttext
     */
    public function getHandouttext()
    {
        return $this->handouttext;
    }

    /**
     * Sets the handouttext
     *
     * @param string $handouttext
     * @return void
     */
    public function setHandouttext($handouttext)
    {
        $this->handouttext = $handouttext;
    }

    /**
     * Returns the importanttext
     *
     * @return string $importanttext
     */
    public function getImportanttext()
    {
        return $this->importanttext;
    }

    /**
     * Sets the importanttext
     *
     * @param string $importanttext
     * @return void
     */
    public function setImportanttext($importanttext)
    {
        $this->importanttext = $importanttext;
    }

    /**
     * Returns the notifysubject
     *
     * @return string $notifysubject
     */
    public function getNotifysubject()
    {
        return $this->notifysubject;
    }

    /**
     * Sets the notifysubject
     *
     * @param string $notifysubject
     * @return void
     */
    public function setNotifysubject($notifysubject)
    {
        $this->notifysubject = $notifysubject;
    }

    /**
     * Returns the pdfSettings
     *
     * @return string $pdfSettings
     */
    public function getPdfSettings()
    {
        return $this->pdfSettings;
    }

    /**
     * Sets the pdfSettings
     *
     * @param string $pdfSettings
     * @return void
     */
    public function setPdfSettings($pdfSettings)
    {
        $this->pdfSettings = $pdfSettings;
    }

    /**
      * Returns the versteckt
      *
      * @return bool $versteckt
      */
    public function getVersteckt() {
	    return $this->versteckt;
    }

    /**
      * Sets the versteckt
      *
      * @param bool $versteckt
      * @return void
      */
    public function setVersteckt($versteckt) {
	    $this->versteckt = $versteckt;
    }

    /**
      * Returns the boolean state of versteckt
      *
      * @return bool
      */
    public function isVersteckt() {
	    return $this->versteckt;
    }

    /**
     * Adds a TpGroup
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $tpSurveyGroup
     * @return void
     */
    public function addTpSurveyGroup(\Mff\MffLsb\Domain\Model\TpGroup $tpSurveyGroup)
    {
        $this->tpSurveyGroup->attach($tpSurveyGroup);
    }

    /**
     * Removes a TpGroup
     *
     * @param \Mff\MffLsb\Domain\Model\TpGroup $tpSurveyGroupToRemove The TpGroup to be removed
     * @return void
     */
    public function removeTpSurveyGroup(\Mff\MffLsb\Domain\Model\TpGroup $tpSurveyGroupToRemove)
    {
        $this->tpSurveyGroup->detach($tpSurveyGroupToRemove);
    }

    /**
     * Returns the tpSurveyGroup
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpGroup> $tpSurveyGroup
     */
    public function getTpSurveyGroup()
    {
        return $this->tpSurveyGroup;
    }

    /**
     * Sets the tpSurveyGroup
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpGroup> $tpSurveyGroup
     * @return void
     */
    public function setTpSurveyGroup(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $tpSurveyGroup)
    {
        $this->tpSurveyGroup = $tpSurveyGroup;
    }
}
