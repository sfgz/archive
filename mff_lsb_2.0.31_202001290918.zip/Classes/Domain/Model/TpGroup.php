<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpGroup
 */
class TpGroup extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * tpsurvey
     *
     * @var int
     */
    protected $tpsurvey = 0;

    /**
     * groupName
     *
     * @var string
     * @validate NotEmpty
     */
    protected $groupName = '';

    /**
     * groupDescription
     *
     * @var string
     */
    protected $groupDescription = '';

    /**
     * reportPartials
     *
     * @var int
     */
    protected $reportPartials = 0;

    /**
     * reportHeaderVertical
     *
     * @var bool
     */
    protected $reportHeaderVertical = false;

    /**
     * reportHideHeader
     *
     * @var bool
     */
    protected $reportHideHeader = false;

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * tpGroupQuestion
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpQuestion>
     * @cascade remove
     */
    protected $tpGroupQuestion = null;

    /**
    * initializes this object
    *
    */
    public function __construct() {
	    //Do not remove the next line: It would break the functionality
	    $this->initStorageObjects();
    }
    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->tpGroupQuestion = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the tpsurvey
     *
     * @return int $tpsurvey
     */
    public function getTpsurvey()
    {
        return $this->tpsurvey;
    }

    /**
     * Sets the tpsurvey
     *
     * @param int $tpsurvey
     * @return void
     */
    public function setTpsurvey($tpsurvey)
    {
        $this->tpsurvey = $tpsurvey;
    }

    /**
     * Returns the groupName
     *
     * @return string $groupName
     */
    public function getGroupName()
    {
        return $this->groupName;
    }

    /**
     * Sets the groupName
     *
     * @param string $groupName
     * @return void
     */
    public function setGroupName($groupName)
    {
        $this->groupName = $groupName;
    }

    /**
     * Returns the groupDescription
     *
     * @return string $groupDescription
     */
    public function getGroupDescription()
    {
        return $this->groupDescription;
    }

    /**
     * Sets the groupDescription
     *
     * @param string $groupDescription
     * @return void
     */
    public function setGroupDescription($groupDescription)
    {
        $this->groupDescription = $groupDescription;
    }

    /**
     * Returns the reportPartials
     *
     * @return int $reportPartials
     */
    public function getReportPartials()
    {
        return $this->reportPartials;
    }

    /**
     * Sets the reportPartials
     *
     * @param int $reportPartials
     * @return void
     */
    public function setReportPartials($reportPartials)
    {
        $this->reportPartials = $reportPartials;
    }

    /**
     * Returns the reportHeaderVertical
     *
     * @return bool $reportHeaderVertical
     */
    public function getReportHeaderVertical()
    {
        return $this->reportHeaderVertical;
    }

    /**
     * Sets the reportHeaderVertical
     *
     * @param bool $reportHeaderVertical
     * @return void
     */
    public function setReportHeaderVertical($reportHeaderVertical)
    {
        $this->reportHeaderVertical = $reportHeaderVertical;
    }

    /**
     * Returns the boolean state of reportHeaderVertical
     *
     * @return bool
     */
    public function isReportHeaderVertical()
    {
        return $this->reportHeaderVertical;
    }
    
    /**
     * Returns the reportHideHeader
     *
     * @return bool $reportHideHeader
     */
    public function getReportHideHeader()
    {
        return $this->reportHideHeader;
    }

    /**
     * Sets the reportHideHeader
     *
     * @param bool $reportHideHeader
     * @return void
     */
    public function setReportHideHeader($reportHideHeader)
    {
        $this->reportHideHeader = $reportHideHeader;
    }

    /**
     * Returns the boolean state of reportHideHeader
     *
     * @return bool
     */
    public function isReportHideHeader()
    {
        return $this->reportHideHeader;
    }

    /**
     * Returns the sorting
     *
     * @return string $sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param string $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

    /**
     * Adds a TpQuestion
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $tpGroupQuestion
     * @return void
     */
    public function addTpGroupQuestion(\Mff\MffLsb\Domain\Model\TpQuestion $tpGroupQuestion)
    {
        $this->tpGroupQuestion->attach($tpGroupQuestion);
    }

    /**
     * Removes a TpQuestion
     *
     * @param \Mff\MffLsb\Domain\Model\TpQuestion $tpGroupQuestionToRemove The TpQuestion to be removed
     * @return void
     */
    public function removeTpGroupQuestion(\Mff\MffLsb\Domain\Model\TpQuestion $tpGroupQuestionToRemove)
    {
        $this->tpGroupQuestion->detach($tpGroupQuestionToRemove);
    }

    /**
     * Returns the tpGroupQuestion
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpQuestion> $tpGroupQuestion
     */
    public function getTpGroupQuestion()
    {
        return $this->tpGroupQuestion;
    }

    /**
     * Sets the tpGroupQuestion
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\MffLsb\Domain\Model\TpQuestion> $tpGroupQuestion
     * @return void
     */
    public function setTpGroupQuestion(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $tpGroupQuestion)
    {
        $this->tpGroupQuestion = $tpGroupQuestion;
    }
}
