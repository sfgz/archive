<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * UserSurvey
 */
class UserSurvey extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * for information only
     *
     * @var string
     */
    protected $templateName = '';

    /**
     * templateLabel
     *
     * @var string
     */
    protected $templateLabel = '';

    /**
     * confirmFile
     *
     * @var string
     */
    protected $confirmFile = '';

    /**
     * templateXml
     *
     * @var string
     */
    protected $templateXml = '';

    /**
     * courseName
     *
     * @var string
     * @validate NotEmpty
     */
    protected $courseName = '';

    /**
     * subject
     *
     * @var string
    * @validate NotEmpty
     */
    protected $subject = '';

    /**
    * startDate
    *
    * @var \DateTime
    * @validate NotEmpty,DateTime
    */
    protected $startDate = null;

    /**
     * expireDays
     *
     * @var int
     */
    protected $expireDays = null;

    /**
     * remoteDays
     *
     * @var int
     */
    protected $remoteDays = null;

  /**
    * deletionDate
    *
    * @var \DateTime
    * @validate NotEmpty,DateTime
    */
    protected $deletionDate = null;

    /**
     * userUid
     *
     * @var string
     */
    protected $userUid = '';

    /**
     * cruserId
     *
     * @var string
     */
    protected $cruserId = '';

    /**
     * enquirerType
     *
     * @var int
     */
    protected $enquirerType = 0;

    /**
     * semesterUid
     *
     * @var int
     */
    protected $semesterUid = 0;

    /**
     * klasseUid
     *
     * @var int
     */
    protected $klasseUid = 0;

    /**
     * fachUid
     *
     * @var int
     */
    protected $fachUid = 0;

    /**
     * remoteKey
     *
     * @var string
     */
    protected $remoteKey = '';

    /**
     * enquirerUid
     *
     * @var string
     */
    protected $enquirerUid = '';

    /**
     * enquirerEmail
     *
     * @var string
     */
    protected $enquirerEmail = '';

    /**
     * enquirerName
     *
     * @var string
     */
    protected $enquirerName = '';

    /**
     * participType
     *
     * @var int
     */
    protected $participType = 0;

    /**
     * participCount
     *
     * @var int
     * @validate NotEmpty
     */
    protected $participCount = 1;

    /**
     * participMails
     *
     * @var string
     */
    protected $participMails = '';

  /**
    * responsesUpdated
    *
    * @var \DateTime
    * @validate DateTime
    */
    protected $responsesUpdated = null;

    /**
     * responsesField
     *
     * @var string
     */
    protected $responsesField = '';

    /**
     * templateGroupOptions
     *
     * @var string
     */
    protected $templateGroupOptions = '';

    /**
     * userTpSurvey
     *
     * @var \Mff\MffLsb\Domain\Model\TpSurvey
     * @validate NotEmpty
     */
    protected $userTpSurvey = null;

    /**
     * surveyUid
     *
     * @var int
     */
    protected $surveyUid = null;

    /**
     * surveyState
     *
     * @var int
     */
    protected $surveyState = null;

    /**
     * responsesCount
     *
     * @var int
     */
    protected $responsesCount = null;

    /**
     * mailState
     *
     * @var int
     */
    protected $mailState = null;

    /**
     * crdate
     *
     * @var int
     */
    protected $crdate = null;

    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects() {}

    /**
     * Returns the templateName
     *
     * @return string $templateName
     */
    public function getTemplateName()
    {
        return $this->templateName;
    }

    /**
     * Sets the templateName
     *
     * @param string $templateName
     * @return void
     */
    public function setTemplateName($templateName)
    {
        $this->templateName = $templateName;
    }

    /**
     * Returns the templateLabel
     *
     * @return string $templateLabel
     */
    public function getTemplateLabel()
    {
        return $this->templateLabel;
    }

    /**
     * Sets the templateLabel
     *
     * @param string $templateLabel
     * @return void
     */
    public function setTemplateLabel($templateLabel)
    {
        $this->templateLabel = $templateLabel;
    }

    /**
     * Returns the confirmFile
     *
     * @return string $confirmFile
     */
    public function getConfirmFile()
    {
        return $this->confirmFile;
    }

    /**
     * Sets the confirmFile
     *
     * @param string $confirmFile
     * @return void
     */
    public function setConfirmFile($confirmFile)
    {
        $this->confirmFile = $confirmFile;
    }

    /**
     * Returns the templateXml
     *
     * @return string $templateXml
     */
    public function getTemplateXml()
    {
        return $this->templateXml;
    }

    /**
     * Sets the templateXml
     *
     * @param string $templateXml
     * @return void
     */
    public function setTemplateXml($templateXml)
    {
        $this->templateXml = $templateXml;
    }

    /**
     * Returns the courseName
     *
     * @return string $courseName
     */
    public function getCourseName()
    {
        return $this->courseName;
    }

    /**
     * Sets the courseName
     *
     * @param string $courseName
     * @return void
     */
    public function setCourseName($courseName)
    {
        $this->courseName = $courseName;
    }

    /**
     * Returns the subject
     *
     * @return string $subject
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * Sets the subject
     *
     * @param string $subject
     * @return void
     */
    public function setSubject($subject)
    {
        $this->subject = $subject;
    }

    /**
     * Returns the startDate
     *
     * @return int $startDate
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Sets the startDate
     *
     * @param int $startDate
     * @return void
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;
    }

    /**
     * Returns the expireDays
     *
     * @return int $expireDays
     */
    public function getExpireDays()
    {
        return $this->expireDays;
    }

    /**
     * Sets the expireDays
     *
     * @param int $expireDays
     * @return void
     */
    public function setExpireDays($expireDays)
    {
        $this->expireDays = $expireDays;
    }

    /**
     * Returns the remoteDays
     *
     * @return int $remoteDays
     */
    public function getRemoteDays()
    {
        return $this->remoteDays;
    }

    /**
     * Sets the remoteDays
     *
     * @param int $remoteDays
     * @return void
     */
    public function setRemoteDays($remoteDays)
    {
        $this->remoteDays = $remoteDays;
    }

    /**
     * Returns the deletionDate
     *
     * @return int $deletionDate
     */
    public function getDeletionDate()
    {
        return $this->deletionDate;
    }

    /**
     * Sets the deletionDate
     *
     * @param int $deletionDate
     * @return void
     */
    public function setDeletionDate($deletionDate)
    {
        $this->deletionDate = $deletionDate;
    }

    /**
     * Returns the userUid
     *
     * @return string $userUid
     */
    public function getUserUid()
    {
        return $this->userUid;
    }

    /**
     * Sets the userUid
     *
     * @param string $userUid
     * @return void
     */
    public function setUserUid($userUid)
    {
        $this->userUid = $userUid;
    }

    /**
     * Returns the cruserId
     *
     * @return string $cruserId
     */
    public function getCruserId()
    {
        return $this->cruserId;
    }

    /**
     * Sets the cruserId
     *
     * @param string $cruserId
     * @return void
     */
    public function setCruserId($cruserId)
    {
        $this->cruserId = $cruserId;
    }

    /**
     * Returns the enquirerType
     *
     * @return int $enquirerType
     */
    public function getEnquirerType()
    {
        return $this->enquirerType;
    }

    /**
     * Sets the enquirerType
     *
     * @param int $enquirerType
     * @return void
     */
    public function setEnquirerType($enquirerType)
    {
        $this->enquirerType = $enquirerType;
    }

    /**
     * Returns the semesterUid
     *
     * @return int $semesterUid
     */
    public function getSemesterUid()
    {
        return $this->semesterUid;
    }

    /**
     * Sets the semesterUid
     *
     * @param int $semesterUid
     * @return void
     */
    public function setSemesterUid($semesterUid)
    {
        $this->semesterUid = $semesterUid;
    }

    /**
     * Returns the klasseUid
     *
     * @return int $klasseUid
     */
    public function getKlasseUid()
    {
        return $this->klasseUid;
    }

    /**
     * Sets the klasseUid
     *
     * @param int $klasseUid
     * @return void
     */
    public function setKlasseUid($klasseUid)
    {
        $this->klasseUid = $klasseUid;
    }

    /**
     * Returns the fachUid
     *
     * @return int $fachUid
     */
    public function getFachUid()
    {
        return $this->fachUid;
    }

    /**
     * Sets the fachUid
     *
     * @param int $fachUid
     * @return void
     */
    public function setFachUid($fachUid)
    {
        $this->fachUid = $fachUid;
    }

    /**
     * Returns the remoteKey
     *
     * @return int $remoteKey
     */
    public function getRemoteKey()
    {
        return $this->remoteKey;
    }

    /**
     * Sets the remoteKey
     *
     * @param int $remoteKey
     * @return void
     */
    public function setRemoteKey($remoteKey)
    {
        $this->remoteKey = $remoteKey;
    }

    /**
     * Returns the enquirerUid
     *
     * @return string $enquirerUid
     */
    public function getEnquirerUid()
    {
        return $this->enquirerUid;
    }

    /**
     * Sets the enquirerUid
     *
     * @param string $enquirerUid
     * @return void
     */
    public function setEnquirerUid($enquirerUid)
    {
        $this->enquirerUid = $enquirerUid;
    }

    /**
     * Returns the enquirerEmail
     *
     * @return string $enquirerEmail
     */
    public function getEnquirerEmail()
    {
        return $this->enquirerEmail;
    }

    /**
     * Sets the enquirerEmail
     *
     * @param string $enquirerEmail
     * @return void
     */
    public function setEnquirerEmail($enquirerEmail)
    {
        $this->enquirerEmail = $enquirerEmail;
    }

    /**
     * Returns the enquirerName
     *
     * @return string $enquirerName
     */
    public function getEnquirerName()
    {
        return $this->enquirerName;
    }

    /**
     * Sets the enquirerName
     *
     * @param string $enquirerName
     * @return void
     */
    public function setEnquirerName($enquirerName)
    {
        $this->enquirerName = $enquirerName;
    }

    /**
     * Returns the participType
     *
     * @return int $participType
     */
    public function getParticipType()
    {
        return $this->participType;
    }

    /**
     * Sets the participType
     *
     * @param int $participType
     * @return void
     */
    public function setParticipType($participType)
    {
        $this->participType = $participType;
    }

    /**
     * Returns the participCount
     *
     * @return string $participCount
     */
    public function getParticipCount()
    {
        return $this->participCount;
    }

    /**
     * Sets the participCount
     *
     * @param string $participCount
     * @return void
     */
    public function setParticipCount($participCount)
    {
        $this->participCount = $participCount;
    }

    /**
     * Returns the participMails
     *
     * @return string $participMails
     */
    public function getParticipMails()
    {
        return $this->participMails;
    }

    /**
     * Sets the participMails
     *
     * @param string $participMails
     * @return void
     */
    public function setParticipMails($participMails)
    {
        $this->participMails = $participMails;
    }

    /**
     * Returns the templateGroupOptions
     *
     * @return string $templateGroupOptions
     */
    public function getTemplateGroupOptions()
    {
        return $this->templateGroupOptions;
    }

    /**
     * Sets the templateGroupOptions
     *
     * @param string $templateGroupOptions
     * @return void
     */
    public function setTemplateGroupOptions($templateGroupOptions)
    {
        $this->templateGroupOptions = $templateGroupOptions;
    }

    /**
     * Returns the responsesUpdated
     *
     * @return int $responsesUpdated
     */
    public function getResponsesUpdated()
    {
        return $this->responsesUpdated;
    }

    /**
     * Sets the responsesUpdated
     *
     * @param int $responsesUpdated
     * @return void
     */
    public function setResponsesUpdated($responsesUpdated)
    {
        $this->responsesUpdated = $responsesUpdated;
    }

    /**
     * Returns the responsesField
     *
     * @return string $responsesField
     */
    public function getResponsesField()
    {
        return $this->responsesField;
    }

    /**
     * Sets the responsesField
     *
     * @param string $responsesField
     * @return void
     */
    public function setResponsesField($responsesField)
    {
        $this->responsesField = $responsesField;
    }

    /**
     * Returns the userTpSurvey
     *
     * @return \Mff\MffLsb\Domain\Model\TpSurvey $userTpSurvey
     */
    public function getUserTpSurvey()
    {
        return $this->userTpSurvey;
    }

    /**
     * Sets the userTpSurvey
     *
     * @param \Mff\MffLsb\Domain\Model\TpSurvey $userTpSurvey
     * @return void
     */
    public function setUserTpSurvey(\Mff\MffLsb\Domain\Model\TpSurvey $userTpSurvey)
    {
        $this->userTpSurvey = $userTpSurvey;
    }

    /**
     * Returns the surveyUid
     *
     * @return int $surveyUid
     */
    public function getSurveyUid()
    {
        return $this->surveyUid;
    }

    /**
     * Sets the surveyUid
     *
     * @param int $surveyUid
     * @return void
     */
    public function setSurveyUid($surveyUid)
    {
        $this->surveyUid = $surveyUid;
    }

    /**
     * Returns the surveyState
     *
     * @return int $surveyState
     */
    public function getSurveyState()
    {
        return $this->surveyState;
    }

    /**
     * Sets the surveyState
     *
     * @param int $surveyState
     * @return void
     */
    public function setSurveyState($surveyState)
    {
        $this->surveyState = $surveyState;
    }

    /**
     * Returns the responsesCount
     *
     * @return int $responsesCount
     */
    public function getResponsesCount()
    {
        return $this->responsesCount;
    }

    /**
     * Sets the responsesCount
     *
     * @param int $responsesCount
     * @return void
     */
    public function setResponsesCount($responsesCount=0)
    {
        $this->responsesCount = $responsesCount;
    }

    /**
     * Returns the mailState
     *
     * @return string $mailState
     */
    public function getMailState()
    {
        return $this->mailState;
    }

    /**
     * Sets the mailState
     *
     * @param string $mailState
     * @return void
     */
    public function setMailState($mailState)
    {
        $this->mailState = $mailState;
    }

    /**
     * Returns the crdate
     *
     * @return string $crdate
     */
    public function getCrdate()
    {
        return $this->crdate;
    }

    /**
     * Sets the crdate
     *
     * @param string $crdate
     * @return void
     */
    public function setCrdate($crdate)
    {
        $this->crdate = $crdate;
    }
}
