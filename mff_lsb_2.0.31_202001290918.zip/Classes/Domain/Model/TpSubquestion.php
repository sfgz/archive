<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * TpSubquestion
 */
class TpSubquestion extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * tpquestion
     *
     * @var int
     */
    protected $tpquestion = 0;
    
    /**
     * question
     *
     * @var string
     */
    protected $question = '';

    /**
     * editable
     *
     * @var bool
     */
    protected $editable = false;

    /**
     * optional
     *
     * @var bool
     */
    protected $optional = false;

    /**
     * sorting
     *
     * @var int
     */
    protected $sorting = 0;

    /**
     * Returns the tpquestion
     *
     * @return int $tpquestion
     */
    public function getTpquestion()
    {
        return $this->tpquestion;
    }

    /**
     * Sets the tpquestion
     *
     * @param int $tpquestion
     * @return void
     */
    public function setTpquestion($tpquestion)
    {
        $this->tpquestion = $tpquestion;
    }

    /**
     * Returns the question
     *
     * @return string $question
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * Sets the question
     *
     * @param string $question
     * @return void
     */
    public function setQuestion($question)
    {
        $this->question = $question;
    }

    /**
     * Returns the editable
     *
     * @return bool $editable
     */
    public function getEditable()
    {
        return $this->editable;
    }

    /**
     * Sets the editable
     *
     * @param bool $editable
     * @return void
     */
    public function setEditable($editable)
    {
        $this->editable = $editable;
    }

    /**
     * Returns the boolean state of editable
     *
     * @return bool
     */
    public function isEditable()
    {
        return $this->editable;
    }

    /**
     * Returns the optional
     *
     * @return bool $optional
     */
    public function getOptional()
    {
        return $this->optional;
    }

    /**
     * Sets the optional
     *
     * @param bool $optional
     * @return void
     */
    public function setOptional($optional)
    {
        $this->optional = $optional;
    }

    /**
     * Returns the boolean state of optional
     *
     * @return bool
     */
    public function isOptional()
    {
        return $this->optional;
    }
    
    /**
     * Returns the sorting
     *
     * @return string $sorting
     */
    public function getSorting()
    {
        return $this->sorting;
    }

    /**
     * Sets the sorting
     *
     * @param string $sorting
     * @return void
     */
    public function setSorting($sorting)
    {
        $this->sorting = $sorting;
    }

}
