<?php
namespace Mff\MffLsb\Domain\Model;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * Classtemplate
 */
class Classtemplate extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * tpsurvey
     *
     * @var int
     */
    protected $tpsurvey = 0;
    
    /**
     * shortclass
     *
     * @var string
     */
    protected $shortclass = '';


    /**
     * Returns the tpsurvey
     *
     * @return int $tpsurvey
     */
    public function getTpsurvey()
    {
        return $this->tpsurvey;
    }

    /**
     * Sets the tpsurvey
     *
     * @param int $tpsurvey
     * @return void
     */
    public function setTpsurvey($tpsurvey)
    {
        $this->tpsurvey = $tpsurvey;
    }

    /**
     * Returns the shortclass
     *
     * @return string $shortclass
     */
    public function getShortclass()
    {
        return $this->shortclass;
    }

    /**
     * Sets the shortclass
     *
     * @param string $shortclass
     * @return void
     */
    public function setShortclass($shortclass)
    {
        $this->shortclass = $shortclass;
    }



}
