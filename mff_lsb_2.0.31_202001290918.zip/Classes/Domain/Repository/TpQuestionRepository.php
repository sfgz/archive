<?php
namespace Mff\MffLsb\Domain\Repository;

/***
 *
 * This file is part of the "LimeSurvey Baker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017 Daniel Rueegg <colormixture@verarbeitung.ch>, medienformfarbe
 *
 ***/

/**
 * The repository for TpQuestions
 */
class TpQuestionRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	* @var array
	*/
	protected $defaultOrderings = array(
	    'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);
	
	/**
	* initialize querySettings
	*/
	public function initializeObject() {
		  $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  //Disable Storage pid
		  $querySettings->setRespectStoragePage(FALSE);
		  $this->setDefaultQuerySettings($querySettings);
		  // Get Hidden and Deleted Records not working: $querySettings->getQuerySettings()->setIgnoreEnableFields(true);
	}
	
}