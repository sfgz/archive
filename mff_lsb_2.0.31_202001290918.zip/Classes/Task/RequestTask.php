<?php
namespace Mff\MffLsb\Task;

 /** 
 * Class RequestTask
 * look up if new responses camed in
 * 
 * 
 */
 
use Mff\MffLsb\Controller\UserSurveyController;
use Mff\MffLsb\Domain\Repository\UserSurveyRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
 
class RequestTask extends AbstractTask {

	/**
	* userSurveyRepository
	*
	* @var \Mff\MffLsb\Domain\Repository\UserSurveyRepository
	* @inject
	*/
	protected $userSurveyRepository = null;

	/**
	* userSurveyController
	*
	* @var \Mff\MffLsb\Controller\UserSurveyController
	*/
	protected $userSurveyController = null;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initiate( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();

			$this->userSurveyController = GeneralUtility::makeInstance(UserSurveyController::class);
			$this->userSurveyController->initialize_basics();
			
			$this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
			$fullsettings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
			$this->settings = $fullsettings['plugin.']['tx_mfflsb_survey.']['settings.'];
			
			$this->timeZone = new \DateTimeZone('Europe/Zurich');
			
			$this->persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance("TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager");
			
			$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
			$querySettings->setRespectStoragePage(FALSE);
			$this->userSurveyRepository = $this->objectManager->get('Mff\\MffLsb\\Domain\\Repository\\UserSurveyRepository');
			$this->userSurveyRepository->setDefaultQuerySettings( $querySettings );
	}

	public function execute(){
			$this->initiate();
			$success = FALSE;
			$objListUpdated = 0;
			
			$aSurveys = $this->userSurveyRepository->findAll();
			if( !count($aSurveys) ) return $success;
			
			foreach( $aSurveys as $objSurvey) $objListUpdated += $this->updateSurveyFromApi($objSurvey);
			$this->persistenceManager->persistAll();
			
			// create flashMessage
			$plur = $objListUpdated == 1 ? 'Umfrage wurde' : 'Umfragen wurden';
			$message = GeneralUtility::makeInstance(
					'TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
					$objListUpdated . ' ' . $plur . ' geändert. ',
					'Aufgefrischt', 
					empty($objListUpdated) ? \TYPO3\CMS\Core\Messaging\FlashMessage::INFO : \TYPO3\CMS\Core\Messaging\FlashMessage::OK
			);
			$this->messageQueue->addMessage($message);
			
			$success = TRUE;
			return $success;
	}
	/**
	* updateSurveyFromApi
	*
	* @param \Mff\MffLsb\Domain\Model\UserSurvey $userSurvey
	* @ignorevalidation $userSurvey
	* @return void
	*/
	public function updateSurveyFromApi(\Mff\MffLsb\Domain\Model\UserSurvey $userSurvey){
			if(  $this->userSurveyController->isSurveyActive($userSurvey) == false ) return 0;
			$successed = 0;
			$survey_uid = $userSurvey->getSurveyUid();
			$lsObjUtility = new \Mff\MffLsb\Utility\LimeSurveyObjectUtility( $this->settings );
			$result = $lsObjUtility->getAnswersFromLs( $survey_uid );
			$textValueOfJson = json_encode( $result['responsesField'] );
			if(count($result['responsesField']['responses']) && '[]' != $textValueOfJson ) {
				$userSurvey->setResponsesField( $textValueOfJson );
				$userSurvey->setResponsesCount( count( $result['responsesField']['responses'] ) );
				$successed = 1;
			}
			$dt = new \DateTime("@".time());
			$dt->setTimeZone( $this->timeZone );
			$userSurvey->setResponsesUpdated($dt);
			$this->userSurveyRepository->update( $userSurvey );
			return $successed;
	}

}
