#
# Table structure for table 'tx_mfflsb_domain_model_tpsurvey'
#
CREATE TABLE tx_mfflsb_domain_model_tpsurvey (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	template_name varchar(255) DEFAULT '' NOT NULL,
	template_label varchar(255) DEFAULT '' NOT NULL,
	page_format int(11) DEFAULT '0' NOT NULL,
	versteckt tinyint(1) unsigned DEFAULT '0' NOT NULL,
	raw_title varchar(255) DEFAULT '' NOT NULL,
	list_label varchar(255) DEFAULT '' NOT NULL,
	description text NOT NULL,
	welcome_text text NOT NULL,
	end_text varchar(255) DEFAULT '' NOT NULL,
	confirm_file varchar(255) DEFAULT '' NOT NULL,
	printanswers varchar(255) DEFAULT 'Y' NOT NULL,
	notifysubject varchar(255) DEFAULT '' NOT NULL,
	notifytext text NOT NULL,
	handouttext text NOT NULL,
	importanttext text NOT NULL,
	template_xml text NOT NULL,
	pdf_settings int(11) DEFAULT '0' NOT NULL,
	tp_survey_group int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mfflsb_domain_model_tpgroup'
#
CREATE TABLE tx_mfflsb_domain_model_tpgroup (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	tpsurvey int(11) unsigned DEFAULT '0' NOT NULL,

	group_name varchar(255) DEFAULT '' NOT NULL,
	group_description text NOT NULL,
	report_partials int(11) DEFAULT '0' NOT NULL,
	report_header_vertical tinyint(1) unsigned DEFAULT '0' NOT NULL,
	report_hide_header tinyint(1) unsigned DEFAULT '0' NOT NULL,
	tp_group_question int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY tpsurvey (tpsurvey),

);

#
# Table structure for table 'tx_mfflsb_domain_model_tpquestion'
#
CREATE TABLE tx_mfflsb_domain_model_tpquestion (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	tpgroup int(11) unsigned DEFAULT '0' NOT NULL,

	question varchar(255) DEFAULT '' NOT NULL,
	hide_title tinyint(1) unsigned DEFAULT '0' NOT NULL,
	mandatory tinyint(1) unsigned DEFAULT '0' NOT NULL,
	question_type int(11) DEFAULT '0' NOT NULL,
	question_width int(11) DEFAULT '70' NOT NULL,
	answers varchar(255) DEFAULT '' NOT NULL,
	tp_question_subquestion int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY tpgroup (tpgroup),

);

#
# Table structure for table 'tx_mfflsb_domain_model_tpsubquestion'
#
CREATE TABLE tx_mfflsb_domain_model_tpsubquestion (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	tpquestion int(11) unsigned DEFAULT '0' NOT NULL,

	question varchar(255) DEFAULT '' NOT NULL,
	editable tinyint(1) unsigned DEFAULT '0' NOT NULL,
	optional tinyint(1) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY tpquestion (tpquestion),

);

#
# Table structure for table 'tx_mfflsb_domain_model_usersurvey'
#
CREATE TABLE tx_mfflsb_domain_model_usersurvey (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	template_name varchar(255) DEFAULT '' NOT NULL,
	template_label varchar(255) DEFAULT '' NOT NULL,
	confirm_file varchar(255) DEFAULT '' NOT NULL,
	template_xml text NOT NULL,
	course_name varchar(255) DEFAULT '' NOT NULL,
	subject varchar(255) DEFAULT '' NOT NULL,
	start_date date DEFAULT '0000-00-00',
	expire_days int(11) unsigned DEFAULT '0' NOT NULL,
	remote_days int(11) unsigned DEFAULT '0' NOT NULL,
	deletion_date date DEFAULT '0000-00-00',
	user_uid varchar(255) DEFAULT '' NOT NULL,
	enquirer_type int(11) DEFAULT '0' NOT NULL,
	semester_uid int(11) unsigned DEFAULT '0' NOT NULL,
	klasse_uid int(11) unsigned DEFAULT '0' NOT NULL,
	fach_uid int(11) unsigned DEFAULT '0' NOT NULL,
	remote_key varchar(255) DEFAULT '' NOT NULL,
	enquirer_uid varchar(255) DEFAULT '' NOT NULL,
	enquirer_email varchar(255) DEFAULT '' NOT NULL,
	enquirer_name varchar(255) DEFAULT '' NOT NULL,
	mail_state int(11) DEFAULT '0' NOT NULL,
	particip_type int(11) DEFAULT '0' NOT NULL,
	particip_count int(11) DEFAULT '0' NOT NULL,
	particip_mails text NOT NULL,
	template_group_options text NOT NULL,
	responses_updated datetime DEFAULT '0000-00-00 00:00:00',
	responses_field text NOT NULL,
	responses_count int(11) DEFAULT '0' NOT NULL,
	survey_uid int(11) DEFAULT '0' NOT NULL,
	survey_state int(11) DEFAULT '0' NOT NULL,
	user_tp_survey int(11) unsigned DEFAULT '0',

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY user_uid (user_uid),

);

#
# Table structure for table 'tx_mfflsb_domain_model_classtemplate'
#
CREATE TABLE tx_mfflsb_domain_model_classtemplate (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	tpsurvey int(11) unsigned DEFAULT '0' NOT NULL,

	shortclass varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,


	PRIMARY KEY (uid),
	KEY parent (pid),
	UNIQUE KEY shortclass (shortclass),
	KEY tpsurvey (tpsurvey),

);


