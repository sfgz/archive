<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Template',
            'Vorlagen für Umfragen verwalten'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Survey',
            'Umfragen verwalten'
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Mff.MffLsb',
            'Remote',
            'Umfragen fremdverwalten'
        );

	$pluginSignature = str_replace('_','',$extKey) . '_survey';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_survey.xml');

	$pluginSignature = str_replace('_','',$extKey) . '_template';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_template.xml');

	$pluginSignature = str_replace('_','',$extKey) . '_remote';
	$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:' . $extKey . '/Configuration/FlexForms/flexform_remote.xml');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($extKey, 'Configuration/TypoScript', 'LimeSurvey Baker');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpsurvey', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpsurvey.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpgroup', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpgroup.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpquestion', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpquestion.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_tpsubquestion', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_tpsubquestion.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_usersurvey', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_usersurvey.xlf');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mfflsb_domain_model_classtemplate', 'EXT:mff_lsb/Resources/Private/Language/locallang_csh_tx_mfflsb_domain_model_classtemplate.xlf');

    },
    $_EXTKEY
);
