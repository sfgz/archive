<?php
namespace Mff\MffLsb\Utility;
use Mff\MffLsb\Utility;

	$aPath = explode( '/' , __FILE__ );
	$rootPathToExt = implode( '/' , array_slice( $aPath , 0 , count($aPath) - 5 ) );
	$libFilePath = '/mff_lsb/Classes/Utility/SpiderImageUtility.php';
	include( $rootPathToExt . $libFilePath );
	$image = new SpiderImageUtility();
	echo $image->main();
	exit();
