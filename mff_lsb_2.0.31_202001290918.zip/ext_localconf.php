<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
	{

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Mff.MffLsb',
            'Template',
            [
                'TpSurvey' => 'list, new, create, edit, update, delete, printout',
                'TpGroup' => 'list, new, create, edit, update, delete',
                'TpQuestion' => 'list, new, create, edit, update, delete',
                'TpSubquestion' => 'list, new, create, edit, update, delete',
                'Json' => 'show'
            ],
            // non-cacheable actions
            [
                'TpSurvey' => 'list, new, edit, delete, create, printout',
                'TpGroup' => 'list, new, edit, delete'
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Mff.MffLsb',
            'Survey',
            [
                'UserSurvey' => 'list, new, create, edit, update, delete',
                'Json' => 'show, update'
            ],
            // non-cacheable actions
            [
                'UserSurvey' => 'list, new, create, edit, update, delete',
            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Mff.MffLsb',
            'Remote',
            [
                'RemoteSurvey' => 'dispo,list, delete',
                'Json' => 'show, update'
            ],
            // non-cacheable actions
            [
                'RemoteSurvey' => 'dispo,list'
            ]
        );

		// wizards
		\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
			'mod {
				wizards.newContentElement.wizardItems.plugins {
					elements {
						template {
							icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($extKey) . 'Resources/Public/Icons/user_plugin_template.svg
							title = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_template
							description = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_template.description
							tt_content_defValues {
								CType = list
								list_type = mfflsb_template
							}
						}
						survey {
							icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($extKey) . 'Resources/Public/Icons/user_plugin_survey.svg
							title = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_survey
							description = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_survey.description
							tt_content_defValues {
								CType = list
								list_type = mfflsb_survey
							}
						}
						remote {
							icon = ' . \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($extKey) . 'Resources/Public/Icons/user_plugin_remote.svg
							title = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_remote
							description = LLL:EXT:mff_lsb/Resources/Private/Language/locallang_db.xlf:tx_mff_lsb_domain_model_remote.description
							tt_content_defValues {
								CType = list
								list_type = mfflsb_remote
							}
						}
					}
					show = *
				}
		}'
		);
		// Register scheduler-Tasks
		if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
			$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\Mff\MffLsb\Task\RemotemailTask::class] = array(
				'extension'			=> $extKey,
				'title'				=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.title',
				'description'		=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.mail_daemon.description',
				'additionalFields'	=> \Mff\MffLsb\Task\RemotemailAdditionalFieldProvider::class
			);
			$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\Mff\MffLsb\Task\DeleteTask::class] = array(
				'extension'			=> $extKey,
				'title'				=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.delete_daemon.title',
				'description'		=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.delete_daemon.description',
				'additionalFields'	=> ''
			);
			$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks'][\Mff\MffLsb\Task\RequestTask::class] = array(
				'extension'			=> $extKey,
				'title'				=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.request_daemon.title',
				'description'		=> 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang.xlf:scheduler.request_daemon.description',
				'additionalFields'	=> ''
			);
		};
    },
    $_EXTKEY
);
