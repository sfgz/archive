      function conditionsFieldViews(selVal){
		// default  = 3,4,6
		$('#needle').attr("title", "");
		$('#needle').attr("placeholder", "");
		$('label[for=needle]').html('Suche');
		$('#needle2').attr("title", "");
		$('#needle2').attr("placeholder", "");
		$('#newtext').attr("title", "");
		$('#newtext').attr("placeholder", "");
		$('label[for=newtext]').html('Ersatz');
		$('#newtext2').attr("title", "");
		$('#newtext2').attr("placeholder", "");
		$('label[for=newtext2]').html('Ersatz 2');
		$('label[for=needle2]').html('Suche 2');
		switch (selVal) {
		    case '0':
			$('#box_fieldname2').fadeOut(100);
			$('#box_needle2').fadeOut(100);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#fieldname').fadeOut(100);
			$('label[for=fieldname]').fadeOut(100);
			$('#needle').fadeOut(100);
			$('label[for=needle]').fadeOut(100);
			break;
		    case '1':
		    case '2':
			$('#needle').attr("title", "_LEER_ zeigt nur leere. * zeigt alle mit irgendeinem Wert.");
			$('#needle2').attr("title", "_LEER_ zeigt nur leere. * zeigt alle mit irgendeinem Wert.");
			$('#newtext').attr("title", "um Feld zu leeren den Platzhalter _LEEREN_ einsetzen");
			$('#newtext2').attr("title", "um Feld zu leeren den Platzhalter _LEEREN_ einsetzen");
			$('#newtext').attr("placeholder", "zB. _LEEREN_ |");
			$('#newtext2').attr("placeholder", "zB. _LEEREN_ |");
			$('#needle').attr("placeholder", "_LEER_ | * (nicht leer) |");
			$('#needle2').attr("placeholder", "_LEER_ | * (nicht leer) |");
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			$('#box_newtext').fadeIn(400);
			$('#box_fieldname2').fadeIn(400);
			$('#box_needle2').fadeIn(400);
			$('#box_newtext2').fadeIn(400);
			break;
		    case '3':
			$('#box_fieldname2').fadeOut(100);
			$('#box_needle2').fadeOut(100);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			break;
		    case '4':
			$('#box_fieldname2').fadeOut(100);
			$('#box_needle2').fadeOut(100);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
// 			$('#fieldname').val(12);
			break;
		    case '5':
			$('#box_needle2').fadeOut(100);
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			$('#box_newtext').fadeIn(400);
			$('#box_fieldname2').fadeIn(400);
			$('#box_newtext2').fadeIn(400);
			$('label[for=needle]').html('Tabelle');
			$('label[for=newtext]').html('Beziehung Feld');
			$('label[for=newtext2]').html('Beziehung Feld');
			break;
		    case '6':
			$('#box_fieldname2').fadeOut(100);
			$('#box_needle2').fadeOut(100);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
// 			$('#fieldname').val(8);
			break;
		    case '7':
			$('#needle').attr("placeholder", "z.B. 22082016");
			$('label[for=needle]').html('Suche');
			$('#needle2').attr("placeholder", "z.B. 22082016");
			$('#newtext').attr("placeholder", "z.B. 30012017");
			$('label[for=newtext]').html('erster Montag');
			$('#newtext2').attr("placeholder", "z.B. 04022017");
			$('label[for=newtext2]').html('letzter Samstag');
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			$('#box_newtext').fadeIn(400);
			$('#box_fieldname2').fadeIn(400);
			$('#box_needle2').fadeIn(400);
			$('#box_newtext2').fadeIn(400);
// 			$('#fieldname').val(3);
// 			$('#fieldname2').val(4);
			break;
		    case '8':
			$('label[for=needle]').html('Formatierung');
			$('label[for=needle2]').html('wenn Suche');
// 			$('#fieldname').val(13);
// 			$('#fieldname2').val(12);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#needle').attr("placeholder", "0#");
			$('#needle').attr("title", "Formatierung zB 0# oder 00##");
			$('#needle2').attr("placeholder", "Lp");
			$('#needle2').attr("title", "Uebereinstimmender Wert");
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			$('#box_fieldname2').fadeIn(400);
			$('#box_needle2').fadeIn(400);
			break;
		    case '9':
			$('#box_needle2').fadeIn(400);
			$('#box_newtext2').fadeOut(100);
			$('#box_newtext').fadeOut(100);
			$('#needle').fadeIn(400);
			$('label[for=needle]').fadeIn(400);
			$('#fieldname').fadeIn(400);
			$('label[for=fieldname]').fadeIn(400);
			$('#box_fieldname2').fadeIn(400);
			$('#needle').attr("placeholder", "z.B. _LEER_ oder n.n.");
			$('label[for=needle]').html('Bedingung');
			$('#needle2').attr("placeholder", "z.B. _LEER_ oder n.n.");
			$('label[for=needle2]').html('Bedingung');
			break;
		    case '10':
			$('#box_needle2').fadeOut(100);
 			$('label[for=needle]').html('Trennzeichen');
			$('#needle').attr("placeholder", "z.B. Leerzeichen");
 			$('label[for=newtext]').html('Index (1 = zweiter Teil, 1- = Rest)');
			$('#newtext').attr("placeholder", "z.B. 1-");
 			$('label[for=newtext2]').html('Index (0 = erster Teil, 1- Rest)');
			$('#newtext2').attr("placeholder", "z.B. 0");
			break;
		}
      }
