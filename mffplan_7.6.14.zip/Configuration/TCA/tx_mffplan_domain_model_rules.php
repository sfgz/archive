<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules',
		'label' => 'description',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,
		'sortby' => 'sorting',

		'enablecolumns' => array(

		),
		'searchFields' => 'description,rendertype,fieldname,needle,newtext,fieldname2,needle2,newtext2,activate,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffplan') . 'Resources/Public/Icons/tx_mffplan_domain_model_rules.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'description, rendertype, fieldname, needle, newtext, fieldname2, needle2, newtext2, activate,sorting',
	),
	'types' => array(
		'1' => array('showitem' => 'description, rendertype, fieldname, needle, newtext, fieldname2, needle2, newtext2, activate, sorting,'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'description' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.description',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'rendertype' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.rendertype',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('none', 0),
					array('replace char', 1),
					array('replace field', 2),
					array('prepend zero', 8),
					array('splitRow', 3),
					array('splitBuildingRoom', 4),
					array('split classes', 6),
					array('date ranges', 7),
					array('testRelations', 5),
					array('exclude if', 9),
					array('splitField', 10),
				),
				'size' => 1,
				'maxitems' => 1,
				'eval' => ''
			)
		),
		'fieldname' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.fieldname',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'needle' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.needle',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'newtext' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.newtext',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'fieldname2' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.fieldname2',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'needle2' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.needle2',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'newtext2' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.newtext2',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'activate' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_rules.activate',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'sorting' => array(
			'exclude' => 0,
			'label' => 'sorting',
			'config' => array(
				'type' => 'input',
				'size' => 5,
				'eval' => 'trim'
			),
		),
		
	),
);
