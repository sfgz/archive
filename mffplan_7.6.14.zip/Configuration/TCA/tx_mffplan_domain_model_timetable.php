<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable',
		'label' => 'weekday',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'weekday,periodicity,date_start,date_end,time_from,time_to,note,import_index,rel_teacher,rel_class,rel_room,rel_subject,rel_period,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffplan') . 'Resources/Public/Icons/tx_mffplan_domain_model_timetable.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'weekday, periodicity, date_start, date_end, time_from, time_to, note, import_index, rel_teacher, rel_period, rel_class, rel_room, rel_subject',
	),
	'types' => array(
		'1' => array('showitem' => 'weekday, periodicity, date_start, date_end, time_from, time_to, note, import_index, rel_teacher, rel_period, rel_class, rel_room, rel_subject, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'weekday' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.weekday',
			'config' => array(
				'type' => 'select',
				'items' => array(
					array('-- leer --', 0),
					array('Mo', 1),
					array('Di', 2),
					array('Mi', 3),
					array('Do', 4),
					array('Fr', 5),
					array('Sa', 6),
					array('So', 7),
				),
				'size' => 1,
				'maxitems' => 1,
				'eval' => ''
			),
		),
		'periodicity' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.periodicity',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'date_start' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.date_start',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'date_end' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.date_end',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'time_from' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.time_from',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'time_to' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.time_to',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'note' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.note',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'import_index' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.import_index',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'rel_teacher' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.rel_teacher',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'fe_users',
				'minitems' => 0,
				'maxitems' => 1,
				'items' => array( array('waehlen', 0) ),
			),
		),
		'rel_class' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.rel_class',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_klasse',
				'foreign_table_where' => 'AND 1=1 Order by class_short ASC',
				'MM' => 'tx_mffplan_timetable_scoolclass_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'module' => array(
							'name' => 'wizard_edit',
						),
						'type' => 'popup',
						'title' => 'Edit',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
				),
			),
		),
		'rel_room' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.rel_room',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_zimmer',
				'foreign_table_where' => 'AND 1=1 Order by haus ASC,zimmer ASC',
				'MM' => 'tx_mffplan_timetable_room_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'module' => array(
							'name' => 'wizard_edit',
						),
						'type' => 'popup',
						'title' => 'Edit',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
				),
			),
		),
		'rel_subject' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.rel_subject',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_fach',
				'MM' => 'tx_mffplan_timetable_subject_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'module' => array(
							'name' => 'wizard_edit',
						),
						'type' => 'popup',
						'title' => 'Edit',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
				),
			),
		),
		'rel_period' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_timetable.rel_period',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffplan_domain_model_periods',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		
	),
);