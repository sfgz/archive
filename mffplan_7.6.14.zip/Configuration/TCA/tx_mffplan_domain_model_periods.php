<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods',
		'label' => 'semester',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'semester,datum_ab,datum_bis,davor_bis,danach_ab,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffplan') . 'Resources/Public/Icons/tx_mffplan_domain_model_periods.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'semester,davor_bis, datum_ab, datum_bis,danach_ab',
	),
	'types' => array(
		'1' => array('showitem' => 'semester,davor_bis, datum_ab, datum_bis,danach_ab, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'semester' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods.semester',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'davor_bis' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods.davor_bis',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'datum_ab' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods.datum_ab',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'datum_bis' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods.datum_bis',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		'danach_ab' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:mffplan/Resources/Private/Language/locallang_db.xlf:tx_mffplan_domain_model_periods.danach_ab',
			'config' => array(
				'dbType' => 'date',
				'type' => 'input',
				'size' => 7,
				'eval' => 'date',
				'checkbox' => 0,
				'default' => '0000-00-00'
			),
		),
		
	),
);