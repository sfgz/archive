<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'Planimport',
	array(
		'Rules' => 'list, new, create, edit, update, delete, compare',
		'Timetable' => 'list, new, create, edit, update, delete',
		
	),
	// non-cacheable actions
	array(
		'Rules' => 'create, edit, update, delete, compare',
		'Timetable' => 'create, edit, update, delete',
		
	)
);
