<?php
namespace Mff\Mffplan\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * RulesController
 */
class RulesController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * rulesRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\RulesRepository
	 * @inject
	 */
	protected $rulesRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 * @inject
	 */
	protected $periodsRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	 * @var \Mff\Mffplan\Utility\PreProcessFileUtility
	 */
	protected $preProcessFileUtility = NULL;

	/**
	* pathToPHPExcel
	*
	* @var string
	*/
	public $pathToPHPExcel = 'typo3conf/ext/mff_contrib/Resources/Private/PHP/PHPExcel_1.8.0/Classes/';
	
	/**
	 * LocalizedRendertypes
	 *
	 * @var array
	 */
	protected $LocalizedRendertypes = array();

	/**
	 * Initialize
	 *
	 * @return void
	 */
	public function initializeAction() {
		foreach ($GLOBALS['TCA']['tx_mffplan_domain_model_rules']['columns']['rendertype']['config']['items'] as $selIx => $pairs) {
			$translation = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('tx_mffplan_domain_model_rules.rendertypes.' . $pairs[1], 'mffplan');
			$this->LocalizedRendertypes[$pairs[1]] = empty($translation) ? $pairs[0] : $translation;
		}
		$this->preProcessFileUtility = new \Mff\Mffplan\Utility\PreProcessFileUtility( $this->settings );
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		if ($this->request->hasArgument('edit_activate') && $this->request->hasArgument('rules')) {
			$editNr = $this->request->getArgument('rules');
			$editVal = $this->request->getArgument('edit_activate');
			$rule = $this->rulesRepository->findByUid($editNr);
			$rule->setActivate($editVal ? 0 : 1);
			$this->rulesRepository->update($rule);
			$this->persistenceManager->persistAll();
			$this->addFlashMessage('The object was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		$rules = $this->rulesRepository->findAll();
		$this->view->assign('rules', $rules);
		$this->view->assign('fieldnames', $this->settings['fieldnames']);
		$this->view->assign('rendertypes', $this->LocalizedRendertypes);
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		$this->view->assign('fieldnames', $this->settings['fieldnames']);
		$this->view->assign('rendertypes', $this->LocalizedRendertypes);
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffplan\Domain\Model\Rules $newRules
	 * @return void
	 */
	public function createAction(\Mff\Mffplan\Domain\Model\Rules $newRules) {
		$this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->rulesRepository->add($newRules);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffplan\Domain\Model\Rules $rules
	 * @ignorevalidation $rules
	 * @return void
	 */
	public function editAction(\Mff\Mffplan\Domain\Model\Rules $rules) {
		$this->view->assign('rules', $rules);
		foreach ($this->settings['fieldnames'] as $nr => $type) {
			$fieldnames[$nr] = $type . ' (' . $nr . ')';
		}
		$this->view->assign('fieldnames', $fieldnames);
		foreach ($this->LocalizedRendertypes as $nr => $type) {
			$rendertypes[$nr] = $type . ' #' . $nr . '';
		}
		$this->view->assign('rendertypes', $rendertypes);
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffplan\Domain\Model\Rules $rules
	 * @return void
	 */
	public function updateAction(\Mff\Mffplan\Domain\Model\Rules $rules) {
		if ($this->request->hasArgument('abort')) {
			$this->redirect('list');
			return;
		}
		$this->addFlashMessage('The object "#' . $rules->getUid() . '" was updated.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->rulesRepository->update($rules);
		$this->redirect('list');
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffplan\Domain\Model\Rules $rules
	 * @return void
	 */
	public function deleteAction(\Mff\Mffplan\Domain\Model\Rules $rules) {
		$this->addFlashMessage('The object was deleted.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->rulesRepository->remove($rules);
		$this->redirect('list');
	}

	/**
	 * Initialize  compare
	 *
	 * @return void
	 */
	public function initializeCompareAction() {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storagePid['foreignStoragePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
		$storagePid['storagePid'] = $settings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds($storagePid);
		// if script is called from external
		if (!is_array($this->settings)) {
			$this->settings = $this->initializeFromExternalCompareAction($settings['plugin.']['tx_mffplan_planimport.']['settings.']);
		}
		$this->settings['storagePid'] = $storagePid['storagePid'];
		$this->settings['foreignStoragePid'] = $storagePid['foreignStoragePid'];
		$this->kurzklasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KurzklasseRepository');
		$this->kurzklasseRepository->setDefaultQuerySettings($querySettings);
		$this->klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
		$this->klasseRepository->setDefaultQuerySettings($querySettings);
		$this->fachRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
		$this->fachRepository->setDefaultQuerySettings($querySettings);
		$this->zimmerRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
		$this->zimmerRepository->setDefaultQuerySettings($querySettings);
		$this->ecouserRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
		if (empty($this->persistenceManager)) {
			$this->persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		}
	}

	/**
	 * from external Initialize compare
	 *
	 * @param $settings
	 * @return void
	 */
	public function initializeFromExternalCompareAction($settings) {
		if (is_array($settings)) {
			foreach ($settings as $sett0Key => $sett0Row) {
				if (is_array($sett0Row)) {
					foreach ($sett0Row as $sett1Key => $sett1Row) {
						if (is_array($sett1Row)) {
							foreach ($sett1Row as $sett2Key => $sett2Row) {
								if (is_array($sett2Row)) {
									foreach ($sett2Row as $sett3Key => $sett3Row) {
										$cnf[rtrim($sett0Key, '.')][rtrim($sett1Key, '.')][rtrim($sett2Key, '.')][rtrim($sett3Key, '.')] = $sett3Row;
									}
								} else {
									$cnf[rtrim($sett0Key, '.')][rtrim($sett1Key, '.')][rtrim($sett2Key, '.')] = $sett2Row;
								}
							}
						} else {
							$cnf[rtrim($sett0Key, '.')][rtrim($sett1Key, '.')] = $sett1Row;
						}
					}
				} else {
					$cnf[rtrim($sett0Key, '.')] = $sett0Row;
				}
			}
		} else {
			$cnf = $settings;
		}
		return $cnf;
	}

	/**
	 * action compare
	 *
	 * @return void
	 */
	public function compareAction() {
		$uploadDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['uploadpath'], '/') . '/';
		$processedDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['processedpath'], '/') . '/';
		$sortTables = array();
		if (!isset($GLOBALS['BE_USER'])) {
			$BEuser = 0;
		} else {
			$BEuser = $GLOBALS['BE_USER']->check('tables_modify', 'tx_mffplan_domain_model_timetable') ? 2 : 1;
		}
		$inVars = $this->request->hasArgument($this->settings['formname']) ? $this->request->getArgument($this->settings['formname']) : array('importoption' => array('clearclass' => 1));
		
		// UPLOAD file
		// preset optoins
		$uploadOk = $this->cmpr_uploadCsvFile($uploadDir , (isset($inVars['preprocess']) ? $inVars['preprocess'] : array() ));
		$opt = $this->preProcessFileUtility->options;
		foreach( $opt as $methodname => $predefValue ) { if( !isset($inVars['preprocess'][$methodname]) ) $inVars['preprocess'][$methodname] = $predefValue ; }
		if ($uploadOk) {
			$this->addFlashMessage('Die Datei ' . pathinfo($uploadOk, PATHINFO_BASENAME) . ' wurde hochgeladen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		// DELETE file
		if ($this->request->hasArgument('delete')) {
			$fileNameToUnlink = $this->request->getArgument('delete');
			@unlink($uploadDir . $fileNameToUnlink);
			$this->addFlashMessage('Die Datei ' . $fileNameToUnlink . ' wurde geloescht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}
		// get filelist, prepare for checkboxes
		if ($uploadOk) {
			$dateiliste = $this->cmpr_getFileList($uploadDir, array());
			$dateiliste[pathinfo($uploadOk, PATHINFO_FILENAME)]['checked'] = 'checked';
		} else {
			$dateiliste = $this->cmpr_getFileList($uploadDir, $inVars['fileselect']);
		}
		foreach ($dateiliste as $rootName => $file) {
			if ($file['checked']) {
				$chkdFilesList[$rootName] = $file;
			}
		}
		// fill array $sortTables for output
		if ($uploadOk) {
			$sortTables = $this->cmpr_readAndRuleOnUploadedFile($dateiliste);
			$this->addFlashMessage('Die Datei wurde eingelesen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		} elseif ($this->request->hasArgument('ok') && count($chkdFilesList)) {
			// get data from uploaded filemaker-files, process data trough rules-proc and store the result in files
			$sortTables = $this->cmpr_readAndRuleOnUploadedFile($dateiliste);
			$this->addFlashMessage('Die Datei(en) wurden eingelesen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		} elseif ($this->request->hasArgument('read')) {
			$readActions = $this->request->getArgument('read');
			// actions from button [create_fach] and [create_class]
			if (isset($readActions['create_fach'])) {
				$this->edit_createFach(trim($readActions['create_fach']));
			} elseif (isset($readActions['create_class'])) {
				$this->edit_createKlasse(trim($readActions['create_class']));
			}
			// read already processed data
			// action from button [add to importfile]
			$sortTables = $this->cmpr_readProcessedFiles($processedDir);
			$sortTables = $this->cmpr_moveAngebotToFach($sortTables, $inVars);
			if (isset($readActions['dbimport']) && $BEuser == 2) {
				// clear relations-field; create new periods; read processed file, import to db and delete importfile.
				if ($this->imp_importToDbFromFile($inVars['importoption'])) {
					unset($sortTables['csv']);
					$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
				}
			} elseif (isset($readActions['import']) && count($inVars['error'])) {
				// add to processed import file, but only if fach exists and ( class exists or class empty )
				$this->cmpr_addToImportFile($sortTables, $inVars);
				unset($inVars['error']);
				// read already processed data
				$sortTables = $this->cmpr_readProcessedFiles($processedDir);
				// action from button [add to importfile]
				$sortTables = $this->cmpr_moveAngebotToFach($sortTables, $inVars);
			}
		} else {
			$sortTables = $this->cmpr_readProcessedFiles($processedDir);
		}
		if($readActions['view_good']) $inVars['importoption']['view_good'] = $readActions['view_good'];
		if (isset($readActions['view_good']) || isset($readActions['dbimport'])) {
			$inVars['ausgabeformat'] = 3;
		} else {
			$inVars['ausgabeformat'] = 1;
		}
		$gb = $this->countDepartmentInTable('gb', $sortTables);
		$wb = $this->countDepartmentInTable('wb', $sortTables);
		$this->view->assign('isDataInTable', array('gb' => $gb, 'wb' => $wb, 'sum' => $gb + $wb));
		$this->view->assign('isBEuser', $BEuser);
		$this->view->assign('formname', $this->settings['formname']);
		$this->view->assign('dateiname', $uploadOk);
		$this->view->assign('ausgabeformat', $inVars['ausgabeformat']);
		$this->view->assign('dateiliste', $dateiliste);
		$this->view->assign('selDateiliste', $chkdFilesList);
		$this->view->assign('tabellen', $sortTables);
		$this->view->assign('preprocess', $inVars['preprocess']);
		$this->view->assign('importoption', isset($inVars['importoption']) ? $inVars['importoption'] : array());
		$this->view->assign('error', isset($inVars['error']) ? $inVars['error'] : array());
		$this->view->assign('fieldnames', $this->settings['ecofieldnames']);

		$intranetStundenplanUtility = new \Mff\Mffplan\Utility\IntranetStundenplanUtility();
		
		$iPeriodUid = $this->request->hasArgument('period') ? $this->request->getArgument('period') :0;
		$periodsCOA = $intranetStundenplanUtility->createPeriodObjects($iPeriodUid);
        $period = $periodsCOA[0];
        $aktPeriode = $periodsCOA[1];
        $aPeriods = $periodsCOA[2];
        $this->view->assign('periods', $aPeriods );
        $this->view->assign('period', $period );
        if($this->request->hasArgument('downloadCourses')){
			$foreignTimetable = 1;//1|2
			$rawQueryResult = $intranetStundenplanUtility->getCourses($foreignTimetable,$period);
			foreach( $rawQueryResult as $idx => $row){
				$out[$idx] = $intranetStundenplanUtility->transformFieldContents( $row , $aktPeriode->getSemester() );
			}
			$csvOut = $this->dwn_arrayToCsv($out);
			$this->dwn_downloadAsCsv($csvOut,'kurse_ab_is2.csv');
        }
	}

	/**
	 * @param $filter
	 * @param $srtTables
	 */
	public function countDepartmentInTable($filter, $srtTables) {
		$depIdFilter = $this->settings['split_table'][$filter]['departmentId'];
		$depLabel = $this->settings['split_table'][$filter]['label'];
		$departmentId = array();
		$klasseRecordsets = $this->klasseRepository->findAll();
		foreach ($klasseRecordsets as $klasserow) {
			$kurzbezeichnung = $klasserow->getClassShort();
			$departmentId[$kurzbezeichnung] = $klasserow->getDepartmentId();
		}
		$out = 0;
		if (is_array($srtTables['csv'])) {
			foreach ($srtTables['csv'] as $idx => $inRow) {
				if ($departmentId[$inRow['Angebot']] == $depIdFilter) {
					++$out;
				}
			}
		}
		return $out;
	}

	/**
	 * handles file upload and deletion
	 * returns string with filename, if action successful
	 *
	 * @param string $uploadDir
	 * @param array $options
	 * @return string
	 */
	public function cmpr_uploadCsvFile($uploadDir , $options = array() ) {
		$fileName = '';
		$extKeyPlgNam = empty($this->request) ? 'tx_mffplan_planimport' : 'tx_' . $this->request->getControllerExtensionKey() . '_' . strtolower($this->request->getPluginName());
		if ($_FILES[$extKeyPlgNam]['tmp_name'][$this->settings['formname']]['dateiname']) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name'][$this->settings['formname']]['dateiname'];
			if( file_exists($uploadDir . $fileName) ) @unlink($uploadDir . $fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move($_FILES[$extKeyPlgNam]['tmp_name'][$this->settings['formname']]['dateiname'], $uploadDir . $fileName);
			
			$this->preProcessFileUtility->preProcessFile( $uploadDir . $fileName , $options );
		}
		return $fileName;
	}

	/**
	 * create a list of files
	 * and return the sum of all filesizes
	 *
	 * @param string $uploadDir
	 * @param $fileselect
	 * @return array
	 */
	public function cmpr_getFileList($uploadDir, $fileselect = array()) {
		$d = dir($uploadDir);
		$filelist = array();
		$fileSizeSum = 0;
		while (false !== ($entry = $d->read())) {
			$filename = pathinfo($entry, PATHINFO_FILENAME);
			$extension = pathinfo($entry, PATHINFO_EXTENSION);
			if ('csv' == $extension) {
				$filelist[$filename]['filename'] = $entry;
				$filSize = filesize($uploadDir . $entry);
				$filelist[$filename]['size'] = round($filSize / 1024, 3);
				$filelist[$filename]['time'] = filemtime($uploadDir . $entry);
				if (isset($fileselect[$filename])) {
					if ($fileselect[$filename]) {
						$filelist[$filename]['checked'] = 'checked';
					}
				}
				$fileSizeSum += $filSize;
			}
		}
		$d->close();
		krsort($filelist);
		return $filelist;
	}

	/**
	 * @param $dateiliste
	 */
	public function cmpr_readAndRuleOnUploadedFile($dateiliste) {
		$chkdFilesList = array();
		$uploadDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['uploadpath'], '/') . '/';
		// uploadpath = /uploads/tx_mffcompare/import/
		if (!count($dateiliste)) {
			return array('array' => array(), 'string' => array());
		}
		foreach ($dateiliste as $rootName => $file) {
			if ($file['checked']) {
				$chkdFilesList[$rootName] = $uploadDir . $file['filename'];
			}
		}
		if (!count($chkdFilesList)) {
			return array('array' => array(), 'string' => array());
		}
		// compute rules on table-data
		$fileNames = $this->settings['filenames'];
		//array( 'csv_error'=>'errors.csv' , 'csv'=>'verarbeitet.csv' );
		$processedDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['processedpath'], '/') . '/';
		$unsortTables = array();
		$strOut = array();
		$sortTables = array();
		$calcObj = new \Mff\Mffplan\Utility\ApplyRuleUtility($this->settings);
		$tableNames = array_keys($fileNames);
		//  array( false=>'csv_error' , true=>'csv' );
		foreach ($chkdFilesList as $rootName => $file) {
			$actualTable = $calcObj->ApplyRulesOnFile($file);
			if( !count($actualTable) ) continue;
			foreach ($actualTable as $ix => $tabRow) {
				$tabOut = array();
				// replace fieldNumber with fieldNames in new Array
				foreach ($this->settings['ecofieldnames'] as $feldnr => $feldname) {
					$tabOut[$feldname] = $tabRow[$feldnr];
				}
				// split table
				// determine current table Name: csv or csv_error
				$currentTableName = $tableNames[empty($tabOut['korrektur'])];
				if ('csv' == $currentTableName) {
					unset($tabOut['korrektur']);
				}
				$newUid = count($unsortTables[$currentTableName]) + 1;
				$unsortTables[$currentTableName][$newUid] = $tabOut;
			}
		}
		// change sort order of tables: first errors
		// write to file
		foreach ($tableNames as $tab) {
			if (file_exists($processedDir . $fileNames[$tab])) {
				@unlink($processedDir . $fileNames[$tab]);
			}
			if (!isset($unsortTables[$tab])) {
				continue;
			}
			$sortTables[$tab] = $unsortTables[$tab];
		}
		file_put_contents($processedDir . 'procdata.json', json_encode($sortTables));
		return $sortTables;
	}

	/**
	 * @param $processedDir
	 * @param $onlyOneTable
	 */
	public function cmpr_readProcessedFiles($processedDir, $onlyOneTable = '') {
		if (file_exists($processedDir . 'procdata.json')) {
			$result = file_get_contents($processedDir . 'procdata.json');
			$sortTables = json_decode($result, TRUE);
			return empty($onlyOneTable) ? $sortTables : $sortTables[$onlyOneTable];
		}
	}

	/**
	 * handles courses without classes (freikurse)
	 * returns array with overwritten table
	 * the script execute following correctures:
	 * if first part of (Course.CourseShort) Fach.Fachkurz compares to whole cell.class
	 * then set cell.fach = Fach.Fachkurz and unset cell.class
	 *
	 * @param string $sortTables array containig the error-table to fix: sortTables[ csv_error ]
	 * @param string $inVars request options containing marked row-id from checkboxes
	 * @return array
	 */
	public function cmpr_moveAngebotToFach($sortTables, $inVars) {
		// execute correctures: if first part of (Course.CourseShort) Fach.Fachkurz compares to whole cell.class
		// then set cell.fach = Fach.Fachkurz and unset cell.class
		if (!is_array($inVars['error'])) {
			return $sortTables;
		}
		$kls = 'Angebot';
		//8;
		$fch = 'Fach';
		//9;
		$table = 'csv_error';
		$Listen = array();
		$klasseRecordsets = $this->klasseRepository->findAll();
		foreach ($klasseRecordsets as $klasserow) {
			$kurzbezeichnung = $klasserow->getClassShort();
			$Listen['klasse'][$kurzbezeichnung] = $kurzbezeichnung;
		}
		$kurzbezeichnung = $this->settings['kursClassShort'];
		if (!isset($Listen['klasse'][$kurzbezeichnung])) {
			$this->edit_createKlasse($kurzbezeichnung, $kurzbezeichnung);
			$Listen['klasse'][$kurzbezeichnung] = $kurzbezeichnung;
		}
		$fachRecordsets = $this->fachRepository->findAll();
		foreach ($fachRecordsets as $fachrow) {
			$kurzbezeichnung = $fachrow->getFachkurz();
			$Listen['fach'][$kurzbezeichnung] = $kurzbezeichnung;
			$bezParts = explode(' ', $kurzbezeichnung);
			if (is_numeric($bezParts[0])) {
				$Listen['kurs'][$bezParts[0]] = $kurzbezeichnung;
			}
		}
		foreach ($inVars['error'] as $ix => $ic) {
			$sortTables[$table][$ix][20] = '';
			$sortTables[$table][$ix][21] = '';
			$sortTables[$table][$ix][22] = '';
			if (empty($ic)) {
				continue;
			}
			// not checked
			$sortTables[$table][$ix][20] = $ix;
			// checked
			$klasse = $sortTables[$table][$ix][$kls];
			$fach = $sortTables[$table][$ix][$fch];
			$kursPart = explode(' ', $klasse);
			if (isset($Listen['kurs'][$klasse])) {
				// 2771 in Klasse matches 2771 A in Fachkurz
				$sortTables[$table][$ix][$fch] = $Listen['kurs'][$klasse];
				$sortTables[$table][$ix][$kls] = $Listen['klasse'][$this->settings['kursClassShort']];
			} elseif (is_numeric($kursPart[0]) && isset($Listen['fach'][$klasse])) {
				// 2771 B matches 2771 B
				$sortTables[$table][$ix][$fch] = $Listen['fach'][$klasse];
				$sortTables[$table][$ix][$kls] = $Listen['klasse'][$this->settings['kursClassShort']];
			} else {
				// GST in Fach matches GST in Fachkurz. First time it will be named klasse_fehlt, then klasse_fehlt_
				if (!isset($Listen['klasse'][$klasse])) {
					$sortTables[$table][$ix][21] = isset($showCreateClassBut[$klasse]) ? ' klasse_fehlt_' : ' klasse_fehlt';
					if(!isset($showCreateClassBut[$klasse]))$showCreateClassBut[$klasse]=$ix;
				}
				if (!isset($Listen['fach'][$fach])) {
					$sortTables[$table][$ix][22] = ' fach_fehlt';
				}
			}
			if (empty($sortTables[$table][$ix]['Zeit_von']) || empty($sortTables[$table][$ix]['Zeit_bis'])) {
				$sortTables[$table][$ix][22] = ' zeit_fehlt';
			}
			if (!empty($sortTables[$table][$ix]['korrektur']) && $sortTables[$table][$ix][$kls] != $this->settings['kursClassShort'] && empty($sortTables[$table][$ix][21]) && empty($sortTables[$table][$ix][22]) && !strpos($sortTables[$table][$ix]['korrektur'], 'fehlt in Kurs.Klasse+Fach')) {
				$sortTables[$table][$ix][22] = ' fehler';
			}
		}
		return $sortTables;
	}

	/**
	 * @param $sortTables
	 * @param $inVars
	 */
	public function cmpr_addToImportFile($sortTables, $inVars) {
		$processedDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['processedpath'], '/') . '/';
		$processed = 0;
		$unfixed = 0;
		if (!is_array($inVars['error'])) return $sortTables;
		
		foreach ($inVars['error'] as $ix => $ic) {
			unset($sortTables['csv_error'][$ix][20]);
			if (empty($ic) || !empty($sortTables['csv_error'][$ix][21]) || !empty($sortTables['csv_error'][$ix][22])) {
				if (!empty($sortTables['csv_error'][$ix]['Fach']) && !empty($ic)) {
					++$unfixed;
				}
				// checked and has errors
				continue;
			}
			unset($sortTables['csv_error'][$ix]['korrektur']);
			unset($sortTables['csv_error'][$ix][20]);
			unset($sortTables['csv_error'][$ix][21]);
			unset($sortTables['csv_error'][$ix][22]);
			$sortTables['csv'][] = $sortTables['csv_error'][$ix];
			unset($sortTables['csv_error'][$ix]);
			++$processed;
		}
		file_put_contents($processedDir . 'procdata.json', json_encode($sortTables));

		if (!method_exists($this, 'getFlashMessageQueue')) {
			return $sortTables;
		}
		$this->addFlashMessage($processed . ' Zeilen zu Importliste angefuegt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		if ($unfixed) {
			$this->addFlashMessage($unfixed . ' Zeilen wurden nicht angefuegt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		}
	}

	/**
	 * @param $importoption
	 */
	protected function imp_importToDbFromFile($importoption) {
		// read the processed file
		$processedDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['processedpath'], '/') . '/';
		$sortTables = $this->cmpr_readProcessedFiles($processedDir);
		$sortTable = $sortTables['csv'];
		if (!count($sortTable)) {
			$this->addFlashMessage('no records in file. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			return true;
		}
		foreach ($sortTable as $ix => $row) {
			if (empty($row['Periode'])) {
				continue;
			}
			$Perioden[$row['Periode']] += 1;
			$Klassen[$row['Periode']][$row['Angebot']] = $row['Angebot'];
		}
		$maxVal = max($Perioden);
		$mostPopularPeriod = array_search($maxVal, $Perioden);
		// clear relations-field in timetable before import, to protect old data from getting deleted
		$periods = $this->periodsRepository->findBySemester($mostPopularPeriod);
		foreach ($periods as $periodObj) {
			$periodUid = $periodObj->getUid();
			if (!empty($periodUid)) {
				break;
			}
		}
		if (isset($periodUid)) {
			$cleartableController = new \Mff\Mffplan\Command\CleartableCommandController();
			if (empty($importoption['keeplast'])) {
				// total-import: delete recordsets from specific period, keep others
				$cleartableController->setExtConf(array('period' => $periodUid));
			} else {
				// partial-import:  only delete recordsets from specific class/period, keep others
				$classShorts = implode(',', $Klassen[$mostPopularPeriod]);
				$cleartableController->setExtConf(array('period' => $periodUid, 'classShorts' => $classShorts));
			}
			$res = $cleartableController->execute();
			$per = $cleartableController->getExtConf('period');
			$classCounter = isset($classShorts) ? ' countClasses: ' . count($Klassen[$mostPopularPeriod]) . ', ' : ' classes ignored, ';
			if ($res['Timetable-']) {
				$this->addFlashMessage('tt recordsets deleted: ' . $res['Timetable-'] . ', ' . $classCounter . ' sem: ' . $mostPopularPeriod . '=' . $per . ' (CleartableCommandController)', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
			if ($res['Timetable+']) {
				$this->addFlashMessage('tt recordsets edited, they may be overwritten or deleted: ' . $res['Timetable+'] . ', ' . $classCounter . ' sem: ' . $mostPopularPeriod . '=' . $per . ' (CleartableCommandController)', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
			}
			if ($res['Timetable']) {
				$this->addFlashMessage('tt recordsets cleard: ' . $res['Timetable'] . ', ' . $classCounter . ' sem: ' . $mostPopularPeriod . '=' . $per . ' (CleartableCommandController)', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
			if ($res['Timetable.']) {
				$this->addFlashMessage('tt recordsets realcleard: ' . $res['Timetable.'] . ', ' . $classCounter . ' sem: ' . $mostPopularPeriod . '=' . $per . ' (CleartableCommandController)', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
			if ($res['Timetable_']) {
				$this->addFlashMessage('tt recordsets periodcleard: ' . $res['Timetable_'] . ', ' . $classCounter . ' sem: ' . $mostPopularPeriod . '=' . $per . ' (CleartableCommandController)', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}
		}
		// load helper class and run synchonized import
		$helper = new \Mff\Mffplan\Utility\ImportToDbUtility($this->settings);
		$messages = $helper->SetupAndRunSync($sortTable);
		if (!count($messages['error']) && !count($messages['warning'])) {
			if (is_array($messages)) {
				$hasErrors = 0;
				foreach ($messages as $errNr => $msgMainrows) {
					foreach ($msgMainrows as $msgRows) {
						if ($errNr) {
							++$hasErrors;
							$this->addFlashMessage($errNr . ': ' . $msgRows, '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
						} else {
							$this->addFlashMessage($msgRows, '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
						}
					}
				}
			}
			// delete imported data from file when import was successful
			if (empty($hasErrors)) {
				$helper->CleanUpAfterSync($sortTables);
			}
			return empty($hasErrors);
		} else {
			$report = '';
			foreach ($messages as $type => $messageList) {
				$report .= $GLOBALS['LANG']->getLL('label.' . $type) . "\n";
				if (count($messageList) == 0) {
					$report .= '	' . $GLOBALS['LANG']->getLL('no.' . $type) . "\n";
				} else {
					foreach ($messageList as $aMessage) {
						$report .= '	- ' . $aMessage . "\n";
					}
				}
			}
			$this->addFlashMessage($report, '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			return false;
		}
		return false;
	}

	/**
	 * @param $fachInfos
	 */
	public function edit_createFach($fachInfos) {
		$inFachArr = explode('|', $fachInfos);
		$newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\\Mffdb\\Domain\\Model\\Fach');
		$newCode->setFachkurz(trim($inFachArr[0]));
		$newCode->setFachbezeichnung(trim($inFachArr[1]));
		$newCode->setCruserId($GLOBALS['TSFE']->fe_user->user['uid']);
		$this->fachRepository->add($newCode);
		$this->persistenceManager->persistAll();
		if (method_exists($this, 'getFlashMessageQueue')) {
			$this->addFlashMessage('Fach erzeugt: ' . $fachInfos . '', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}
	}

	/**
	 * @param $classShort
	 * @param $klasseKurz
	 */
	public function edit_createKlasse($classShort, $klasseKurz = '') {
		$klsArr = explode(' ', trim($classShort));
		$kurz = !empty($klasseKurz) ? $klasseKurz : substr($klsArr[0], 0, strlen($klsArr[0]) - 2);
		$jahr = ( $classShort == $klasseKurz || is_numeric(substr($klsArr[0],0,1)) ) ? date('y') : substr($klsArr[0], strlen($klsArr[0]) - 2, 2);
		if( !is_numeric($jahr) || empty($jahr) ) $jahr = date('y');
		$zug = isset($klsArr[1]) ? trim($klsArr[1]) : '';
		$kurzklasseUid = $this->edit_getMkKurzklasseUid($kurz);
		$yearDuration = empty($this->settings['orphanClassDurationYears']) ? 4 : $this->settings['orphanClassDurationYears'];
		$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_mffdb_domain_model_klasse', array(
			'klasse_start' => mktime(0, 0, 0, 1, 1, 2000 + $jahr),
			'klasse_ende' => mktime(23, 59, 59, 12, 31, 2000 + $yearDuration + $jahr),
			'pid' => $this->settings['foreignStoragePid'],
			'kurzklasse' => $kurzklasseUid,
			'class_short' => $classShort,
			'klasse_kurz' => $kurz,
			'klasse_jahr' => $jahr,
			'klasse_zug' => $zug,
			'tstamp' => time(),
			'crdate' => time(),
			'cruser_id' => $GLOBALS['TSFE']->fe_user->user['uid']
		));
		if (method_exists($this, 'getFlashMessageQueue')) {
			$this->addFlashMessage('Klasse "' . $classShort . '" erzeugt.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
	}

	/**
	 * @param $kurzbezeichnung
	 */
	public function edit_getMkKurzklasseUid($kurzbezeichnung) {
		$kurzklassen = $this->kurzklasseRepository->findByKurzbezeichnung($kurzbezeichnung);
		foreach ($kurzklassen as $kk) {
			$kurzklasseUid = $kk->getUid();
			if (!empty($kurzklasseUid)) {
				break;
			}
		}
		if (empty($kurzklasseUid)) {
			$newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\\Mffdb\\Domain\\Model\\Kurzklasse');
			$newCode->setKurzbezeichnung($kurzbezeichnung);
			$newCode->setCruserId($GLOBALS['TSFE']->fe_user->user['uid']);
			$this->kurzklasseRepository->add($newCode);
			$this->persistenceManager->persistAll();
			$kurzklasseUid = $newCode->getUid();
			if (method_exists($this, 'getFlashMessageQueue')) {
				$this->addFlashMessage('Kurzklasse "' . $kurzbezeichnung . '" erzeugt. Unter "Kurzklassen" den Fachbereich eintragen!', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
		}
		return $kurzklasseUid;
	}

	/**
	 * Initialize  compare
	 *
	 * @return void
	 */
	public function initializeDownloadAction() {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration(\TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storagePid['foreignStoragePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
		$this->settings['kursClassShort'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['kursClassShort'];
		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds($storagePid);
		$this->klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
		$this->klasseRepository->setDefaultQuerySettings($querySettings);
	}

	/**
	 * action download
	 *
	 * @param string $filter filter data for: error gb wb dbimport
	 * @return void
	 */
	public function downloadAction($filter = 'dbimport') {
		$processedDir = rtrim(PATH_site, '/') . '/' . rtrim($this->settings['processedpath'], '/') . '/';
		$inVars = $this->request->hasArgument($this->settings['formname']) ? $this->request->getArgument($this->settings['formname']) : array('importoption' => array('clearclass' => 1));
		$result = file_get_contents($processedDir . 'procdata.json');
		$srtTables = json_decode($result, TRUE);
		switch ($filter) {
			case 'dbimport':	return $this->dwn_downloadAsCsv($this->dwn_arrayToCsv($srtTables['csv']), 'verarbeitet_' . $filter . '_' . date('ymd-Hi') . '.csv');
				break;
			case 'gb':	
			case 'wb':	$depIdFilter = $this->settings['split_table'][$filter]['departmentId'];
				$depLabel = $this->settings['split_table'][$filter]['label'];
				$departmentId = array();
				$klasseRecordsets = $this->klasseRepository->findAll();
				foreach ($klasseRecordsets as $klasserow) {
					$kurzbezeichnung = $klasserow->getClassShort();
					$departmentId[$kurzbezeichnung] = $klasserow->getDepartmentId();
				}
				$departmentId[$this->settings['kursClassShort']] = 1;
				foreach ($srtTables['csv'] as $idx => $inRow) {
					if ($departmentId[$inRow['Angebot']] == $depIdFilter) {
						$arrOut[$idx] = $inRow;
					}
				}
				unset($this->settings['ecofieldnames'][$this->settings['specialfields']['hints']]);
				return $this->dwn_downloadAsCsv($this->dwn_arrayToCsv($arrOut), 'zu_eco_' . $depLabel . '_' . date('ymd-Hi') . '.csv');
				break;
			case 'error':	return $this->dwn_downloadAsXls(array('csv_error' => $srtTables['csv_error']));
				break;
		}
		$this->redirect('compare');
	}

	/**
	 * @param $sortTable
	 */
	protected function dwn_arrayToCsv($sortTable) {
		if (!is_array($sortTable)) {
			return;
		}
		$delimiter = empty($this->settings['csv_options']['delimiter']) ? ';' : $this->settings['csv_options']['delimiter'];
		$textQualifier = $this->settings['csv_options']['text_qualifier'];
		$strOut = '';
		// First row with fieldnames
		foreach ($sortTable as $idx => $row) {
			$rowArr = array();
			foreach ($this->settings['ecofieldnames'] as $fld => $fieldname) {
				// 		foreach( array_keys($row) as $filedname){
				$rowArr[$fieldname] = $textQualifier . $fieldname . $textQualifier;
			}
			$strOut .= implode($delimiter, $rowArr) . '
';
			break;
		}
		// body of table without or with "textQualifier"
		if (empty($textQualifier)) {
			foreach ($sortTable as $idx => $row) {
				$rowArr = array();
				foreach ($this->settings['ecofieldnames'] as $fld => $fieldname) {
					$rowArr[$fieldname] = $row[$fieldname];
				}
				$strOut .= implode($delimiter, $rowArr) . '
';
			}
		} else {
			foreach ($sortTable as $idx => $row) {
				$rowArr = array();
				foreach ($this->settings['ecofieldnames'] as $fld => $fieldname) {
					//foreach( $row as $fieldname => $content){
					$rowArr[$fieldname] = (is_numeric($row[$fieldname]) && strlen($row[$fieldname])!= 8) || empty($row[$fieldname]) ? $row[$fieldname] : $textQualifier . $row[$fieldname] . $textQualifier;
				}
				$strOut .= implode($delimiter, $rowArr) . '
';
			}
		}
		$strOut .= '
';
		if ('utf-8' != $this->settings['csv_options']['encoding']) {
			$strOut = iconv('utf-8', $this->settings['csv_options']['encoding'], $strOut);
		}
		return $strOut;
	}

	/**
	 * @param $strOut
	 * @param $filename
	 */
	protected function dwn_downloadAsCsv($strOut, $filename = 'verarbeitet.csv'
	) {
		$headers = array(
			'Pragma' => 'public',
			'Expires' => 0,
			'Cache-Control' => 'must-revalidate, post-check=0, pre-check=0',
			'Cache-Control' => 'public',
			'Content-Description' => 'File Transfer',
			'Content-Type' => 'application/vnd.ms-excel',
			'Content-Disposition' => 'attachment; filename="' . $filename . '"',
			'Content-Transfer-Encoding' => 'binary'
		);
		foreach ($headers as $header => $data) {
			$this->response->setHeader($header, $data);
		}
		$this->response->sendHeaders();
		echo $strOut;
		die;
	}

	/**
	 * @param $sortTables
	 */
	public function dwn_downloadAsXls($sortTables) {
		if (!is_array($sortTables)) {
			return false;
		}
		$errormessages = array(
			'stundenplan_error' => 'Fehler in der Stundenplan-DB (Ecoopen)',
			'csv_error' => 'Fehler in einer CSV-Datei (neuer Plan)',
			'fehlt_irgendwo' => 'Unterschiede zwischen CSV-Datei und Datenbank',
			'csv' => 'CSV-Datei (neuer Plan)'
		);
		$filename = 'ausgeschlossen_' . date('ymd-Hi') . '.xlsx';
		//$extKey =  $this->request->getControllerExtensionKey();
		$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->pathToPHPExcel);
		set_include_path($extDir);
		include($extDir . 'PHPExcel/IOFactory.php');
		$objPHPExcel = new \PHPExcel();
		$objPHPExcel->getActiveSheet()->setTitle('stundenplan_vergleich');
		$rowIdx = 1;
		foreach ($sortTables as $tablename => $tablecontent) {
			if (!is_array($tablecontent)) {
				continue;
			}
			$x = 0;
			foreach ($tablecontent as $uid => $row) {
				if (!empty($row['Lehrer'])) {
					++$x;
				}
			}
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $rowIdx, $x . 'x ' . $errormessages[$tablename]);
			++$rowIdx;
			$ix = 0;
			foreach ($this->settings['ecofieldnames'] as $index => $fld) {
				$objRichText = new \PHPExcel_RichText();
				//$objCellTitle = $objRichText->createTextRun( iconv("UTF-8", $this->csv_charset,$fld) );
				$objCellTitle = $objRichText->createTextRun($fld);
				$objCellTitle->getFont()->setBold(true);
				$objCellTitle->getFont()->setItalic(true);
				//$objCellTitle->getFont()->setStrikethrough(true);
				$objPHPExcel->getActiveSheet()->getCellByColumnAndRow($ix, $rowIdx)->setValue($objRichText);
				$objPHPExcel->getActiveSheet()->getColumnDimension(chr(65 + $ix))->setAutoSize(true);
				++$ix;
			}
			++$rowIdx;
			foreach ($tablecontent as $uid => $row) {
				$colIdx = 0;
				foreach ($this->settings['ecofieldnames'] as $ix => $fld) {
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($colIdx, $rowIdx, $row[$fld]);
					++$colIdx;
				}
				++$rowIdx;
			}
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $rowIdx, '');
			++$rowIdx;
		}
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="' . $filename . '"');
		header('Cache-Control: max-age=0');
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		die;
	}

}
