<?php
namespace Mff\Mffplan\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Teacher
 * used to extend \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
 */
class Teacher extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUser {

	/**
	 * ecoAcronym
	 *
	 * @var string
	 */
	protected $ecoAcronym = '';

	/**
	 * disable
	 *
	 * @var bool
	 */
	protected $disable = FALSE;

	/**
	 * Returns the ecoAcronym
	 *
	 * @return string $ecoAcronym
	 */
	public function getEcoAcronym() {
		return $this->ecoAcronym;
	}

	/**
	 * Sets the ecoAcronym
	 *
	 * @param string $ecoAcronym
	 * @return void
	 */
	public function setEcoAcronym($ecoAcronym) {
		$this->ecoAcronym = $ecoAcronym;
	}

	/**
	 * Returns the disable
	 *
	 * @return bool $disable
	 */
	public function getDisable() {
		return $this->disable;
	}

	/**
	 * Sets the disable
	 *
	 * @param bool $disable
	 * @return void
	 */
	public function setDisable($disable) {
		$this->disable = $disable;
	}

	/**
	 * Returns the boolean state of disable
	 *
	 * @return bool
	 */
	public function isDisable() {
		return $this->disable;
	}

}