<?php
namespace Mff\Mffplan\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Periods
 */
class Periods extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * semester
	 *
	 * @var string
	 */
	protected $semester = '';

	/**
	 * datumAb
	 *
	 * @var \DateTime
	 */
	protected $datumAb = NULL;

	/**
	 * datumBis
	 *
	 * @var \DateTime
	 */
	protected $datumBis = NULL;

	/**
	 * davorBis
	 *
	 * @var \DateTime
	 */
	protected $davorBis = NULL;

	/**
	 * danachAb
	 *
	 * @var \DateTime
	 */
	protected $danachAb = NULL;

	/**
	 * Returns the semester
	 *
	 * @return string $semester
	 */
	public function getSemester() {
		return $this->semester;
	}

	/**
	 * Sets the semester
	 *
	 * @param string $semester
	 * @return void
	 */
	public function setSemester($semester) {
		$this->semester = $semester;
	}

	/**
	 * Returns the datumAb
	 *
	 * @return \DateTime $datumAb
	 */
	public function getDatumAb() {
		return $this->datumAb;
	}

	/**
	 * Sets the datumAb
	 *
	 * @param \DateTime $datumAb
	 * @return void
	 */
	public function setDatumAb(\DateTime $datumAb) {
		$this->datumAb = $datumAb;
	}

	/**
	 * Returns the datumBis
	 *
	 * @return \DateTime $datumBis
	 */
	public function getDatumBis() {
		return $this->datumBis;
	}

	/**
	 * Sets the datumBis
	 *
	 * @param \DateTime $datumBis
	 * @return void
	 */
	public function setDatumBis(\DateTime $datumBis) {
		$this->datumBis = $datumBis;
	}

	/**
	 * Returns the davorBis
	 *
	 * @return \DateTime $davorBis
	 */
	public function getDavorBis() {
		return $this->davorBis;
	}

	/**
	 * Sets the davorBis
	 *
	 * @param \DateTime $davorBis
	 * @return void
	 */
	public function setDavorBis(\DateTime $davorBis) {
		$this->davorBis = $davorBis;
	}

	/**
	 * Returns the danachAb
	 *
	 * @return \DateTime $danachAb
	 */
	public function getDanachAb() {
		return $this->danachAb;
	}

	/**
	 * Sets the danachAb
	 *
	 * @param \DateTime $danachAb
	 * @return void
	 */
	public function setDanachAb(\DateTime $danachAb) {
		$this->danachAb = $danachAb;
	}

}