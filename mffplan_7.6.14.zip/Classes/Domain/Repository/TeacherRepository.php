<?php
namespace Mff\Mffplan\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Teacher
 * used to extend \TYPO3\CMS\Extbase\Persistence\Repository
 */
class TeacherRepository extends \TYPO3\CMS\Extbase\Domain\Repository\FrontendUserRepository {

	/**
	 * @var array
	 */
	protected $defaultOrderings = array(
		'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);
	
	  /**
	  *  Find by user-field tx_extbase_type e.g. 'Tx_Mffdb_Ecouser'
	  * 
	  */
	  public function findTeachers() {
		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $pidArr['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
// 		  $pidArr['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
// 		  $pidArr['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		  $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		  $querySettings->setIgnoreEnableFields( TRUE );
		  $querySettings->setRespectStoragePage(TRUE);
		  $querySettings->setStoragePageIds( $pidArr );
		  $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      $query->matching(
		  $query->logicalAnd(
		      $query->equals('tx_extbase_type', 'Tx_Mffdb_Ecouser'),
		      $query->greaterThan('eco_acronym', ''),
		      $query->greaterThan('username', ''),
		      $query->equals('deleted', 0)
		  )
	      );
	      $query->setOrderings(
		  array(
		      'username' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
		  )
	      );	  
	      return $query->execute();
	  }

	  public function callSqlStatement( $qryStatement , $ReturnRawQueryResult = TRUE) {
	      $Query = $this->createquery();
// 	      $Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
	      $Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
	      $Query->getQuerySettings()->setRespectStoragePage(FALSE);
	      $Query->statement($qryStatement); 
	      return $Query->execute($ReturnRawQueryResult);
	  }
	  
	  public function getTeachersFachbereich( $relConnection='Klassen' , $passedDays = 180 ) {
	      $proc = 'getTeachersFb_' . $relConnection ;
	      $oldestDate = time() - round( $passedDays * 24 * 60 * 60 );
	      $qryStatement = 'SELECT DISTINCT '.$this->$proc( $oldestDate );
	      return $this->callSqlStatement( $qryStatement );
	  }
	  
	  public function getTeachersFb_AllTeachersRelations( $oldestDate=0  ) {
	      return '
	      fe_users.uid AS plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota, fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_teacherrelation.uid AS relationUid,
	      tx_mffdb_domain_model_teacherrelation.hidden,
	      tx_mffdb_domain_model_teacherrelation.leiter,
	      tx_mffdb_domain_model_teacherrelation.auto_reference,
	      "" AS groups
	      FROM fe_users
	        LEFT JOIN tx_mffdb_domain_model_teacherrelation 
		    ON tx_mffdb_domain_model_teacherrelation.tea_ecouser=fe_users.uid
		LEFT JOIN tx_mffdb_domain_model_fachbereich 
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_teacherrelation.fachbereich 
	      WHERE fe_users.eco_acronym > ""
	      ORDER BY fe_users.username
	     ';
	  }
	  public function getTeachersFb_Klassen( $oldestDate=0 ) {
	      // Fachbereich-Lehrpersonen Klassen
	      // verknuepft Lehrpersonen ueber Klassen zu Fachbereichen
	      // wenn deren Faecher keinen Kursregeln entsprechen
	      return '
	      tx_mffplan_domain_model_timetable.rel_teacher AS plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_klasse.class_short AS content
	      FROM tx_mffdb_domain_model_fachbereich
		JOIN tx_mffdb_domain_model_kurzklasse
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kurzklasse.fachbereich 
		JOIN tx_mffdb_domain_model_klasse
		    ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse 
	        JOIN tx_mffplan_timetable_scoolclass_mm 
	            ON tx_mffdb_domain_model_klasse.uid=tx_mffplan_timetable_scoolclass_mm.uid_foreign
	        JOIN tx_mffplan_domain_model_timetable
	            ON tx_mffplan_timetable_scoolclass_mm.uid_local=tx_mffplan_domain_model_timetable.uid
	        JOIN fe_users 
	            ON tx_mffplan_domain_model_timetable.rel_teacher=fe_users.uid
	        JOIN tx_mffplan_timetable_subject_mm 
	            ON tx_mffplan_domain_model_timetable.uid=tx_mffplan_timetable_subject_mm.uid_local
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffplan_timetable_subject_mm.uid_foreign=tx_mffdb_domain_model_fach.uid 
	      WHERE tx_mffdb_domain_model_fach.fach_kursregel = 0
	      AND DATE(tx_mffplan_domain_model_timetable.date_end) >= "'.date('Y-m-d' , $oldestDate).'"
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffplan_domain_model_timetable.rel_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_klasse.class_short
	      ';
	  }
	  public function getTeachersFb_Kurse( $oldestDate=0 ) {
	      // Fachbereich-Lehrpersonen Kursregeln
	      // verknuepft Lehrpersonen ueber Faecher zu Fachbereichen
	      // wenn die Faecher den Kursregeln des Fachebreiches entsprechen
	      return '
	      tx_mffplan_domain_model_timetable.rel_teacher AS plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_fach.fachkurz AS content
	      FROM tx_mffdb_domain_model_fachbereich 
		JOIN tx_mffdb_domain_model_kursregel 
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kursregel.fachbereich 
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffdb_domain_model_kursregel.uid=tx_mffdb_domain_model_fach.fach_kursregel
	        JOIN tx_mffplan_timetable_subject_mm 
	            ON tx_mffdb_domain_model_fach.uid=tx_mffplan_timetable_subject_mm.uid_foreign
	        JOIN tx_mffplan_domain_model_timetable
	            ON tx_mffplan_timetable_subject_mm.uid_local=tx_mffplan_domain_model_timetable.uid
	        JOIN fe_users 
	            ON tx_mffplan_domain_model_timetable.rel_teacher=fe_users.uid
	      WHERE NOT tx_mffdb_domain_model_fach.fach_kursregel = 0
	      AND DATE(tx_mffplan_domain_model_timetable.date_end) >= "'.date('Y-m-d' , $oldestDate).'"
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffplan_domain_model_timetable.rel_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_fach.fachkurz
	     ';
	  }
	  public function getTeachersFb_AbuKlassen( $oldestDate=0 ) {
	      // Fachbereich-ABU-Lehrpersonen Kursregeln + Klassen
	      // verknuepft ABU-Lehrpersonen ueber Faecher zu Klassen zu Fachbereichen
	      // wenn die Faecher den Kursregeln des ABU-Fachebreiches entsprechen
	      
	      // Fachbereich-UID von ABU (Allgemeinbildung und Sport) ermitteln
	      $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $abuFbUid = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['abuFbUid'];
	      
	      return '
	      tx_mffplan_domain_model_timetable.rel_teacher AS plan_teacher, fe_users.name, fe_users.username, fe_users.email, fe_users.cloud_quota,fe_users.disable AS disable,fe_users.eco_acronym,
	      tx_mffdb_domain_model_fachbereich.uid AS fachbereichNr,
	      IF(tx_mffdb_domain_model_fachbereich.cloud_key="",tx_mffdb_domain_model_fachbereich.fachbereichname,tx_mffdb_domain_model_fachbereich.cloud_key) as cloudkey,
	      tx_mffdb_domain_model_fachbereich.sorting,
	      tx_mffdb_domain_model_klasse.class_short AS content
	      FROM tx_mffdb_domain_model_fachbereich
		JOIN tx_mffdb_domain_model_kurzklasse
		    ON tx_mffdb_domain_model_fachbereich.uid=tx_mffdb_domain_model_kurzklasse.fachbereich 
		JOIN tx_mffdb_domain_model_klasse
		    ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse 
		    
	        JOIN tx_mffplan_timetable_scoolclass_mm 
	            ON tx_mffdb_domain_model_klasse.uid=tx_mffplan_timetable_scoolclass_mm.uid_foreign
	        JOIN tx_mffplan_domain_model_timetable
	            ON tx_mffplan_timetable_scoolclass_mm.uid_local=tx_mffplan_domain_model_timetable.uid
	        JOIN fe_users 
	            ON tx_mffplan_domain_model_timetable.rel_teacher=fe_users.uid
	        JOIN tx_mffplan_timetable_subject_mm 
	            ON tx_mffplan_domain_model_timetable.uid=tx_mffplan_timetable_subject_mm.uid_local
		JOIN tx_mffdb_domain_model_fach 
		    ON tx_mffplan_timetable_subject_mm.uid_foreign=tx_mffdb_domain_model_fach.uid
		JOIN tx_mffdb_domain_model_kursregel 
		    ON tx_mffdb_domain_model_fach.fach_kursregel=tx_mffdb_domain_model_kursregel.uid
	      WHERE tx_mffdb_domain_model_kursregel.fachbereich = '.$abuFbUid.'
	      AND DATE(tx_mffplan_domain_model_timetable.date_end) >= "'.date('Y-m-d' , $oldestDate).'"
	      AND fe_users.eco_acronym > ""
	      ORDER BY tx_mffplan_domain_model_timetable.rel_teacher,tx_mffdb_domain_model_fachbereich.sorting,tx_mffdb_domain_model_klasse.class_short
	      ';
	  }
	  public function getTeachersFb_sortFachbereich( $oldestDate=0 ) {
	      return ' uid, fachbereichname FROM tx_mffdb_domain_model_fachbereich ORDER BY sorting';
	  }

	
}
