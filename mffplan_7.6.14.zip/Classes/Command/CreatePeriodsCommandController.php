<?php
namespace Mff\Mffplan\Command;
use \DateTime;

 /** 
 * Class CreatePeriodsCommandController
 * 
 * Creates Periods based on calendar (calendar-field:semestergrenze)
 * called by \Mff\Mffplan\Utility\ImportToDbUtility
 * 
 */
 
class CreatePeriodsCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mffplan';
	    
	protected $extConf = array(); // Extension configuration

	/**
	 * reads the calendar
	 * creates period objects if necessary
	 * 
	 * returns true
	 *
	 * @return void
	 */
	public function execute(){
		date_default_timezone_set( 'Europe/Zurich' );
		$this->GmtZone = new \DateTimeZone('GMT');
		$this->timeZone = new \DateTimeZone('Europe/Zurich');
		// get configuration
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $this->getSettings( $objectManager );
		
		$querySettings->setStoragePageIds( array($this->extConf['foreignStoragePid'],$this->extConf['storagePid']) );
		$kalenderRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KalenderRepository');
		$kalenderRepository->setDefaultQuerySettings($querySettings);
		
		$querySettings->setStoragePageIds( array($this->extConf['storagePid'],$this->extConf['foreignStoragePid']) );
		$periodsRepository = $objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
		$periodsRepository->setDefaultQuerySettings($querySettings);
		
		$periods = $this->getPeriodsFromCalendar( $kalenderRepository );
		$counter = $this->createAndRepairPeriods( $periodsRepository , $periods );
		if($counter){
		    $persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		    $persistenceManager->persistAll();
		}
		
		return true;
	}
	
	/**
	 * UNUSED, use createAndRepairPeriods() instead 
	 * creates period recordsets/objects if necessary
	 * returns amount of created recordsets
	 * 
	 * @param object $periodsRepository 
	 * @param array $periods 
	 * @return integer
	 */
	public function createPeriods( $periodsRepository , $periods ) {
		$counter = 0;
		foreach( $periods as $sm => $prdRow ){
		    $periodsRecordsets = $periodsRepository->findBySemester( $prdRow['period'] );
		    if( empty($periodsRecordsets) || !count($periodsRecordsets) ){
			  $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffplan\Domain\Model\Periods');
			  $newCode->setSemester( $prdRow['period'] );
			  $dtAb = new DateTime( date('Y-m-d',$prdRow['datum_ab']) );
			  $dtAb->setTimeZone( $this->timeZone );
			  $newCode->setDatumAb( $dtAb );
			  $dtBs = new DateTime( date('Y-m-d',$prdRow['datum_bis']) );
			  $dtBs->setTimeZone( $this->timeZone );
			  $newCode->setDatumBis( $dtBs );
			  $dvBs = new DateTime( date('Y-m-d',$prdRow['davor_bis']) );
			  $dvBs->setTimeZone( $this->timeZone );
			  $newCode->setDavorBis( $dvBs );
			  $ddAb = new DateTime( date('Y-m-d',$prdRow['danach_ab']) );
			  $ddAb->setTimeZone( $this->timeZone );
			  $newCode->setDanachAb( $ddAb );
			  $periodsRepository->add($newCode);
			  ++$counter; 
		    }
		}
		return $counter;
	}
	
	/**
	 * createAndRepairPeriods
	 * repairs period recordsets/objects if necessary
	 * returns amount of created recordsets
	 * 
	 * @param object $periodsRepository 
	 * @param array $periods 
	 * @return integer
	 */
	public function createAndRepairPeriods( $periodsRepository , $periods ) {
		$counter = 0;
		foreach( $periods as $sm => $prdRow ){
		    $periodsRecordsets = $periodsRepository->findBySemester( $prdRow['period'] );
		    
		    $dObjDatAb = new DateTime( date('Y-m-d',$prdRow['datum_ab']) );
		    $dObjDatAb->setTimeZone( $this->timeZone );
		    
		    $dObjDatBis = new DateTime( date('Y-m-d',$prdRow['datum_bis']) , $this->GmtZone );
		    if( $dObjDatBis->format('N') <= 5 ) $dObjDatBis->add(new \DateInterval('P'.( 6 - $dObjVorBis->format('N') ).'D'));
		    $dObjDatBis->setTimeZone( $this->timeZone );
		    
		    $dObjVorBis = new DateTime( date('Y-m-d',$prdRow['davor_bis']) , $this->GmtZone );
		    if( $dObjVorBis->format('N') <= 5 )  $dObjVorBis->add(new \DateInterval('P'.( 6 - $dObjVorBis->format('N') ).'D'));
		    $dObjVorBis->setTimeZone( $this->timeZone );
		    
		    $dObjNachAb = new DateTime( date('Y-m-d',$prdRow['danach_ab']) );
		    $dObjNachAb->setTimeZone( $this->timeZone );
		    
		    if( empty($periodsRecordsets) || !count($periodsRecordsets) ){
			  $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffplan\Domain\Model\Periods');
			  $newCode->setSemester( $prdRow['period'] );
			  $newCode->setDatumAb( $dObjDatAb );
			  $newCode->setDatumBis( $dObjDatBis );
			  $newCode->setDavorBis( $dObjVorBis );
			  $newCode->setDanachAb( $dObjNachAb );
			  $periodsRepository->add($newCode);
			  ++$counter; 
		    }else{// maybe calendar-data has changed
			  foreach($periodsRecordsets as $rep){
			      $edToken = 0;
			      if( $dObjDatAb !=  $rep->getDatumAb() ) { ++$edToken; $rep->setDatumAb( $dObjDatAb );}
			      if( $dObjDatBis !=  $rep->getDatumBis() ) { ++$edToken; $rep->setDatumBis( $dObjDatBis );}
			      if( $dObjVorBis !=  $rep->getDavorBis() ) { ++$edToken; $rep->setDavorBis( $dObjVorBis );}
			      if( $dObjNachAb !=  $rep->getDanachAb() ) { ++$edToken; $rep->setDanachAb( $dObjNachAb );}
			      if( $edToken ) {
				    ++$counter; 
				    $periodsRepository->update($rep);
			      }
			  }
		    }
		}
		return $counter;
	}
	
	/**
	 * reads the calendars recordsets, but only those marked with 'semestergrenze'
	 * transforms the calendar-object to formatted array
	 * 
	 * @param object $kalenderRepository 
	 * @return array
	 */
	public function getPeriodsFromCalendar( $kalenderRepository ) {
 		$kalenderRecordsets = $kalenderRepository->findBySemestergrenze( TRUE );
		// date() formats: 
		// w: 0 (Sonntag) - 6 (Samstag) 
		// N: 1 (Montag) - 7 (Sonntag) 
		$semKrz = array( 0=>'HS' , 1=>'FS' );
		$periods = array();
		foreach( $kalenderRecordsets as $calRow ){
		    $ferienstart = $calRow->getBeginn(); // is monday, perhaps sunday, we need past saturday
		    $ferienende = $calRow->getEnde(); // is saturday. we need next monday
		    
		    // semesterEnde if 6 (sa) its ok. but it is Mo 1 or So 0. 
		    $timeDeltaToPastSaturday = ( date('w',$ferienstart) +1 ) * (3600*24);
		    $semesterEnde = date('w',$ferienstart)==6 ? $ferienstart : $ferienstart-$timeDeltaToPastSaturday ;

		    // semesterStart if 1 (mo) its ok. but its 6 Sa.
		    $timeDeltaToNextMonday =( 8 - date('N',$ferienende) ) * (3600*24);
		    $semesterStart = date('w',$ferienende)==1 ? $ferienende : $ferienende+$timeDeltaToNextMonday ;

		    $isSpring = ( (0+date( 'm' , $semesterStart )) < 6 ) ? 1 : 0;
		    $pStartName = $semKrz[ $isSpring ]; // spring:FS summer:HS 
		    $pEndName =  $semKrz[ $isSpring == 0 ]; // spring:HS summer:FS 
		    $pStartYear = date( 'y' , $semesterStart ); // spring16:16 summer16:16 
		    $pEndYear = $pStartYear - $isSpring ; // spring16:15 summer16:16
		    
		    $periods[ $pStartYear.$pStartName ]['period'] = $pStartName.$pStartYear;
		    $periods[ $pStartYear.$pStartName ]['datum_ab'] = $semesterStart; // spring:FS16 summer:HS16 
		    $periods[ $pEndYear.$pEndName ]['period'] = $pEndName.$pEndYear;
		    $periods[ $pEndYear.$pEndName ]['datum_bis'] = $semesterEnde; // spring:HS15 summer:FS16 
		    $periods[ $pStartYear.$pStartName ]['davor_bis'] = $semesterEnde; // spring:HS15 summer:FS16 
		    $periods[ $pEndYear.$pEndName ]['danach_ab'] = $semesterStart; // spring:FS16 summer:HS17
		}
		
		if(!count($periods)) return true;
		
		// sorting period and unsetting those with empty date-values
		ksort($periods);
		foreach($periods as $sem => $period){
		    if( empty($period['datum_ab']) || empty($period['datum_bis']) ) unset($periods[$sem]);
		}
		
		return $periods;
	}
	
	/**
	 * reads configuration into property extConf , returns querySettings
	 *
	 * @param object $objectManager 
	 * @return object
	 */
	public function getSettings( $objectManager ){
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf'][$this->extKey]);

		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$this->extConf['storagePid'] = $settings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$this->extConf['foreignStoragePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		return $querySettings;
	}
	
// 	/**
// 	 * transforms a given datestring to integer value
// 	 *
// 	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
// 	 * @return integer
// 	 */
// 	public function parseLocalDate($datevalue) {
// 		$termin = new DateTime( $datevalue );
// 		$value = $termin->getTimestamp();
// 		if (!empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['serverTimeZone']) ) {
// 			$value += $termin->getOffset();
// 		}
// 		return $value;
// 	}
}