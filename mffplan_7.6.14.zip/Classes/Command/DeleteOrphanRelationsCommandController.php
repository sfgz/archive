<?php
namespace Mff\Mffplan\Command;
/**
 * Class DeleteOrphanRelationsCommandController
 * 
 * deletes subtables
 * called by \Mff\Mffplan\Utility\ImportToDbUtility
 * 
 */
class DeleteOrphanRelationsCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * Repos
	 * severeal Repository objects in a array
	 *
	 * @var array
	 */
	protected $Repos = NULL;

	/**
	 * conf
	 * Configuration
	 *
	 * @var array
	 */
	public $conf = array(
	    'tables'=>array(
		'subject' => array( 'current'=>'tx_mffplan_timetable_subject_mm', 'parent'=>'tx_mffplan_domain_model_timetable' ),
		'room' => array( 'current'=>'tx_mffplan_timetable_room_mm', 'parent'=>'tx_mffplan_domain_model_timetable' ),
		'scoolclass' => array( 'current'=>'tx_mffplan_timetable_scoolclass_mm' , 'parent'=>'tx_mffplan_domain_model_timetable' )
	    ),
	    'query' => 'DELETE FROM ###CURRENT### USING ###CURRENT### LEFT JOIN  ###PARENT### ON ###CURRENT###.uid_local =  ###PARENT###.uid WHERE ###PARENT###.uid is NULL;'
	);


	public function execute(){
 		foreach( array_keys($this->conf['tables']) as $activeTable) {
		    $this->fixTable( $activeTable );
 		}
 		return true;
 	}
 	
	public function fixTable( $activeTable ){
 		$repl = array(  '###CURRENT###'=>$this->conf['tables'][$activeTable]['current'] , '###PARENT###'=>$this->conf['tables'][$activeTable]['parent']);
 		$sql = str_replace( array_keys($repl) , $repl , $this->conf['query'] );

 		$GLOBALS['TYPO3_DB']->sql_query($sql);
		
 		return true;
	}

}
