<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
  * Class ApplyRulesUtility
  * reads rules from conditions and aplies them to tables
  * 
  * RULES
  * 1 Replace one or more Chars Rule
  * 2 Replace-Text if ...
  * 3 Split Rows
  * 4 Split Building-Room and create new Rows
  * 5 Authenticate Fieldcontent against given Database-Tables
  * 6 Split joined classes 
  * 7 Replace date if it is specific daterange;
  *   needs clearDateTime() and clearPeriodicity().
  * 8 fill left with zeros
  * 9 Disable Row if ...
  * 
*/

class ApplyRuleUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * rulesRepository
	 * info: inject does not work here, we load repository 
	 *       manually by objectManager in __construct method
	 *
	 * @var \Mff\Mffplan\Domain\Repository\RulesRepository
	 * @inject
	 */
	protected $rulesRepository = NULL;
	

	/**
	 * rules
	 * the rules table as a array
	 *
	 * @var array
	 */
	protected $rules = NULL;

	/**
	* settings
	* gets overwritten later
	*
	* @var array
	*/
	public $settings = array( 'fieldnames' => array(), 'specialfields' => array() );

	public function __construct( $settings = array() ) {
	      $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      // read conditions set rules
	      $this->rulesRepository = $objectManager->get('Mff\\Mffplan\\Domain\\Repository\\RulesRepository');
	      $this->rules = $this->getConditions();
	      // set settings
	      if( count($settings) ){
		  $this->settings = $settings;
	      }else{
		  // read configuration
		  $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $allSettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $this->settings = $allSettings['plugin.']['tx_mffplan_planimport.']['settings.'];
	      }
	}

	/**
	 * returns the conditions
	 *
	 * @param array $table The array of table to return
	 * @return array
	 */
	protected function getConditions() {
	    // fast n dirty but not working: return $this->rulesRepository->execQueryStatement('SELECT * FROM tx_mffplan_domain_model_rules WHERE activate=1');
	    // read conditions
	    $conditions = $this->rulesRepository->findAllIfActivated();
	    foreach($conditions as $uid=>$cond){
		$rules[$uid]['rendertype'] = $cond->getRendertype();
		$rules[$uid]['fieldname'] = $cond->getFieldname() ;
		$rules[$uid]['needle'] = $cond->getNeedle() ;
		$rules[$uid]['newtext'] = $cond->getNewtext() ;
		$rules[$uid]['fieldname2'] = $cond->getFieldname2() ;
		$rules[$uid]['needle2'] = $cond->getNeedle2() ;
		$rules[$uid]['newtext2'] = $cond->getNewtext2() ;
		$rules[$uid]['uid'] = $cond->getUid() ;
	    }
	    return $rules;
	}

	/**
	 * reads a csv-file and transforms the content to a array
	 * then start the loop "ApplyRulesOnTable" 
	 * and return the resulting array
	 *
	 * @param string $file The file to read
	 * @return array
	 */
	public function ApplyRulesOnFile( $file ) {
	      $csvUtil = new \Mff\Mffplan\Utility\CsvToArrayUtility( $this->settings['csv_options'] );
	      $table = $csvUtil->CsvToArray( $file ) ;
	      foreach($this->rules as $rule) $table = $this->executeRule( $table , $rule );
	      return $table;
	}
	
	/**
	 * returns the commented array with right and wrong data
	 *
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	public function executeRule( $table , $rule ) {
	    $method = 'cmpr_execRuleNr_' . $rule['rendertype'];
	    if(method_exists( $this , $method ))  $table = $this->$method( $table , $rule );
	    return $table;
	}
	
	/**
	 * Rule no 10
	 * Split a field in parts, hold one part in the field and overwrite a other field with the other part
	 * 
	 * split-char is in needle
	 * the index of the part to use is in newtext and newtext2 (0 = take first part ... 2- take all parts after 1)
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_10( $table , $rule ) {
	    if(!count($table)) return;
	    if( strlen($rule['needle']) < 1 ) return $table;
	    $repTable = array();
// 	    $row0 = array_shift($table);
	    foreach($table as $ix => $tabRow ){
			$repTable[$ix] = $tabRow;
			if( empty($tabRow[$rule['fieldname']]) ) continue;
			$aText = explode( ' ' , $tabRow[$rule['fieldname']] );
			if( strpos( $rule['newtext'] , '-' ) ){
				$index = rtrim( $rule['newtext'] , '-' )+0;
				if( count($aText) <= $index2 ){
					$newText = $tabRow[$rule['fieldname']];
				}else{
					$aSlicedText = array_slice( $aText , $index );
					$newText = implode( $rule['needle'] , $aSlicedText );
				}
			}else{
				$newText = $aText[ ($rule['newtext']+0) ];
			}
 			$repTable[$ix][$rule['fieldname']] = $newText;
			
			if( !empty($tabRow[$rule['fieldname2']]) && count($aText) ){
				if( strpos( $rule['newtext2'] , '-' ) ){
					$index2 = rtrim( $rule['newtext2'] , '-' )+0;
					if( count($aText) <= $index2 ){
						$newText2 = $tabRow[$rule['fieldname2']];
					}else{
						$aSlicedText = array_slice( $aText , $index2 );
						$newText2 = implode( $rule['needle'] , $aSlicedText );
					}
				}else{
					$newText2 = $aText[ ($rule['newtext2']+0) ];
				}
 				$repTable[$ix][$rule['fieldname2']] = $newText2;
			}
	    }
//  	    array_unshift( $repTable , $row0 );
	    return $repTable;
	}
	
	/**
	 * Rule no 1
	 * Replace one or more Chars Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_1( $table , $rule ) {
	     // Replace one or more Chars Rule
	     $repTable = array();
	    if(!count($table)) return;
	    foreach($table as $ix => $tabRow ){
			$repTable[$ix] = $tabRow;
			if( !empty($rule['needle']) && !empty($tabRow[$rule['fieldname']]) ){
				$newText = ('_LEEREN_' == $rule['newtext']) ? '' : $rule['newtext'];
				$oldText = $tabRow[$rule['fieldname']];
				$repTable[$ix][$rule['fieldname']] = str_replace( $rule['needle'] , $newText , $oldText );
			}
			if( !empty($rule['needle2']) && !empty($tabRow[$rule['fieldname2']]) ){
				$newText2 = ('_LEEREN_' == $rule['newtext2']) ? '' : $rule['newtext2'];
				$oldText2 = $repTable[$ix][$rule['fieldname2']];
				$repTable[$ix][$rule['fieldname2']] = str_replace( $rule['needle2'] , $newText2 , $oldText2 );
			}
	    }
	    return $repTable;
	}

	/**
	 * Rule no 2
	 * Replace-Text if Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_2( $table , $rule ) {
	    // Replace-Text if Rule
	    // 
	    // IF content of field=needle AND content of field2=needle2 
	    // THEN replace with newtex and/or newtext2 if not empty. 
	    // 
	    // clear with placeholder _LEEREN_ in newtext
	    // use as empty: _LEER_ 
	    // dont search but set true IF needle=empty or needle2=empty
	    // searches parts of strings by *asterisk in needle but replaces whole string in newtext 
	    // 
	    $repTable = array();
	    if(!count($table)) return;
	    foreach($table as $ix => $tabRow ){
		  $repTable[$ix] = $tabRow;
		  $needle[1] = trim($rule['needle']);
		  $needle[2] = trim($rule['needle2']);
		  if( empty($needle[1]) && empty($needle[2]) ) continue;
		  $tFieldname[1] = $rule['fieldname'];
		  $tFieldname[2] = $rule['fieldname2'];
		  for( $cNr = 1 ; $cNr <= 2 ; ++$cNr ) {
		      if(empty($tFieldname[$cNr])){
			  $compare[$cNr] = TRUE ;
			  continue;
		      }else{
			  $fieldvalue[$cNr] = trim($tabRow[$tFieldname[$cNr]]);
		      }
		      if( $needle[$cNr] == '' ){
			  // search disabled for this field
			  $compare[$cNr] = TRUE ;
		      }elseif( $needle[$cNr] == '_LEER_' ){
			  // field has to be empty
			  $compare[$cNr] = empty($fieldvalue[$cNr]) ;
		      }elseif( $needle[$cNr] == '*' ){
			  // field must not be empty
			  $compare[$cNr] = !empty($fieldvalue[$cNr]) ;
		      }elseif( strpos( ' ' . $needle[$cNr] , '*' ) == 1 ){
			  // asterisk on start *search
			  $sepChars = str_replace(  '*' , '' , $needle[$cNr] );
			  $expectedPosition = strlen($fieldvalue[$cNr]) - strlen($sepChars);
			  $compare[$cNr] = (strpos( $fieldvalue[$cNr] , $sepChars ) == $expectedPosition);
		      }elseif( strpos( $needle[$cNr] , '*' ) == strlen($needle[$cNr])-1 ){
			  // asterisk on end search*
			  $sepChars = str_replace(  '*' , '' , $needle[$cNr] );
			  $compare[$cNr] = (strpos( ' ' . $fieldvalue[$cNr] , $sepChars ) == 1);
		      }elseif( strpos( $needle[$cNr] , '*' ) ){
			  // asterisk in middle sea*ch
			  $sepChars = explode( '*' , $needle[$cNr] );
			  $compare[$cNr] = TRUE;
			  $oldPos = 0;
			  foreach($sepChars as $chr){
			      $newPos = strpos( ' ' . $fieldvalue[$cNr] , $chr );
			      if( $newPos <= $oldPos ){
				  $compare[$cNr] = FALSE;
				  break;
			      }else{
				  $oldPos = $newPos;
			      }
			  }
		      }else{ 
			  // value has to map exactly with needle
			  $compare[$cNr] = ($fieldvalue[$cNr] == $needle[$cNr]) ;
		      }
		  }
		  if( $compare[1] && $compare[2] ){
		      $newText[1] = trim($rule['newtext']);
		      $newText[2] = trim($rule['newtext2']);
		      for( $cNr = 1 ; $cNr <= 2 ; ++$cNr ) {
			  if( empty($tFieldname[$cNr]) ){
			      continue;
			  }elseif( '_LEEREN_' == $newText[$cNr]){
			      $repTable[$ix][$tFieldname[$cNr]] = '';
			  }elseif(!empty($newText[$cNr])){
			      $repTable[$ix][$tFieldname[$cNr]] = $newText[$cNr];
			  }
		      }
		  }
	    }
	    return $repTable;
	}

	/**
	 * Rule no 3
	 * Split Rows-Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_3( $table , $rule ) {
	    // Split Rows-Rule
	    $repTable = array();
	    if(!count($table)) return;
	    foreach($table as $ix => $tabRow ){
		  $splittetFieldContent = explode( $rule['needle'] , $tabRow[$rule['fieldname']] );
		  foreach( $splittetFieldContent as $splitIx=>$word){
		      $repTable[$ix.'.'.$splitIx] = $tabRow;
		      $repTable[$ix.'.'.$splitIx][$rule['fieldname']] = trim($word);
		  }
	    }
	    return $repTable;
	}

	/**
	 * Rule no 4
	 * Split Building-Room 
	 * and create new Rows -Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_4( $table , $rule ) {
	    // Split Building-Room and create new Rows -Rule
	    if(!count($table)) return;
	    $repTable = array();
	    foreach($table as $ix => $tabRow ){
		  $splittetFieldContent = explode( $rule['needle'] , $tabRow[$rule['fieldname']] );
		  foreach( $splittetFieldContent as $splitIx=>$word){
		      $wp = explode( ' ' , trim($word) );
		      if( count($wp) == 2 ){
					$repTable[$ix.'.'.$splitIx] = $tabRow;
					$repTable[$ix.'.'.$splitIx][$rule['fieldname']-1] = $wp[0];
					$repTable[$ix.'.'.$splitIx][$rule['fieldname']] = $wp[1];
		      }else{
					$repTable[$ix.'.'.$splitIx] = $tabRow;
					$repTable[$ix.'.'.$splitIx][$rule['fieldname']] = trim($word);
		      }
		  }
	    }
	    return $repTable;
	}

	/**
	 * Rule no 5
	 * Authenticate Fieldcontent 
	 * against given Database-Tables -Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_5( $table , $rule ) {
	    // Authenticate Fieldcontent against given Database-Tables -Rule
	    if(!count($table)) return;
	    $repTable = array();
	    $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	    $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	    $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	    $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	    // if( ucFirst($rule['needle']) == 'Ecouser' )
	    $storagePid['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
	    // else
	    $storagePid['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
	    $tablePathName = str_replace( '##TABLENAME##' , ucFirst($rule['needle']) , 'Mff\\Mffdb\\Domain\\Repository\##TABLENAME##Repository') ;
	    $querySettings->setStoragePageIds( $storagePid );
	    $kursRepository = $objectManager->get( $tablePathName );
	    $kursRepository->setDefaultQuerySettings($querySettings);
	    $kursRecordsets = $kursRepository->findAll();
	    $indexFields = array( $rule['newtext'] , $rule['newtext2'] );
	    foreach($kursRecordsets as $x=>$kRow){
		  $sCntArray = array();
		  foreach( $indexFields as $fix=>$newtextfield){
		      if( $fix==1 && empty($rule['fieldname2']) ){
					$sCntArray[$fix][] =0;
		      }else{
					$fieldsLoop = explode( ' ' , $newtextfield );
					if( count($fieldsLoop) == 1 ){
						$cmd = 'get'.ucfirst($fieldsLoop[0]);
						if(method_exists( $kRow , $cmd )) $sCntArray[$fix][] = trim( $kRow->$cmd() );
					}elseif( count($fieldsLoop) == 2 ){
						$cmd = 'get'.ucfirst($fieldsLoop[0]);
						if(method_exists( $kRow , $cmd )){
							$sSubCont = $kRow->$cmd();
							$cmd = 'get'.ucfirst($fieldsLoop[1]);
							foreach($sSubCont as $subObj){
									if(method_exists( $subObj , $cmd )) $sCntArray[$fix][] = trim( $subObj->$cmd() );
							}
						}
					}
		      }
		  }
		  if( count($sCntArray[0]) && count($sCntArray[1]) ){
		      foreach( $sCntArray[0] as $match0){
			    foreach( $sCntArray[1] as $match1){
				$kombiExists[trim($match0)][trim($match1)]=1;
			    }
		      }
		  }
		  if( count($sCntArray[1]) ){
		      foreach( $sCntArray[1] as $match1){
			  $singleSwitchedExists[trim($match1)]=1;
		      }
		  }
	    }
	    // loop table and look up for corresponding values in array
	    $K = $this->settings['specialfields']['hints'];
	    foreach($table as $ix => $tabRow ){
		$sField1 = trim($tabRow[ $rule['fieldname'] ]);
		$sField2 = empty($rule['fieldname2']) ? 0 : trim($tabRow[ $rule['fieldname2'] ]);
		if(  !isset($kombiExists[$sField1][$sField2]) ){
		    if(!isset($tabRow[$K])) $tabRow[$K]='';
		    if( !empty($rule['fieldname2']) ){
				if(  !isset($singleSwitchedExists[$sField1]) || isset($singleSwitchedExists[$sField2]) ){
					$tabRow[$K] = trim( $tabRow[$K].' ('.$sField1.'+'.$sField2.' fehlt in '.ucFirst($rule['needle']).'.'.$this->settings['fieldnames'][$rule['fieldname']].'+'.$this->settings['fieldnames'][$rule['fieldname2']].')');
				}else{
					$tabRow[$K] = trim( $tabRow[$K].' ('.$sField1.'+'.$sField2.' fehlt in '.ucFirst($rule['needle']).'.'.$this->settings['fieldnames'][$rule['fieldname']].'+'.$this->settings['fieldnames'][$rule['fieldname2']].')');
				}
		    }else{
				$tabRow[$K] = trim( $tabRow[$K].' ('.$sField1.' fehlt in '.ucFirst($rule['needle']).')');
		    }
		}
		$repTable[$ix] = $tabRow;
	    }
	    return $repTable;
	}

	/**
	 * Rule no 6
	 * Split joined classes Rule
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_6( $table , $rule ) {
	    // Split Rows-Rule
	    if(!count($table)) return;
	    $repTable = array();
	    foreach($table as $ix => $tabRow ){
		  $splittetFieldContent = explode( $rule['needle'] , $tabRow[$rule['fieldname']] );
		  if( count($splittetFieldContent) != 2 ) { $repTable[$ix] = $tabRow; continue; }
		  $jFrom = 0 + substr( $splittetFieldContent[0] , strlen($splittetFieldContent[0])-2 );
		  $jTo = 0 + substr( $splittetFieldContent[1] , 0 , 2 );
		  if( !is_numeric($jFrom) || !is_numeric($jTo) ) { $repTable[$ix] = $tabRow; continue; }
		  $tBefore = substr( $splittetFieldContent[0] , 0 , strlen($splittetFieldContent[0])-2 );
		  $tAfter = substr( $splittetFieldContent[1] , 2 );
		  for( $j = $jFrom ; $j <= $jTo ; ++$j ){
		      $repTable[$ix.'.'.$j] = $tabRow;
		      $JJ = sprintf( '%02s' , $j );
		      $repTable[$ix.'.'.$j][$rule['fieldname']] = trim( $tBefore . $JJ . $tAfter );
		  }
	    }
	    return $repTable;
	}

	/**
	 * Rule no 7
	 * Replace date if it is specific daterange 
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_7( $table , $rule ) {
	    // Replace date if it is specific daterange 
	    if(!count($table)) return;
	    $repTable = array();
	    $ifOldDateFrom = $rule['needle'];
	    $ifOldDateTo = $rule['needle2'];
	    
	    $uxFirstMonday = mktime( 12,0,0, substr($rule['newtext'] , 2 , 2) , substr($rule['newtext'] , 0 , 2) , substr($rule['newtext'] , 4 , 4) );
	    $uxFirstSunday = $uxFirstMonday - (3600*24);
	    
	    $uxLastSaturday = mktime( 12,0,0, substr($rule['newtext2'] , 2 , 2) , substr($rule['newtext2'] , 0 , 2) , substr($rule['newtext2'] , 4 , 4) );
	    $uxLastSunday = $uxLastSaturday- (3600*24*6);
	     
	    $fldNrWeekDay = $this->settings['specialfields']['weekday'] ;
	    foreach($table as $ix => $tabRow ){
		$repTable[$ix] = $tabRow;
		$dateFrom = $tabRow[$rule['fieldname']];
		$dateTo = $tabRow[$rule['fieldname2']];
		$weekDay = $tabRow[$fldNrWeekDay];
		if( $dateFrom == $ifOldDateFrom && $dateTo == $ifOldDateTo ){
		    $repTable[$ix][$rule['fieldname']] = date('dmY' , $uxFirstSunday + (3600*24*$weekDay) );
		    $repTable[$ix][$rule['fieldname2']] = date('dmY' , $uxLastSunday + (3600*24*$weekDay) );
		}
	    }
	    $repTable = $this->cmpr_clearDateTime( $repTable  , $rule );
	    return $this->cmpr_clearPeriodicity( $repTable  , $rule );
	}

	/**
	 * returns the cleaned array 
	 * mark wrong data with notice in hint-field
	 *
	 * @param array $table The array of table to return
	 * @return array
	 */
	protected function cmpr_clearDateTime( $table  , $rule ) {
	    // value replacement and date-filtering for the entire table
	    if(!count($table)) return;
	    $dateNow = ceil( time() / (3600*24) )  * (3600*24);
	    $actualTable = array();
	    $dateformat = 'dmY';
	    $F = $rule['fieldname'];
	    $T = $rule['fieldname2'];
	    $D = $this->settings['specialfields']['weekday'];
	    $K = $this->settings['specialfields']['hints'];
	    foreach($table as $ix=>$tabRow){
				if( !is_numeric($tabRow[$T]) ) continue;
				$uxDateTo = mktime(23,59,59 , substr($tabRow[$T],2,2) , substr($tabRow[$T],0,2) , substr($tabRow[$T],4,4) );
		//		if( $uxDateTo < $dateNow ) continue;
				$uxDateFrom = mktime(0,0,0 , substr($tabRow[$F],2,2) , substr($tabRow[$F],0,2) , substr($tabRow[$F],4,4) );
				$dateDiff = $uxDateTo-$uxDateFrom;
				if( empty($tabRow[$D]) || date('N',$uxDateFrom) != $tabRow[$D] || date('N',$uxDateTo) != $tabRow[$D] ){
					$weekDayWrong = TRUE ; }else{$weekDayWrong=FALSE;
				}
				if( $weekDayWrong && $dateDiff < (3600*24*7) && $dateDiff > (3600*24) ){
					// Wochentag leer: wochenkurs
					for( $loopDate = $uxDateFrom , $z=0 ; $loopDate <= $uxDateTo ; $loopDate += (3600*24) ){
					$actualTable[$ix.'.'.$z]=$tabRow;
					$actualTable[$ix.'.'.$z][$D]= date('N',$loopDate);
					$actualTable[$ix.'.'.$z][$F]= date($dateformat,$loopDate );
					$actualTable[$ix.'.'.$z][$T]= date($dateformat,$loopDate+(24*3600)-1) ;
					++$z;
					}
				}elseif( $weekDayWrong && $dateDiff >= (3600*24*7) && $dateDiff < (3600*24*14)  ){
					// 2-Wochenkurs FEHLER
					$actualTable[$ix] = $tabRow;
					$actualTable[$ix][$F]= date($dateformat,$uxDateFrom );
					$actualTable[$ix][$T]= date($dateformat,$uxDateTo) ;
					$actualTable[$ix][$K]=' [Wochentag/Datum Fehler]';
				}else{
					$actualTable[$ix] = $tabRow;
					$testFrom = $uxDateFrom;
					$testTo = $uxDateTo;
					if( empty($tabRow[$D]) && date('N',$uxDateFrom) == date('N',$uxDateTo) ){
					// Wochentag leer, aus Datum erstellen
					$actualTable[$ix][$D]= date('N',$uxDateFrom);
					$actualTable[$ix][$F]= date($dateformat,$uxDateFrom);
					$actualTable[$ix][$T]= date($dateformat,$uxDateTo);
				//	Wochentag eingesetzt
					}elseif( !empty($tabRow[$D]) && $weekDayWrong  ){
					// Datum stimmt nicht mit Wochentag ueberein
					$dayDiffFrom = $tabRow[$D] - date('N',$uxDateFrom);
					$dayDiffTo = date('N',$uxDateTo) - $tabRow[$D];
					$testFrom = $uxDateFrom + ( $dayDiffFrom * 3600*24 );
					$testTo = $uxDateTo - ( $dayDiffTo * 3600*24 );
					$actualTable[$ix][$F]= date($dateformat,$testFrom);
					$actualTable[$ix][$T]= date($dateformat,$testTo);
				//	Datum korrigiert '.date('d.m',$uxDateFrom).'-'.date('d.m',$uxDateTo)
					}else{
					$actualTable[$ix][$F]= date($dateformat,$uxDateFrom) ;
					$actualTable[$ix][$T]= date($dateformat,$uxDateTo) ;
					}
					// Wochentag final test
					if( empty($actualTable[$ix][$D]) || date('N',$testFrom) != $actualTable[$ix][$D] || date('N',$testTo) != $actualTable[$ix][$D] ){
					if( isset($actualTable[$ix][$K]) ){
						$actualTable[$ix][$K].=' [Wochentag/Datum Fehler]';
					}else{
						$actualTable[$ix][$K]='[Wochentag/Datum Fehler]';
					}
					}
				}
	    }
	    return $actualTable;
	}

	/**
	 * returns the cleaned array 
	 * mark wrong data with notice in hint-field
	 *
	 * @param array $table The array of table to return
	 * @return array
	 */
	protected function cmpr_clearPeriodicity( $table  , $rule ) {
	    if(!count($table)) return;
	    $dateformat = 'dmY';
	    $F = $rule['fieldname'];
	    $T = $rule['fieldname2'];
	    $D = $this->settings['specialfields']['weekday'];
	    $P = $this->settings['specialfields']['periodicity'];
	    $K = $this->settings['specialfields']['hints'];
	    foreach($table as $ix=>$tabRow){
		if( $tabRow[$P] < 2 ) continue;
		$uxDateFrom = mktime(0,0,0 , substr($tabRow[$F],2,2) , substr($tabRow[$F],0,2) , substr($tabRow[$F],4,4) );
		$uxDateTo = mktime(23,59,59 , substr($tabRow[$T],2,2) , substr($tabRow[$T],0,2) , substr($tabRow[$T],4,4) );
		if( date('N',$uxDateFrom) != $tabRow[$D] || date('N',$uxDateTo) != $tabRow[$D] ) {
		    $table[$ix][$K]=' [Wochentag/Datum Fehler]';
		}else{
		    $weekDiff = ($uxDateTo - $uxDateFrom) / (3600*24*7);
		    $newWeekDiff = floor( $weekDiff / $tabRow[$P] ) * $tabRow[$P];
		    if($weekDiff!=$newWeekDiff) $table[$ix][$T]= date( $dateformat , $uxDateFrom + ( $newWeekDiff * 3600 * 24 * 7 ) );
		}
	    }
	    return $table;
	}

	/**
	 * Rule no 8
	 * fill left with zeros Rule
	 * 0# or 00## etc.
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_8( $table , $rule ) {
	    // fill left with zeros Rule 
	    // needle = 000# or 0# (NOT 0 or #)
	    if(!count($table)) return;
	    if( $rule['needle']=='#' || empty($rule['needle']) || empty($rule['fieldname']) ) return $table;

	    $repTable = array();
	    $cntZeroes = strpos( $rule['needle'] , '#');
	    $minChars = strlen( $rule['needle'] );
	    $prefix = substr( $rule['needle'] , 0 , $cntZeroes);
	     
	    foreach($table as $ix => $tabRow ){
		$repTable[$ix] = $tabRow;
		$len = strlen( trim($tabRow[$rule['fieldname']]) );
		$match1 = ( $len < $minChars );
		$match2 = (empty($rule['fieldname2']) || $rule['needle2'] == $tabRow[$rule['fieldname2']]) ? 1 : 0;
		if( $match1 && $match2 ){
		    $diff = ( $minChars - $len );
		    $repTable[$ix][$rule['fieldname']] =  substr($prefix , 0 , $diff) . $tabRow[$rule['fieldname']] ;
		}
	    }
	    return $repTable;
	}

	/**
	 * Rule no 9
	 * Disable Row if ...
	 * 
	 * @param array $table The array of table to return
	 * @param array $rule rule to run against table
	 * @return array
	 */
	protected function cmpr_execRuleNr_9( $table , $rule ) {
	    $K = $this->settings['specialfields']['hints'];
	    if(!count($table)) return;
	    $repTable = array();
	    foreach($table as $ix => $tabRow ){
				$repTable[$ix] = $tabRow;
				$match1 = ($rule['needle'] == $tabRow[$rule['fieldname']]) || ($rule['needle'] == '_LEER_' && empty($tabRow[$rule['fieldname']]) ) ;
				$match2a = $rule['needle2'] == $tabRow[$rule['fieldname2']] ;
				$match2b = $rule['needle2'] == '_LEER_' && empty($tabRow[$rule['fieldname2']]) ;
				$match2 = empty($rule['fieldname2']) ? 0 : ( $match2a || $match2b );
				if( $match1 || $match2 ){
					$msg = '';
					if( $match1 ) $msg .= '('.$this->settings['fieldnames'][$rule['fieldname']].'='.$rule['needle'].') ';
					if( $match2 ) $msg .= '('.$this->settings['fieldnames'][$rule['fieldname2']].'='.$rule['needle2'].') ';
					if( isset($repTable[$ix][$K]) ){
					$repTable[$ix][$K].=$msg;
					}else{
					$repTable[$ix][$K]=$msg;
					}
				}
	    }
	    return $repTable;
	}
}
