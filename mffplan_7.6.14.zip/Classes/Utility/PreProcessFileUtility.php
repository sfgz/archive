<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PreProcessFileUtility
 */

class PreProcessFileUtility implements \TYPO3\CMS\Core\SingletonInterface {
	
	/**
	 * options
	 *
	 * @var array
	 */
	Public $options = array( 'utf16decodeFile'=>FALSE , 'shrinkByDate'=>FALSE , 'shrinkByTime'=>TRUE, 'shrinkByTimeValue'=>15 , 'adjustRoom'=>TRUE );
	
	/**
	 * csvOptions
	 *
	 * @var array
	 */
	protected $csvOptions = array();
	
	/**
	 * filename
	 *
	 * @var string
	 */
	protected $filename = '';
	
	/**
	 * table
	 *
	 * @var array
	 */
	protected $table =  array();
	
	/**
	 * fieldnames
	 *
	 * @var array
	 */
	protected $fieldnames =  array();

	/**
	 * kalenderRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KalenderRepository
	 */
	protected $kalenderRepository = NULL;
	
	/**
	* __construct
	*
	* @return void
	*/
	public function __construct( $settings = array() ) {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);

	      $this->kalenderRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KalenderRepository');
	      $this->kalenderRepository->setDefaultQuerySettings($this->querySettings);
	      
	      if( isset($settings['csv_options']) ) $this->csvOptions = $settings['csv_options'];
	      
	}
	
	/**
	 * preProcessFile
	 *
	 * @param string $filename
	 * @param array $options default are values from $this->options
	 * @return void
	 */
	public function preProcessFile( $filename , $options = array() ){
			if( count($options) ){
				foreach( $options as $optName => $optValue ) {
					if( isset($this->options[$optName]) ) $this->options[$optName] = $optValue;
				}
			}
			if( empty($this->options['utf16decodeFile']) && empty($this->options['shrinkByDate']) && empty($this->options['shrinkByTime']) && empty($this->options['adjustRoom']) ) {
//				return false;
 			//	$this->csvOptions['encoding'] = 'utf-8';
			}
			$outTable = array();
			$shortTable = $this->readTable( $filename );
			foreach( $shortTable as $row ) $outTable[] = implode( $this->csvOptions['delimiter'] , $row ) . "\n";
			file_put_contents( $filename , $outTable );
			return true;
	}
	
	/**
	 * readTable
	 * returns array table
	 *
	 * @param string $filename
	 * @return void
	 */
	private function readTable( $filename ) {
			$this->filename = $filename;
			if( !empty($this->options['utf16decodeFile']) ) $this->utf16decodeFile( $filename );
			$shortTable = array();
			$csvUtil = new \Mff\Mffplan\Utility\CsvToArrayUtility( $this->csvOptions );
			$fullTable = $csvUtil->encodedCsvToCleanArray( $filename ) ;
			// Fields: "Wochentag";"Zeit_von";"Zeit_bis";"Datum_von";"Datum_bis";"Periodizitaet";"Periode";"Klasse";"Angebot";"Fach";"Fachprefix";"Lehrer";"Gebaeude";"Raum";"Anz_Wochenlek"
			$this->fieldnames = array_flip( array_shift( $fullTable ) );
			$this->table = $this->dimTableWithDate( $fullTable );
			if(count($this->table)){
				if( !empty($this->options['shrinkByDate']) ) $this->table = $this->shrinkByDate();
				if( !empty($this->options['shrinkByTime']) ) $this->table = $this->shrinkByTime( $this->options['shrinkByTime'] );
 				if( !empty($this->options['adjustRoom']) ) $this->table = $this->adjustRoom();
 				$shortTable = $this->redimTable();
			}
			return $shortTable;
	}
	
	/**
	 * utf16decodeFile
	 *
	 * @param string $filename
	 * @return void
	 */
	private function utf16decodeFile( $filename ) {
				$decodetContent = iconv( 'UTF-16' , 'ISO-8859-15' , file_get_contents($filename) );
				file_put_contents( $filename , $decodetContent );
				return true;
	}
	
	/**
	 * dimTableWithDate
	 * returns array with shrunken table
	 *
	 * @param array $fullTable
	 * @return string
	 */
	private function dimTableWithDate( $fullTable ) {
			$fldDatumVon = $this->fieldnames['Datum_von'];
			$fldDatumBis = $this->fieldnames['Datum_bis'];
			foreach( $fullTable as $row ){
					if( strlen( $row[$fldDatumVon] ) == 7 ) $row[$fldDatumVon] = '0' . $row[$fldDatumVon];
					if( strlen( $row[$fldDatumBis] ) == 7 ) $row[$fldDatumBis] = '0' . $row[$fldDatumBis];
					$day = substr($row[$fldDatumVon] , 0 , 2) ;
					$month = substr($row[$fldDatumVon] , 2 , 2) ;
					$year = substr($row[$fldDatumVon] , 4 , 4) ;
					$prsIx = $row[$this->fieldnames['Angebot']] . '.' . 
								$row[$this->fieldnames['Fach']] . '.' . 
								$row[$this->fieldnames['Lehrer']] . '.' . 
								$row[$this->fieldnames['Wochentag']] . '.' . 
								$row[$this->fieldnames['Raum']] . '.' . 
								$row[$this->fieldnames['Zeit_von']]. '.' . 
								$row[$this->fieldnames['Zeit_bis']] ;
					$datelessRow[ $year . '.' . $month . '.' . $day ][ $prsIx ] = $row;
			}
			
			if( !count($datelessRow) ) return array();
 			ksort($datelessRow);
			foreach( array_keys($datelessRow) as $i ) {
				ksort($datelessRow[$i]); 
			}
			
			return  $datelessRow ;
    }
	
	/**
	* shrinkByDate
	*
	* @return array
	*/
	private function shrinkByDate() {
			$table = $this->table;
					$firstUxDate = time() * 2;
					$lastUxDate = 0;
					foreach( array_keys($table) as $i ) {
							$dateArr =explode('.' , $i );
							$aktDate = mktime(12,0,0,$dateArr[1],$dateArr[2],$dateArr[0]);
							if( $aktDate > $lastUxDate ) $lastUxDate = $aktDate;
							if( $aktDate < $firstUxDate ) $firstUxDate = $aktDate;
					}
					$nextWeek = $this->mkArrayNextWeek( $firstUxDate , $lastUxDate );
					
					foreach( $table as $date => $classGroup ) {
							$aDate = explode( '.' , $date );
							$uxDateStart = mktime( 12,0,0, $aDate[1] , $aDate[2] , $aDate[0] );
							foreach( $classGroup as $ownIx => $row) {
									// loop weekwise from startdate to last possible date
									// and join weeks
									for( $loopDay = $uxDateStart+(7*3600*24) ; $loopDay <= $lastUxDate ; $loopDay+=(7*3600*24)){
											$ttdate = date( 'Y.m.d' , $loopDay );
											$caldate = date( 'Ymd' , $loopDay );
											if( isset( $table[$ttdate][$ownIx] ) ){
											//		$table[$date][$ownIx][ $rowNames['Datum_bis'] ] = date( 'dmY' , $loopDay );
													unset( $table[$ttdate][$ownIx] );
											}elseif( isset( $nextWeek[$caldate] ) ){
													$calNewDate = date( 'Y.m.d' ,$nextWeek[$caldate]);
													if( isset( $table[$calNewDate][$ownIx] ) ){
											//				$table[$date][$ownIx][ $rowNames['Datum_bis'] ] = date( 'dmY' ,$nextWeek[$caldate]);
															unset( $table[$calNewDate][$ownIx] );
													}
											}
									}
							}
							if(!count($table[$date])) unset($table[$date]);
					}
					return $table;
	}

	/**
	 * mkArrayNextWeek
	 * returns array with date as key and nextweek-date as value
	 *
	 * @param int $firstUxDate
	 * @param int $lastUxDate
	 * @return string
	 */
	private function mkArrayNextWeek( $firstUxDate , $lastUxDate ) {
 			$alleKalender = $this->kalenderRepository->findByPrivat( '0' );
			$nextWeek = array();
			$sNextWeek = array();
			foreach($alleKalender as $objCal){
				$ganztag = $objCal->getGanztag();
				if( !$ganztag ) continue;
				$cal = array( 'beginn' => $objCal->getBeginn()+(12*3600) , 'ende' => $objCal->getEnde()+(12*3600) );
				if( empty( $cal['beginn'] ) ) continue;
				if( $cal['ende'] < $firstUxDate ) continue;
				if( $cal['beginn'] > $lastUxDate ) continue;
				$newTo = $cal['beginn']+round( ($cal['ende']-$cal['beginn']) / (3600*24) ) * (3600*24);
				// step through each day and set startday, copy old endday
				for( $akt = $cal['beginn'] ; $akt <= $cal['ende'] ; $akt += (3600*24*1) ){
						$calendar[$akt] = $objCal->getFerientext() . ' - '.date('d.m.y',$cal['ende']);
						$nextWeek[$akt] = $cal['ende'] ;
				}
			}
			ksort( $nextWeek );
			// step through each day and set endday corresponding to weekday
			foreach( $nextWeek as $akt => $oldDateTo ) {
				$endWeekday = date( 'N' , $oldDateTo );
				$wdAkt = date('N',$akt);
				if( $wdAkt > $endWeekday ){
					$daysToAdd = $wdAkt - $endWeekday;
				}else{
					$daysToAdd = 7-( $endWeekday - $wdAkt );
				}
				$newDate = $oldDateTo + ( 3600 * 24 * $daysToAdd );
				$sNextWeek[date( 'Ymd' , $akt )] =  $newDate ;
			}
			return $sNextWeek;
    }
	
	/**
	* shrinkByTime
	*
	* @param int $maxBreakMinutes
	* @return array
	*/
	private function shrinkByTime( $maxBreakMinutes = 15 ) {
			$deepTable = array();
			$outTable = array();
			$table = $this->table;
			foreach( $table as $dateStart => $groups ) {
					foreach( $groups as $teaClasTime => $row ) {
							$aIx = explode('.' , $teaClasTime);
							$deepTable[$dateStart][implode('.',array_slice($aIx,0,5))][$aIx[5]] = $row;
					}
					foreach($deepTable[$dateStart] as $blockIx => $blockRows ){
							$lastEnd = 0;
							$lastIndex = 0;
							foreach($blockRows as $timeIx => $row ){
									$aThisStart = explode( ':' , $timeIx );
									$thisStart = $aThisStart[0] * 60 + $aThisStart[1];
									$aThisEnd = explode( ':' , $row[$this->fieldnames['Zeit_bis']] );
									$thisEnd = $aThisEnd[0] * 60 + $aThisEnd[1];
									if( $lastEnd + $maxBreakMinutes >= $thisStart ){
										$deepTable[$dateStart][$blockIx][$lastIndex][$this->fieldnames['Zeit_bis']] = $row[$this->fieldnames['Zeit_bis']];
										unset( $deepTable[$dateStart][$blockIx][$timeIx] );
									}else{
										$lastIndex = $timeIx;
									}
									$lastEnd = $thisEnd;
							}
					}
					foreach($deepTable[$dateStart] as $blockIx => $blockRows ){
							foreach($blockRows as $timeIx => $row ){
									$outTable[$dateStart][$blockIx . '.' . $timeIx ] = $row;
							}
					}
			}
// 			array_unshift( $outTable , array_flip($this->fieldnames) );
			return $outTable;
	}
	
	/**
	* adjustRoom
	*
	* @return array
	*/
	private function adjustRoom() {
			$outTable = $this->table;
			foreach( $this->table as $i=> $groups ) {
					foreach( $groups as $ownIx=>$row ) {
							$aZmr = explode( ' ' , $row[$this->fieldnames['Raum']] );
							$outTable[$i][$ownIx][$this->fieldnames['Raum']] = trim( array_pop( $aZmr ) );
							$outTable[$i][$ownIx][$this->fieldnames['Gebaeude']] = trim( array_shift( $aZmr ) );
					}
			}
			return $outTable;
	}
	
	/**
	* groupByRoom
	*
	* @return array
	*/
	private function redimTable() {
			foreach( $this->table as $i=> $groups ) {
					foreach( $groups as $ownIx=>$row ) {
							$shortTable[] = $row;
					}
			}
			array_unshift( $shortTable , array_flip($this->fieldnames) );
			return $shortTable;
	}
	
	public function getTable(){
		return $this->table;
	}
	
	public function getFieldnames(){
		return $this->fieldnames;
	}

}
