<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

 use Cobweb\ExternalImport\Importer;

/**
 * Class ImportToDbUtility
 * 
 * runs method synchronizeData() from extension external_import 
 * for timetable-csv-file created in filemaker 
 * with connector = csv ( extension svconnector_csv)
 * 
 */

class ImportToDbUtility implements \TYPO3\CMS\Core\SingletonInterface {
	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	 * __construct
	 *
	 * @param array $settings
	 * @return void
	 */
	public function __construct( $settings = array() ) {
	      if( !count($settings) ){
		  // read configuration
		  $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		  $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $allSettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $rawSettings = $allSettings['plugin.']['tx_mffplan_planimport.']['settings.'];
		  $settings = $this->initializeSettings($rawSettings);
	      }
	      $this->settings = $settings ;
	}
	/**
	* from external Initialize compare
	 *
	* @return void
	*/
	public function initializeSettings($settings) {
		  if(is_array($settings)){
		      foreach($settings as $sett0Key => $sett0Row) {
			  if( is_array($sett0Row) ){
				foreach($sett0Row as $sett1Key => $sett1Row) {
				    if( is_array($sett1Row) ){
					foreach($sett1Row as $sett2Key => $sett2Row) {
					    if( is_array($sett2Row) ){
						foreach($sett2Row as $sett3Key => $sett3Row) {
						    $cnf[rtrim($sett0Key,'.')][rtrim($sett1Key,'.')][rtrim($sett2Key,'.')][rtrim($sett3Key,'.')] = $sett3Row;
						}
					    }else{
						$cnf[rtrim($sett0Key,'.')][rtrim($sett1Key,'.')][rtrim($sett2Key,'.')] = $sett2Row;
					    }
					}
				    }else{
					$cnf[rtrim($sett0Key,'.')][rtrim($sett1Key,'.')] = $sett1Row;
				    }
				}
			  }else{
			      $cnf[rtrim($sett0Key,'.')] = $sett0Row;
			  }
		      }
		  }else{
		      $cnf = $settings;
		  }
		  return $cnf;
	}
	
	/**
	 * SetupAndRunSync
	 * used in RulesController
	 * - creates periods (e.g. HS16) if affored based on calendar-data
	 * - transforms the array from one table (e.g. $sortTables['csv']) in a csv-file for the extension external_import
	 * - run the synchronizing-script from the extension 'external_import'
	 *
	 * @param array $sortTable 2-dimensional array representing one table
	 * @return void
	 */
	public function SetupAndRunSync( $sortTable ) {
		$this->checkPeriods();
		$this->arrayToImportFile( $sortTable );
		$messages = $this->runSynchronizeData();
		return $messages;
	}
	
	/**
	 * CleanUpAfterSync
	 * used in RulesController
	 * To run after import from file to database-table
	 *  - delete imported data from json-file 
	 *  - delete import-file, that was created for the extension external_import
	 *  - clear tables without related records
	 *
	 * @param array $sortTables
	 * @return void
	 */
	public function CleanUpAfterSync( $sortTables ) {
		// delete imported data from json-file
		$downloadDir  = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['processedpath'] , '/' ) . '/';
		unset($sortTables['csv']);
		file_put_contents( $downloadDir . 'procdata.json' , json_encode($sortTables) );

		// delete import-file for the extension external_import
		if( empty($this->settings['keepFile']) ){
		    $importFile = rtrim( PATH_site , '/' ) . '/' . $this->settings['importfile'];
		    if(file_exists($importFile)) unlink($importFile);
		}

		// clear tables without related records
		$DeleteOrphansController = new \Mff\Mffplan\Command\DeleteOrphanRelationsCommandController();
		$DeleteOrphansController->execute();
	}
	
	/**
	 * checkPeriods - helper for SetupAndRunSync
	 */
	public function checkPeriods() {
		// create new periods if there is new calendar data
		$createPeriodsController = new \Mff\Mffplan\Command\CreatePeriodsCommandController();
		$createPeriodsController->execute();
	}
	
	/**
	 * getLists - lists of superior tables
	 */
	public function getLists() {
	      $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
	      $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
	      $storagePid['foreignStoragePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
	      $querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setRespectStoragePage(TRUE);
	      $querySettings->setStoragePageIds( $storagePid );
	      
	      $this->settings['storagePid'] = $settings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
	      $this->settings['foreignStoragePid'] = $storagePid['foreignStoragePid'];

	      $this->kurzklasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KurzklasseRepository');
	      $this->kurzklasseRepository->setDefaultQuerySettings($querySettings);

	      $this->klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
	      $this->klasseRepository->setDefaultQuerySettings($querySettings);
	      
	      $this->fachRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
	      $this->fachRepository->setDefaultQuerySettings($querySettings);
	      
	      $this->zimmerRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
	      $this->zimmerRepository->setDefaultQuerySettings($querySettings);
	      
	      $this->ecouserRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
	      $this->ecouserRepository->setDefaultQuerySettings($querySettings);
		// read related fields into Lists
		$Listen = array();
		$klasseRecordsets = $this->klasseRepository->findAll();
		foreach( $klasseRecordsets as $klasserow ){
		      $kurzbezeichnung = $klasserow->getClassShort();
		      $klasseUid = $klasserow->getUid();
		      $Listen['klasse'][$kurzbezeichnung]=$klasseUid;
		}

		$fachRecordsets = $this->fachRepository->findAll();
		foreach( $fachRecordsets as $fachrow ){
		      $kurzbezeichnung = $fachrow->getFachkurz();
		      $fachUid = $fachrow->getUid();
		      $Listen['fach'][$kurzbezeichnung]=$fachUid;
		}

		$zimmerRecordsets = $this->zimmerRepository->findAll();
		foreach( $zimmerRecordsets as $fachrow ){
		      $haus = $fachrow->getHaus();
		      $zimmer = $fachrow->getZimmer();
		      $LocationUid = $fachrow->getUid();
		      $Listen['raum'][$haus][$zimmer]=$LocationUid;
		}

		$ecouserRecordsets = $this->ecouserRepository->findTeachers();
		foreach( $ecouserRecordsets as $teacher ){
		      $ecoKey = $teacher->getEcoAcronym();
		      $userUid = $teacher->getUid();
		      $Listen['lehrer'][$ecoKey]=$userUid;
		}
		return $Listen;
	}
	
	/**
	 * arrayToImportFile - helper for SetupAndRunSync
	 *
	 * @param array $table   2-dimensional array representing one table
	 * @return void
	 */
	public function arrayToImportFile( $table ) {
		// $Listen  2-dimensional array containing the indizes of many tables 
		$Listen = $this->getLists();
		$importFile = rtrim( PATH_site , '/' ) . '/' . $this->settings['importfile'];
		$fileContent = implode( ';' , $this->settings['dbfieldnames']) . "\n";
		foreach( $table as $ix => $row ){
		    $fil['Wochentag'] = $row['Wochentag'];
		    $fil['Periodizitaet'] = $row['Periodizitaet'];
		    $fil['timeFrom'] = $row['Zeit_von'];
		    $fil['timeTo'] = $row['Zeit_bis'];
		    $fil['Bemerkung'] = $row['Bemerkung'];
		    $fil['Periode'] = $row['Periode'];

		    $fil['pid'] = $this->settings['storagePid'];
		    $fil['dateStart'] =$this->formatEcoDateToDate( $row['Datum_von'] );
		    $fil['dateEnd'] =$this->formatEcoDateToDate( $row['Datum_bis'] );
		    
		    $fil['lehrerUid'] 	= !isset($Listen['lehrer'][ $row['Lehrer'] ]) ? '' : $Listen['lehrer'][ $row['Lehrer'] ];
		    $fil['locationUid'] = !isset($Listen['raum'][$row['Gebaeude']][$row['Raum']]) ? '' : $Listen['raum'][$row['Gebaeude']][$row['Raum']];
		    $fil['fachUid'] 	= !isset($Listen['fach'][ $row['Fach'] ]) ? '' : $Listen['fach'][ $row['Fach'] ];
		    $fil['klasseUid'] 	= !isset($Listen['klasse'][ $row['Angebot'] ]) ? '' : $Listen['klasse'][ $row['Angebot'] ];
		    
		    $fil['importIndex'] = $fil['lehrerUid'] .
					  '-'.date( 'dmy\T' , $fil['dateStart']).$row['Zeit_von'] .
					  '-'.$row['Periodizitaet'] .
					  '-'.date( 'dmy\T' , $fil['dateEnd']).$row['Zeit_bis'];
		    
		    $dbArr=array();
		    foreach($this->settings['dbfieldnames'] as $fld){ $dbArr[$fld] = $fil[$fld]; }

		    $fileContent .= implode( ';' , $dbArr ) . "\n";
		}
		
		$fileContent =  iconv( 'utf-8' , $this->settings['csv_options']['encoding'] , $fileContent);
		file_put_contents( $importFile , $fileContent );
	}
	
	/**
	 * runSynchronizeData - helper for SetupAndRunSync
	 * 
	 * @return array
	 */
	public function runSynchronizeData() {
	//	$importer = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('tx_externalimport_importer');
		$importer = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(Importer::class);
		$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['ctrl']['external'][0]['connector'] = 'csv';
		$messages = $importer->synchronizeData( 'tx_mffplan_domain_model_timetable' , 0 );
		return $messages;
	}
	
	/**
	 * formatEcoDateToDate - called from arrayToImportFile - helper for SetupAndRunSync
	 * returns the  Date in timestamp format
	 *
	 * @param string $ecoDate Date in format ddmmyyyy
	 * @return int
	 */
	public function formatEcoDateToDate( $ecoDate ) {
	    $day = substr( $ecoDate , 0 , 2 );
	    $month = substr( $ecoDate , 2 , 2 );
	    $year = substr( $ecoDate , 4 , 4 );
	    return mktime( 12,0,0,  $month , $day , $year );
	}

}