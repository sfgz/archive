<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class AnalyseUtility
 */

class AnalyseUtility implements \TYPO3\CMS\Core\SingletonInterface {
	/**
	* settings
	*
	* @var array
	*/
	public $settings = array();
	
	/**
	 * datesTable
	 *
	 * @var array
	 */
	protected $datesTable = array();
	
	/**
	 * weekdayWords
	 *
	 * @var array
	 */
	protected $weekdayWords = array();
	
	/**
	* pathToPHPExcel
	*
	* @var string
	*/
	public $pathToPHPExcel = 'typo3conf/ext/mff_contrib/Resources/Private/PHP/PHPExcel_1.8.0/Classes/';
	
	/**
	 * __construct
	 *
	 * @param array $settings
	 * @return void
	 */
	public function __construct( $settings = array() ) {
	      if( !count($settings) ){
		  // read configuration
		  $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		  $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $allSettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $rawSettings = $allSettings['plugin.']['tx_mffplan_planimport.']['settings.'];
		  foreach ($rawSettings as $ptSetting=>$settingValue){
		      $settings[ rtrim( $ptSetting , '.' ) ] = $settingValue;
		  }
	      }
	      $this->settings = $settings;
	      for( $n=1 ; $n <= 7 ; ++$n ){ 
		  $weekdayWords[$n] = \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate( 'weekdays.'.$n, 'mffplan');
		  $this->weekdayWords[$n] = substr( $weekdayWords[$n] , 0 , 2 );
	      }
	}
	
	/**
	 * evalConflicts
	 * evaluates conflicts
	 *
	 * @param array $sortTables
	 * @param int $conflicttypes 	Type 1 = conflict with lehrperson, 
	 * 				Type 2 = conflict with klasse, 
	 * 				Type 3 = conflict with zimmer
	 * @return void
	 */
	public function evalConflicts( $sortTables , $conflicttypes , $exclude = array() ) {
	    if(!isset($sortTables['csv'])) return $sortTables;
	    if(!count($sortTables['csv'])) return $sortTables;
	    if(!count($conflicttypes)) return $sortTables;

	    $resultTable = array();
	    if($conflicttypes[1]==1) $resTab['Lehrer'] = $this->TeacherConflicts( $sortTables['csv'] , $exclude['Lehrer'] );
	    if($conflicttypes[2]==2) $resTab['Zimmer'] = $this->RoomConflicts( $sortTables['csv'] , $exclude['Zimmer'] );
	    if($conflicttypes[3]==3) $resTab['Klassen'] = $this->ClassConflicts( $sortTables['csv'] , $exclude['Klassen'] );
	    if(!count($resTab)) return $sortTables;
	    
	    $resultArray = array();
	    foreach($resTab as $tNam=>$table) {
		ksort($table);
		$table = $this->translateDateTime( $table );
		foreach($table as $tix=>$tRow) {
		    if( empty($tRow['korrektur']) ) continue;
		    // for the right sort-order
		    $index = $tRow['Wochentag'].'_' . $tRow[$tNam];
		    foreach($this->settings['errorfieldnames'] as $fld) {
			  $resultArray[$index][$tix][$fld] = $tRow[$fld];
		    }
		}
	    }
	    
	    ksort($resultArray);
	    
	    $outTable = $sortTables; // include other tables like 'csv_error'
	    $outTable['conflicts'] = $resultArray;
	    return  $outTable ;
	}
	
	public function downloadConflictsAsXls( $sortTables , $exclude = array() ) {
	    if(!isset($sortTables['csv'])) return $sortTables;
	    if(!count($sortTables['csv'])) return $sortTables;
	    
	    $notUsed = array(
		'Lehrer' => array( 'Kls'=>1 , 'Zmr'=>1 , 'korrektur'=>1),
		'Zimmer' => array( 'Kls'=>1 , 'Lpn'=>1 , 'korrektur'=>1),
		'Klassen' => array( 'Lpn'=>1 , 'Zmr'=>1 , 'korrektur'=>1),
		'csv_error' => array( 21=>1 , 22=>1 , 'korrektur'=>1),
		'missingSources' => array( 21=>1 , 22=>1 , 'korrektur'=>1),
	    );

	    $resTab['Lehrer'] = $this->TeacherConflicts( $sortTables['csv'] , $exclude['Lehrer'] );
	    $resTab['Zimmer'] = $this->RoomConflicts( $sortTables['csv'] , $exclude['Zimmer'] );
	    $resTab['Klassen'] = $this->ClassConflicts( $sortTables['csv'] , $exclude['Klassen']  );
	    
	    $outTable = array();
	    foreach($resTab  as $tNam=>$tabCont) {
		$tabCont = $this->translateDateTime( $tabCont );
		foreach($tabCont  as $tix=>$tRow) {
			if( empty($tRow['korrektur']) ) continue;
			// for the right sort-order
			$index = $tRow['Wochentag'] .'_'. $tRow[$tNam];
			foreach($this->settings['errorfieldnames'] as $fld) {
			    if(!isset($notUsed[$tNam][$fld])) $outTable[$tNam][ $index ][ $tix ][$fld] = $tRow[$fld];
			}
		}
		if(isset($outTable[$tNam])) ksort($outTable[$tNam]);
	    }
	    $errortables = array( 'missingSources' , 'csv_error');
	    if(!isset($errortables)) return;
	    foreach($errortables as $tNam){
		if(!count($sortTables[$tNam])) continue;
		foreach($sortTables[$tNam]  as $tix=>$tRow) {
		    $outTable[$tNam][0][$tix]['korrektur'] = substr($tRow['korrektur'] , 0 , 50);
		    foreach($tRow as $fld=>$cnt) if(!isset($notUsed[$tNam][$fld])) $outTable[$tNam][0][$tix][$fld] = $cnt;
		}
	    }
	    return  $this->downloadAsXls( $outTable );
	}
	
	/**
	 * 
	 *
	 * @param string $sortTables array containig the error-table to fix: sortTables[ csv_error ]
	 * @return array
	 */
	public function checkMissingSources( $sortTables ) {
	      if(!is_array($sortTables['csv_error'])) return $sortTables;
	      foreach( $sortTables['csv_error'] as $ix => $row){
		    if(
			( $row[21] == ' klasse_fehlt' &&  $row[22] == '' ) ||
			( $row[21] == ' klasse_fehlt' &&  $row[22] == ' fach_fehlt' )
		    ) {
			$sortTables['missingSources'][$ix]=$row;
		    }
	      }
	      return $sortTables;
	}
	public function TeacherConflicts( $table , $excludefields ) {
	    $resultTable = array();
	    $cropTable = array();
	    $excludetFieldArr = explode( ',' , $excludefields);
	    foreach($excludetFieldArr as $fld){ $exludeValue[ trim($fld) ]= trim($fld);}
	    foreach($table as $tix=>$zeile){
		  if( isset( $exludeValue[$zeile['Lehrer']] ) ) continue;
		  // create index
		  $idx = '';
		  $idx.= $zeile['Lehrer'];
		  $idx.= $zeile['Wochentag'];
		  $idx.= $zeile['Zeit_von'];
		  $idx.= $zeile['Zeit_bis'];
		  $idx.= $zeile['Datum_von'];
		  $idx.= $zeile['Datum_bis'];
		  // create array for fields Klassen, Faecher and Zimmer
		  $cropTable[ $idx ]['Klassen'][$zeile['Angebot']] = $zeile['Angebot'];
		  $cropTable[ $idx ]['Faecher'][$zeile['Fach']] = substr($zeile['Fach'] , 0 , 8);
		  $cropTable[ $idx ]['Zimmer'][$zeile['Gebaeude'] . '.' . $zeile['Raum']] = $zeile['Gebaeude'] . ' ' . $zeile['Raum'];
		  // create datetime for compare-action ROCHADE Datum_von - dateFrom
		  $zeile['dateFrom'] = isset($this->datesTable[$zeile['Datum_von']]) ? $this->datesTable[$zeile['Datum_von']] :$this->ecoDate2timestamp( $zeile['Datum_von'] );
		  $zeile['dateTo'] = isset($this->datesTable[$zeile['Datum_bis']]) ? $this->datesTable[$zeile['Datum_bis']] :$this->ecoDate2timestamp( $zeile['Datum_bis'] );
		  $zeile['timeFrom'] = isset($this->datesTable[$zeile['Zeit_von']]) ? $this->datesTable[$zeile['Zeit_von']] :$this->ecoTime2decimal( $zeile['Zeit_von'] );
		  $zeile['timeTo'] = isset($this->datesTable[$zeile['Zeit_bis']]) ? $this->datesTable[$zeile['Zeit_bis']] :$this->ecoTime2decimal( $zeile['Zeit_bis'] );
		  $zeile['Tag'] = $this->weekdayWords[$zeile['Wochentag']];
		  // fill the main-part of recordset
		  $cropTable[ $idx ]['main'] = $zeile;
	    }
	    
	    // overwrite fields Angebot, Fach, Gebaeude with imploded array
	    foreach($cropTable as $idx=>$zeile){
		$resultTable[ $idx ] = $cropTable[ $idx ]['main'];
		$resultTable[ $idx ]['Klassen'] = implode( ', ' , $zeile['Klassen'] );
		$resultTable[ $idx ]['Faecher'] = implode( ', ' , $zeile['Faecher'] );
		$resultTable[ $idx ]['Zimmer'] = implode( ', ' , $zeile['Zimmer'] );
	    }
	    $resultTable = $this->conflictPart( $resultTable , 1 );
	    return $resultTable;
	}
	public function RoomConflicts( $table , $excludefields ) {
	    $resultTable = array();
	    $cropTable = array();
	    $excludetFieldArr = explode( ',' , $excludefields);
	    foreach($excludetFieldArr as $fld){ $exludeValue[ trim($fld) ]= trim($fld);}
	    foreach($table as $tix=>$zeile){
		  if( isset( $exludeValue[$zeile['Gebaeude'] . ' ' . $zeile['Raum']] ) ) continue;
		  // create index
		  $idx = '';
		  $idx.= $zeile['Gebaeude'] . '.' . $zeile['Raum'];
		  $idx.= $zeile['Lehrer'];
		  $idx.= $zeile['Wochentag'];
		  $idx.= $zeile['Zeit_von'];
		  $idx.= $zeile['Zeit_bis'];
		  $idx.= $zeile['Datum_von'];
		  $idx.= $zeile['Datum_bis'];
		  // create array for fields Klassen, Faecher and Zimmer
		  $cropTable[ $idx ]['Klassen'][$zeile['Angebot']] = $zeile['Angebot'];
		  $cropTable[ $idx ]['Faecher'][$zeile['Fach']] = substr($zeile['Fach'] , 0 , 8);
		  $zeile['Zimmer'] = $zeile['Gebaeude'] . ' ' . $zeile['Raum'];
		  // create datetime for compare-action ROCHADE
		  $zeile['dateFrom'] = isset($this->datesTable[$zeile['Datum_von']]) ? $this->datesTable[$zeile['Datum_von']] :$this->ecoDate2timestamp( $zeile['Datum_von'] );
		  $zeile['dateTo'] = isset($this->datesTable[$zeile['Datum_bis']]) ? $this->datesTable[$zeile['Datum_bis']] :$this->ecoDate2timestamp( $zeile['Datum_bis'] );
		  $zeile['timeFrom'] = isset($this->datesTable[$zeile['Zeit_von']]) ? $this->datesTable[$zeile['Zeit_von']] :$this->ecoTime2decimal( $zeile['Zeit_von'] );
		  $zeile['timeTo'] = isset($this->datesTable[$zeile['Zeit_bis']]) ? $this->datesTable[$zeile['Zeit_bis']] :$this->ecoTime2decimal( $zeile['Zeit_bis'] );
// 		  $zeile['Datum_von'] = date( 'd.m.y' , $zeile['dateFrom']);
// 		  $zeile['Datum_bis'] = date( 'd.m.y' , $zeile['dateTo']);
		  $zeile['Tag'] = $this->weekdayWords[$zeile['Wochentag']];
		  // fill the main-part of recordset
		  $cropTable[ $idx ]['main'] = $zeile;
	    }
	    // overwrite fields Angebot, Fach with imploded array
	    foreach($cropTable as $idx=>$zeile){
		$resultTable[ $idx ] = $cropTable[ $idx ]['main'];
		$resultTable[ $idx ]['Klassen'] = implode( ', ' , $zeile['Klassen'] );
		$resultTable[ $idx ]['Faecher'] = implode( ', ' , $zeile['Faecher'] );
	    }
	    $resultTable = $this->conflictPart( $resultTable , 2 );
	    return $resultTable;
	}
	public function ClassConflicts( $table , $excludefields ) {
	    $resultTable = array();
	    $cropTable = array();
	    $excludetFieldArr = explode( ',' , $excludefields);
	    foreach($excludetFieldArr as $fld){ $exludeValue[ trim($fld) ]= trim($fld);}
	    foreach($table as $tix=>$zeile){
		  $klasse = ($this->settings['kursClassShort'] == $zeile['Angebot']) ? $zeile['Fach'] :$zeile['Angebot'];
		  if( isset( $exludeValue[$klasse] ) ) continue;
		  // create index
		  $idx = '';
		  $idx.= $klasse;
		  $idx.= $zeile['Lehrer'];
		  $idx.= $zeile['Wochentag'];
		  $idx.= $zeile['Zeit_von'];
		  $idx.= $zeile['Zeit_bis'];
		  $idx.= $zeile['Datum_von'];
		  $idx.= $zeile['Datum_bis'];
		  // create array for fields Klassen, Faecher and Zimmer
		  $zeile['Klassen'] = $klasse;
		  $cropTable[ $idx ]['Faecher'][$zeile['Fach']] = substr($zeile['Fach'] , 0 , 8);
		  $cropTable[ $idx ]['Zimmer'][$zeile['Gebaeude'] . '.' . $zeile['Raum']] = $zeile['Gebaeude'] . ' ' . $zeile['Raum'];
		  // create datetime for compare-action ROCHADE
		  $zeile['dateFrom'] = isset($this->datesTable[$zeile['Datum_von']]) ? $this->datesTable[$zeile['Datum_von']] :$this->ecoDate2timestamp( $zeile['Datum_von'] );
		  $zeile['dateTo'] = isset($this->datesTable[$zeile['Datum_bis']]) ? $this->datesTable[$zeile['Datum_bis']] :$this->ecoDate2timestamp( $zeile['Datum_bis'] );
		  $zeile['timeFrom'] = isset($this->datesTable[$zeile['Zeit_von']]) ? $this->datesTable[$zeile['Zeit_von']] :$this->ecoTime2decimal( $zeile['Zeit_von'] );
		  $zeile['timeTo'] = isset($this->datesTable[$zeile['Zeit_bis']]) ? $this->datesTable[$zeile['Zeit_bis']] :$this->ecoTime2decimal( $zeile['Zeit_bis'] );
//		  $zeile['Datum_von'] = date( 'd.m.y' , $zeile['dateFrom']);
//		  $zeile['Datum_bis'] = date( 'd.m.y' , $zeile['dateTo']);
		  $zeile['Tag'] = $this->weekdayWords[$zeile['Wochentag']];
		  // fill the main-part of recordset
		  $cropTable[ $idx ]['main'] = $zeile;
	    }
	    // overwrite fields Fach, Gebaeude with imploded array
	    foreach($cropTable as $idx=>$zeile){
		$resultTable[ $idx ] = $cropTable[ $idx ]['main'];
		$resultTable[ $idx ]['Faecher'] = implode( ', ' , $zeile['Faecher'] );
		$resultTable[ $idx ]['Zimmer'] = implode( ', ' , $zeile['Zimmer'] );
	    }
	    $resultTable = $this->conflictPart( $resultTable , 3 );
	    return $resultTable;
	}

	/**
	 * action saldi
	 *
	 * @return void
	 */
	public function conflictPart( $cTable , $cType ) {
		$resTable = array();
		foreach($cTable as $tix=>$tRow) {
		    $test = 0;
		    foreach($cTable as $innerIndex=>$innerRow) {
			if( $innerIndex == $tix ) continue; // dont compare with it self
			$isTest = $this->conflictPartCompare( $tRow , $innerRow , $cType );
			if($isTest){
			    ++$test;
			}
		    }
		    $resTable[$tix] = $cTable[$tix];
		    if($test) { 
			$resTable[$tix]['korrektur'] = isset($cTable[$tix]['korrektur']) ? $cTable[$tix]['korrektur'].$cType : $cType ; 
			$resTable[$tix][ $this->settings['errorfieldnames'][20+$cType] ] = $test; 
		    }
		}
		return $resTable;
	}
	public function conflictPartCompare( $outerValues , $loopValues , $cType ) {
	      $isInWeekRange = $outerValues['Wochentag'] == $loopValues['Wochentag'];
	      $isOtherTeacher = $outerValues['Lehrer'] != $loopValues['Lehrer'];
	      $isSameTeacher = ( ($cType==1 && $isOtherTeacher == FALSE ) || $cType!=1);
	      $isSameRoom = ( ($cType==2 && ($outerValues['Zimmer'] == $loopValues['Zimmer']) && $isOtherTeacher ) || $cType!=2);
	      $isSameClass = ( ($cType==3 && ($outerValues['Klassen'] == $loopValues['Klassen']) && $isOtherTeacher) || $cType!=3);
	      $isInDateRange = 0;
	      $isInTimeRange = 0;
	      // is date overlapping or equal? Other params dependending on conflictType
	      if( $isInWeekRange && $isSameTeacher && $isSameRoom && $isSameClass ) { 
		  if( 
		      ( $loopValues['dateFrom'] <= $outerValues['dateFrom'] && $loopValues['dateTo'] > $outerValues['dateFrom'] ) || 
		      ( $loopValues['dateFrom'] >= $outerValues['dateFrom'] && $loopValues['dateFrom'] < $outerValues['dateTo'] )
		  ) $isInDateRange = 1;
	      }
	      // AND is time overlapping or equal?
	      if($isInDateRange) { 
		  if( 
		      ( $loopValues['timeFrom'] <= $outerValues['timeFrom'] && $loopValues['timeTo'] > $outerValues['timeFrom'] ) || 
		      ( $loopValues['timeFrom'] >= $outerValues['timeFrom'] && $loopValues['timeFrom'] < $outerValues['timeTo'] )
		  ) $isInTimeRange = 1;
	      }
	      // If there is a teacher-conflict, perhaps because of classGroups
	      if( $cType==1 && $isInTimeRange ) {
		  if( $outerValues['Zimmer'] == $loopValues['Zimmer'] && 
		      $isOtherTeacher == FALSE && 
		      $loopValues['Periodizitaet'] % $outerValues['Periodizitaet'] == 0 &&
		      $loopValues['dateFrom'] == $outerValues['dateFrom'] &&
		      $loopValues['timeFrom'] == $outerValues['timeFrom'] 
		  ) $isInTimeRange = 0;
	      }
	      // If there is a conflict, periodicity perhaps resolves it
	      if( $isInTimeRange ) {
		  // get week-differences
		  $sWeekDiff = date( 'W' , $outerValues['dateFrom'] ) - date( 'W' , $loopValues['dateFrom'] );
		  $eWeekDiff = date( 'W' , $outerValues['dateTo'] ) - date( 'W' , $loopValues['dateTo'] );
		  // evaluate the lower periodicity, if they are different
		  $periodicity = $loopValues['Periodizitaet'] > $outerValues['Periodizitaet'] ? $outerValues['Periodizitaet'] : $loopValues['Periodizitaet'];
		  // if some rest remains by division weekDiff / periodicity then there is no conflict. 0 != modulo($eWeekDiff,$periodicity)
		  if(!empty($sWeekDiff) && !empty($eWeekDiff)) {
		      if( $sWeekDiff % $periodicity != 0 ) {
			  // look up for endDate if no conflict by startDate 
			  if( $eWeekDiff % $periodicity != 0 ) $isInTimeRange = 0;
		      }
		  }
	      }
	      return $isInTimeRange;
	}
	public function downloadAsXls( $sortTables) {
	   // if( !is_array($sortTables['conflicts']) ) return false;
            $filename = 'vergleiche_' . date( 'ymd-Hi' ) . '.xlsx' ;
		//$extKey =  $this->request->getControllerExtensionKey();
		$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->pathToPHPExcel );
		set_include_path($extDir);
		include $extDir.'PHPExcel/IOFactory.php';

		$objPHPExcel = new \PHPExcel();

		$sheetNr = 0;
		foreach( $sortTables as $sheetname => $sheetcontent ){
		      $rowIdx = 1;
		      if($sheetNr) {
			  $PHPExcel_Worksheet = new \PHPExcel_Worksheet($objPHPExcel);
			  $objPHPExcel->addSheet($PHPExcel_Worksheet,$sheetNr);
			  $objPHPExcel->getSheet($sheetNr)->setTitle( $sheetname );
		      }else{
			  $objPHPExcel->getSheet($sheetNr)->setTitle( $sheetname );
		      }
		      foreach( $sheetcontent as $tablename => $tablecontent ){
			  if( is_array( $tablecontent ) ) {
				$ix=0;
				foreach($tablecontent as $uid=>$row){
				    foreach(array_keys($row) as $fld) {
					$objRichText = new \PHPExcel_RichText();
					$objCellTitle = $objRichText->createTextRun( $fld );
					$objCellTitle->getFont()->setBold(true);
					$objCellTitle->getFont()->setItalic(true);
					$objPHPExcel->getSheet($sheetNr)->getCellByColumnAndRow($ix,$rowIdx)->setValue($objRichText);
					$objPHPExcel->getSheet($sheetNr)->getColumnDimension( chr(65+$ix) )->setAutoSize(true);
					++$ix;
				    }
				    break;
				}
				++$rowIdx;
				foreach($tablecontent as $uid=>$row){
				    $colIdx=0;
				    foreach(array_keys($row) as $fld) {
					$objPHPExcel->getSheet($sheetNr)->setCellValueByColumnAndRow($colIdx,$rowIdx,$row[$fld] );
					++$colIdx;
				    }
				    ++$rowIdx;
				}
				$objPHPExcel->getSheet($sheetNr)->setCellValueByColumnAndRow(0,$rowIdx, '' );
				++$rowIdx;
			  }
		      }
		      ++$sheetNr;
		}

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="'.$filename.'"');
		header('Cache-Control: max-age=0');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		
		exit();
	}
	
	public function translateDateTime( $table ) {
	    foreach($table as $tix=>$zeile){
		  $table[$tix]['Datum_von'] = date( 'd.m.y' , $zeile['dateFrom']);
		  $table[$tix]['Datum_bis'] = date( 'd.m.y' , $zeile['dateTo']);
	    }
	    return $table;
	}

	/**
	 * ecoTime2decimal
	 *
	 * @param string $ecoTime Time in format HH:ii
	 * @return void
	 */
	public function ecoTime2decimal( $ecoTime ) {
		  $len = strlen($ecoTime);
		  $fullHowers = 60 * substr( $ecoTime , 0 , $len-3 );
		  $restMinutes = substr( $ecoTime , $len-2 , 2 );
		  $this->datesTable[$ecoTime] = ($fullHowers + $restMinutes);
		  return $this->datesTable[$ecoTime];
	}
	
	/**
	 * ecoDate2timestamp
	 *
	 * @param string $ecoDate Date in format DDMMYYYY
	 * @return void
	 */
	public function ecoDate2timestamp( $ecoDate ) {
	      if(empty($ecoDate) || strlen( $ecoDate)!=8 ) return $ecoDate;
	      $this->datesTable[$ecoDate] = mktime( 0,0,0 , substr( $ecoDate , 2 , 2) , substr( $ecoDate , 0 , 2 ) , substr( $ecoDate , 4 , 4) );
	      return $this->datesTable[$ecoDate];
	}
}
