<?php

namespace Mff\Mffplan\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Mff\Mffplan\Domain\Model\Timetable.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class TimetableTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \Mff\Mffplan\Domain\Model\Timetable
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = new \Mff\Mffplan\Domain\Model\Timetable();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getWeekdayReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setWeekdayForIntSetsWeekday() {	}

	/**
	 * @test
	 */
	public function getPeriodicityReturnsInitialValueForInt() {	}

	/**
	 * @test
	 */
	public function setPeriodicityForIntSetsPeriodicity() {	}

	/**
	 * @test
	 */
	public function getDateStartReturnsInitialValueForDateTime() {
		$this->assertEquals(
			NULL,
			$this->subject->getDateStart()
		);
	}

	/**
	 * @test
	 */
	public function setDateStartForDateTimeSetsDateStart() {
		$dateTimeFixture = new \DateTime();
		$this->subject->setDateStart($dateTimeFixture);

		$this->assertAttributeEquals(
			$dateTimeFixture,
			'dateStart',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getDateEndReturnsInitialValueForDateTime() {
		$this->assertEquals(
			NULL,
			$this->subject->getDateEnd()
		);
	}

	/**
	 * @test
	 */
	public function setDateEndForDateTimeSetsDateEnd() {
		$dateTimeFixture = new \DateTime();
		$this->subject->setDateEnd($dateTimeFixture);

		$this->assertAttributeEquals(
			$dateTimeFixture,
			'dateEnd',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTimeFromReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTimeFrom()
		);
	}

	/**
	 * @test
	 */
	public function setTimeFromForStringSetsTimeFrom() {
		$this->subject->setTimeFrom('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'timeFrom',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTimeToReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTimeTo()
		);
	}

	/**
	 * @test
	 */
	public function setTimeToForStringSetsTimeTo() {
		$this->subject->setTimeTo('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'timeTo',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getNoteReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getNote()
		);
	}

	/**
	 * @test
	 */
	public function setNoteForStringSetsNote() {
		$this->subject->setNote('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'note',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getImportIndexReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getImportIndex()
		);
	}

	/**
	 * @test
	 */
	public function setImportIndexForStringSetsImportIndex() {
		$this->subject->setImportIndex('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'importIndex',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getRelTeacherReturnsInitialValueForTeacher() {
		$this->assertEquals(
			NULL,
			$this->subject->getRelTeacher()
		);
	}

	/**
	 * @test
	 */
	public function setRelTeacherForTeacherSetsRelTeacher() {
		$relTeacherFixture = new \Mff\Mffplan\Domain\Model\Teacher();
		$this->subject->setRelTeacher($relTeacherFixture);

		$this->assertAttributeEquals(
			$relTeacherFixture,
			'relTeacher',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getRelClassReturnsInitialValueForScoolclass() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getRelClass()
		);
	}

	/**
	 * @test
	 */
	public function setRelClassForObjectStorageContainingScoolclassSetsRelClass() {
		$relClas = new \Mff\Mffplan\Domain\Model\Scoolclass();
		$objectStorageHoldingExactlyOneRelClass = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneRelClass->attach($relClas);
		$this->subject->setRelClass($objectStorageHoldingExactlyOneRelClass);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneRelClass,
			'relClass',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addRelClasToObjectStorageHoldingRelClass() {
		$relClas = new \Mff\Mffplan\Domain\Model\Scoolclass();
		$relClassObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$relClassObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($relClas));
		$this->inject($this->subject, 'relClass', $relClassObjectStorageMock);

		$this->subject->addRelClas($relClas);
	}

	/**
	 * @test
	 */
	public function removeRelClasFromObjectStorageHoldingRelClass() {
		$relClas = new \Mff\Mffplan\Domain\Model\Scoolclass();
		$relClassObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$relClassObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($relClas));
		$this->inject($this->subject, 'relClass', $relClassObjectStorageMock);

		$this->subject->removeRelClas($relClas);

	}

	/**
	 * @test
	 */
	public function getRelRoomReturnsInitialValueForRoom() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getRelRoom()
		);
	}

	/**
	 * @test
	 */
	public function setRelRoomForObjectStorageContainingRoomSetsRelRoom() {
		$relRoom = new \Mff\Mffplan\Domain\Model\Room();
		$objectStorageHoldingExactlyOneRelRoom = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneRelRoom->attach($relRoom);
		$this->subject->setRelRoom($objectStorageHoldingExactlyOneRelRoom);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneRelRoom,
			'relRoom',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addRelRoomToObjectStorageHoldingRelRoom() {
		$relRoom = new \Mff\Mffplan\Domain\Model\Room();
		$relRoomObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$relRoomObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($relRoom));
		$this->inject($this->subject, 'relRoom', $relRoomObjectStorageMock);

		$this->subject->addRelRoom($relRoom);
	}

	/**
	 * @test
	 */
	public function removeRelRoomFromObjectStorageHoldingRelRoom() {
		$relRoom = new \Mff\Mffplan\Domain\Model\Room();
		$relRoomObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$relRoomObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($relRoom));
		$this->inject($this->subject, 'relRoom', $relRoomObjectStorageMock);

		$this->subject->removeRelRoom($relRoom);

	}

	/**
	 * @test
	 */
	public function getRelSubjectReturnsInitialValueForSubject() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getRelSubject()
		);
	}

	/**
	 * @test
	 */
	public function setRelSubjectForObjectStorageContainingSubjectSetsRelSubject() {
		$relSubject = new \Mff\Mffplan\Domain\Model\Subject();
		$objectStorageHoldingExactlyOneRelSubject = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneRelSubject->attach($relSubject);
		$this->subject->setRelSubject($objectStorageHoldingExactlyOneRelSubject);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneRelSubject,
			'relSubject',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addRelSubjectToObjectStorageHoldingRelSubject() {
		$relSubject = new \Mff\Mffplan\Domain\Model\Subject();
		$relSubjectObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$relSubjectObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($relSubject));
		$this->inject($this->subject, 'relSubject', $relSubjectObjectStorageMock);

		$this->subject->addRelSubject($relSubject);
	}

	/**
	 * @test
	 */
	public function removeRelSubjectFromObjectStorageHoldingRelSubject() {
		$relSubject = new \Mff\Mffplan\Domain\Model\Subject();
		$relSubjectObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$relSubjectObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($relSubject));
		$this->inject($this->subject, 'relSubject', $relSubjectObjectStorageMock);

		$this->subject->removeRelSubject($relSubject);

	}

	/**
	 * @test
	 */
	public function getRelPeriodReturnsInitialValueForPeriods() {
		$this->assertEquals(
			NULL,
			$this->subject->getRelPeriod()
		);
	}

	/**
	 * @test
	 */
	public function setRelPeriodForPeriodsSetsRelPeriod() {
		$relPeriodFixture = new \Mff\Mffplan\Domain\Model\Periods();
		$this->subject->setRelPeriod($relPeriodFixture);

		$this->assertAttributeEquals(
			$relPeriodFixture,
			'relPeriod',
			$this->subject
		);
	}
}
