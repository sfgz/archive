<?php
namespace Mff\Mffplan\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *  			
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class Mff\Mffplan\Controller\RulesController.
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class RulesControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \Mff\Mffplan\Controller\RulesController
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = $this->getMock('Mff\\Mffplan\\Controller\\RulesController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllRulessFromRepositoryAndAssignsThemToView() {

		$allRuless = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$rulesRepository = $this->getMock('Mff\\Mffplan\\Domain\\Repository\\RulesRepository', array('findAll'), array(), '', FALSE);
		$rulesRepository->expects($this->once())->method('findAll')->will($this->returnValue($allRuless));
		$this->inject($this->subject, 'rulesRepository', $rulesRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('ruless', $allRuless);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenRulesToView() {
		$rules = new \Mff\Mffplan\Domain\Model\Rules();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newRules', $rules);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($rules);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenRulesToRulesRepository() {
		$rules = new \Mff\Mffplan\Domain\Model\Rules();

		$rulesRepository = $this->getMock('Mff\\Mffplan\\Domain\\Repository\\RulesRepository', array('add'), array(), '', FALSE);
		$rulesRepository->expects($this->once())->method('add')->with($rules);
		$this->inject($this->subject, 'rulesRepository', $rulesRepository);

		$this->subject->createAction($rules);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenRulesToView() {
		$rules = new \Mff\Mffplan\Domain\Model\Rules();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('rules', $rules);

		$this->subject->editAction($rules);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenRulesInRulesRepository() {
		$rules = new \Mff\Mffplan\Domain\Model\Rules();

		$rulesRepository = $this->getMock('Mff\\Mffplan\\Domain\\Repository\\RulesRepository', array('update'), array(), '', FALSE);
		$rulesRepository->expects($this->once())->method('update')->with($rules);
		$this->inject($this->subject, 'rulesRepository', $rulesRepository);

		$this->subject->updateAction($rules);
	}

	/**
	 * @test
	 */
	public function deleteActionRemovesTheGivenRulesFromRulesRepository() {
		$rules = new \Mff\Mffplan\Domain\Model\Rules();

		$rulesRepository = $this->getMock('Mff\\Mffplan\\Domain\\Repository\\RulesRepository', array('remove'), array(), '', FALSE);
		$rulesRepository->expects($this->once())->method('remove')->with($rules);
		$this->inject($this->subject, 'rulesRepository', $rulesRepository);

		$this->subject->deleteAction($rules);
	}
}
