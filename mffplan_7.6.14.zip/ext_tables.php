<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
// mffplan/ext_tables.php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'Planimport',
	'Planimport'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'Mff Stundenplan');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_rules', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_rules.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_timetable', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_timetable.xlf');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_periods', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_periods.xlf');

### timetable
// Load description of table tx_mffplan_domain_model_timetable
// t3lib_div::loadTCA('tx_mffplan_domain_model_timetable');

// Add the external information to the ctrl section // 'connector' => 'csv',
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'csv',
		'parameters' => array(
			'filename' => 'uploads/tx_mffplan/dbimport.csv',
			'delimiter' => ';',
			'text_qualifier' => '',
			'skip_rows' => '1',
			'encoding' => 'ISO-8859-15',
			'locale' => 'de_CH.UTF-8'
		),
		'data' => 'array',
		'referenceUid' => 'import_index',
		'enforcePid' => FALSE,
		'priority' => 1010,
		'description' => 'Importiert timetable aus Datei zu mffPlan (RulesController)'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['pid']['external'] = array(
	0 => array( 
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['import_index']['external'] = array(
	0 => array( 
		'field' => 'importIndex'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['weekday']['external'] = array(
	0 => array( 
		'field' => 'Wochentag'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['periodicity']['external'] = array(
	0 => array( 
		'field' => 'Periodizitaet'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['date_start']['external'] = array(
	0 => array( 
		'field' => 'dateStart'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['date_end']['external'] = array(
	0 => array( 
		'field' => 'dateEnd'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['time_from']['external'] = array(
	0 => array( 
		'field' => 'timeFrom'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['time_to']['external'] = array(
	0 => array( 
		'field' => 'timeTo'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['note']['external'] = array(
	0 => array( 
		'field' => 'Bemerkung'
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['rel_teacher']['external'] = array(
	0 => array(
		'field' => 'lehrerUid',
		'mapping' => array(
			'table' => 'fe_users',
			'reference_field' => 'uid'
		)
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['rel_class']['external'] = array(
	0 => array(
		'field' => 'klasseUid',
		'MM' => array(
			'mapping' => array(
				'table' => 'tx_mffdb_domain_model_klasse',
				'reference_field' => 'uid',
			)
		)
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['rel_room']['external'] = array(
	0 => array(
		'field' => 'locationUid',
		'MM' => array(
			'mapping' => array(
				'table' => 'tx_mffdb_domain_model_zimmer',
				'reference_field' => 'uid'
			)
		)
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['rel_subject']['external'] = array(
	0 => array(
		'field' => 'fachUid',
		'MM' => array(
			'mapping' => array(
				'table' => 'tx_mffdb_domain_model_fach',
				'reference_field' => 'uid'
			)
		)
	)
);
$GLOBALS['TCA']['tx_mffplan_domain_model_timetable']['columns']['rel_period']['external'] = array(
	0 => array(
		'field' => 'Periode',
		'mapping' => array(
			'table' => 'tx_mffplan_domain_model_periods',
			'reference_field' => 'semester'
		)
	)
);
