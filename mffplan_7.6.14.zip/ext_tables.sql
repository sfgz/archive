#
# Table structure for table 'tx_mffplan_domain_model_rules'
#
CREATE TABLE tx_mffplan_domain_model_rules (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	description varchar(255) DEFAULT '' NOT NULL,
	rendertype int(11) DEFAULT '0' NOT NULL,
	fieldname varchar(255) DEFAULT '' NOT NULL,
	needle varchar(255) DEFAULT '' NOT NULL,
	newtext varchar(255) DEFAULT '' NOT NULL,
	fieldname2 varchar(255) DEFAULT '' NOT NULL,
	needle2 varchar(255) DEFAULT '' NOT NULL,
	newtext2 varchar(255) DEFAULT '' NOT NULL,
	activate tinyint(1) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffplan_domain_model_timetable'
#
CREATE TABLE tx_mffplan_domain_model_timetable (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	weekday int(11) DEFAULT '0' NOT NULL,
	periodicity int(11) DEFAULT '0' NOT NULL,
	date_start date DEFAULT '1970-01-01',
	date_end date DEFAULT '1970-01-01',
	time_from varchar(255) DEFAULT '' NOT NULL,
	time_to varchar(255) DEFAULT '' NOT NULL,
	note varchar(255) DEFAULT '' NOT NULL,
	import_index varchar(255) DEFAULT '' NOT NULL,
	rel_teacher int(11) unsigned DEFAULT '0',
	rel_class int(11) unsigned DEFAULT '0' NOT NULL,
	rel_room int(11) unsigned DEFAULT '0' NOT NULL,
	rel_subject int(11) unsigned DEFAULT '0' NOT NULL,
	rel_period int(11) unsigned DEFAULT '0',

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY date_start (date_start),
	KEY date_end (date_end),
	KEY rel_room (rel_room),
	KEY rel_teacher (rel_teacher),
	KEY rel_period (rel_period),

);

#
# Table structure for table 'tx_mffplan_domain_model_periods'
#
CREATE TABLE tx_mffplan_domain_model_periods (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	semester varchar(255) DEFAULT '' NOT NULL,
	davor_bis date DEFAULT '1970-01-01',
	datum_ab date DEFAULT '1970-01-01',
	datum_bis date DEFAULT '1970-01-01',
	danach_ab date DEFAULT '1970-01-01',

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffplan_timetable_scoolclass_mm'
#
CREATE TABLE tx_mffplan_timetable_scoolclass_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_mffplan_timetable_room_mm'
#
CREATE TABLE tx_mffplan_timetable_room_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'tx_mffplan_timetable_subject_mm'
#
CREATE TABLE tx_mffplan_timetable_subject_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (

	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,

);


-- #
-- # Table structure for table 'tx_mffdb_domain_model_klasse'
-- #
-- CREATE TABLE tx_mffdb_domain_model_klasse (
-- 
-- 	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,
-- 
-- );

-- #
-- # Table structure for table 'tx_mffdb_domain_model_zimmer'
-- #
-- CREATE TABLE tx_mffdb_domain_model_zimmer (
-- 
-- 	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,
-- 
-- );

-- #
-- # Table structure for table 'tx_mffdb_domain_model_fach'
-- #
-- CREATE TABLE tx_mffdb_domain_model_fach (
-- 
-- 	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,
-- 
-- );

