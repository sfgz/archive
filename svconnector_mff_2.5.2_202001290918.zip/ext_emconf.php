<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "svconnector_json".
 *
 * Auto generated 26-02-2017 02:23
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
  'title' => 'Mff Connector service - JSON with Auth',
  'description' => 'Connector service for JSON data with authentication and backup functionality.',
  'category' => 'services',
  'version' => '2.5.2',
  'state' => 'stable',
  'uploadfolder' => true,
  'createDirs' => '',
  'clearcacheonload' => true,
  'author' => 'Prakash A Bhat, Francois Suter (Cobweb)',
  'author_email' => 'typo3@cobweb.ch',
  'author_company' => '',
  'constraints' => 
  array (
    'depends' => 
    array (
      'typo3' => '7.6.0-7.99.99',
      'svconnector' => '3.0.0-0.0.0',
    ),
    'conflicts' => 
    array (
    ),
    'suggests' => 
    array (
    ),
  ),
);

