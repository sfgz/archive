<?php
// mffplan/ext_localconf.php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['mffdb']['processResponse'][] = 'EXT:mffplan/class.tx_mffdb_repository_hook.php:tx_mffdb_repository_hook';

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'Planimport',
	array(
		'Rules' => 'compare,list, new, create, edit, update, delete, download',
		'Timetable' => 'list, new, create, edit, update, delete',
		'Analyse' => 'conflicts,saldi',
		
	),
	// non-cacheable actions
	array(
		'Rules' => 'compare, list,create, edit, update, delete',
		'Timetable' => 'list, create, edit, update',
		'Analyse' => 'conflicts,saldi',
		
	)
);
// Register scheduler-Tasks
if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
	$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Mff\\Mffplan\\Command\\CreatePeriodsCommandController'] = array(
		'extension'			=> $_EXTKEY,
		'title'				=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.rebuild_periods.title',
		'description'		=> 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang.xlf:scheduler.rebuild_periods.description',
		'additionalFields'	=> ''
	);
}
