<?php
namespace Mff\Mffplan\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Timetable
 */
class Timetable extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * weekday
	 *
	 * @var int
	 */
	protected $weekday = 0;

	/**
	 * periodicity
	 *
	 * @var int
	 */
	protected $periodicity = 0;

	/**
	 * dateStart
	 *
	 * @var \DateTime
	 */
	protected $dateStart = NULL;

	/**
	 * dateEnd
	 *
	 * @var \DateTime
	 */
	protected $dateEnd = NULL;

	/**
	 * timeFrom
	 *
	 * @var string
	 */
	protected $timeFrom = '';

	/**
	 * timeTo
	 *
	 * @var string
	 */
	protected $timeTo = '';

	/**
	 * note
	 *
	 * @var string
	 */
	protected $note = '';

	/**
	 * importIndex
	 *
	 * @var string
	 */
	protected $importIndex = '';

	/**
	 * relTeacher
	 *
	 * @var \Mff\Mffplan\Domain\Model\Teacher
	 */
	protected $relTeacher = NULL;

	/**
	 * relClass
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Scoolclass>
	 */
	protected $relClass = NULL;

	/**
	 * relRoom
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Room>
	 */
	protected $relRoom = NULL;

	/**
	 * relSubject
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Subject>
	 */
	protected $relSubject = NULL;

	/**
	 * relPeriod
	 *
	 * @var \Mff\Mffplan\Domain\Model\Periods
	 */
	protected $relPeriod = NULL;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->relClass = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->relRoom = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->relSubject = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the weekday
	 *
	 * @return int $weekday
	 */
	public function getWeekday() {
		return $this->weekday;
	}

	/**
	 * Sets the weekday
	 *
	 * @param int $weekday
	 * @return void
	 */
	public function setWeekday($weekday) {
		$this->weekday = $weekday;
	}

	/**
	 * Returns the periodicity
	 *
	 * @return int $periodicity
	 */
	public function getPeriodicity() {
		return $this->periodicity;
	}

	/**
	 * Sets the periodicity
	 *
	 * @param int $periodicity
	 * @return void
	 */
	public function setPeriodicity($periodicity) {
		$this->periodicity = $periodicity;
	}

	/**
	 * Returns the dateStart
	 *
	 * @return \DateTime $dateStart
	 */
	public function getDateStart() {
		return $this->dateStart;
	}

	/**
	 * Sets the dateStart
	 *
	 * @param \DateTime $dateStart
	 * @return void
	 */
	public function setDateStart(\DateTime $dateStart) {
		$this->dateStart = $dateStart;
	}

	/**
	 * Returns the dateEnd
	 *
	 * @return \DateTime $dateEnd
	 */
	public function getDateEnd() {
		return $this->dateEnd;
	}

	/**
	 * Sets the dateEnd
	 *
	 * @param \DateTime $dateEnd
	 * @return void
	 */
	public function setDateEnd(\DateTime $dateEnd) {
		$this->dateEnd = $dateEnd;
	}

	/**
	 * Returns the timeFrom
	 *
	 * @return string $timeFrom
	 */
	public function getTimeFrom() {
		return $this->timeFrom;
	}

	/**
	 * Sets the timeFrom
	 *
	 * @param string $timeFrom
	 * @return void
	 */
	public function setTimeFrom($timeFrom) {
		$this->timeFrom = $timeFrom;
	}

	/**
	 * Returns the timeTo
	 *
	 * @return string $timeTo
	 */
	public function getTimeTo() {
		return $this->timeTo;
	}

	/**
	 * Sets the timeTo
	 *
	 * @param string $timeTo
	 * @return void
	 */
	public function setTimeTo($timeTo) {
		$this->timeTo = $timeTo;
	}

	/**
	 * Returns the note
	 *
	 * @return string $note
	 */
	public function getNote() {
		return $this->note;
	}

	/**
	 * Sets the note
	 *
	 * @param string $note
	 * @return void
	 */
	public function setNote($note) {
		$this->note = $note;
	}

	/**
	 * Returns the importIndex
	 *
	 * @return string $importIndex
	 */
	public function getImportIndex() {
		return $this->importIndex;
	}

	/**
	 * Sets the importIndex
	 *
	 * @param string $importIndex
	 * @return void
	 */
	public function setImportIndex($importIndex) {
		$this->importIndex = $importIndex;
	}

	/**
	 * Returns the relTeacher
	 *
	 * @return \Mff\Mffplan\Domain\Model\Teacher $relTeacher
	 */
	public function getRelTeacher() {
		return $this->relTeacher;
	}

	/**
	 * Sets the relTeacher
	 *
	 * @param \Mff\Mffplan\Domain\Model\Teacher $relTeacher
	 * @return void
	 */
	public function setRelTeacher(\Mff\Mffplan\Domain\Model\Teacher $relTeacher) {
		$this->relTeacher = $relTeacher;
	}

	/**
	 * Adds a Scoolclass
	 *
	 * @param \Mff\Mffplan\Domain\Model\Scoolclass $relClas
	 * @return void
	 */
	public function addRelClas(\Mff\Mffplan\Domain\Model\Scoolclass $relClas) {
		$this->relClass->attach($relClas);
	}

	/**
	 * Removes a Scoolclass
	 *
	 * @param \Mff\Mffplan\Domain\Model\Scoolclass $relClasToRemove The Scoolclass to be removed
	 * @return void
	 */
	public function removeRelClas(\Mff\Mffplan\Domain\Model\Scoolclass $relClasToRemove) {
		$this->relClass->detach($relClasToRemove);
	}

	/**
	 * Adds a Scoolclass
	 *
	 * @param \Mff\Mffplan\Domain\Model\Scoolclass $relClass
	 * @return void
	 */
	public function addRelClass(\Mff\Mffplan\Domain\Model\Scoolclass $relClass) {
		$this->relClass->attach($relClas);
	}

	/**
	 * Removes a Scoolclass
	 *
	 * @param \Mff\Mffplan\Domain\Model\Scoolclass $relClassToRemove The Scoolclass to be removed
	 * @return void
	 */
	public function removeRelClass(\Mff\Mffplan\Domain\Model\Scoolclass $relClassToRemove) {
		$this->relClass->detach($relClassToRemove);
	}

	/**
	 * Returns the relClass
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Scoolclass> $relClass
	 */
	public function getRelClass() {
		return $this->relClass;
	}

	/**
	 * Sets the relClass
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Scoolclass> $relClass
	 * @return void
	 */
	public function setRelClass(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $relClass) {
		$this->relClass = $relClass;
	}

	/**
	 * Adds a Room
	 *
	 * @param \Mff\Mffplan\Domain\Model\Room $relRoom
	 * @return void
	 */
	public function addRelRoom(\Mff\Mffplan\Domain\Model\Room $relRoom) {
		$this->relRoom->attach($relRoom);
	}

	/**
	 * Removes a Room
	 *
	 * @param \Mff\Mffplan\Domain\Model\Room $relRoomToRemove The Room to be removed
	 * @return void
	 */
	public function removeRelRoom(\Mff\Mffplan\Domain\Model\Room $relRoomToRemove) {
		$this->relRoom->detach($relRoomToRemove);
	}

	/**
	 * Returns the relRoom
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Room> $relRoom
	 */
	public function getRelRoom() {
		return $this->relRoom;
	}

	/**
	 * Sets the relRoom
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Room> $relRoom
	 * @return void
	 */
	public function setRelRoom(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $relRoom) {
		$this->relRoom = $relRoom;
	}

	/**
	 * Adds a Subject
	 *
	 * @param \Mff\Mffplan\Domain\Model\Subject $relSubject
	 * @return void
	 */
	public function addRelSubject(\Mff\Mffplan\Domain\Model\Subject $relSubject) {
		$this->relSubject->attach($relSubject);
	}

	/**
	 * Removes a Subject
	 *
	 * @param \Mff\Mffplan\Domain\Model\Subject $relSubjectToRemove The Subject to be removed
	 * @return void
	 */
	public function removeRelSubject(\Mff\Mffplan\Domain\Model\Subject $relSubjectToRemove) {
		$this->relSubject->detach($relSubjectToRemove);
	}

	/**
	 * Returns the relSubject
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Subject> $relSubject
	 */
	public function getRelSubject() {
		return $this->relSubject;
	}

	/**
	 * Sets the relSubject
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffplan\Domain\Model\Subject> $relSubject
	 * @return void
	 */
	public function setRelSubject(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $relSubject) {
		$this->relSubject = $relSubject;
	}

	/**
	 * Returns the relPeriod
	 *
	 * @return \Mff\Mffplan\Domain\Model\Periods $relPeriod
	 */
	public function getRelPeriod() {
		return $this->relPeriod;
	}

	/**
	 * Sets the relPeriod
	 *
	 * @param \Mff\Mffplan\Domain\Model\Periods $relPeriod
	 * @return void
	 */
	public function setRelPeriod(\Mff\Mffplan\Domain\Model\Periods $relPeriod) {
		$this->relPeriod = $relPeriod;
	}

}