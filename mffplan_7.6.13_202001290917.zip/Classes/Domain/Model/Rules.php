<?php
namespace Mff\Mffplan\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Rules to run on table contents
 */
class Rules extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * sorting
	 *
	 * @var int
	 */
	protected $sorting = 0;

	/**
	 * description
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $description = '';

	/**
	 * rendertype
	 *
	 * @var int
	 * @validate NotEmpty
	 */
	protected $rendertype = 0;

	/**
	 * fieldname
	 *
	 * @var string
	 */
	protected $fieldname = '';

	/**
	 * needle
	 *
	 * @var string
	 */
	protected $needle = '';

	/**
	 * newtext
	 *
	 * @var string
	 */
	protected $newtext = '';

	/**
	 * fieldname2
	 *
	 * @var string
	 */
	protected $fieldname2 = '';

	/**
	 * needle2
	 *
	 * @var string
	 */
	protected $needle2 = '';

	/**
	 * newtext2
	 *
	 * @var string
	 */
	protected $newtext2 = '';

	/**
	 * activate
	 *
	 * @var bool
	 */
	protected $activate = FALSE;

	/**
	 * Returns the description
	 *
	 * @return string $description
	 */
	public function getDescription() {
		return $this->description;
	}

	/**
	 * Sets the description
	 *
	 * @param string $description
	 * @return void
	 */
	public function setDescription($description) {
		$this->description = $description;
	}

	/**
	 * Returns the rendertype
	 *
	 * @return int $rendertype
	 */
	public function getRendertype() {
		return $this->rendertype;
	}

	/**
	 * Sets the rendertype
	 *
	 * @param int $rendertype
	 * @return void
	 */
	public function setRendertype($rendertype) {
		$this->rendertype = $rendertype;
	}

	/**
	 * Returns the fieldname
	 *
	 * @return string $fieldname
	 */
	public function getFieldname() {
		return $this->fieldname;
	}

	/**
	 * Sets the fieldname
	 *
	 * @param string $fieldname
	 * @return void
	 */
	public function setFieldname($fieldname) {
		$this->fieldname = $fieldname;
	}

	/**
	 * Returns the needle
	 *
	 * @return string $needle
	 */
	public function getNeedle() {
		return $this->needle;
	}

	/**
	 * Sets the needle
	 *
	 * @param string $needle
	 * @return void
	 */
	public function setNeedle($needle) {
		$this->needle = $needle;
	}

	/**
	 * Returns the newtext
	 *
	 * @return string $newtext
	 */
	public function getNewtext() {
		return $this->newtext;
	}

	/**
	 * Sets the newtext
	 *
	 * @param string $newtext
	 * @return void
	 */
	public function setNewtext($newtext) {
		$this->newtext = $newtext;
	}

	/**
	 * Returns the fieldname2
	 *
	 * @return string $fieldname2
	 */
	public function getFieldname2() {
		return $this->fieldname2;
	}

	/**
	 * Sets the fieldname2
	 *
	 * @param string $fieldname2
	 * @return void
	 */
	public function setFieldname2($fieldname2) {
		$this->fieldname2 = $fieldname2;
	}

	/**
	 * Returns the needle2
	 *
	 * @return string $needle2
	 */
	public function getNeedle2() {
		return $this->needle2;
	}

	/**
	 * Sets the needle2
	 *
	 * @param string $needle2
	 * @return void
	 */
	public function setNeedle2($needle2) {
		$this->needle2 = $needle2;
	}

	/**
	 * Returns the newtext2
	 *
	 * @return string $newtext2
	 */
	public function getNewtext2() {
		return $this->newtext2;
	}

	/**
	 * Sets the newtext2
	 *
	 * @param string $newtext2
	 * @return void
	 */
	public function setNewtext2($newtext2) {
		$this->newtext2 = $newtext2;
	}

	/**
	 * Returns the activate
	 *
	 * @return bool $activate
	 */
	public function getActivate() {
		return $this->activate;
	}

	/**
	 * Sets the activate
	 *
	 * @param bool $activate
	 * @return void
	 */
	public function setActivate($activate) {
		$this->activate = $activate;
	}

	/**
	 * Returns the boolean state of activate
	 *
	 * @return bool
	 */
	public function isActivate() {
		return $this->activate;
	}

	/**
	 * Returns the sorting
	 *
	 * @return int $sorting
	 */
	public function getSorting() {
		return $this->sorting;
	}

	/**
	 * Sets the sorting
	 *
	 * @param int $sorting
	 * @return void
	 */
	public function setSorting($sorting) {
		$this->sorting = $sorting;
	}

}