<?php
namespace Mff\Mffplan\Domain\Repository;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Timetables
 */
class TimetableRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {

	/**
	 * @var array
	 */
	protected $defaultOrderings = array(
		'uid' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
	);

	/**
	 * findBySemesterGroupByKlasseTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $semesterUid
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findBySemesterGroupByKlasseTeacherFiltered( $semesterUid , $filter = array() ){
	      $sqlStatement = 'SELECT kurzbezeichnung,"fm" AS source, CONCAT_WS(" ",last_name,first_name) AS user, email, username,tx_mffdb_domain_model_fach.*, ';
	      $sqlStatement .= 'tx_mffplan_domain_model_timetable.uid,';
	      $sqlStatement .= 'tx_mffplan_domain_model_timetable.pid,';
	      $sqlStatement .= 'UNIX_TIMESTAMP(date_start) AS plan_start,';
	      $sqlStatement .= 'UNIX_TIMESTAMP(date_end) AS plan_ende,';
	      $sqlStatement .= 'rel_teacher AS plan_teacher,tx_mffdb_domain_model_klasse.class_short AS Klasse,';
	      $sqlStatement .= 'tx_mffdb_domain_model_kurzklasse.*,tx_mffdb_domain_model_klasse.* FROM tx_mffdb_domain_model_kurzklasse ';
	      $sqlStatement .= 'JOIN tx_mffdb_domain_model_klasse ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse ';
	      $sqlStatement .= 'JOIN tx_mffplan_timetable_scoolclass_mm ON tx_mffdb_domain_model_klasse.uid=tx_mffplan_timetable_scoolclass_mm.uid_foreign ';
	      $sqlStatement .= 'JOIN tx_mffplan_domain_model_timetable ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_scoolclass_mm.uid_local ';
	      $sqlStatement .= 'JOIN tx_mffplan_timetable_subject_mm ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_subject_mm.uid_local ';
	      $sqlStatement .= 'JOIN tx_mffdb_domain_model_fach ON tx_mffdb_domain_model_fach.uid=tx_mffplan_timetable_subject_mm.uid_foreign ';
	      $sqlStatement .= 'JOIN fe_users ON fe_users.uid=tx_mffplan_domain_model_timetable.rel_teacher ';
 	      
 	      $sqlStatement .= 'WHERE  tx_mffplan_domain_model_timetable.rel_period = ' . $semesterUid . ' ';
 	      $sqlStatement .= ' AND  tx_mffdb_domain_model_fach.fach_kursregel = 0 ';
 	      if($filter['fachbereich']){
		    $aFltFb = explode( ',' , $filter['fachbereich'] );
		    if(is_array($aFltFb)){
			  $aWhere = array();
			  foreach($aFltFb as $val){
				$aWhere[] = ' fachbereich='.$val;
			  }
			  if(count($aWhere)) $sqlStatement .= ' AND (' . implode( ' OR ' , $aWhere ) . ') ';
		    }
 	      }
 	      
	     $sqlStatement .= ' GROUP BY fe_users.uid,tx_mffdb_domain_model_klasse.uid,fachbezeichnung ';
	      
	      $sqlStatement .= ' ORDER BY tx_mffplan_domain_model_timetable.date_start,fachbereich,class_short ASC ';
	      
	      $rawQueryResult = $this->callSqlStatement( $sqlStatement );
	      return $rawQueryResult;
	}
	
	/**
	 * findBySemesterGroupByKursregelTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $semesterUid
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findBySemesterGroupByKursregelTeacherFiltered( $semesterUid , $filter = array() ){
	      // filter[ 'fachbereich' ] = 7,8  
	      $sqlStatement = 'SELECT "KURS" AS kurzbezeichnung,"fm" AS source, CONCAT_WS(" ",last_name,first_name) AS user, email,';
	      $sqlStatement .= ' username,tx_mffdb_domain_model_fach.*, ';
	      $sqlStatement .= 'tx_mffplan_domain_model_timetable.uid,';
	      $sqlStatement .= 'tx_mffplan_domain_model_timetable.pid,';
	      $sqlStatement .= 'UNIX_TIMESTAMP(date_start) AS plan_start,';
	      $sqlStatement .= 'UNIX_TIMESTAMP(date_end) AS plan_ende,';
	      $sqlStatement .= 'rel_teacher AS plan_teacher,fachkurz AS Klasse,';
	      $sqlStatement .= 'tx_mffdb_domain_model_kursregel.* FROM tx_mffdb_domain_model_kursregel ';
	      $sqlStatement .= 'JOIN tx_mffdb_domain_model_fach ON tx_mffdb_domain_model_kursregel.uid=tx_mffdb_domain_model_fach.fach_kursregel ';
	      $sqlStatement .= 'JOIN tx_mffplan_timetable_subject_mm ON tx_mffdb_domain_model_fach.uid=tx_mffplan_timetable_subject_mm.uid_foreign ';
	      $sqlStatement .= 'JOIN tx_mffplan_domain_model_timetable ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_subject_mm.uid_local ';
	      $sqlStatement .= 'JOIN fe_users ON fe_users.uid=tx_mffplan_domain_model_timetable.rel_teacher ';
 	      
 	      $sqlStatement .= 'WHERE  tx_mffplan_domain_model_timetable.rel_period = ' . $semesterUid;
 	      if($filter['fachbereich']){
		    $aFltFb = explode( ',' , $filter['fachbereich'] );
		    if(is_array($aFltFb)){
			  $aWhere = array();
			  foreach($aFltFb as $val){
				$aWhere[] = ' fachbereich='.$val;
			  }
			  if(count($aWhere)) $sqlStatement .= ' AND (' . implode( ' OR ' , $aWhere ) . ') ';
		    }
 	      }
 	      
	     $sqlStatement .= ' GROUP BY fe_users.uid, tx_mffdb_domain_model_fach.uid ';
	      
	      $sqlStatement .= ' ORDER BY tx_mffplan_domain_model_timetable.date_start,fachbereich,fachbezeichnung ASC ';
	      
	      $rawQueryResult = $this->callSqlStatement( $sqlStatement );
	      return $rawQueryResult;
	}
	
	/**
	 * findByRoomsAndDate
	 * used by extension Mffrps Raumplanung
	 *
	 * @param array  $zimmerArr uids of rooms, or empty
	 * @param int $datum
	 * @param int $datum_bis
	 * @return void
	 */
	public function findByRoomsAndDate( $zimmerArr = array() , $datum , $datum_bis=NULL ){
	    $sqlAndWhere = array();
	    $searchDate = date('Y-m-d', $datum );
	    $searchToDate = $datum_bis==NULL ? date('Y-m-d', $datum ) : date('Y-m-d', $datum_bis );
	    $weekDay = date('N', $datum );
	    
	    if($datum) $sqlAndWhere[] = ' date_start <= "' . $searchToDate .'" AND date_end >= "' . $searchDate .'" ';
	    
	    if($weekDay) $sqlAndWhere[] = ' weekday = ' . $weekDay . ' ';
	    
	    if(count($zimmerArr)){
		$roomWhereArr = array();
		foreach($zimmerArr as $roomNr) $roomWhereArr[] = ' tx_mffplan_timetable_room_mm.uid_foreign = '.$roomNr;
		$sqlAndWhere[] = ' (' . implode( ' OR ' , $roomWhereArr ) . ') ';
	    }
	    
	    $sqlStmt = 'SELECT DISTINCT fe_users.uid AS teacherId, name,first_name,last_name,
	    tx_mffdb_domain_model_klasse.class_short, 
	    ignore_holiday,
	    ignore_vacation,
	    fachkurz,fachbezeichnung,
	    tx_mffplan_timetable_room_mm.uid_foreign AS plan_zimmer,
	    tx_mffplan_domain_model_timetable.uid,
	    periodicity,
	    date_start,
	    date_end,
	    time_from,
	    time_to
	    FROM tx_mffplan_domain_model_timetable 
	     JOIN tx_mffplan_timetable_room_mm 
	    ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_room_mm.uid_local 
	    JOIN tx_mffplan_timetable_subject_mm 
	    ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_subject_mm.uid_local
	    JOIN tx_mffdb_domain_model_fach 
	    ON tx_mffdb_domain_model_fach.uid = tx_mffplan_timetable_subject_mm.uid_foreign
	    JOIN tx_mffplan_timetable_scoolclass_mm 
	    ON tx_mffplan_domain_model_timetable.uid = tx_mffplan_timetable_scoolclass_mm.uid_local
	    JOIN tx_mffdb_domain_model_klasse 
	    ON tx_mffdb_domain_model_klasse.uid = tx_mffplan_timetable_scoolclass_mm.uid_foreign
	    LEFT JOIN tx_mffdb_domain_model_kurzklasse 
	    ON tx_mffdb_domain_model_kurzklasse.uid = tx_mffdb_domain_model_klasse.kurzklasse
	    LEFT JOIN tx_mffdb_domain_model_fachbereich 
	    ON tx_mffdb_domain_model_fachbereich.uid = tx_mffdb_domain_model_kurzklasse.fachbereich
	    JOIN fe_users 
	    ON fe_users.uid = tx_mffplan_domain_model_timetable.rel_teacher
	    ';
	    
	    if(count($sqlAndWhere)) $sqlStmt .= ' WHERE ' . implode( ' AND ' , $sqlAndWhere ) . ' ';
	    
	    $sqlStmt .= ' ORDER BY date_start,time_from,class_short,name; ';
	    
// 	    return $this->callSqlStatement( $sqlStmt );
	    $zmrTimetable  = $this->callSqlStatement( $sqlStmt );
	    return $this->groupArrayByClass( $zmrTimetable );
	}
	public function groupArrayByClass( $zmrTimetable ){
	      $outArr = array();
	      $grpArr = array();
	      $clsArr = array();
	      foreach( $zmrTimetable as $ttRecord){
		    $idx = $ttRecord['periodicity'].'-'.
			    $ttRecord['date_start'].'-'.
			    $ttRecord['date_end'].'-'.
			    $ttRecord['time_from'].'-'.
			    $ttRecord['time_to'].'-'.
			    $ttRecord['name'].'-'.
			    $ttRecord['plan_zimmer'];
		    $grpArr[$idx] = $ttRecord;
		    $clsArr[$idx][$ttRecord['class_short']] = $ttRecord['class_short'];
	      }
	      foreach( $grpArr  as $idx => $ttRecord ){
		  if( !is_array($clsArr[$idx]) )continue;
		  foreach( $clsArr[$idx] as $class_short ){
		      $outArr[$idx.'-'.$class_short] = $ttRecord; 
		      $outArr[$idx.'-'.$class_short]['class_short'] = $class_short; 
		  }
	      }
	    return $outArr;
	}

	/**
	 * findByUidOrderedBy
	 * find a range of recordsets By Uid If Activated And Sort
	 * take account of page Range eg. 25 recordsets per page
	 * outputs a range of recordsets representing a page
	 * Used in header of editform
	 *
	 * @param array $orderFields
	 * @param array $filterFields
	 * @param int $pageNr Group/Page pointed to
	 * @param int $range amount of recordsets that should be displayd in one Group/Page
	 * @return void
	 */
	public function old_findByUidOrderedBy($orderFields, $filterFields, $pageNr, $range) {
		return $this->createQuery()->execute();
	}

	/**
	 * findByGroupOrderedBy
	 * find a range of recordsets By Group/Page If Activated And Sort
	 * take account of page Range eg. 25 recordsets per page
	 * take also account of filter-options
	 * outputs a range of recordsets representing a page
	 * Used in List
	 * possible filters are period (uid:semester),
	 * teacher (uid:name), class (uid:classShort), room (uid:fachkurz), subject (uid:fachkurz)
	 *
	 * @param array $orderFields
	 * @param array $filterFields e.g. array( period => 1 , class => 95 )
	 * @param int $range amount of recordsets that should be displayd in one Group/Page
	 * @param int $pageNr Group/Page pointed to
	 * @param boolean $returnAsArray output
	 * @return void
	 */
	public function findByGroupOrderedBy($orderFields = array(), $filterFields = array(), $range = 0, $pageNr = 0, $returnAsArray = false
	) {
		$query = $this->createQuery();
// 		$query->getQuerySettings()->setReturnRawQueryResult($returnAsArray);
		if (!count($orderFields)) {$orderFields=array( 'date_start' => 'a'  , 'uid' => 'a' );}
		$orderings = array();
		foreach ($orderFields as $field => $direction) {
			if (empty($field)) {
				continue;
			}
			$orderings[$field] = $direction != 'd' && $direction != 'DESC' ? \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING : \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING;
			if ($field == 'date_start' || $field == 'date_end' || $field == 'time_from' || $field == 'time_to') {
				$orderings['time_from'] = $orderings[$field];
				$orderings['time_to'] = $orderings[$field];
			}
		}
		$query->setOrderings($orderings);
		
		if (count($filterFields)) {
			$constraints = array();
			foreach ($filterFields as $fieldname => $hasvalue) {
				$constraints[] = $query->equals($fieldname, $hasvalue);
			}
			$query->matching($query->logicalAnd($constraints));
		}
		if ($range) {
			$query->setOffset($pageNr < 2 ? 0 : ($pageNr - 1) * $range);
			$query->setLimit($range);
		}
		return $query->execute($returnAsArray);
	}

	/**
	 * findAllIfActivated
	 *
	 * @param array $orderFields
	 * @return void
	 */
	public function findAllOrderedBy($orderFields) {
		$orderings = array();
		foreach ($orderFields as $field => $direction) {
			if (!empty($field)) {
				$orderings[$field] = $direction != 'DESC' ? \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING : \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING;
			}
		}
		$query = $this->createQuery();
		$query->setOrderings($orderings);
		return $query->execute();
	}

	/**
	 * Find data from Timetable with
	 * 'import_index' not empty
	 */
	public function findeDataToClear() {
		$querySettings = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setIgnoreEnableFields(TRUE);
		$querySettings->setRespectStoragePage(FALSE);
		$this->setDefaultQuerySettings($querySettings);
		$query = $this->createQuery();
		$query->matching($query->logicalNot($query->equals('import_index', '')));
		return $query->execute();
	}

	/**
	 * @param $periodUid
	 * @return boolean
	 */
	public function deletePeriodFromTimetable($periodUid) {
		if (empty($periodUid)) {
			return false;
		}
		$res = $GLOBALS['TYPO3_DB']->sql_query('DELETE FROM tx_mffplan_domain_model_timetable WHERE tx_mffplan_domain_model_timetable.rel_period = ' . $periodUid);
		return true;
	}

	public function truncateTimetable() {
		$res = $GLOBALS['TYPO3_DB']->sql_query('TRUNCATE TABLE tx_mffplan_domain_model_timetable');
		//   var_dump($res);
		return $GLOBALS['TYPO3_DB']->sql_query('ALTER TABLE tx_mffplan_domain_model_timetable AUTO_INCREMENT =1');
	}

	/**
	 * @param $qryStatement
	 * @param $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
// 		$Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}

}