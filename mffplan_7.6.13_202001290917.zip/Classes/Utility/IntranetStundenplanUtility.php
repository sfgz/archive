<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class IntranetStundenplanUtility
 */

class IntranetStundenplanUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 */
	protected $periodsRepository = NULL;

	/**
	 * stundenplanRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\StundenplanRepository
	 */
	protected $stundenplanRepository = NULL;

	/**
	 * zimmerRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\ZimmerRepository
	 */
	protected $zimmerRepository = NULL;
	
	/**
	 * frontendUserRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
	 * @inject
	 */
	protected $frontendUserRepository = NULL;
	  
	/**
	 * abuFbUid
	 * 
	 * @var integer
	 */
	protected $abuFbUid = NULL;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct( ) {
	      $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
	      $this->querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $this->querySettings->setRespectStoragePage(FALSE);

	      $this->periodsRepository = $this->objectManager->get('Mff\\Mffplan\\Domain\\Repository\\PeriodsRepository');
	      $this->periodsRepository->setDefaultQuerySettings($this->querySettings);

	      $this->stundenplanRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\StundenplanRepository');
	      $this->stundenplanRepository->setDefaultQuerySettings($this->querySettings);

	      $this->zimmerRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
	      $this->zimmerRepository->setDefaultQuerySettings($this->querySettings);
	      
	      $this->frontendUserRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\EcouserRepository');
		  $this->frontendUserRepository->setDefaultQuerySettings($this->querySettings);

		  $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		  $settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		  $this->abuFbUid = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['abuFbUid'];
	}
    
	/**
	* transformFieldContents
	*
	* @param int $iPeriodUid
	* @return array iPeriodUid , objActualPeriod , aObjAllPeriods
	*/
	public function createPeriodObjects( $iPeriodUid = 0 ){
        $aObjAllPeriods = $this->periodsRepository->findAll();
		if($iPeriodUid){
			foreach( $aObjAllPeriods as $aPer) {
				if( $aPer->getUid()== $iPeriodUid){
					$objActualPeriod = $aPer; break;
				}
			}
		}else{
			$jetzt = time();
			foreach( $aObjAllPeriods as $aPer) {
				if( $aPer->getDavorBis()->format('U') <= $jetzt && $aPer->getDanachAb()->format('U') >= $jetzt){
					$objActualPeriod = $aPer; break;
				}
			}
			$iPeriodUid = ($objActualPeriod) ? $objActualPeriod->getUid() : 0;
		}
		return array( $iPeriodUid , $objActualPeriod , $aObjAllPeriods  );
	}
    
	/**
	* transformFieldContents
	*
	* @param string $fieldname
	* @param string $value
	* @return string
	*/
	public function transformFieldContents( $row , $period ){
        $oFeUser = $this->frontendUserRepository->findByUid( $row['plan_teacher'] );
        $oZimmer = $this->zimmerRepository->findByUid( $row['plan_zimmer'] );
        $outFields = array(
				'Wochentag'	=>	'plan_tag', 
				'Zeit_von'	=>	'zeit_ab', 
				'Zeit_bis'	=>	'zeit_bis', 
				'Datum_von'	=>	'plan_start', 
				'Datum_bis'	=>	'plan_ende', 
				'Periodizitaet'	=>	'plan_periodizitaet', 
				'Periode'	=>	$period, 
				'Klasse'	=>	'', 
				'Angebot'	=>	'Klasse', 
				'Fach'	=>	$row['query'] == 'kurs' ? 'fachbezeichnung' : 'fachkurz', 
				'Fachprefix'	=>	'', 
				'Lehrer'	=>	$oFeUser ? $oFeUser->getEcoAcronym():'n.n.', 
				'Gebaeude'	=>	$oZimmer ? $oZimmer->getHaus():'', 
				'Raum'	=>	$oZimmer ? $oZimmer->getZimmer():'', 
				'Anz_Wochenlek'	=> '' 
        );
		foreach($outFields as $fldOut => $fldIn ) {
			if( empty($fldIn) ){
				$outRow[$fldOut] = '';
			}else{
				switch($fldOut){
					case 'Datum_von':
					case 'Datum_bis':
							$outRow[$fldOut] = date( 'dmY' , $row[$fldIn] );
					break;
					case 'Zeit_von':
					case 'Zeit_bis':
							$outRow[$fldOut] = substr( $row[$fldIn] , 0 , 5 );
					break;
					case 'Periode':
					case 'Lehrer':
					case 'Gebaeude':
							$outRow[$fldOut] = $fldIn;
					break;
					case 'Raum':
// 							$outRow[$fldOut] = $outFields['Gebaeude'] . ' ' . $fldIn; FIXME dani 21.9.2018
							$outRow[$fldOut] = $fldIn;
					break;
					default:
					$outRow[$fldOut] = $row[$fldIn];
				}
			}
			if( !isset($tabConf[$fld]) ) $tabConf[$fld] = $z;
		}
		return $outRow;
    }
    
	/**
	* getCourses
	*
	* @param int $foreignTimetable
	* @param int $period
	* @return void
	*/
	public function getCourses( $foreignTimetable , $period){
	    $grpQueryResult = array();
	    $sortFlatQueryResult = array();
	    $flatQueryResult = array();
	    $rawQueryResult = array();
	    $aAnonymous = array( '.nn'=> 1 , 'ref'=>1 );

		// $rawQueryResult['klasse'] = $this->stundenplanRepository->findBySemesterGroupByKlasseTeacherFiltered( $period  );
		$rawQueryResult['kurs'] = $this->stundenplanRepository->findBySemesterGroupByKursregelTeacherFiltered( $period , array('not_fachbereich'=>$this->abuFbUid) );

		foreach($rawQueryResult as $tIx => $qows ) {
			foreach( $qows as $klasseTeacher ){
				$tIdx = $klasseTeacher['plan_teacher'] . '_' . str_replace(' ','_',$klasseTeacher['Klasse']). '_' . $klasseTeacher['subject_id']. '_' .$klasseTeacher['plan_start']. '_' .$klasseTeacher['zeit_ab'] ;
				$flatQueryResult[ $tIdx ] = $klasseTeacher;
				$flatQueryResult[ $tIdx ]['query'] = $tIx;
				$sortArr[ $tIdx ] = $klasseTeacher['plan_start'] . '_' . str_replace(' ','_',$klasseTeacher['Klasse']). '_' .$klasseTeacher['plan_teacher'];
			}
		}
	    
	    if( is_array($sortArr) ){
		  @asort($sortArr);
		  foreach($sortArr as $ix => $six ) {
		      $sortFlatQueryResult[$ix] = $flatQueryResult[$ix];
		  }
	    }
	    
	    if( is_array($sortFlatQueryResult) ){
		  foreach( $sortFlatQueryResult as $klasseTeacher ){
			$idx = $klasseTeacher['plan_teacher'] . '_' . str_replace(' ','_',$klasseTeacher['Klasse']);
			if( isset( $aAnonymous[ $klasseTeacher['username'] ]) ){
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ] = $klasseTeacher;
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ]['anonymous'] = $klasseTeacher['subject_id'];
			      $grpQueryResult[ $idx. '_' . $klasseTeacher['subject_id'] ]['email'] ='';
			}else{
			      $idx .= '_0';
			      if( isset( $grpQueryResult[ $idx ] ) ){
				  $grpQueryResult[ $idx ]['fachbezeichnung'] .= ', '.$klasseTeacher['fachbezeichnung'];
			      }else{
				  $grpQueryResult[ $idx ] = $klasseTeacher;
				  $grpQueryResult[ $idx ]['anonymous'] = 0;
			      }
			}
		  }
	    }
	    return $grpQueryResult;
	}
	
}
