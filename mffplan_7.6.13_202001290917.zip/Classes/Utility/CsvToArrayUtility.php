<?php
namespace Mff\Mffplan\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class CsvToArrayUtility
 */

class CsvToArrayUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* csvOptions
	* gets overwritten later
	*
	* @var array
	*/
	public $csvOptions = array( );

	/**
	 * __construct
	 *
	 * @param array $csv_options
	 * @return void
	 */
	public function __construct( $csv_options = array() ) {
	      if( !count($csv_options) ){
				// read configuration
				$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
				$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
				$allSettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
				$csv_options = $allSettings['plugin.']['tx_mffplan_planimport.']['settings.']['csv_options.'];
	      }
	      $this->csvOptions = $csv_options;
	}

	/**
	 * cmpr_csvFile2array transform a csv-file into an array
	 * translates charcode
	 * removes text-enclosure
	 * removes field-separer
	 * 
	 * part from the extension svconnector_csv
	 * (c) 2008-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
	 *
	 * @param string $uploadDirFile
	 * @return array
	 */
	public function CsvToArray( $uploadDirFile ) {
		$fileData = array();
		$filename = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($uploadDirFile);
		if (!file_exists($filename)) return $fileData;
		$fp = fopen($filename, 'r');
		while ($row = fgetcsv($fp, 0, $this->csvOptions['in_delimiter'])) {
			$fileData[] = $row;
		}
		fclose($fp);
		return $fileData;
	}

	/**
	 * cmpr_csvFile2array transform a csv-file into an array
	 * translates charcode
	 * removes text-enclosure
	 * removes field-separer
	 * 
	 * part from the extension svconnector_csv
	 * (c) 2008-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
	 *
	 * @param string $uploadDirFile
	 * @return array
	 */
	public function encodedCsvToCleanArray( $uploadDirFile ) {
		$fileData = array();
		$filename = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($uploadDirFile);
		if (!file_exists($filename)) return $fileData;
		
		// Force auto-detection of line endings
		ini_set('auto_detect_line_endings', TRUE);

		$parameters =  $this->csvOptions;
		
		// if defined in config set $srcRep for exchanging special chars 
		if (!empty($parameters['ascii_replace'])) {
		      $ascPairs = explode( ',' , $parameters['ascii_replace'] );
		      foreach($ascPairs as $pair){
			  $asciSrc = explode(':' , trim($pair) );
			  $srcRep[ chr($asciSrc[0]) ] = empty($asciSrc[1]) ? '' : chr($asciSrc[1]);
		      }
		}

		// Check if the current (BE) charset is the same as the file encoding
		if (empty($parameters['encoding'])) {
			$isSameCharset = TRUE;
		} else {
			$encoding = $this->getCharsetConverter()->parse_charset($parameters['encoding']);
			$isSameCharset = $this->getCharset() == $encoding;
		}

		// Open the file and read it line by line, already interpreted as CSV data
		$fp = fopen($filename, 'r');
		$delimiter = (empty($parameters['in_delimiter'])) ? ',' : $parameters['in_delimiter'];
		$qualifier = (empty($parameters['text_qualifier'])) ? '"' : $parameters['text_qualifier'];

		// Set locale, if specific locale is defined
		$oldLocale = '';
		if (!empty($parameters['locale'])) {
			// Get the old locale first, in order to restore it later
			$oldLocale = setlocale(LC_ALL, 0);
			setlocale(LC_ALL, $parameters['locale']);
		}

		$isFirstRow = TRUE;
		while ($row = fgetcsv($fp, 0, $delimiter, $qualifier)) {
			// In the first row, remove UTF-8 Byte Order Mark if applicable
			if ($isFirstRow) {
				$byteOrderMark = pack('H*','EFBBBF');
				$row[0] = preg_replace('/^' . $byteOrderMark . '/', '', $row[0]);
				$isFirstRow = FALSE;
			}
			$numData = count($row);
			// If the row is an array with a single NULL entry, it corresponds to a blank line
			// and we want to skip it (see note in http://php.net/manual/en/function.fgetcsv.php#refsect1-function.fgetcsv-returnvalues)
			if ($numData === 1 && current($row) === NULL) {
				continue;
			}
			// exchange special chars if defined
			if( isset($srcRep) ){
			    for ($i = 0; $i < $numData; $i++) {
				    $row[$i] = str_replace( array_keys($srcRep) , $srcRep , $row[$i] );
			    }
			}
			// If the charset of the file is not the same as the BE charset,
			// convert every input to the proper charset
			if (!$isSameCharset) {
				for ($i = 0; $i < $numData; $i++) {
					$row[$i] = $this->getCharsetConverter()->conv($row[$i], $encoding, $this->getCharset());
				}
			}
			$fileData[] = $row;
		}
		fclose($fp);

		// Reset locale, if necessary
		if (!empty($oldLocale)) {
			setlocale(LC_ALL, $oldLocale);
		}
		// Return the result
		return $fileData;
	}
	
	/**
	 * from the extension svconnector_csv
	 * (c) 2008-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
	 *
	 * Gets the currently used character set depending on context.
	 *
	 * Defaults to UTF-8 if information is not available.
	 *
	 * @return string
	 */
	public function getCharset() {
		if (TYPO3_MODE == 'FE') {
			return $GLOBALS['TSFE']->renderCharset;
		} elseif (isset($GLOBALS['LANG'])) {
			return $GLOBALS['LANG']->charSet;
		} else {
			return 'utf-8';
		}
	}

	/**
	 * from the extension svconnector_csv
	 * (c) 2008-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
	 *
	 * Get an existing instance of the charset conversion class, depending on context.
	 *
	 * @throws Exception
	 * @return t3lib_cs
	 */
	public function getCharsetConverter() {
		if (TYPO3_MODE == 'FE') {
			return $GLOBALS['TSFE']->csConvObj;
		} elseif (isset($GLOBALS['LANG'])) {
			return $GLOBALS['LANG']->csConvObj;
		} else {
			throw new Exception(
				sprintf('No charset converter available in the current context (%s)', TYPO3_MODE),
				1396448479
			);
		}
	}
}
