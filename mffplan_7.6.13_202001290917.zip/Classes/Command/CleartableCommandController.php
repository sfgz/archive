<?php
namespace Mff\Mffplan\Command;
use \DateTime;

 /** 
 * Class CleartableCommandController
 * 
 * This Controller protects old Data from getting deleted 
 * by setting the relational-field to empty string
 * 
 */
 
class CleartableCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	public    $extKey = 'mffplan';
	    
	protected $extConf = array(); // Extension configuration
	
	protected $classList = array(); // classList

	/**
	 * Deletes recordsets wich are expired on a specified date in past.
	 *
	 * Prevents the importroutine on deleting expired recordsets.
	 *    If enddate of recordset is in the past then disable the reference-field 
	 *    by inserting an empty string.
	 * 
	 * returns an array with amount of affected recordsets  
	 *
	 * @return array
	 */
	public function execute(){
		
		// get configuration
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$querySettings = $this->getSettings( $objectManager );

		$this->klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
		$this->klasseRepository->setDefaultQuerySettings($querySettings);
		$classRecordsets = $this->klasseRepository->findAll();
		foreach($classRecordsets as $classObj){
		    $this->classList[$classObj->getUid()] = $classObj->getClassShort() ;
		}
		
		// set dateranges
		$actualDate = $this->parseLocalDate( date('Y-m-d') . '23:59:00' );// mktime( 21,59,0, date('m') , date('d') , date('Y') );
		$planRangeDate = mktime( 0,0,0, 1,1, date('Y')-$this->extConf['daterange_stundenplan'] );
		// clean TimetableRepository
		$counter = array();
		$ttRepository = $objectManager->get('Mff\\Mffplan\\Domain\\Repository\\TimetableRepository');
		$ttRepository->setDefaultQuerySettings($querySettings);
		// get all where 'import_index' NOT empty
		if( !empty($this->extConf['classShorts'])  ){
		      $ttRecordsets = $ttRepository->findAll();
		      foreach( $ttRecordsets as $plnRow ){
			  $touchTests = $this->isSetToTouchable( $plnRow ); 
			  if( $touchTests[false]==0 && $touchTests[true] > 0){ // if there are only matching classes, touch this rs
			      $uniqueIndex = $this->createImportIndex( $plnRow ) ;
			      $plnRow->setImportIndex($uniqueIndex); 
			      $ttRepository->update($plnRow);
			      ++$counter['Timetable+']; 
			  }elseif( $plnRow->getImportIndex() != '' ){
			      $plnRow->setImportIndex(''); 
			      $ttRepository->update($plnRow);
			      ++$counter['Timetable.']; 
			  }elseif( $touchTests[true] > 0 ){ // some matching classes where deleted, update this rs, but do not touch
			      ++$counter['Timetable+']; //  ImportIndex is already empty (ImportIndex == '')
			  }
		      }
		}elseif( !empty($this->extConf['period']) ){
		      $ttRecordsets = $ttRepository->findAll();
		      foreach( $ttRecordsets as $plnRow ){
			  $objTtPeriod = $plnRow->getRelPeriod();
			  if( !$objTtPeriod ) continue;
			  if( $plnRow->getRelPeriod()->getUid() == $this->extConf['period'] ){
			      ++$counter['Timetable+']; 
			      $uniqueIndex = $this->createImportIndex( $plnRow ) ;
			      $plnRow->setImportIndex($uniqueIndex); 
			      $ttRepository->update($plnRow);
			  }elseif( $plnRow->getImportIndex() != '' ){
			      $plnRow->setImportIndex(''); 
			      $ttRepository->update($plnRow);
			      ++$counter['Timetable_']; 
			  }
		      }
		}else{
		      $ttRecordsets = $ttRepository->findeDataToClear();
		      foreach( $ttRecordsets as $plnRow ){
			  $plnEnde = $plnRow->getDateEnd()->getTimestamp();
			  if( $planRangeDate > $plnEnde ){ // ends after deletion date: delete it
			      $ttRepository->remove($plnRow); 
			      ++$counter['Timetable-'];
			  }elseif( $actualDate > $plnEnde ){ // old, ends before now. keep it - clear import_index
			      $plnRow->setImportIndex(''); 
			      $ttRepository->update($plnRow);
			      ++$counter['Timetable']; 
			  }
		      }
		}

		if( array_sum($counter) ){
		    $persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
		    $persistenceManager->persistAll();
 		}
		return $counter;
	}
	private function createImportIndex( $plnRow ){
	      $teaObj = $plnRow->getRelTeacher();
	      $dtStart = $plnRow->getDateStart();
	      $dtEnd = $plnRow->getDateEnd();
	      $teacherUid = ($teaObj) ? $teaObj->getUid() : 0;
	      $dateFrom = ($dtStart) ? date( 'dmy' ,$dtStart->getTimestamp() ).'T'.$plnRow->getTimeFrom()  : '' ;
	      $periodicity = $plnRow->getPeriodicity();
	      $dateTo = ($dtEnd) ? date( 'dmy' ,$dtEnd->getTimestamp() ).'T'.$plnRow->getTimeTo()  : '' ;
	      $uniqueIndex = rtrim( rtrim( trim( $teacherUid.'-'.$dateFrom , '-' ) . '-' . $periodicity , '-' ) . '-' . $dateTo , '-' ) ;
	      return $uniqueIndex;
	}
	public function isSetToTouchable( $plnRow ){
		$periodTest = false; // if extConf['period'] is not set, keep all recordsets!
		$classTest = false; // if one class ist not in uploadlist, keep rs. but delete classes in list
		if( !empty($this->extConf['period']) ){
		      $objPeriod = $plnRow->getRelPeriod();
		      if($objPeriod){
			    $periodUid = $objPeriod->getUid();
			    $periodTest = $periodUid == $this->extConf['period'] ? true : false;
		      }
		}
		if(!$periodTest) return array( false=>1 , true=>0 );
		$possibleClasses = array_flip( explode( ',' , $this->extConf['classShorts'] ) );
		$classesRelation = $plnRow->getRelClass();
		$persistsClassTest = array( false=>0 , true=>0 );
		foreach($classesRelation as $classObj){
		// FIXME! $classObj->getUid()
		    $classShortInTtRs = $this->classList[$classObj->getUid()];
		    $isClassTouchable = isset($possibleClasses[$classShortInTtRs]);
		    $persistsClassTest[ $isClassTouchable ] +=1 ;
		    if($isClassTouchable) $plnRow->removeRelClass($classObj); // remove matching class
		}
		if($persistsClassTest[TRUE]) return $persistsClassTest;
		return array( false=>1 , true=>0 ); // if $periodTest failed, do not touch this rs
	}
	public function getExtConf( $key = 'period' ){ return $this->extConf[$key];
	}
	public function setExtConf( $extConf , $overwrite = true){
	      foreach($extConf as $key=>$value){ if( !isset($this->extConf[$key]) || $overwrite ) $this->extConf[$key]=$value;}
	}
	
	/**
	 * reads configuration into property extConf , returns querySettings
	 *
	 * @param object $objectManager 
	 * @return object
	 */
	public function getSettings( $objectManager ){
		$extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);
		$this->setExtConf($extConf , false);

		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storagePid['storagePid'] = $settings['plugin.']['tx_mffplan_planimport.']['persistence.']['storagePid'];
		$storagePid['foreignStoragePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storagePid );

	      return $querySettings;
	}
	
	/**
	 * transforms a given datestring to integer value
	 *
	 * @param string $datevalue A string-formatted Date like 2015-11-26 08:15:00
	 * @return integer
	 */
	public function parseLocalDate($datevalue) {
		$termin = new DateTime( $datevalue );
		$value = $termin->getTimestamp();
		if (!empty($GLOBALS['TYPO3_CONF_VARS']['SYS']['serverTimeZone']) ) {
			$value += $termin->getOffset();
		}
		return $value;
	}
}