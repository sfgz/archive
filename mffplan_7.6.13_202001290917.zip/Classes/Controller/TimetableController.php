<?php
namespace Mff\Mffplan\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * TimetableController
 */
class TimetableController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * timetableRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TimetableRepository
	 * @inject
	 */
	protected $timetableRepository = NULL;

	/**
	 * periodsRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\PeriodsRepository
	 * @inject
	 */
	protected $periodsRepository = NULL;

	/**
	 * teacherRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TeacherRepository
	 * @inject
	 */
	protected $teacherRepository = NULL;

	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		if ($this->request->hasArgument('rangeselect')) {
			$reqPeriod = $this->request->getArgument('rangeselect');
			if (!empty($reqPeriod['relPeriod'])) {
				$period = $reqPeriod['relPeriod'];
			}
		}
		$now = time();
		$toNight = mktime(23, 59, 59, date('m', $now), date('d', $now), date('Y', $now));
		$periodsList = array();
		$periodsRepository = $this->periodsRepository->findAll();
		foreach ($periodsRepository as $peri) {
			$periodDescription = $peri->getSemester();
			$periodUid = $peri->getUid();
			$dateTo = $peri->getDatumBis()->getTimestamp();
			if (empty($period) && $dateTo > $toNight) {
				$period = $periodUid;
			}
			$periodsList[$periodUid] = $periodDescription;
		}
		
		if ($this->request->hasArgument('deleteall')) {
			if (!empty($period)) {
				$this->timetableRepository->deletePeriodFromTimetable($period);
			}
		}
		
		if ($this->request->hasArgument('pagina')) {
			$pagina = $this->request->getArgument('pagina');
		} else {
			$pagina = array('sorting' => array('field' => 'uid', 'order' => 'a'));
		}
		$sort = $this->lst_sortingOptions('tx_mffplan_domain_model_timetable', $pagina['sorting']);
		
		$sortingFields = array($pagina['sorting']['field'] => $pagina['sorting']['order']);
		$filterFields = array('rel_period' => $period);
		
		if (!empty($reqPeriod['download'])) {
			$timetables[$periodsList[$period]] = $this->lst_getTimetableAsXls( $sortingFields , $filterFields );
			$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
			$downloader->downloadAsXls($timetables, 'timetable_' . $periodsList[$period] . '.xlsx');
			return;
		}

		$allRecordsets = $this->timetableRepository->findByGroupOrderedBy($sortingFields, $filterFields, 0);
		$paginator = array(
			'filter' => $filterFields,
			'sorting' => array(
				'field' => $pagina['sorting']['field'],
				'order' => $pagina['sorting']['order']
			),
			'page' => $pagina['page'] ? 0 + $pagina['page'] : 1,
			'range' => $pagina['range'] ? 0 + $pagina['range'] : 20,
			'recordsets' => count($allRecordsets)
		);
		$totalPages = $paginator['range'] > 1 ? ceil($paginator['recordsets'] / $paginator['range']) : 1;
		for ($pagerlist = array(), $z = 1; $z <= $totalPages; ++$z) {
			$pagerlist[$z] = $z;
		}
		
		$timetable = $this->timetableRepository->findByGroupOrderedBy( $sortingFields , $filterFields, $paginator['range'], $paginator['page'], false);
		
		$this->view->assign('periodslist', array('options' => $periodsList, 'selected' => $period));
		$this->view->assign('timetables', $timetable);
		$this->view->assign('paginator', $paginator);
		$this->view->assign('sort', $sort);
		$this->view->assign('pagerlist', $pagerlist);
	}

	/**
	 * sortingOptions
	 *
	 * @param string $fullTableName the db-table to look up
	 * @param array $sorting
	 * @return array
	 */
	public function lst_sortingOptions($fullTableName, $sorting) {
		$additionalFields = 'uid,'; // FIXME dirty hack
		$shownFields = explode(',', $additionalFields.$GLOBALS['TCA'][$fullTableName]['interface']['showRecordFieldList']);
		if (empty($sorting['field'])) {
			$orderField = $GLOBALS['TCA'][$fullTableName]['ctrl']['default_sortby'];
			if (empty($orderField)) {
				$orderField = $GLOBALS['TCA'][$fullTableName]['ctrl']['sortby'];
			}
			$sorting = array('field' => $orderField, 'order' => 'a');
		}
		foreach ($shownFields as $iFld) {
			$field = trim($iFld);
			$sort[$field]['field'] = $field;
			$sort[$field]['order'] = $sorting['field'] == $field && $sorting['order'] == 'a' ? 'd' : 'a';
			$sort['Invert'][$field]['field'] = $field;
			$sort['Invert'][$field]['order'] = $sorting['field'] == $field && $sorting['order'] == 'a' ? 'a' : 'd';
		}
		return $sort;
	}

	/**
	 * getTimetableAsXls
	 *
	 * @param array $sortingFields
	 * @param array $filterFields
	 * @return array
	 */
	public function lst_getTimetableAsXls( $sortingFields , $filterFields ) {
		$TimetableObj = $this->timetableRepository->findByGroupOrderedBy( $sortingFields , $filterFields, 0, 1, false);
		$ttArr = array();
		$liste = $this->lst_getLists();

		foreach($TimetableObj as $tix => $ttRow){
		    $klasse = array();
		    $klsObjs = $ttRow->getRelClass();
		    if($klsObjs) {foreach($klsObjs as $kls){$shrt = $kls->getUid();$klasse[$shrt] = $liste['klassen'][$shrt];}}
		    $zimmer = array();
		    $zmrObjs = $ttRow->getRelRoom();
		    if($zmrObjs) {foreach($zmrObjs as $kls){$shrt = $kls->getUid() ;$zimmer[$shrt] = $liste['zimmer'][$shrt];}}
		    $fach = array();
		    $fchObjs = $ttRow->getRelSubject();
		    if($fchObjs) {foreach($fchObjs as $kls){$shrt = $kls->getUid();$fach[$shrt] = $liste['fach'][$shrt];}}
		    $dtStart = $ttRow->getDateStart();
		    $dtEnd = $ttRow->getDateEnd();
		    $teacher = $ttRow->getRelTeacher();
		    $ttArr[$tix]['weekday']=$ttRow->getWeekday();
		    $ttArr[$tix]['timeFrom'] = $ttRow->getTimeFrom();
		    $ttArr[$tix]['timeTo'] = $ttRow->getTimeTo();
		    $ttArr[$tix]['periodicity']=$ttRow->getPeriodicity();
		    $ttArr[$tix]['dateStart'] = ($dtStart) ? $dtStart->format('d.m.y') : '';
		    $ttArr[$tix]['dateEnd'] = ($dtEnd) ? $dtEnd->format('d.m.y') : '';
		    $ttArr[$tix]['teacher']= ($teacher) ? $teacher->getEcoAcronym() : '';
		    $ttArr[$tix]['zimmer']= implode( ', ' , $zimmer);
		    $ttArr[$tix]['klasse']= implode( ', ' , $klasse);
		    $ttArr[$tix]['fach']= implode( ', ' , $fach);
		    $ttArr[$tix]['bemerkung'] = $ttRow->getNote();
		    $ttArr[$tix]['uid'] = $ttRow->getUid();
		}
		return $ttArr;
	}

	/**
	 * getLists 
	 *
	 * @param array $listen may be empty
	 * @return array
	 */
	public function lst_getLists( $listen = array() ) {
			$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
			$querySettings->setRespectStoragePage(FALSE);

			$klasseRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KlasseRepository');
			$klasseRepository->setDefaultQuerySettings($querySettings);
			$klassenObjs = $klasseRepository->findAll();
			foreach($klassenObjs as $klsRow){
			    $nam = $klsRow->getClassShort();
			    $key = $klsRow->getUid();
			    $listen['klassen'][$key]= $nam;
			}

			$fachRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
			$fachRepository->setDefaultQuerySettings($querySettings);
			$klassenObjs = $fachRepository->findAll();
			foreach($klassenObjs as $klsRow){
			    $nam = $klsRow->getFachkurz();
			    $key = $klsRow->getUid();
			    $listen['fach'][$key]= $nam;
			}

			$zimmerRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\ZimmerRepository');
			$zimmerRepository->setDefaultQuerySettings($querySettings);
			$klassenObjs = $zimmerRepository->findAll();
			foreach($klassenObjs as $klsRow){
			    $nam = $klsRow->getHaus();
			    $nam .= ' ' . $klsRow->getZimmer();
			    $key = $klsRow->getUid();
			    $listen['zimmer'][$key]= $nam;
			}
			return $listen;
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		$teacherlist = $this->teacherRepository->findTeachers();
		$this->view->assign('teacherlist', $teacherlist);
	}

	/**
	 * Initialize  create
	 *
	 * @return void
	 */
	public function initializeCreateAction() {
		$args = $this->arguments['newTimetable']->getPropertyMappingConfiguration();
		$args->forProperty('dateStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		$args->forProperty('dateEnd')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffplan\Domain\Model\Timetable $newTimetable
	 * @return void
	 */
	public function createAction(\Mff\Mffplan\Domain\Model\Timetable $newTimetable) {
		$this->addFlashMessage('The object was created. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->timetableRepository->add($newTimetable);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffplan\Domain\Model\Timetable $timetable
	 * @ignorevalidation $timetable
	 * @return void
	 */
	public function editAction(\Mff\Mffplan\Domain\Model\Timetable $timetable) {
		$teacherlist = array();
		$teacherRepository = $this->teacherRepository->findTeachers();
		foreach ($teacherRepository as $teacher) {
			$isHidden = $teacher->getDisable();
			if ($isHidden) {
				continue;
			}
			$username = $teacher->getUsername();
			$fullname = $teacher->getName();
			$userUid = $teacher->getUid();
			$teacherlist[$userUid] = $fullname;
		}
		$thea = $timetable->getRelTeacher();
		foreach($thea as $t) $tUid = $t->getUid();
		$this->view->assign('teacherlist', array('options' => $teacherlist, 'selected' => $tUid));
		
		$periodsList = array();
		$periodsRepository = $this->periodsRepository->findAll();
		foreach ($periodsRepository as $period) {
			$periodDescription = $period->getSemester();
			$periodUid = $period->getUid();
			$periodsList[$periodUid] = $periodDescription;
		}
		$peri = $timetable->getRelPeriod();
		$this->view->assign('periodslist', array('options' => $periodsList, 'selected' => $peri));
		$this->view->assign('timetable', $timetable);
		$paginatorArguments = $this->request->hasArgument('pagina') ? $this->request->getArgument('pagina') : array();
		$this->view->assign('pagina', $paginatorArguments);
	}

	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
		$args = $this->arguments['timetable']->getPropertyMappingConfiguration();
		$args->forProperty('dateStart')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
		$args->forProperty('dateEnd')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffplan\Domain\Model\Timetable $timetable
	 * @return void
	 */
	public function updateAction(\Mff\Mffplan\Domain\Model\Timetable $timetable) {
		$paginatorArguments = $this->request->hasArgument('pagina') ? array('pagina' => $this->request->getArgument('pagina')) : array();
		if ($this->request->hasArgument('Abort')) {
			return $this->forward('list', NULL, NULL, $paginatorArguments);
		}
		$this->addFlashMessage('The object was updated. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->timetableRepository->update($timetable);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->forward('list', NULL, NULL, $paginatorArguments);
	}

	/**
	 * action delete
	 *
	 * @param \Mff\Mffplan\Domain\Model\Timetable $timetable
	 * @return void
	 */
	public function deleteAction(\Mff\Mffplan\Domain\Model\Timetable $timetable) {
		$paginatorArguments = $this->request->hasArgument('pagina') ? array('pagina' => $this->request->getArgument('pagina')) : array();
		$this->timetableRepository->remove($timetable);
		$this->persistenceManager->persistAll();
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->addFlashMessage('The object was deleted, cache for page ' . $GLOBALS['TSFE']->id . ' cleared.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->forward('list', NULL, NULL, $paginatorArguments);
	}

}