<?php
namespace Mff\Mffplan\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * AnalyseController
 */
class AnalyseController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * timetableRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TimetableRepository
	 * @inject
	 */
	protected $timetableRepository = NULL;

	/**
	 * teacherRepository
	 *
	 * @var \Mff\Mffplan\Domain\Repository\TeacherRepository
	 * @inject
	 */
	protected $teacherRepository = NULL;
	
	
	/**
	 * action conflicts
	 *
	 * @return void
	 */
	public function conflictsAction() {
		$helper = new \Mff\Mffplan\Utility\AnalyseUtility( $this->settings );
		$rCtrl = new \Mff\Mffplan\Controller\RulesController();
		$rCtrl->initializeAction();
		$rCtrl->initializeCompareAction();

		$uploadDir   = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
		$downloadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['processedpath'] , '/' ) . '/';
		
		$inVars = $this->request->hasArgument($this->settings['formname']) ? $this->request->getArgument($this->settings['formname']) : array('importoption'=>array('clearclass'=>1));
		$readActions = $this->request->hasArgument('read') ? $this->request->getArgument('read') : array();

		// UPLOAD file
		$uploadOk = $rCtrl->cmpr_uploadCsvFile( $uploadDir  );
		if($uploadOk) $this->addFlashMessage('Die Datei '.pathinfo($uploadOk,PATHINFO_BASENAME).' wurde hochgeladen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		
		// DELETE file
		if($this->request->hasArgument('delete')) {
			$fileNameToUnlink = $this->request->getArgument('delete');
			@unlink($uploadDir.$fileNameToUnlink);
			$this->addFlashMessage('Die Datei '.$fileNameToUnlink.' wurde geloescht.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}

		// get filelist, prepare for checkboxes
		if($uploadOk) {
		    $dateiliste = $rCtrl->cmpr_getFileList($uploadDir , array() );
		    $dateiliste[pathinfo($uploadOk , PATHINFO_FILENAME)]['checked'] = 'checked';
		}else{
		    $dateiliste = $rCtrl->cmpr_getFileList($uploadDir , $inVars['fileselect'] );
		}
		foreach( $dateiliste as $rootName=>$file ) if($file['checked']) $chkdFilesList[$rootName] = $file;
		
		// if checkMissingSources results with missingSources
		// actions from button [create_fach] and [create_class]
		if( isset( $readActions['create_fach'] ) ){
		    $rCtrl->edit_createFach( trim($readActions['create_fach']) );
		}elseif( isset( $readActions['create_class'] ) ){
		    $rCtrl->edit_createKlasse( trim($readActions['create_class']) );
		}elseif($uploadOk || ($this->request->hasArgument('ok') && count($chkdFilesList)) ) {
		    $sortTables = $rCtrl->cmpr_readAndRuleOnUploadedFile( $dateiliste );
		    $this->addFlashMessage('Die Datei wurde eingelesen.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}
		
		// fill array $sortTables for output
		$sortTables = $rCtrl->cmpr_readProcessedFiles( $downloadDir );
		if(is_array($sortTables['csv_error'])) foreach($sortTables['csv_error'] as $ix => $ic) $checkAll['error'][$ix] = $ix;
 		$sortTables = $rCtrl->cmpr_moveAngebotToFach( $sortTables , $checkAll );
 		$sortTables = $rCtrl->cmpr_addToImportFile( $sortTables , $checkAll );
		$sortTables = $helper->checkMissingSources( $sortTables );
		
		// actions from button [view_conflicts]
		if( isset( $readActions['view_conflicts'] )  ){
		    $sortTables = $helper->evalConflicts( $sortTables , $inVars['conflicttypes'] , $inVars['exclude'] );
		    $inVars['ausgabeformat']=4;
		}else{
		    $inVars['ausgabeformat']=2;
		}
		
		if($readActions['downloadXls']){
		    $result = $helper->downloadConflictsAsXls( $sortTables , $inVars['exclude'] );
		    $inVars['ausgabeformat']=4;
		}
		
		$this->view->assign('formname', $this->settings['formname']);
		$this->view->assign('dateiname', $uploadOk);
		$this->view->assign('ausgabeformat', $inVars['ausgabeformat'] );
		$this->view->assign('dateiliste', $dateiliste);
		$this->view->assign('selDateiliste', $chkdFilesList);
		$this->view->assign('tabellen', $sortTables);
		$this->view->assign('conflicttypes', isset($inVars['conflicttypes']) ? $inVars['conflicttypes'] : array());
		$this->view->assign('exclude', isset($inVars['exclude']) ? $inVars['exclude'] : array());
	}

	/**
	 * action saldi
	 *
	 * @return void
	 */
	public function saldiAction() {
		$rCtrl = new \Mff\Mffplan\Controller\RulesController();
		$fileNames = $this->settings['filenames'];//array( 'csv_error'=>'errors.csv' , 'csv'=>'verarbeitet.csv' );
		$uploadDir = rtrim( PATH_site , '/' ) . '/' . rtrim( $this->settings['uploadpath'] , '/' ) . '/';
		$downloadDir  = rtrim( PATH_site , '/' ) . '/' .rtrim( $this->settings['processedpath'] , '/' ) . '/';
		
		$inVars = $this->request->hasArgument($this->settings['formname']) ? $this->request->getArgument($this->settings['formname']) : array('importoption'=>array('clearclass'=>1));
		$readActions = $this->request->hasArgument('read') ? $this->request->getArgument('read') : array();
		
		
		// fill array $sortTables for output
		$sortTables = array();
		$sortTables = $rCtrl->cmpr_readProcessedFiles( $downloadDir );
		
		
		if( count( $readActions )  ){
		    $inVars['ausgabeformat']=3;
		}
		
		$this->view->assign('formname', $this->settings['formname']);
		$this->view->assign('ausgabeformat', isset($inVars['ausgabeformat']) ? $inVars['ausgabeformat'] : 0 );
		$this->view->assign('tabellen', $sortTables);
	}


}