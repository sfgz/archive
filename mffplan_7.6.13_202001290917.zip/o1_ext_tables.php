<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'Planimport',
	'Planimport'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'Mff Stundenplan');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_rules', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_rules.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffplan_domain_model_rules');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_timetable', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_timetable.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffplan_domain_model_timetable');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_mffplan_domain_model_periods', 'EXT:mffplan/Resources/Private/Language/locallang_csh_tx_mffplan_domain_model_periods.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_mffplan_domain_model_periods');
