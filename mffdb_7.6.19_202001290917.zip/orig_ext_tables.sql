#
# Table structure for table 'tx_mffdb_domain_model_fachbereich'
#
CREATE TABLE tx_mffdb_domain_model_fachbereich (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fachbereichname varchar(255) DEFAULT '' NOT NULL,
	cloud_key varchar(255) DEFAULT '' NOT NULL,
	hide_public tinyint(1) unsigned DEFAULT '0' NOT NULL,
	long_subject tinyint(1) unsigned DEFAULT '0' NOT NULL,
	fb_kurzklassen int(11) unsigned DEFAULT '0' NOT NULL,
	fb_kursregeln int(11) unsigned DEFAULT '0' NOT NULL,
	fb_teachers int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffdb_domain_model_kurzklasse'
#
CREATE TABLE tx_mffdb_domain_model_kurzklasse (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fachbereich int(11) unsigned DEFAULT '0' NOT NULL,

	kurzbezeichnung varchar(255) DEFAULT '' NOT NULL,
	krz_cloudquota int(11) unsigned DEFAULT '0',
	krz_klassen int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY fachbereich (fachbereich),
	KEY krz_cloudquota (krz_cloudquota),

);

#
# Table structure for table 'tx_mffdb_domain_model_cloudquota'
#
CREATE TABLE tx_mffdb_domain_model_cloudquota (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	bezeichnung varchar(255) DEFAULT '' NOT NULL,
	speicherplatz varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffdb_domain_model_fach'
#
CREATE TABLE tx_mffdb_domain_model_fach (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fachbezeichnung varchar(255) DEFAULT '' NOT NULL,
	fachkurz varchar(255) DEFAULT '' NOT NULL,
	subject_id varchar(255) DEFAULT '' NOT NULL,
	fach_kursregel int(11) unsigned DEFAULT '0',
	fach_kurse int(11) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY fach_kursregel (fach_kursregel),

);

#
# Table structure for table 'tx_mffdb_domain_model_kursregel'
#
CREATE TABLE tx_mffdb_domain_model_kursregel (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fachbereich int(11) unsigned DEFAULT '0' NOT NULL,

	regelname varchar(255) DEFAULT '' NOT NULL,
	wert_ab varchar(255) DEFAULT '' NOT NULL,
	wert_bis int(11) DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	sorting int(11) DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY fachbereich (fachbereich),

);

#
# Table structure for table 'tx_mffdb_domain_model_klasse'
#
CREATE TABLE tx_mffdb_domain_model_klasse (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kurzklasse int(11) unsigned DEFAULT '0' NOT NULL,

	class_short varchar(255) DEFAULT '' NOT NULL,
	klassenname varchar(255) DEFAULT '' NOT NULL,
	klasse_kurz varchar(255) DEFAULT '' NOT NULL,
	klasse_jahr int(11) DEFAULT '0' NOT NULL,
	klasse_zug varchar(255) DEFAULT '' NOT NULL,
	klasse_start int(11) DEFAULT '0' NOT NULL,
	klasse_ende int(11) DEFAULT '0' NOT NULL,
	department_id int(11) DEFAULT '0' NOT NULL,
	classteacher_id int(11) DEFAULT '0' NOT NULL,
	class_id varchar(255) DEFAULT '' NOT NULL,
	ref_class_id varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY kurzklasse (kurzklasse),

);

#
# Table structure for table 'tx_mffdb_domain_model_kurs'
#
CREATE TABLE tx_mffdb_domain_model_kurs (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fach int(11) unsigned DEFAULT '0' NOT NULL,

	course_id varchar(255) DEFAULT '' NOT NULL,
	kurs_start int(11) DEFAULT '0' NOT NULL,
	kurs_ende int(11) DEFAULT '0' NOT NULL,
	department_id int(11) DEFAULT '0' NOT NULL,
	course_short varchar(255) DEFAULT '' NOT NULL,
	kurse_klassen int(11) unsigned DEFAULT '0' NOT NULL,
	kurs_plaene int(11) unsigned DEFAULT '0' NOT NULL,
	ref_course_id varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY fach (fach),

);

#
# Table structure for table 'tx_mffdb_domain_model_zimmer'
#
CREATE TABLE tx_mffdb_domain_model_zimmer (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	zimmer varchar(255) DEFAULT '' NOT NULL,
	haus varchar(255) DEFAULT '' NOT NULL,
	besonderes text NOT NULL,
	telefon varchar(255) DEFAULT '' NOT NULL,
	preise varchar(255) DEFAULT '' NOT NULL,
	ausschliessen tinyint(1) unsigned DEFAULT '0' NOT NULL,
	location_id varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffdb_domain_model_stundenplan'
#
CREATE TABLE tx_mffdb_domain_model_stundenplan (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	kurs int(11) unsigned DEFAULT '0' NOT NULL,

	timetable_id varchar(255) DEFAULT '' NOT NULL,
	plan_start int(11) DEFAULT '0' NOT NULL,
	plan_ende int(11) DEFAULT '0' NOT NULL,
	plan_tag int(11) DEFAULT '0' NOT NULL,
	plan_periodizitaet int(11) DEFAULT '0' NOT NULL,
	zeit_ab varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	bemerkung varchar(255) DEFAULT '' NOT NULL,
	plan_zimmer int(11) unsigned DEFAULT '0',
	plan_teacher int(11) unsigned DEFAULT '0',
	ref_timetable_id varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY kurs (kurs),
	KEY plan_teacher (plan_teacher),
	KEY plan_zimmer (plan_zimmer),

);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (

	eco_acronym varchar(255) DEFAULT '' NOT NULL,
	eco_key varchar(255) DEFAULT '' NOT NULL,
	eco_klasse int(11) unsigned DEFAULT '0',

	tx_extbase_type varchar(255) DEFAULT '' NOT NULL,

	KEY eco_klasse (eco_klasse),
);

#
# Table structure for table 'tx_mffdb_domain_model_teacherrelation'
#
CREATE TABLE tx_mffdb_domain_model_teacherrelation (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	fachbereich int(11) unsigned DEFAULT '0' NOT NULL,

	leiter tinyint(1) unsigned DEFAULT '0' NOT NULL,
	auto_reference varchar(255) DEFAULT '' NOT NULL,
	tea_ecouser int(11) unsigned DEFAULT '0',

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	hidden tinyint(4) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY fachbereich (fachbereich),
	KEY tea_ecouser (tea_ecouser),

);

#
# Table structure for table 'tx_mffdb_domain_model_kalender'
#
CREATE TABLE tx_mffdb_domain_model_kalender (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	ferientext varchar(255) DEFAULT '' NOT NULL,
	beginn int(11) DEFAULT '0' NOT NULL,
	ende int(11) DEFAULT '0' NOT NULL,
	code varchar(255) DEFAULT '' NOT NULL,
	semestergrenze tinyint(1) unsigned DEFAULT '0' NOT NULL,
	privat tinyint(1) unsigned DEFAULT '0' NOT NULL,
	ganztag tinyint(1) unsigned DEFAULT '0' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,

	PRIMARY KEY (uid),
	KEY parent (pid),

);

#
# Table structure for table 'tx_mffdb_domain_model_kurzklasse'
#
CREATE TABLE tx_mffdb_domain_model_kurzklasse (

	fachbereich  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_domain_model_teacherrelation'
#
CREATE TABLE tx_mffdb_domain_model_teacherrelation (

	fachbereich  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_domain_model_kursregel'
#
CREATE TABLE tx_mffdb_domain_model_kursregel (

	fachbereich  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_domain_model_klasse'
#
CREATE TABLE tx_mffdb_domain_model_klasse (

	kurzklasse  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_domain_model_kurs'
#
CREATE TABLE tx_mffdb_domain_model_kurs (

	fach  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_domain_model_stundenplan'
#
CREATE TABLE tx_mffdb_domain_model_stundenplan (

	kurs  int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_mffdb_kurs_klasse_mm'
#
CREATE TABLE tx_mffdb_kurs_klasse_mm (
	uid_local int(11) unsigned DEFAULT '0' NOT NULL,
	uid_foreign int(11) unsigned DEFAULT '0' NOT NULL,
	sorting int(11) unsigned DEFAULT '0' NOT NULL,
	sorting_foreign int(11) unsigned DEFAULT '0' NOT NULL,

	KEY uid_local (uid_local),
	KEY uid_foreign (uid_foreign)
);
