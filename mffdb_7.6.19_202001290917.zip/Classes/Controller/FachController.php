<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * FachController
 */
class FachController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 * @inject
	 */
	protected $fachRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		$faches = $this->fachRepository->findAll();
		if ($this->request->hasArgument('download')) {
			$aFach = array();
			foreach( $faches as $ix => $fch ){
			      $aFach[$ix] = array(
				  'FachBezeichnung' => $fch->getFachbezeichnung(),
				  'FachKurz' => $fch->getFachkurz(),
				  'FerienIgnorieren' => $fch->getIgnoreVacation() ? 1 : '',
				  'SubjectID' => $fch->getSubjectId()
			      );
			}
			$downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
			$downloader->downloadAsXls( array( 'faecher'=>$aFach ) , 'fachListe_' . date('ymd_Hi') . '.xlsx');
			return;
		}
		$this->view->assign('faches', $faches);
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fach $fach
	 * @ignorevalidation $fach
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\Fach $fach) {
		$this->view->assign('fach', $fach);
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\Fach $fach
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\Fach $fach) {
		$this->addFlashMessage('The object was updated. Please be aware that this action is publicly accessible unless you implement an access check. See <a href="http://wiki.typo3.org/T3Doc/Extension_Builder/Using_the_Extension_Builder#1._Model_the_domain" target="_blank">Wiki</a>', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->fachRepository->update($fach);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->forward('edit', NULL, NULL, array('fach' => $fach));
	}

}