<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * KurzklasseController
 */
class KurzklasseController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * kurzklasseRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KurzklasseRepository
	 * @inject
	 */
	public $kurzklasseRepository = NULL;
	
	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 * @inject
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * cloudquotaRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\CloudquotaRepository
	 * @inject
	 */
	public $cloudquotaRepository = NULL;

	/**
	 * userRepository
	 *
	 * @var Mff\Mffdb\Domain\Repository\EcouserRepository
	 * @inject
	 */
	protected $userRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function initializeAction() {
		/** get PID where users are stored from Extension mff_import **/
		//$extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);
		
		/** @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings */
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');

		//$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		
		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$extConf['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
		$extConf['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		  
		$usersPids = array( $extConf['studentPid'] , $extConf['teacherPid'] );
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds( $usersPids );
		$this->userRepository->setDefaultQuerySettings($querySettings);
	}
	public function listAction() {
		$kurzklasses = $this->kurzklasseRepository->findAllOrderByKurzbezeichnung();
		$quotaSum = 0;
		$classUser = array();
		$studArr = $this->readStudents();
		foreach($kurzklasses as $kurzklasse){
			$kUid = $kurzklasse->getUid();
			$classUser[$kUid] = $this->readClassStudents($kurzklasse,$studArr);
			$classUser[$kUid]['uid'] = $kUid;
			$quotaSum += $classUser[$kUid]['summary'];
		}
		$fachbereiche = $this->fachbereichRepository->findAll();
		
		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();
		if( isset($rawGetArguments['tx_mffdb_fbv']['download']) ){
		    foreach( $fachbereiche as $fbUid=>$fb ) {
			$fbNameByUid[ $fb->getUid() ]['bez'] = $fb->getFachbereichname();
			$fbNameByUid[ $fb->getUid() ]['srt'] = $fb->getSorting();
		    }
		    foreach( $kurzklasses as $kurzklasseUid=>$kurzklasse ) {
			      $kUid=$kurzklasse->getUid();
			      $fbUid=$kurzklasse->getFachbereich();
			      $krzCloudquota=$kurzklasse->getKrzCloudquota();
			      if( empty($krzCloudquota) ){
				  $Speicherplatz = '';
			      }else{
				  $Speicherplatz = $krzCloudquota->getSpeicherplatz();
// 				  foreach($krzCloudquota as $quot){
// 				      if($quot){$Speicherplatz = $quot->getSpeicherplatz();break;}
// 				  }
			      }
			      $xlsData['kurzklasse'][$kurzklasseUid]['uid']=$kUid;
			      $xlsData['kurzklasse'][$kurzklasseUid]['kurzbezeichnung']=$kurzklasse->getKurzbezeichnung();
			      $xlsData['kurzklasse'][$kurzklasseUid]['klassennamen']=$kurzklasse->getKlassennamen();
			      $xlsData['kurzklasse'][$kurzklasseUid]['fbNr']=$fbUid;
			      $xlsData['kurzklasse'][$kurzklasseUid]['fbSort']=$fbNameByUid[$fbUid]['srt'];
			      $xlsData['kurzklasse'][$kurzklasseUid]['fachbereich']=$fbNameByUid[$fbUid]['bez'];
			      $xlsData['kurzklasse'][$kurzklasseUid]['quota']=$Speicherplatz;
			      $xlsData['kurzklasse'][$kurzklasseUid]['lernende']=$classUser[$kUid]['students'];
			      $xlsData['kurzklasse'][$kurzklasseUid]['summeGB']=$classUser[$kUid]['summary'];
		    }
		    $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
		    $downloader->downloadAsXls( $xlsData , 'kurzklassen.xlsx' );
		}
		
		$this->view->assign('quotaSum', $quotaSum);
		$this->view->assign('classUser', $classUser);
		$this->view->assign('kurzklasses', $kurzklasses);
		$this->view->assign('fachbereiche', $fachbereiche);
		$this->view->assign('settings', $this->settings );
		
// 		Inserts klassennamen in Kurzklasse, run this script only once
// 		foreach($kurzklasses as $kurzklasse){
// 			$classes = $kurzklasse->getKrzKlassen();
// 			foreach($classes as $kls){
// 			    $klassenname = $kls->getKlassenname();
// 			    if(!empty($klassenname)){
// 				$kurzklasse->setKlassennamen( $klassenname );
// 				$this->kurzklasseRepository->update( $kurzklasse );
// 				break;
// 			    }
// 			}
// 		}
// 		$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
// 		$persistenceManager->persistAll();
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $newKurzklasse
	 * @return void
	 */
	public function createAction(\Mff\Mffdb\Domain\Model\Kurzklasse $newKurzklasse) {
		$this->addFlashMessage('The object was created. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->kurzklasseRepository->add($newKurzklasse);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse
	 * @ignorevalidation $kurzklasse
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse) {
		$cloudquota = $this->cloudquotaRepository->findAll();
 		$kurzklassen = $this->kurzklasseRepository->findAllOrderByKurzbezeichnung();
 		$fachbereich = $this->fachbereichRepository->findAll();
		$studArr = $this->readStudents();
		$classUser = $this->readClassStudents($kurzklasse,$studArr);
		$this->view->assign('classuser', $classUser);
 		$this->view->assign('fachbereich', $fachbereich);
 		$this->view->assign('kurzklassen', $kurzklassen);
		$this->view->assign('cloudquota', $cloudquota);
		$this->view->assign('kurzklasse', $kurzklasse);
		$this->view->assign('cloudquotaPid', $this->settings['cloudquotaPid'] );
	}
	
	/**
	 *  readClassStudents
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse
	 * @param array $studArr
	 * @return array
	 */
	private function readClassStudents(\Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse,$studArr){
	    $KurzklasseArr = array();
	    $studSum = 0;
	    $klassen = $kurzklasse->getKrzKlassen();
	    $quota = $kurzklasse->krzCloudquota->speicherplatz;
	    foreach($klassen as $klasse){
		  $cUid = $klasse->getUid();
		  $KurzklasseArr[$cUid]['uid'] = $cUid;
		  $KurzklasseArr[$cUid]['classShort'] = $klasse->getClassShort();
		  $KurzklasseArr[$cUid]['klassenname'] = $klasse->getKlassenname();
		  $KurzklasseArr[$cUid]['klasseEnde'] = $klasse->getKlasseEnde();
		  $KurzklasseArr[$cUid]['classId'] = $klasse->getClassId();
		  $KurzklasseArr[$cUid]['departmentId'] = $klasse->getDepartmentId();
		  $KurzklasseArr[$cUid]['studcount'] = count($studArr[$cUid]);
		  $studSum += $KurzklasseArr[$cUid]['studcount'];
	    }
	    return array( 'summary'=>($quota * $studSum),'students'=>$studSum,'details'=>$KurzklasseArr);
	}
	
	private function readStudents(){
	    $ecouser = $this->userRepository->findAll();
	    $studArr = array();
	    foreach($ecouser as $user){
		$klsObj = $user->getEcoKlasse();
		if(!$klsObj)continue;
		$classUid = $klsObj->getUid();
		if(!$classUid)continue;
		$userUid = $user->getUid();
		if(!$userUid)continue;
//		$studArr[$classUid][$userUid] = $user->getUsername();
		$studArr[$classUid][$userUid] = $userUid;
	    }
	    return $studArr;
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\Kurzklasse $kurzklasse) {
		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
		if( isset($rawGetArguments['tx_mffdb_fbv']['abort']) ) {
		    $this->redirect('list');
		    return;
		}
		$this->addFlashMessage('The object was updated. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		$this->kurzklasseRepository->update($kurzklasse);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		if( isset($rawGetArguments['tx_mffdb_fbv']['save']) ) {
		    $this->redirect('edit', NULL, NULL, array('kurzklasse' => $kurzklasse));
		}else{
		    $this->redirect('list');
		}
	}

}