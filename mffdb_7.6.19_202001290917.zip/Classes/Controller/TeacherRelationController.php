<?php
namespace Mff\Mffdb\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * TeacherRelationController
 */
class TeacherRelationController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * fachbereichRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachbereichRepository
	 * @inject
	 */
	protected $fachbereichRepository = NULL;

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 * @inject
	 */
	protected $fachRepository = NULL;

	/**
	 * teacherRelationRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\TeacherRelationRepository
	 * @inject
	 */
	protected $teacherRelationRepository = NULL;

	/**
	 * ecouserRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\EcouserRepository
	 * @inject
	 */
	protected $ecouserRepository = NULL;

	/**
	 * stundenplanRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\StundenplanRepository
	 * @inject
	 */
	protected $stundenplanRepository = NULL;

	/**
	 * kursRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KursRepository
	 * @inject
	 */
	protected $kursRepository = NULL;

	/**
	 * klasseRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KlasseRepository
	 * @inject
	 */
	protected $klasseRepository = NULL;

	/**
	 * kurzklasseRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KurzklasseRepository
	 * @inject
	 */
	protected $kurzklasseRepository = NULL;

	/**
	 * action list
	 *
	 * @return void
	 */

	 public function initializeAction() {
		/** get PIDs where users are stored from plugin tx_mffdb_fbv **/
		/** set PIDs for ecouserRepository **/
		
		/** @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings */
		$querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');

		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$pidArr['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
		$pidArr['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		  
		$querySettings->setRespectStoragePage(TRUE);
		$querySettings->setStoragePageIds( $pidArr );
		$this->ecouserRepository->setDefaultQuerySettings($querySettings);
	}

	public function listAction() {
		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_GET();
		$rawPostArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
		if( isset($rawGetArguments['tx_mffdb_fbv']['download']) ){
		    $GPvar = $rawGetArguments['tx_mffdb_fbv']['download'];
		}elseif( !isset($rawPostArguments['tx_mffdb_fbv']) && isset($rawGetArguments) ){
		    $GPvar = $rawGetArguments['tx_mffdb_fbv'];
		}else{
		    $GPvar = $rawPostArguments['tx_mffdb_fbv'];
		}
		
		if( !isset($GPvar['days_past']) ){
		    $GPvar['days_past'] = 457;
		}elseif( empty($GPvar['days_past']) ) {
		    $GPvar['days_past'] = 0;
		}
		
		if($GPvar['create_relations']) {
		    $this->createTeacherRelations($GPvar);
		}elseif($GPvar['delete_relations']) {
		    $schedulerTask = new \Mff\MffImport\Command\TeacherrelationsCommandController();
		    $deleteResult = $schedulerTask->deleteAutoRelations();
		    $this->addFlashMessage('Alle automatisch erstellten Lehrperson-Fachbereich Beziehungen wurden geloescht. ' . date('d.m.y H:i')   , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}elseif( is_array($rawGetArguments['tx_mffdb_fbv']) ) { 
		    $this->addTeacherRelation($rawGetArguments['tx_mffdb_fbv']);
		    $this->toggleHiddenTeacher($rawGetArguments['tx_mffdb_fbv']);
		}
		
		if( isset($rawGetArguments['tx_mffdb_fbv']['download']) ){
		    $registerTabs = array( 
			0=>'nur mit Beziehungen' , 
			3=>'nur erfasste Beziehungen' , 
			4=>'nur errechnete Beziehungen' , 
			1=>'nur ohne Beziehungen' , 
			2=>'alle' 
		    );
		    foreach( $registerTabs as $tabNr=>$tabName ) {
			$GPvar['empty_names'] = $tabNr;
			$teacherRelation = $this->assembleComputedTeacherRelations( $GPvar );
			foreach( $teacherRelation as $teacherUid=>$fbteachers ) {
			    foreach( $fbteachers as $fachbereichKey=>$teacherRelation ) {
				  $xlsData[$tabName][$teacherUid.'_'.$fachbereichKey]=$teacherRelation;
			    }
			}
		    }
		    $downloader = new \Mff\Mffdb\Utility\ArrayToXlsUtility();
		    $downloader->downloadAsXls( $xlsData , 'teacherRelations.xlsx' );
		}else{
		
		$teacherRelation = $this->assembleComputedTeacherRelations( $GPvar );
		
		}
		$this->view->assign('tx_mffdb_fbv', $GPvar );
		$this->view->assign('fachbereiche', $teacherRelation );

	}
	
	/**
	 * createTeacherRelations
	 *
	 * @return void
	 */
	public function createTeacherRelations( $GPvar ) {
		$schedulerTask = new \Mff\MffImport\Command\TeacherrelationsCommandController();
		$teacherRelation = $schedulerTask->evaluateTeacherRelations($GPvar['days_past']  );
		$createResult = $schedulerTask->createAutoRelations( $teacherRelation );
		$this->addFlashMessage('Beziehungen aus den letzten '.$GPvar['days_past'].' Tagen errechnet und erstellt. ' . date('d.m.y H:i')   , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		return true;
	}

	public function assembleComputedTeacherRelations( $GPvar ) {
		$teacherRelation = array();
		$outRow = array();
		
		// sample the original teacherRelation records in array $teacherRelation[ teacherUsername ][ fachbereichNr ]
		$teaRelRepository = $this->teacherRelationRepository->getTeachersFachbereich( 'AllTeachersRelations'  );
		foreach($teaRelRepository as $row) $teacherRelation[$row['username']][empty($row['fachbereichNr']) ? 0 : $row['fachbereichNr']] = $row;

		$schedulerTask = new \Mff\MffImport\Command\TeacherrelationsCommandController();
		$teacherRelation = $schedulerTask->evaluateTeacherRelations($GPvar['days_past'] , $teacherRelation );

		// outputs filtered or sorted data in array $outRow[ user-uid ][ fachbereich-uid ][ fieldnames ] = values
		if( $GPvar['empty_names'] == 1 ){ // pick out only the names without corresponding recordsets in Fachbereich
		    foreach($teacherRelation as $username => $nameRow){
			  if( is_array($teacherRelation[$username][0]) ) $outRow[ $teacherRelation[$username][0]['plan_teacher'] ][ 0 ] = $teacherRelation[$username][0];
		    }
		}else{ // sort teachers recordsets by fachbereich for output 2=all 0=only with relation 3=only real 4=only eval
		    $sortFachbereich = $this->teacherRelationRepository->getTeachersFachbereich( 'sortFachbereich'  );
		    foreach($teacherRelation as $username => $nameRow){
			  foreach($sortFachbereich as $row){
			      if( !is_array($teacherRelation[$username][$row['uid']]) ) continue;
			      if(
				    ( $GPvar['empty_names'] == 3 && !empty($teacherRelation[$username][$row['uid']]['relationUid']) ) ||
				    ( $GPvar['empty_names'] == 4 && empty($teacherRelation[$username][$row['uid']]['relationUid']) ) ||
				    $GPvar['empty_names'] < 3
			      ) $outRow[ $teacherRelation[$username][$row['uid']]['plan_teacher'] ][ $row['uid'] ] = $teacherRelation[$username][$row['uid']];
			  }
			  if( $GPvar['empty_names'] == 2 && is_array($teacherRelation[$username][0]) ) $outRow[ $teacherRelation[$username][0]['plan_teacher'] ][ 0 ] = $teacherRelation[$username][0];
		    }
		}
		return $outRow;
	}

	public function addTeacherRelation($fbvGetArguments ) {
		$addTeacher = 0;
		if( !empty($fbvGetArguments['teacher_add']) ) { 
		    $aTeacher = explode( '.' , $fbvGetArguments['teacher_add'] );
		    $edTeacher = $aTeacher[1];
			$newTeacherUser = $this->ecouserRepository->findByUid($edTeacher);
			    $newCode = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Mff\Mffdb\Domain\Model\TeacherRelation');
			    $newCode->setFachbereich($aTeacher[0]);
			    $newCode->setTeaEcouser( $newTeacherUser );
			    $this->teacherRelationRepository->add($newCode);
			    $change[] = ' '. $edTeacher . ' zum Fachbereich hinzugef&uuml;gt';
		}elseif( !empty($fbvGetArguments['teacher_del']) ) {  
		    $edTeacher = $fbvGetArguments['teacher_del'];
		    $fbTeachers = $this->teacherRelationRepository->findeByUid( $edTeacher , TRUE );
		    foreach( $fbTeachers as $teacher ){
			    $this->teacherRelationRepository->remove($teacher);
			    $change[] = ' '. $edTeacher . ' aus Fachbereich entfernt';
		    }
		}
		if(!empty($edTeacher)) {
		    if(count($change)) {
			$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
			$persistenceManager->persistAll();
			$this->addFlashMessage('&Auml;nderung an den Lehrpersonen des Fachbereichs wurde gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		    }else{
			$this->addFlashMessage('Da ging was schief - &Auml;nderung nicht gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
		
	}

	public function toggleHiddenTeacher($fbvGetArguments ) {
		$hideUserNr = 0;
		$hideTeacherNr = 0;
		$aStatusText = array( false=>'angezeigt' , true=>'versteckt' );
		$change = array();
		if( !empty($fbvGetArguments['user_hide']) ) { 
		    $uHidden = TRUE;
		    $hideUserNr = $fbvGetArguments['user_hide'];
		}elseif( !empty($fbvGetArguments['user_unhide']) ) {  
		    $uHidden = FALSE; 
		    $hideUserNr = $fbvGetArguments['user_unhide'];
		}
		if( !empty($hideUserNr) ){
		    // hide/unhide user from fe_user
		    $fbTeachers = $this->ecouserRepository->findeByUid( $hideUserNr );
		    foreach( $fbTeachers as $teacher ){
			    $teacher->setDisable( $uHidden );
			    $this->ecouserRepository->update($teacher);
			    $change[] = ' '. $hideUserNr . ' wird  ' . $aStatusText[ $uHidden ];
		    }
		}
		
		if( !empty($fbvGetArguments['teacher_hide']) ) { 
		    $bHidden = TRUE;
		    $hideTeacherNr = $fbvGetArguments['teacher_hide'];
		}elseif( !empty($fbvGetArguments['teacher_unhide']) ) {  
		    $bHidden = FALSE; 
		    $hideTeacherNr = $fbvGetArguments['teacher_unhide'];
		}
		if( !empty($hideTeacherNr) ){
		    // hide/unhide user from teacherRelation
		    $change = array();
//		    $teacher = $this->teacherRelationRepository->findByUid( $hideTeacherNr );
 		    $fbTeachers = $this->teacherRelationRepository->findeByUid( $hideTeacherNr );
 		    foreach( $fbTeachers as $teacher ){
			$teacherRelationId = $teacher->getUid();
			if( $teacherRelationId == $hideTeacherNr ){
			    $teacher->setHidden( $bHidden );
			    $this->teacherRelationRepository->update($teacher);
			    $change[] = ' '. $hideTeacherNr . ' wird fuer Fachbereich ' . $aStatusText[ $bHidden ];
			}
 		    }
		}
		
		if( $hideUserNr || $hideTeacherNr ) {
		    // persist if changed something
		    if(count($change)) {
			$persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
			$persistenceManager->persistAll();
			$this->addFlashMessage('&Auml;nderung an den Lehrpersonen des Fachbereichs wurde gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		    }else{
			$this->addFlashMessage('Da ging was schief - &Auml;nderung nicht gespeichert. '. implode(',',$change), '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		}
	  
	}

	/**
	 * action new
	 *
	 * @return void
	 */
	public function newAction() {
		
	}

	/**
	 * action create
	 *
	 * @param \Mff\Mffdb\Domain\Model\TeacherRelation $newTeacherRelation
	 * @return void
	 */
	public function createAction(\Mff\Mffdb\Domain\Model\TeacherRelation $newTeacherRelation) {
		$this->addFlashMessage('The object was created.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->teacherRelationRepository->add($newTeacherRelation);
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \Mff\Mffdb\Domain\Model\TeacherRelation $teacherRelation
	 * @ignorevalidation $teacherRelation
	 * @return void
	 */
	public function editAction(\Mff\Mffdb\Domain\Model\TeacherRelation $teacherRelation) {
		$this->view->assign('teacherRelation', $teacherRelation);
		$teatcherObj = $teacherRelation->getTeaEcouser();
		$teaUid = $teatcherObj->getUid();
		$fachbereichNr = $teacherRelation->getFachbereich();
		
		$fachbereich = $this->fachbereichRepository->findByUid($fachbereichNr);
		$fachbereichBezeichnung = $fachbereich->getFachbereichname();
		$this->view->assign('fachbereich', $fachbereichBezeichnung );
		
		// <- FIXME ONLY for ABU!
		if($fachbereichNr == 1){
		    $fachRepository = $this->fachRepository->findAll();
		    foreach($fachRepository as $fach){
			$kursRegel = $fach->getFachKursregel();
			if(empty($kursRegel)) continue;
			$fbUid = $kursRegel->getFachbereich();
			if( $fbUid != $fachbereichNr ) continue;
			$kurseRep = $fach->getFachKurse();
			foreach($kurseRep as $kurs){
			    $kursUid = $kurs->getUid();
			    if(empty($kursUid)) continue;
			    $kursPlaene = $kurs->getKursPlaene();
			    if(empty($kursPlaene)) continue;
			    foreach($kursPlaene as $plan){
				$ecoUser = $plan->getPlanTeacher();
				if(empty($ecoUser)) continue;
				if( $teaUid != $ecoUser->getUid()) continue;
				$lpPlan[$kursUid] = $teaUid;
			    }
			    
			}
		    }
		    $fachbereicheRep = $this->fachbereichRepository->findAll();
		    foreach($fachbereicheRep as $fachbereich){
			$kurzklasseRepository = $fachbereich->getFbKurzklassen();
			if(empty($kurzklasseRepository)) continue;
			foreach($kurzklasseRepository as $kurzklasse){
			    $klassenzuege = $kurzklasse->getKrzKlassen();
			    if(empty($klassenzuege)) continue;
			    foreach($klassenzuege as $klasse){
				$klassenBezeichnung = $klasse->getClassShort();
				$klassenUid = $klasse->getUid();
				$klassArr['klasse'][ $klassenUid ] = $klassenBezeichnung;
			    }
			}
		    }
 		// -> FIXME 
		}else{
		// <- FIXME not for ABU!
		// get class-names of fachbereich
		    $kurzklasseRepository = $fachbereich->getFbKurzklassen();
		    if(empty($kurzklasseRepository)) return;
		    foreach($kurzklasseRepository as $kurzklasse){
			$klassenzuege = $kurzklasse->getKrzKlassen();
			if(empty($klassenzuege)) continue;
			foreach($klassenzuege as $klasse){
			    $klassenBezeichnung = $klasse->getClassShort();
			    $klassenUid = $klasse->getUid();
			    $klassArr['klasse'][ $klassenUid ] = $klassenBezeichnung;
			}
		    }
		    // get course-ids of teacher if there is related plan
		    $kursRepository = $this->kursRepository->findAll();
		    foreach($kursRepository as $kurs){
			$kursUid = $kurs->getUid();
			if(empty($kursUid)) continue;
			$kursPlaene = $kurs->getKursPlaene();
			if(empty($kursPlaene)) continue;
			foreach($kursPlaene as $plan){
			    $ecoUser = $plan->getPlanTeacher();
			    if(empty($ecoUser)) continue;
			    if( $teaUid != $ecoUser->getUid()) continue;
			    $lpPlan[$kursUid] = $teaUid;
			}
		    }
		    // get class-ids of teacher if there is related plan and class
		    foreach($kursRepository as $kurs){
			$kursUid = $kurs->getUid();
			if(!isset($lpPlan[$kursUid])) continue;
			$kursKlassen = $kurs->getKurseKlassen();
			if(empty($kursKlassen)) continue;
			foreach($kursKlassen as $klsMMtable){
			      $klassenUid = $klsMMtable->getUid();
			      if(empty($klassenUid)) continue;
			      if(!isset($klassArr['klasse'][ $klassenUid ])) continue;
			      if(!isset($lpPlan[$kursUid])) continue;
			      $teaFbKls[$klassenUid] = $klassArr['klasse'][ $klassenUid ];
			}
		    }
		    if(is_array($teaFbKls)) asort($teaFbKls);
		    $this->view->assign('klassen', $teaFbKls );
 		// -> FIXME 
   		}
	}

	/**
	 * action update
	 *
	 * @param \Mff\Mffdb\Domain\Model\TeacherRelation $teacherRelation
	 * @return void
	 */
	public function updateAction(\Mff\Mffdb\Domain\Model\TeacherRelation $teacherRelation) {
		$this->addFlashMessage('The object was updated. ', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		$this->teacherRelationRepository->update($teacherRelation);
		$GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
		$this->redirect('list');
	}

	public function upgrade_importRows() {
 		// <f:form action="list" name="teacherRelation"><f:form.submit name="service" value="Service" />{serviceDone}</f:form>
  		$rawGetArguments = \TYPO3\CMS\Core\Utility\GeneralUtility::_POST();
 		if( !isset($rawGetArguments['tx_mffdb_fbv']['service']) ) return;
		$serviceDone = 0;
		$planRepository = $this->stundenplanRepository->findAll();
		foreach( $planRepository as $stdPlan ) {
		    $ttId = $stdPlan->getTimetableId();
		    $nId = $stdPlan->getRefTimetableId();
		    if( empty($nId) ){
			if( empty($ttId)  ){
			    $bemerkung = $stdPlan->getBemerkung();
			    if( substr($bemerkung , 0 , 1 ) == '+' ) {
				$numbPart = substr($bemerkung , 1 );
				if(is_numeric($numbPart)) $ttId = $numbPart;
			    }
			    if( empty($ttId)  ) continue;
			    $stdPlan->setBemerkung( str_replace( '+'.$ttId , '' , $bemerkung ) );
			    $stdPlan->setTimetableId( $ttId );
			    $this->stundenplanRepository->update($stdPlan);
			    $serviceDone = 1;
			}else{
			    if( empty($ttId)  ) continue;
			    $stdPlan->setRefTimetableId( $ttId );
			    $this->stundenplanRepository->update($stdPlan);
			    $serviceDone = 1;
			}
		    }
		}
		$kursRepository = $this->kursRepository->findAll();
		foreach( $kursRepository as $kurs ) {
		    $ttId = $kurs->getCourseId();
		    $nId = $kurs->getRefCourseId();
		    if( !empty($ttId) && empty($nId) ){
			$kurs->setRefCourseId( $ttId );
			$this->kursRepository->update($kurs);
			$serviceDone = 1;
		    }
		}
		$klasseRepository = $this->klasseRepository->findAll();
		foreach( $klasseRepository as $klasse ) {
		    $ttId = $klasse->getClassId();
		    $nId = $klasse->getRefClassId();
		    if( !empty($ttId) && empty($nId) ){
			$klasse->setRefClassId( $ttId );
			$this->klasseRepository->update($klasse);
			$serviceDone = 1;
		    }
		}
		
		if($serviceDone) {
		      $persistenceManager = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
		      $persistenceManager->persistAll();
		      $this->addFlashMessage('&Auml;nderung in Tabellen gespeichert. ' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
 		$this->view->assign('serviceDone', $serviceDone);
 		return $serviceDone;
	}

}
