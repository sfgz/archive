<?php
namespace Mff\Mffdb\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class AnalyseUtility
 */

class ArrayToXlsUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	* pathToPHPExcel
	*
	* @var string
	*/
	private $pathToPHPExcel = 'EXT:mff_contrib/Resources/Private/PHP/PHPExcel_1.8.0/Classes/';

	/**
	* returns the pathToPHPExcel
	* 
	*/
	public function getPathToPHPExcel()
	{
	    return $this->pathToPHPExcel;
	}
	
	/**
	 * downloadAsXls
	 *
	 * @param array $sortTables
	 * @param string $filename
	 * @return void
	 */
	public function downloadAsXls( $sortTables , $filename = '' ) {
		if(empty($filename)) $filename = 'vergleiche_' . date( 'ymd-Hi' ) . '.xlsx' ;
		
		$objPHPExcel = $this->arrayToXls( $sortTables  );

		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment;filename="'.$filename.'"');
		header('Cache-Control: max-age=0');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save('php://output');
		
		exit();
	}
	/**
	 * saveAsXls
	 *
	 * @param array $sortTables
	 * @param string $filename
	 * @return void
	 */
	public function saveAsXls( $sortTables , $filePathName ) {
		
		$objPHPExcel = $this->arrayToXls( $sortTables  );

// 		if(empty($filename)) $filename = 'vergleiche_' . date( 'ymd-Hi' ) . '.xlsx' ;
// 		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
// 		header('Content-Disposition: attachment;filename="'.$filename.'"');
// 		header('Cache-Control: max-age=0');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->save($filePathName);
		
		//exit();
	}
	
	/**
	 * arrayToXls
	 *
	 * @param array $sortTables
	 * @return void
	 */
	public function arrayToXls( $sortTables  ) {
		$extDir = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( $this->pathToPHPExcel );
		set_include_path($extDir);
		include $extDir.'PHPExcel/IOFactory.php';
		
		$objPHPExcel = new \PHPExcel();

		$sheetNr = 0;
		foreach( $sortTables as $sheetname => $tablecontent ){
		      $rowIdx = 1;
		      if($sheetNr) {
			  $PHPExcel_Worksheet = new \PHPExcel_Worksheet($objPHPExcel);
			  $objPHPExcel->addSheet($PHPExcel_Worksheet,$sheetNr);
			  $objPHPExcel->getSheet($sheetNr)->setTitle( $sheetname );
		      }else{
			  $objPHPExcel->getSheet($sheetNr)->setTitle( $sheetname );
		      }
		     // foreach( $sheetcontent as $tablename => $tablecontent ){
			  if( is_array( $tablecontent ) ) {
				$ix=0;
				foreach($tablecontent as $uid=>$row){
				    if(!is_array($row) ) break;
				    foreach(array_keys($row) as $fld) {
					$objRichText = new \PHPExcel_RichText();
					$objCellTitle = $objRichText->createTextRun( $fld );
					$objCellTitle->getFont()->setBold(true);
					$objCellTitle->getFont()->setItalic(true);
					$objPHPExcel->getSheet($sheetNr)->getCellByColumnAndRow($ix,$rowIdx)->setValue($objRichText);
					$objPHPExcel->getSheet($sheetNr)->getColumnDimension( chr(65+$ix) )->setAutoSize(true);
					++$ix;
				    }
				    break;
				}
				++$rowIdx;
				foreach($tablecontent as $uid=>$row){
				    if(!is_array($row) ) break;
				    $colIdx=0;
				    foreach(array_keys($row) as $fld) {
					$objPHPExcel->getSheet($sheetNr)->setCellValueByColumnAndRow($colIdx,$rowIdx,$row[$fld] );
					++$colIdx;
				    }
				    ++$rowIdx;
				}
				$objPHPExcel->getSheet($sheetNr)->setCellValueByColumnAndRow(0,$rowIdx, '' );
				++$rowIdx;
			  }
		      //}
		      ++$sheetNr;
		}
		return $objPHPExcel;
	}
}