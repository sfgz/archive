<?php
namespace Mff\Mffdb\ViewHelpers\Form;

/*                                                                        *
 * This script is backported from the TYPO3 Flow package "TYPO3.Fluid".   *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License, either version 3   *
 *  of the License, or (at your option) any later version.                *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */
/**
 * This view helper generates a <select> dropdown list for to use with a form.
 *
 * = Basic usage =
 * see SelectViewHelper
 * this class appends the option onchange, 
 * wich is used for JavaScript
 *
 */
 
class SelectViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\SelectViewHelper {
    
	/**
	 * @var string
	 */
	protected $tagName = 'select';
    
	/**
	 * @var mixed
	 */
	protected $selectedValue = NULL;

	/**
	 * Initialize the arguments.
	 *
	 * @return void
	 * @api
	 */
	public function initializeArguments() {
		parent::initializeArguments();
		$this->registerArgument('onchange','string','a js command',FALSE);
	}
    
	/**
	 * Render the tag.
	 *
	 * @return string rendered tag.
	 * @api
	 */
	public function render() {
		$onchange = $this->arguments['onchange'] !== NULL ? $this->arguments['onchange'] : '';//$this->renderChildren();
		if ($onchange) {
		    $this->tag->addAttribute('onchange', $onchange);
		}
		$name = $this->getName();
		$this->tag->addAttribute('name', $name);
		$options = $this->getOptions();
		if (empty($options)) {
			$options = array('' => '');
		}
		$this->tag->setContent($this->renderOptionTags($options));
		$this->setErrorClassAttribute();
		$content = '';
		// register field name for token generation.
		// in case it is a multi-select, we need to register the field name
		// as often as there are elements in the box
		if ($this->hasArgument('multiple') && $this->arguments['multiple'] !== '') {
			$content .= $this->renderHiddenFieldForEmptyValue();
			for ($i = 0; $i < count($options); $i++) {
				$this->registerFieldNameForFormTokenGeneration($name);
			}
		} else {
			$this->registerFieldNameForFormTokenGeneration($name);
		}
		$content .= $this->tag->render();
		return $content;
	}


}