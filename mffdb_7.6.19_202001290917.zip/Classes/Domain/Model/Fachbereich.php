<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Fachbereich Einträge sind manuell zu erstellen. Alle Verknüfungen sind manuell
 * zu erstellen: fbKurzklassen, fbKursregeln, fbTeachers
 */
class Fachbereich extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * fachbereichname
	 *
	 * @var string
	 */
	protected $fachbereichname = '';

	/**
	 * cloudKey
	 *
	 * @var string
	 */
	protected $cloudKey = '';

	/**
	 * sorting
	 *
	 * @var int
	 */
	protected $sorting = '';

	/**
	 * hidePublic
	 *
	 * @var bool
	 */
	protected $hidePublic = FALSE;

	/**
	 * ignoreHoliday
	 *
	 * @var bool
	 */
	protected $ignoreHoliday = FALSE;

	/**
	 * longSubject
	 *
	 * @var bool
	 */
	protected $longSubject = FALSE;

	/**
	 * usergroup
	 *
	 * @var int
	 */
	protected $usergroup = '';

	/**
	 * Manuell zu erstellende Beziehung
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurzklasse>
	 * @cascade remove
	 */
	protected $fbKurzklassen = NULL;

	/**
	 * Manuell zu erstellende Beziehung
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\TeacherRelation>
	 * @cascade remove
	 */
	protected $fbTeachers = NULL;

	/**
	 * Manuell zu erstellende Beziehung
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kursregel>
	 * @cascade remove
	 */
	protected $fbKursregeln = NULL;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->fbKurzklassen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->fbTeachers = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->fbKursregeln = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the fachbereichname
	 *
	 * @return string $fachbereichname
	 */
	public function getFachbereichname() {
		return $this->fachbereichname;
	}

	/**
	 * Sets the fachbereichname
	 *
	 * @param string $fachbereichname
	 * @return void
	 */
	public function setFachbereichname($fachbereichname) {
		$this->fachbereichname = $fachbereichname;
	}

	/**
	 * Returns the cloudKey
	 *
	 * @return string $cloudKey
	 */
	public function getCloudKey() {
		return $this->cloudKey;
	}

	/**
	 * Sets the cloudKey
	 *
	 * @param string $cloudKey
	 * @return void
	 */
	public function setCloudKey($cloudKey) {
		$this->cloudKey = $cloudKey;
	}

	/**
	 * Returns the sorting
	 *
	 * @return bool $sorting
	 */
	public function getSorting() {
		return $this->sorting;
	}

	/**
	 * Sets the sorting
	 *
	 * @param bool $sorting
	 * @return void
	 */
	public function setSorting($sorting) {
		$this->sorting = $sorting;
	}

	/**
	 * Returns the hidePublic
	 *
	 * @return bool $hidePublic
	 */
	public function getHidePublic() {
		return $this->hidePublic;
	}

	/**
	 * Sets the hidePublic
	 *
	 * @param bool $hidePublic
	 * @return void
	 */
	public function setHidePublic($hidePublic) {
		$this->hidePublic = $hidePublic;
	}

	/**
	 * Returns the boolean state of hidePublic
	 *
	 * @return bool
	 */
	public function isHidePublic() {
		return $this->hidePublic;
	}

	
	/**
	 * Returns the ignoreHoliday
	 *
	 * @return bool $ignoreHoliday
	 */
	public function getIgnoreHoliday() {
		return $this->ignoreHoliday;
	}

	/**
	 * Sets the ignoreHoliday
	 *
	 * @param bool $ignoreHoliday
	 * @return void
	 */
	public function setIgnoreHoliday($ignoreHoliday) {
		$this->ignoreHoliday = $ignoreHoliday;
	}

	/**
	 * Returns the boolean state of ignoreHoliday
	 *
	 * @return bool
	 */
	public function isIgnoreHoliday() {
		return $this->ignoreHoliday;
	}


	/**
	 * Returns the longSubject
	 *
	 * @return bool $longSubject
	 */
	public function getLongSubject() {
		return $this->longSubject;
	}

	/**
	 * Sets the longSubject
	 *
	 * @param bool $longSubject
	 * @return void
	 */
	public function setLongSubject($longSubject) {
		$this->longSubject = $longSubject;
	}

	/**
	 * Returns the boolean state of longSubject
	 *
	 * @return bool
	 */
	public function isLongSubject() {
		return $this->longSubject;
	}

	/**
	 * Returns the usergroup
	 *
	 * @return int $usergroup
	 */
	public function getUsergroup() {
		return $this->usergroup;
	}

	/**
	 * Sets the usergroup
	 *
	 * @param int $usergroup
	 * @return void
	 */
	public function setUsergroup($usergroup) {
		$this->usergroup = $usergroup;
	}

	/**
	 * Adds a Kurzklasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $fbKurzklassen
	 * @return void
	 */
	public function addFbKurzklassen(\Mff\Mffdb\Domain\Model\Kurzklasse $fbKurzklassen) {
		$this->fbKurzklassen->attach($fbKurzklassen);
	}

	/**
	 * Removes a Kurzklasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kurzklasse $fbKurzklassenToRemove The Kurzklasse to be removed
	 * @return void
	 */
	public function removeFbKurzklassen(\Mff\Mffdb\Domain\Model\Kurzklasse $fbKurzklassenToRemove) {
		$this->fbKurzklassen->detach($fbKurzklassenToRemove);
	}

	/**
	 * Returns the fbKurzklassen
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurzklasse> $fbKurzklassen
	 */
	public function getFbKurzklassen() {
		return $this->fbKurzklassen;
	}

	/**
	 * Sets the fbKurzklassen
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kurzklasse> $fbKurzklassen
	 * @return void
	 */
	public function setFbKurzklassen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $fbKurzklassen) {
		$this->fbKurzklassen = $fbKurzklassen;
	}

	/**
	 * Adds a TeacherRelation
	 *
	 * @param \Mff\Mffdb\Domain\Model\TeacherRelation $fbTeacher
	 * @return void
	 */
	public function addFbTeacher(\Mff\Mffdb\Domain\Model\TeacherRelation $fbTeacher) {
		$this->fbTeachers->attach($fbTeacher);
	}

	/**
	 * Removes a TeacherRelation
	 *
	 * @param \Mff\Mffdb\Domain\Model\TeacherRelation $fbTeacherToRemove The TeacherRelation to be removed
	 * @return void
	 */
	public function removeFbTeacher(\Mff\Mffdb\Domain\Model\TeacherRelation $fbTeacherToRemove) {
		$this->fbTeachers->detach($fbTeacherToRemove);
	}

	/**
	 * Returns the fbTeachers
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\TeacherRelation> $fbTeachers
	 */
	public function getFbTeachers() {
		return $this->fbTeachers;
	}

	/**
	 * Sets the fbTeachers
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\TeacherRelation> $fbTeachers
	 * @return void
	 */
	public function setFbTeachers(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $fbTeachers) {
		$this->fbTeachers = $fbTeachers;
	}

	/**
	 * Adds a Kursregel
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $fbKursregeln
	 * @return void
	 */
	public function addFbKursregeln(\Mff\Mffdb\Domain\Model\Kursregel $fbKursregeln) {
		$this->fbKursregeln->attach($fbKursregeln);
	}

	/**
	 * Removes a Kursregel
	 *
	 * @param \Mff\Mffdb\Domain\Model\Kursregel $fbKursregelnToRemove The Kursregel to be removed
	 * @return void
	 */
	public function removeFbKursregeln(\Mff\Mffdb\Domain\Model\Kursregel $fbKursregelnToRemove) {
		$this->fbKursregeln->detach($fbKursregelnToRemove);
	}

	/**
	 * Returns the fbKursregeln
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kursregel> $fbKursregeln
	 */
	public function getFbKursregeln() {
		return $this->fbKursregeln;
	}

	/**
	 * Sets the fbKursregeln
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Kursregel> $fbKursregeln
	 * @return void
	 */
	public function setFbKursregeln(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $fbKursregeln) {
		$this->fbKursregeln = $fbKursregeln;
	}

}