<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Kurzklasse wird automatisch erzeugt und mit Klasse verknüpft. Mit Fachbereich
 * und Cloudquota manuell zu verknüpfen.
 */
class Kurzklasse extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * fachbereich
	 *
	 * @var int
	 */
	protected $fachbereich = 0;

	/**
	 * kurzbezeichnung
	 *
	 * @var string
	 */
	protected $kurzbezeichnung = '';

	/**
	 * klassennamen
	 *
	 * @var string
	 */
	protected $klassennamen = '';

	/**
	 * Manuell zu erstellende Beziehung
	 *
	 * @var \Mff\Mffdb\Domain\Model\Cloudquota
	 */
	public $krzCloudquota = NULL;

	/**
	 * krzKlassen
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse>
	 * @cascade remove
	 */
	protected $krzKlassen = NULL;

	/**
	 * cruserId
	 *
	 * @var int
	 */
	protected $cruserId = FALSE;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->krzKlassen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the fachbereich
	 *
	 * @return int $fachbereich
	 */
	public function getFachbereich() {
		return $this->fachbereich;
	}

	/**
	 * Sets the fachbereich
	 *
	 * @param int $fachbereich
	 * @return void
	 */
	public function setFachbereich($fachbereich) {
		$this->fachbereich = $fachbereich;
	}

	/**
	 * Returns the kurzbezeichnung
	 *
	 * @return string $kurzbezeichnung
	 */
	public function getKurzbezeichnung() {
		return $this->kurzbezeichnung;
	}

	/**
	 * Sets the kurzbezeichnung
	 *
	 * @param string $kurzbezeichnung
	 * @return void
	 */
	public function setKurzbezeichnung($kurzbezeichnung) {
		$this->kurzbezeichnung = $kurzbezeichnung;
	}

	/**
	 * Returns the klassennamen
	 *
	 * @return string $klassennamen
	 */
	public function getKlassennamen() {
		return $this->klassennamen;
	}

	/**
	 * Sets the klassennamen
	 *
	 * @param string $klassennamen
	 * @return void
	 */
	public function setKlassennamen($klassennamen) {
		$this->klassennamen = $klassennamen;
	}

	/**
	 * Returns the krzCloudquota
	 *
	 * @return \Mff\Mffdb\Domain\Model\Cloudquota $krzCloudquota
	 */
	public function getKrzCloudquota() {
		return $this->krzCloudquota;
	}

	/**
	 * Sets the krzCloudquota
	 *
	 * @param \Mff\Mffdb\Domain\Model\Cloudquota $krzCloudquota
	 * @return void
	 */
	public function setKrzCloudquota(\Mff\Mffdb\Domain\Model\Cloudquota $krzCloudquota) {
		$this->krzCloudquota = $krzCloudquota;
	}

	/**
	 * Adds a Klasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Klasse $krzKlassen
	 * @return void
	 */
	public function addKrzKlassen(\Mff\Mffdb\Domain\Model\Klasse $krzKlassen) {
		$this->krzKlassen->attach($krzKlassen);
	}

	/**
	 * Removes a Klasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Klasse $krzKlassenToRemove The Klasse to be removed
	 * @return void
	 */
	public function removeKrzKlassen(\Mff\Mffdb\Domain\Model\Klasse $krzKlassenToRemove) {
		$this->krzKlassen->detach($krzKlassenToRemove);
	}

	/**
	 * Returns the krzKlassen
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse> $krzKlassen
	 */
	public function getKrzKlassen() {
		return $this->krzKlassen;
	}

	/**
	 * Sets the krzKlassen
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse> $krzKlassen
	 * @return void
	 */
	public function setKrzKlassen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $krzKlassen) {
		$this->krzKlassen = $krzKlassen;
	}

	/**
	 * Returns the cruserId
	 *
	 * @return string $cruserId
	 */
	public function getCruserId() {
		return $this->cruserId;
	}

	/**
	 * Sets the cruserId
	 *
	 * @param string $cruserId
	 * @return void
	 */
	public function setCruserId($cruserId) {
		$this->cruserId = $cruserId;
	}

}