<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Kursregel
 */
class Kursregel extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * regelname
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $regelname = '';

	/**
	 * Fach "ab" (zB. 2801) oder genau passende Kurzbezeichnung (zB. Ges).
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $wertAb = '';

	/**
	 * Fach "bis" (zB. 2899). Muss eine Zahl sein - oder leer.
	 *
	 * @var int
	 */
	protected $wertBis = 0;

	/**
	 * fachbereich
	 *
	 * @var int
	 */
	protected $fachbereich = 0;

	/**
	 * sorting
	 *
	 * @var integer
	 */
	protected $sorting = 0;


	/**
	 * Returns the regelname
	 *
	 * @return string $regelname
	 */
	public function getRegelname() {
		return $this->regelname;
	}

	/**
	 * Sets the regelname
	 *
	 * @param string $regelname
	 * @return void
	 */
	public function setRegelname($regelname) {
		$this->regelname = $regelname;
	}

	/**
	 * Returns the fachbereich
	 *
	 * @return int $fachbereich
	 */
	public function getFachbereich() {
		return $this->fachbereich;
	}

	/**
	 * Sets the fachbereich
	 *
	 * @param int $fachbereich
	 * @return void
	 */
	public function setFachbereich($fachbereich) {
		$this->fachbereich = $fachbereich;
	}

	/**
	 * Returns the wertAb
	 *
	 * @return string $wertAb
	 */
	public function getWertAb() {
		return $this->wertAb;
	}

	/**
	 * Sets the wertAb
	 *
	 * @param string $wertAb
	 * @return void
	 */
	public function setWertAb($wertAb) {
		$this->wertAb = $wertAb;
	}

	/**
	 * Returns the wertBis
	 *
	 * @return int $wertBis
	 */
	public function getWertBis() {
		return $this->wertBis;
	}

	/**
	 * Sets the wertBis
	 *
	 * @param int $wertBis
	 * @return void
	 */
	public function setWertBis($wertBis) {
		$this->wertBis = $wertBis;
	}

	/**
	 * Returns the sorting
	 *
	 * @return integer $sorting
	 */
	public function getSorting() {
		return $this->sorting;
	}

	/**
	 * Sets the sorting
	 *
	 * @param integer $sorting
	 * @return void
	 */
	public function setSorting($sorting) {
		$this->sorting = $sorting;
	}

}