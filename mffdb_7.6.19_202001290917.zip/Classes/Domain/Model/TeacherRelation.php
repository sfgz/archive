<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * TeacherRelation
 */
class TeacherRelation extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * fachbereich
	 *
	 * @var integer
	 */
	protected $fachbereich = NULL;

	/**
	 * leiter
	 *
	 * @var bool
	 */
	protected $leiter = FALSE;

	/**
	 * autoReference
	 *
	 * @var string
	 */
	protected $autoReference = '';

	/**
	 * Manuell zu erstellende Beziehung
	 *
	 * @var \Mff\Mffdb\Domain\Model\Ecouser
	 */
	protected $teaEcouser = NULL;

	/**
	 * hidden
	 *
	 * @var bool
	 */
	protected $hidden = FALSE;

	/**
	 * Returns the fachbereich
	 *
	 * @return bool $fachbereich
	 */
	public function getFachbereich() {
		return $this->fachbereich;
	}

	/**
	 * Sets the fachbereich
	 *
	 * @param bool $fachbereich
	 * @return void
	 */
	public function setFachbereich($fachbereich) {
		$this->fachbereich = $fachbereich;
	}

	/**
	 * Returns the leiter
	 *
	 * @return bool $leiter
	 */
	public function getLeiter() {
		return $this->leiter;
	}

	/**
	 * Sets the leiter
	 *
	 * @param bool $leiter
	 * @return void
	 */
	public function setLeiter($leiter) {
		$this->leiter = $leiter;
	}

	/**
	 * Returns the boolean state of leiter
	 *
	 * @return bool
	 */
	public function isLeiter() {
		return $this->leiter;
	}

	/**
	 * Returns the autoReference
	 *
	 * @return string $autoReference
	 */
	public function getAutoReference() {
		return $this->autoReference;
	}

	/**
	 * Sets the autoReference
	 *
	 * @param string $autoReference
	 * @return void
	 */
	public function setAutoReference($autoReference) {
		$this->autoReference = $autoReference;
	}

	/**
	 * Returns the teaEcouser
	 *
	 * @return \Mff\Mffdb\Domain\Model\Ecouser $teaEcouser
	 */
	public function getTeaEcouser() {
		return $this->teaEcouser;
	}

	/**
	 * Sets the teaEcouser
	 *
	 * @param \Mff\Mffdb\Domain\Model\Ecouser $teaEcouser
	 * @return void
	 */
	public function setTeaEcouser(\Mff\Mffdb\Domain\Model\Ecouser $teaEcouser) {
		$this->teaEcouser = $teaEcouser;
	}

	/**
	 * Returns the hidden
	 *
	 * @return bool $hidden
	 */
	public function getHidden() {
		return $this->hidden;
	}

	/**
	 * Sets the hidden
	 *
	 * @param bool $hidden
	 * @return void
	 */
	public function setHidden($hidden) {
		$this->hidden = $hidden;
	}

	/**
	 * Returns the boolean state of hidden
	 *
	 * @return bool
	 */
	public function isHidden() {
		return $this->hidden;
	}

}