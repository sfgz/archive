<?php
namespace Mff\Mffdb\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Kurs
 */
class Kurs extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * courseId
	 *
	 * @var string
	 */
	protected $courseId = '';

	/**
	 * refCourseId
	 *
	 * @var string
	 */
	protected $refCourseId = '';

	/**
	 * kursStart
	 *
	 * @var int
	 */
	protected $kursStart = 0;

	/**
	 * kursEnde
	 *
	 * @var int
	 */
	protected $kursEnde = 0;

	/**
	 * departmentId
	 *
	 * @var int
	 */
	protected $departmentId = 0;

	/**
	 * courseShort
	 *
	 * @var string
	 */
	protected $courseShort = '';

	/**
	 * kurseKlassen
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse>
	 */
	protected $kurseKlassen = NULL;

	/**
	 * kursPlaene
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Stundenplan>
	 * @cascade remove
	 * @lazy
	 */
	protected $kursPlaene = NULL;

	/**
	 * fach
	 *
	 * @var int
	 */
	protected $fach = NULL;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->kurseKlassen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->kursPlaene = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the courseId
	 *
	 * @return string $courseId
	 */
	public function getCourseId() {
		return $this->courseId;
	}

	/**
	 * Sets the courseId
	 *
	 * @param string $courseId
	 * @return void
	 */
	public function setCourseId($courseId) {
		$this->courseId = $courseId;
	}

	/**
	 * Returns the refCourseId
	 *
	 * @return string $refCourseId
	 */
	public function getRefCourseId() {
		return $this->refCourseId;
	}

	/**
	 * Sets the refCourseId
	 *
	 * @param string $refCourseId
	 * @return void
	 */
	public function setRefCourseId($refCourseId) {
		$this->refCourseId = $refCourseId;
	}

	/**
	 * Returns the kursStart
	 *
	 * @return int $kursStart
	 */
	public function getKursStart() {
		return $this->kursStart;
	}

	/**
	 * Sets the kursStart
	 *
	 * @param int $kursStart
	 * @return void
	 */
	public function setKursStart($kursStart) {
		$this->kursStart = $kursStart;
	}

	/**
	 * Returns the kursEnde
	 *
	 * @return int $kursEnde
	 */
	public function getKursEnde() {
		return $this->kursEnde;
	}

	/**
	 * Sets the kursEnde
	 *
	 * @param int $kursEnde
	 * @return void
	 */
	public function setKursEnde($kursEnde) {
		$this->kursEnde = $kursEnde;
	}

	/**
	 * Returns the departmentId
	 *
	 * @return int $departmentId
	 */
	public function getDepartmentId() {
		return $this->departmentId;
	}

	/**
	 * Sets the departmentId
	 *
	 * @param int $departmentId
	 * @return void
	 */
	public function setDepartmentId($departmentId) {
		$this->departmentId = $departmentId;
	}

	/**
	 * Returns the courseShort
	 *
	 * @return string $courseShort
	 */
	public function getCourseShort() {
		return $this->courseShort;
	}

	/**
	 * Sets the courseShort
	 *
	 * @param string $courseShort
	 * @return void
	 */
	public function setCourseShort($courseShort) {
		$this->courseShort = $courseShort;
	}

	/**
	 * Adds a Klasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Klasse $kurseKlassen
	 * @return void
	 */
	public function addKurseKlassen(\Mff\Mffdb\Domain\Model\Klasse $kurseKlassen) {
		$this->kurseKlassen->attach($kurseKlassen);
	}

	/**
	 * Removes a Klasse
	 *
	 * @param \Mff\Mffdb\Domain\Model\Klasse $kurseKlassenToRemove The Klasse to be removed
	 * @return void
	 */
	public function removeKurseKlassen(\Mff\Mffdb\Domain\Model\Klasse $kurseKlassenToRemove) {
		$this->kurseKlassen->detach($kurseKlassenToRemove);
	}

	/**
	 * Returns the kurseKlassen
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse> $kurseKlassen
	 */
	public function getKurseKlassen() {
		return $this->kurseKlassen;
	}

	/**
	 * Sets the kurseKlassen
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Klasse> $kurseKlassen
	 * @return void
	 */
	public function setKurseKlassen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $kurseKlassen) {
		$this->kurseKlassen = $kurseKlassen;
	}

	/**
	 * Adds a Stundenplan
	 *
	 * @param \Mff\Mffdb\Domain\Model\Stundenplan $kursPlaene
	 * @return void
	 */
	public function addKursPlaene(\Mff\Mffdb\Domain\Model\Stundenplan $kursPlaene) {
		$this->kursPlaene->attach($kursPlaene);
	}

	/**
	 * Removes a Stundenplan
	 *
	 * @param \Mff\Mffdb\Domain\Model\Stundenplan $kursPlaeneToRemove The Stundenplan to be removed
	 * @return void
	 */
	public function removeKursPlaene(\Mff\Mffdb\Domain\Model\Stundenplan $kursPlaeneToRemove) {
		$this->kursPlaene->detach($kursPlaeneToRemove);
	}

	/**
	 * Returns the kursPlaene
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Stundenplan> $kursPlaene
	 */
	public function getKursPlaene() {
		return $this->kursPlaene;
	}

	/**
	 * Sets the kursPlaene
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Mff\Mffdb\Domain\Model\Stundenplan> $kursPlaene
	 * @return void
	 */
	public function setKursPlaene(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $kursPlaene) {
		$this->kursPlaene = $kursPlaene;
	}

	/**
	 * Returns the fach
	 *
	 * @return int $fach
	 */
	public function getFach() {
		return $this->fach;
	}

	/**
	 * Sets the fach
	 *
	 * @param int $fach
	 * @return void
	 */
	public function setFach($fach) {
		$this->fach = $fach;
	}

}