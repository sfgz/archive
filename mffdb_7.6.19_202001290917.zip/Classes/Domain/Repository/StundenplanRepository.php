<?php
namespace Mff\Mffdb\Domain\Repository;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * The repository for Stundenplans
 */
class StundenplanRepository extends \TYPO3\CMS\Extbase\Persistence\Repository {


	  /**
	  *  Find data from Stundenplan with 
	  *  'plan_ende' older than today 
	  *  and 
	  *  'ref_timetable_id' not empty
	  * 
	  */
	  public function findeDataToClearOlderThanNow( $dateNow=0 ) {
	      if(empty($dateNow)) $dateNow = time();
	      $querySettings = $this->objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
	      $querySettings->setIgnoreEnableFields(TRUE);
 	      $querySettings->setRespectStoragePage(FALSE);
	      $this->setDefaultQuerySettings($querySettings);
	      $query = $this->createQuery();
	      $query->matching(
		    $query->logicalAnd(
			    $query->logicalNot(
			      $query->equals('ref_timetable_id', '')
			    ),
			    $query->lessThan('plan_ende', $dateNow )
		    )
	      );
	      return $query->execute();
	  }
	
	/**
	 * findByRoomsAndDate
	 * used by extension Mffrps Raumplanung
	 *
	 * @param array  $zimmerArr uids of rooms, or empty
	 * @param int $datum
	 * @return void
	 */
	public function findByRoomsAndDate( $zimmerArr = array() , $datum ){
	    $sqlAndWhere = array();
	    $searchDate =  $datum ;
	    $weekDay = date('N', $datum );
	    
	    if($searchDate) $sqlAndWhere[] = ' plan_start <= "' . $searchDate .'" AND plan_ende >= "' . $searchDate .'" ';
	    
	    if($weekDay) $sqlAndWhere[] = ' plan_tag = ' . $weekDay . ' ';
	    
	    $sqlAndWhere[] = ' tx_mffdb_domain_model_stundenplan.ref_teacher_ecokey >0 ';
	    
	    if(count($zimmerArr)){
		$roomWhereArr = array();
		foreach($zimmerArr as $roomNr) $roomWhereArr[] = ' tx_mffdb_domain_model_stundenplan.plan_zimmer = '.$roomNr;
		$sqlAndWhere[] = ' (' . implode( ' OR ' , $roomWhereArr ) . ') ';
	    }
	    
	    $groupedFields = '';
	    
	    $sqlStmt = 'SELECT DISTINCT fe_users.uid AS teacherId, name,first_name,last_name, 
	    tx_mffdb_domain_model_klasse.class_short, 
	    ignore_holiday,
	    ignore_vacation,
	    fachkurz,fachbezeichnung,
	    plan_zimmer,
	    tx_mffdb_domain_model_stundenplan.uid,
	    plan_periodizitaet AS periodicity, 
	    plan_start AS date_start, 
	    plan_ende AS date_end, 
	    zeit_ab AS time_from, 
	    zeit_bis AS time_to
	    FROM tx_mffdb_domain_model_stundenplan 
	    JOIN tx_mffdb_domain_model_kurs 
	    ON tx_mffdb_domain_model_stundenplan.kurs = tx_mffdb_domain_model_kurs.uid
	    JOIN tx_mffdb_domain_model_fach 
	    ON tx_mffdb_domain_model_fach.uid = tx_mffdb_domain_model_kurs.fach
	    LEFT JOIN tx_mffdb_kurs_klasse_mm 
	    ON tx_mffdb_domain_model_kurs.uid = tx_mffdb_kurs_klasse_mm.uid_local
	    LEFT JOIN tx_mffdb_domain_model_klasse 
	    ON tx_mffdb_domain_model_klasse.uid = tx_mffdb_kurs_klasse_mm.uid_foreign
	    LEFT JOIN tx_mffdb_domain_model_kurzklasse 
	    ON tx_mffdb_domain_model_kurzklasse.uid = tx_mffdb_domain_model_klasse.kurzklasse
	    LEFT JOIN tx_mffdb_domain_model_fachbereich 
	    ON tx_mffdb_domain_model_fachbereich.uid = tx_mffdb_domain_model_kurzklasse.fachbereich
	    JOIN fe_users 
	    ON fe_users.eco_key = tx_mffdb_domain_model_stundenplan.ref_teacher_ecokey
	    ';
	    
	    if(count($sqlAndWhere)) $sqlStmt .= ' WHERE ' . implode( ' AND ' , $sqlAndWhere ) . ' ';
	    
	    // max(tx_mffdb_domain_model_stundenplan.uid) AS uid,
	    //$sqlStmt .= ' GROUP BY '.$groupedFields.' plan_periodizitaet, plan_start, plan_ende, zeit_ab, zeit_bis ';
	    $sqlStmt .= ' ORDER BY plan_start,zeit_ab,class_short,name; ';
	    
	    //return $this->callSqlStatement( $sqlStmt );
	    $zmrTimetable  = $this->callSqlStatement( $sqlStmt );
	    return $this->groupArrayByClass( $zmrTimetable );
	    
	}
	public function groupArrayByClass( $zmrTimetable ){
	      $outArr = array();
	      $grpArr = array();
	      $clsArr = array();
	      foreach( $zmrTimetable as $ttRecord){
	 //     if(empty($ttRecord['class_short']))$ttRecord['class_short']='KURS';
		    $idx = $ttRecord['periodicity'].'-'.
			    $ttRecord['date_start'].'-'.
			    $ttRecord['date_end'].'-'.
			    $ttRecord['time_from'].'-'.
			    $ttRecord['time_to'].'-'.
			    $ttRecord['name'].'-'.
			    $ttRecord['plan_zimmer'];
		    $grpArr[$idx] = $ttRecord;
		    $clsArr[$idx][$ttRecord['class_short']] = $ttRecord['class_short'];
	      }
	      foreach( $grpArr  as $idx => $ttRecord ){
		  if( !is_array($clsArr[$idx]) )continue;
		  foreach( $clsArr[$idx] as $class_short ){
		      $outArr[$idx.'-'.$class_short] = $ttRecord; 
		      $outArr[$idx.'-'.$class_short]['class_short'] = $class_short; 
		  }
	      }
	    return $outArr;
	}
	
	/**
	 * findBySemesterGroupByKlasseTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $uxDateFrom
	 * @param int $uxDateTo
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findBySemesterGroupByKlasseTeacherFiltered( $semesterUid, $filter = array() ){
	      $aPeriod = $this->findPeriodsUnixTimeBySemester($semesterUid);
	      $newAb = 3601 + mktime( 23,59,59,date('m',$aPeriod['ab']),date('d',$aPeriod['ab']),date('Y',$aPeriod['ab']) );
	      return $this->findByDaterangesGroupByKlasseTeacherFiltered( $newAb , $aPeriod['bis'] , $filter );
	}
	
	/**
	 * findByDaterangesGroupByKlasseTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $uxDateFrom
	 * @param int $uxDateTo
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findByDaterangesGroupByKlasseTeacherFiltered( $uxDateFrom , $uxDateTo , $filter = array() ){
	      // NOTE: we can not search for class 'KURS' because in Intranet there is no class on KURS-courses 
	      $sqlStatement = 'SELECT kurzbezeichnung,"int" AS source, CONCAT_WS(" ",last_name,first_name) AS user, email, username,tx_mffdb_domain_model_fach.*,class_short AS Klasse,tx_mffdb_domain_model_stundenplan.*,tx_mffdb_domain_model_kurzklasse.*,tx_mffdb_domain_model_klasse.* FROM tx_mffdb_domain_model_kurzklasse ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_klasse ON tx_mffdb_domain_model_kurzklasse.uid=tx_mffdb_domain_model_klasse.kurzklasse ';
	      $sqlStatement .= ' JOIN tx_mffdb_kurs_klasse_mm ON tx_mffdb_kurs_klasse_mm.uid_foreign = tx_mffdb_domain_model_klasse.uid ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_kurs ON tx_mffdb_domain_model_kurs.uid = tx_mffdb_kurs_klasse_mm.uid_local ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_fach ON tx_mffdb_domain_model_fach.uid=tx_mffdb_domain_model_kurs.fach ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_stundenplan ON tx_mffdb_domain_model_kurs.uid=tx_mffdb_domain_model_stundenplan.kurs ';
	      $sqlStatement .= ' JOIN fe_users ON fe_users.uid=tx_mffdb_domain_model_stundenplan.plan_teacher ';
	      
	      $sqlStatement .= ' WHERE ';
	      $sqlStatement .= '  tx_mffdb_domain_model_stundenplan.plan_start <=' . $uxDateTo;
	      $sqlStatement .= ' AND tx_mffdb_domain_model_stundenplan.plan_start >' . $uxDateFrom;
 	      if($filter['not_fachbereich']) {
			$sqlStatement .= ' AND NOT fachbereich=' . $filter['not_fachbereich'] . ' ';
 	      }
 	      if($filter['fachbereich']) {
		    $aFltFb = explode( ',' , $filter['fachbereich'] );
		    if(is_array($aFltFb)){
			  $aWhere = array();
			  foreach($aFltFb as $val){
				$aWhere[] = ' fachbereich='.$val;
			  }
			  if(count($aWhere)) $sqlStatement .= ' AND (' . implode( ' OR ' , $aWhere ) . ') ';
		    }
 	      }

	      $sqlStatement .= ' GROUP BY fe_users.uid, tx_mffdb_domain_model_klasse.uid,fachbezeichnung ';
	      
	      $sqlStatement .= ' ORDER BY tx_mffdb_domain_model_stundenplan.plan_start,fachbereich,class_short  ASC ';
	      
	      $rawQueryResult = $this->callSqlStatement( $sqlStatement );
	      return $rawQueryResult;
	}
	
	/**
	 * findBySemesterGroupByKursregelTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $semesterUid
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findBySemesterGroupByKursregelTeacherFiltered( $semesterUid , $filter = array() ){
	      $aPeriod = $this->findPeriodsUnixTimeBySemester($semesterUid);
	      $newAb = 3601 + mktime( 23,59,59,date('m',$aPeriod['ab']),date('d',$aPeriod['ab']),date('Y',$aPeriod['ab']) );
	      return $this->findByDaterangesGroupByKursregelTeacherFiltered( $newAb , $aPeriod['bis'] , $filter );
	}
	
	/**
	 * findByDaterangesGroupByKursregelTeacherFiltered
	 * used by extension MffLsb LimeSurveyBaker
	 *
	 * @param int $uxDateFrom
	 * @param int $uxDateTo
	 * @param array  $filter key-value pairs or empty
	 * @return void
	 */
	public function findByDaterangesGroupByKursregelTeacherFiltered( $uxDateFrom , $uxDateTo , $filter = array() ){
	      // filter[ 'fachbereich' ] = 7,8  
	      $sqlStatement = 'SELECT "KURS" AS kurzbezeichnung,"int" AS source, CONCAT_WS(" ",last_name,first_name) AS user, email, username,tx_mffdb_domain_model_fach.*,fachkurz AS Klasse,tx_mffdb_domain_model_stundenplan.*, tx_mffdb_domain_model_kursregel.* FROM tx_mffdb_domain_model_kursregel ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_fach ON tx_mffdb_domain_model_kursregel.uid=tx_mffdb_domain_model_fach.fach_kursregel ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_kurs ON tx_mffdb_domain_model_fach.uid=tx_mffdb_domain_model_kurs.fach ';
	      $sqlStatement .= ' JOIN tx_mffdb_domain_model_stundenplan ON tx_mffdb_domain_model_kurs.uid=tx_mffdb_domain_model_stundenplan.kurs ';
	      $sqlStatement .= ' JOIN fe_users ON fe_users.uid=tx_mffdb_domain_model_stundenplan.plan_teacher ';
	      
	      $sqlStatement .= ' WHERE ';
	      $sqlStatement .= ' tx_mffdb_domain_model_stundenplan.plan_start <=' . $uxDateTo;
	      $sqlStatement .= ' AND tx_mffdb_domain_model_stundenplan.plan_start >' . $uxDateFrom;
 	      if($filter['not_fachbereich']) {
			$excludetFb = explode( ',' , trim($filter['not_fachbereich']) );
			if( count($excludetFb) ){
				foreach($excludetFb as $fbNr) $sqlStatement .= ' AND NOT  tx_mffdb_domain_model_kursregel.fachbereich=' . $fbNr . ' ';
			}
 	      }
 	      if($filter['fachbereich']) {
		    $aFltFb = explode( ',' , $filter['fachbereich'] );
		    if(is_array($aFltFb)){
			  $aWhere = array();
			  foreach($aFltFb as $val){
				$aWhere[] = ' tx_mffdb_domain_model_kursregel.fachbereich='.$val;
			  }
			  if(count($aWhere)) $sqlStatement .= ' AND (' . implode( ' OR ' , $aWhere ) . ') ';
		    }
 	      }
// 	      $sqlStatement .= 'WHERE uid_foreign IS NULL ';

	      $sqlStatement .= ' GROUP BY fe_users.uid, tx_mffdb_domain_model_fach.uid ';
	      
	      $sqlStatement .= ' ORDER BY tx_mffdb_domain_model_stundenplan.plan_start,tx_mffdb_domain_model_kursregel.fachbereich,fachbezeichnung ASC ';
	      
	      $rawQueryResult = $this->callSqlStatement( $sqlStatement );
	      return $rawQueryResult;
	}
	
	/**
	 * findPeriodsUnixTimeBySemester
	 * used by findBySemesterGroupByKursregelTeacherFiltered for extension MffLsb LimeSurveyBaker
	 *
	 * @param int $semesterUid
	 * @return void
	 */
	public function findPeriodsUnixTimeBySemester( $semesterUid  ){
	      $sqlStatement = 'SELECT  UNIX_TIMESTAMP(davor_bis) as ab,UNIX_TIMESTAMP(danach_ab) as bis ';
	      $sqlStatement .= ' FROM tx_mffplan_domain_model_periods ';
	      $sqlStatement .= ' WHERE uid = ' . $semesterUid ;
	      // execute sql-statement
	      $aPeriod = $this->callSqlStatement( $sqlStatement );
	      // return the first element
	      return array_shift( $aPeriod );
	}

	/**
	 * @param $qryStatement
	 * @param $ReturnRawQueryResult
	 * @return void
	 */
	public function callSqlStatement($qryStatement, $ReturnRawQueryResult = TRUE) {
		$Query = $this->createquery();
// 		$Query->getQuerySettings()->setReturnRawQueryResult($ReturnRawQueryResult);
		$Query->getQuerySettings()->setIgnoreEnableFields(TRUE);
		$Query->getQuerySettings()->setRespectStoragePage(FALSE);
		$Query->statement($qryStatement);
		return $Query->execute($ReturnRawQueryResult);
	}
	
}
