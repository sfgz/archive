<?php
// mffdb/ext_localconf.php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Mff.' . $_EXTKEY,
	'Fbv',
	array(
		'Fachbereich' => 'list, show, new, create, edit, update, delete, downloads, maillists',
		'Kurzklasse' => 'list, new, create, edit, update',
		'Cloudquota' => 'list, new, create, edit, update, delete',
		'Fach' => 'list, edit, update',
		'Kursregel' => 'list, new, create, edit, update, delete',
		'Klasse' => 'list, edit, update',
		'Kurs' => 'list, edit, update',
		'Zimmer' => 'list, show, new, create, edit, update',
		'TeacherRelation' => 'list, new, create, edit, update',
		'Kalender' => 'list, show, new, create, edit, update, delete',
		
	),
	// non-cacheable actions
	array(
		'Fachbereich' => 'create, update, delete, downloads',
		'Kurzklasse' => 'create, update',
		'Cloudquota' => 'create, update, delete',
		'Fach' => 'edit, update',
		'Kursregel' => 'edit,create, update, delete',
		'Klasse' => 'update',
		'Kurs' => 'update',
		'Zimmer' => 'list,edit,create, update',
		'TeacherRelation' => 'list,create, update',
		'Kalender' => 'create, update, delete',
		
	)
);
