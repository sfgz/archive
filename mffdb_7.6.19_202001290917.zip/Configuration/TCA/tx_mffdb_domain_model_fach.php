<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach',
		'label' => 'fachbezeichnung',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(
			'disabled' => 'hidden',
		),
		'searchFields' => 'fachbezeichnung,fachkurz,subject_id,ignore_vacation,fach_kursregel,fach_kurse,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_fach.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'fachbezeichnung, fachkurz, subject_id, ignore_vacation, fach_kursregel, fach_kurse, hidden',
	),
	'types' => array(
		'1' => array('showitem' => 'fachbezeichnung, fachkurz, subject_id, ignore_vacation, fach_kursregel, fach_kurse, hidden, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'fachbezeichnung' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.fachbezeichnung',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'fachkurz' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.fachkurz',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'subject_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.subject_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'ignore_vacation' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.ignore_vacation',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'fach_kursregel' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.fach_kursregel',
			'config' => array(
				'type' => 'select',
				'items' => array( array('keine', 0)),
				'foreign_table' => 'tx_mffdb_domain_model_kursregel',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'fach_kurse' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fach.fach_kurse',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_kurs',
				'foreign_field' => 'fach',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'hidden' => array(
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
			'config' => array(
				'type' => 'check',
			),
		),
		
	),
);