<?php

if (!isset($GLOBALS['TCA']['fe_users']['ctrl']['type'])) {
	if (file_exists($GLOBALS['TCA']['fe_users']['ctrl']['dynamicConfigFile'])) {
		require_once($GLOBALS['TCA']['fe_users']['ctrl']['dynamicConfigFile']);
	}
	// no type field defined, so we define it here. This will only happen the first time the extension is installed!!
	$GLOBALS['TCA']['fe_users']['ctrl']['type'] = 'tx_extbase_type';
	$tempColumnstx_mffdb_fe_users = array();
	$tempColumnstx_mffdb_fe_users[$GLOBALS['TCA']['fe_users']['ctrl']['type']] = array(
		'exclude' => 1,
		'label'   => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb.tx_extbase_type',
		'config' => array(
			'type' => 'select',
			'items' => array(
				array('Ecouser','Tx_Mffdb_Ecouser')
			),
			'default' => 'Tx_Mffdb_Ecouser',
			'size' => 1,
			'maxitems' => 1,
		)
	);
	\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('fe_users', $tempColumnstx_mffdb_fe_users, 1);
}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
	'fe_users',
	$GLOBALS['TCA']['fe_users']['ctrl']['type'],
	'',
	'after:' . $GLOBALS['TCA']['fe_users']['ctrl']['label']
);

$tmp_mffdb_columns = array(

	'eco_acronym' => array(
		'exclude' => 0,
		'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_ecouser.eco_acronym',
		'config' => array(
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		),
	),
	'eco_key' => array(
		'exclude' => 0,
		'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_ecouser.eco_key',
		'config' => array(
			'type' => 'input',
			'size' => 30,
			'eval' => 'trim'
		),
	),
	'eco_klasse' => array(
		'exclude' => 0,
		'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_ecouser.eco_klasse',
		'config' => array(
			'type' => 'select',
			'items' => array( array('keine', 0)),
			'foreign_table' => 'tx_mffdb_domain_model_klasse',
			'minitems' => 0,
			'maxitems' => 1,
		),
	),
	'cloud_quota' => array(
		'exclude' => 0,
		'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_ecouser.cloud_quota',
		'config' => array(
			'type' => 'input',
			'size' => 8,
			'eval' => 'trim'
		),
	),
	'ref_class_id' => array(
		'config' => array(
			'type' => 'passthrough',
		),
	),
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('fe_users',$tmp_mffdb_columns);

/* inherit and extend the show items from the parent class */

if(isset($GLOBALS['TCA']['fe_users']['types']['0']['showitem'])) {
	$GLOBALS['TCA']['fe_users']['types']['Tx_Mffdb_Ecouser']['showitem'] = $GLOBALS['TCA']['fe_users']['types']['0']['showitem'];
} elseif(is_array($GLOBALS['TCA']['fe_users']['types'])) {
	// use first entry in types array
	$fe_users_type_definition = reset($GLOBALS['TCA']['fe_users']['types']);
	$GLOBALS['TCA']['fe_users']['types']['Tx_Mffdb_Ecouser']['showitem'] = $fe_users_type_definition['showitem'];
} else {
	$GLOBALS['TCA']['fe_users']['types']['Tx_Mffdb_Ecouser']['showitem'] = '';
}
$GLOBALS['TCA']['fe_users']['types']['Tx_Mffdb_Ecouser']['showitem'] .= ',--div--;LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_ecouser,';
$GLOBALS['TCA']['fe_users']['types']['Tx_Mffdb_Ecouser']['showitem'] .= 'eco_acronym, eco_key, eco_klasse,cloud_quota';

$GLOBALS['TCA']['fe_users']['columns'][$GLOBALS['TCA']['fe_users']['ctrl']['type']]['config']['items'][] = array('LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:fe_users.tx_extbase_type.Tx_Mffdb_Ecouser','Tx_Mffdb_Ecouser');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr(
	'',
	'EXT:/Resources/Private/Language/locallang_csh_.xlf'
);