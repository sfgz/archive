<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender',
		'label' => 'ferientext',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'ferientext,beginn,ende,code,semestergrenze,privat,ganztag,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_kalender.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'ferientext, beginn, ende, code, semestergrenze, privat, ganztag',
	),
	'types' => array(
		'1' => array('showitem' => 'ferientext, beginn, ende, code, semestergrenze, privat, ganztag, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'ferientext' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.ferientext',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'beginn' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.beginn',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'ende' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.ende',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'code' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.code',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'semestergrenze' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.semestergrenze',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'privat' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.privat',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'ganztag' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kalender.ganztag',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		
	),
);