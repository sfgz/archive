<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse',
		'label' => 'class_short',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,
		'default_sortby' => 'class_short',

		'enablecolumns' => array(

		),
		'searchFields' => 'class_short,klassenname,klasse_kurz,klasse_jahr,klasse_zug,klasse_start,klasse_ende,department_id,classteacher_id,class_id,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_klasse.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'class_short, klassenname, klasse_kurz, klasse_jahr, klasse_zug, klasse_start, klasse_ende, department_id, classteacher_id, class_id,ref_class_id',
	),
	'types' => array(
		'1' => array('showitem' => 'class_short, klassenname, klasse_kurz, klasse_jahr, klasse_zug, klasse_start, klasse_ende, department_id, classteacher_id, class_id, ref_class_id'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'class_short' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.class_short',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'klassenname' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klassenname',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'klasse_kurz' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klasse_kurz',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'klasse_jahr' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klasse_jahr',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'klasse_zug' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klasse_zug',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'klasse_start' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klasse_start',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'klasse_ende' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.klasse_ende',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'department_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.department_id',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'classteacher_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.classteacher_id',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'class_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_klasse.class_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		
		'ref_class_id' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		
		'kurzklasse' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);