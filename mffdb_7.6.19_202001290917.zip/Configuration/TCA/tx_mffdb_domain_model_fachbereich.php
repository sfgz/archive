<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich',
		'label' => 'fachbereichname',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,
		'sortby' => 'sorting',

		'enablecolumns' => array(

		),
		'searchFields' => 'fachbereichname,cloud_key,hide_public,ignore_holiday,long_subject,usergroup,fb_kurzklassen,fb_teachers,fb_kursregeln,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_fachbereich.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'fachbereichname, cloud_key, hide_public, ignore_holiday, long_subject, usergroup, fb_kurzklassen, fb_kursregeln, fb_teachers, sorting',
	),
	'types' => array(
		'1' => array('showitem' => 'fachbereichname, cloud_key, hide_public, ignore_holiday, long_subject, usergroup, fb_kurzklassen, fb_kursregeln, fb_teachers, sorting,'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'fachbereichname' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.fachbereichname',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'cloud_key' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.cloud_key',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'hide_public' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.hide_public',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'ignore_holiday' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.ignore_holiday',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'long_subject' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.long_subject',
			'config' => array(
				'type' => 'check',
				'default' => 0
			)
		),
		'usergroup' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.usergroup',
			'config' => array(
				'type' => 'select',
				'items' => array( array('keine', 0)),
				'foreign_table' => 'fe_groups',
				'foreign_table_where' => 'AND fe_groups.pid=###CURRENT_PID###',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'fb_kurzklassen' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.fb_kurzklassen',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_kurzklasse',
				'foreign_field' => 'fachbereich',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'fb_kursregeln' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.fb_kursregeln',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_kursregel',
				'foreign_field' => 'fachbereich',
				'foreign_sortby' => 'sorting',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'useSortable' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'fb_teachers' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_fachbereich.fb_teachers',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_teacherrelation',
				'foreign_field' => 'fachbereich',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		'sorting' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
		
	),
);