<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs',
		'label' => 'course_id',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'course_id,kurs_start,kurs_ende,department_id,course_short,kurse_klassen,kurs_plaene,fach',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_kurs.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'course_id, ref_course_id, tstamp,kurs_start, kurs_ende, department_id, course_short, kurse_klassen, kurs_plaene, fach',
	),
	'types' => array(
		'1' => array('showitem' => 'course_id, ref_course_id, tstamp,kurs_start, kurs_ende, department_id, course_short, kurse_klassen, kurs_plaene, fach'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'course_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.course_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'ref_course_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.ref_course_id',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'tstamp' => array(
			'exclude' => 0,
			'label' => 'tstamp',
			'config' => array(
				'type' => 'passthrough'
			)
		),
		'kurs_start' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.kurs_start',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'kurs_ende' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.kurs_ende',
			'config' => array(
				'type' => 'input',
				'size' => 13,
				'max' => 20,
				'eval' => 'datetime',
				'checkbox' => 0,
				'default' => 0
			)
		),
		'department_id' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.department_id',
			'config' => array(
				'type' => 'input',
				'size' => 4,
				'eval' => 'int'
			)
		),
		'course_short' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.course_short',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'kurse_klassen' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.kurse_klassen',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_klasse',
				'foreign_table_where' => 'AND 1=1 Order by class_short ASC',
				'MM' => 'tx_mffdb_kurs_klasse_mm',
				'size' => 10,
				'autoSizeMax' => 30,
				'maxitems' => 9999,
				'multiple' => 0,
				'wizards' => array(
					'_PADDING' => 1,
					'_VERTICAL' => 1,
					'edit' => array(
						'module' => array(
							'name' => 'wizard_edit',
						),
						'type' => 'popup',
						'title' => 'Edit',
						'icon' => 'edit2.gif',
						'popup_onlyOpenIfSelected' => 1,
						'JSopenParams' => 'height=350,width=580,status=0,menubar=0,scrollbars=1',
						),
					'add' => Array(
						'module' => array(
							'name' => 'wizard_add',
						),
						'type' => 'script',
						'title' => 'Create new',
						'icon' => 'add.gif',
						'params' => array(
							'table' => 'tx_mffdb_domain_model_klasse',
							'pid' => '###CURRENT_PID###',
							'setValue' => 'prepend'
						),
					),
				),
			),
		),
		'kurs_plaene' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurs.kurs_plaene',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_stundenplan',
				'foreign_field' => 'kurs',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 1,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		
		'fach' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);