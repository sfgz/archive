<?php
return array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurzklasse',
		'label' => 'kurzbezeichnung',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'enablecolumns' => array(

		),
		'searchFields' => 'kurzbezeichnung,klassennamen,krz_cloudquota,krz_klassen,',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath('mffdb') . 'Resources/Public/Icons/tx_mffdb_domain_model_kurzklasse.gif'
	),
	'interface' => array(
		'showRecordFieldList' => 'kurzbezeichnung, klassennamen, krz_cloudquota, krz_klassen',
	),
	'types' => array(
		'1' => array('showitem' => 'kurzbezeichnung, klassennamen, krz_cloudquota, krz_klassen, '),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(

		'kurzbezeichnung' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurzklasse.kurzbezeichnung',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'klassennamen' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurzklasse.klassennamen',
			'config' => array(
				'type' => 'input',
				'size' => 30,
				'eval' => 'trim'
			),
		),
		'krz_cloudquota' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurzklasse.krz_cloudquota',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_mffdb_domain_model_cloudquota',
				'minitems' => 0,
				'maxitems' => 1,
			),
		),
		'krz_klassen' => array(
			'exclude' => 0,
			'label' => 'LLL:EXT:mffdb/Resources/Private/Language/locallang_db.xlf:tx_mffdb_domain_model_kurzklasse.krz_klassen',
			'config' => array(
				'type' => 'inline',
				'foreign_table' => 'tx_mffdb_domain_model_klasse',
				'foreign_field' => 'kurzklasse',
				'maxitems' => 9999,
				'appearance' => array(
					'collapseAll' => 0,
					'levelLinksPosition' => 'top',
					'showSynchronizationLink' => 1,
					'showPossibleLocalizationRecords' => 1,
					'showAllLocalizationLink' => 1
				),
			),

		),
		
		'fachbereich' => array(
			'config' => array(
				'type' => 'passthrough',
			),
		),
	),
);