<?php
namespace Mff\Mffdb\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *  			
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class Mff\Mffdb\Controller\CloudquotaController.
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class CloudquotaControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \Mff\Mffdb\Controller\CloudquotaController
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = $this->getMock('Mff\\Mffdb\\Controller\\CloudquotaController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllCloudquotasFromRepositoryAndAssignsThemToView() {

		$allCloudquotas = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$cloudquotaRepository = $this->getMock('', array('findAll'), array(), '', FALSE);
		$cloudquotaRepository->expects($this->once())->method('findAll')->will($this->returnValue($allCloudquotas));
		$this->inject($this->subject, 'cloudquotaRepository', $cloudquotaRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('cloudquotas', $allCloudquotas);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenCloudquotaToView() {
		$cloudquota = new \Mff\Mffdb\Domain\Model\Cloudquota();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newCloudquota', $cloudquota);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($cloudquota);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenCloudquotaToCloudquotaRepository() {
		$cloudquota = new \Mff\Mffdb\Domain\Model\Cloudquota();

		$cloudquotaRepository = $this->getMock('', array('add'), array(), '', FALSE);
		$cloudquotaRepository->expects($this->once())->method('add')->with($cloudquota);
		$this->inject($this->subject, 'cloudquotaRepository', $cloudquotaRepository);

		$this->subject->createAction($cloudquota);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenCloudquotaToView() {
		$cloudquota = new \Mff\Mffdb\Domain\Model\Cloudquota();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('cloudquota', $cloudquota);

		$this->subject->editAction($cloudquota);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenCloudquotaInCloudquotaRepository() {
		$cloudquota = new \Mff\Mffdb\Domain\Model\Cloudquota();

		$cloudquotaRepository = $this->getMock('', array('update'), array(), '', FALSE);
		$cloudquotaRepository->expects($this->once())->method('update')->with($cloudquota);
		$this->inject($this->subject, 'cloudquotaRepository', $cloudquotaRepository);

		$this->subject->updateAction($cloudquota);
	}
}
