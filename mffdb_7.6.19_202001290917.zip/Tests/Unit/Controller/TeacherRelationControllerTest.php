<?php
namespace Mff\Mffdb\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *  			
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class Mff\Mffdb\Controller\TeacherRelationController.
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class TeacherRelationControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {

	/**
	 * @var \Mff\Mffdb\Controller\TeacherRelationController
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = $this->getMock('Mff\\Mffdb\\Controller\\TeacherRelationController', array('redirect', 'forward', 'addFlashMessage'), array(), '', FALSE);
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllTeacherRelationsFromRepositoryAndAssignsThemToView() {

		$allTeacherRelations = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$teacherRelationRepository = $this->getMock('', array('findAll'), array(), '', FALSE);
		$teacherRelationRepository->expects($this->once())->method('findAll')->will($this->returnValue($allTeacherRelations));
		$this->inject($this->subject, 'teacherRelationRepository', $teacherRelationRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('teacherRelations', $allTeacherRelations);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenTeacherRelationToView() {
		$teacherRelation = new \Mff\Mffdb\Domain\Model\TeacherRelation();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newTeacherRelation', $teacherRelation);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($teacherRelation);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenTeacherRelationToTeacherRelationRepository() {
		$teacherRelation = new \Mff\Mffdb\Domain\Model\TeacherRelation();

		$teacherRelationRepository = $this->getMock('', array('add'), array(), '', FALSE);
		$teacherRelationRepository->expects($this->once())->method('add')->with($teacherRelation);
		$this->inject($this->subject, 'teacherRelationRepository', $teacherRelationRepository);

		$this->subject->createAction($teacherRelation);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenTeacherRelationToView() {
		$teacherRelation = new \Mff\Mffdb\Domain\Model\TeacherRelation();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('teacherRelation', $teacherRelation);

		$this->subject->editAction($teacherRelation);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenTeacherRelationInTeacherRelationRepository() {
		$teacherRelation = new \Mff\Mffdb\Domain\Model\TeacherRelation();

		$teacherRelationRepository = $this->getMock('', array('update'), array(), '', FALSE);
		$teacherRelationRepository->expects($this->once())->method('update')->with($teacherRelation);
		$this->inject($this->subject, 'teacherRelationRepository', $teacherRelationRepository);

		$this->subject->updateAction($teacherRelation);
	}
}
