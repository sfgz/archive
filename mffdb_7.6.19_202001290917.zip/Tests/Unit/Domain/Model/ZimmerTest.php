<?php

namespace Mff\Mffdb\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Mff\Mffdb\Domain\Model\Zimmer.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class ZimmerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \Mff\Mffdb\Domain\Model\Zimmer
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = new \Mff\Mffdb\Domain\Model\Zimmer();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getZimmerReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getZimmer()
		);
	}

	/**
	 * @test
	 */
	public function setZimmerForStringSetsZimmer() {
		$this->subject->setZimmer('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'zimmer',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getHausReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getHaus()
		);
	}

	/**
	 * @test
	 */
	public function setHausForStringSetsHaus() {
		$this->subject->setHaus('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'haus',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getBesonderesReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getBesonderes()
		);
	}

	/**
	 * @test
	 */
	public function setBesonderesForStringSetsBesonderes() {
		$this->subject->setBesonderes('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'besonderes',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getTelefonReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getTelefon()
		);
	}

	/**
	 * @test
	 */
	public function setTelefonForStringSetsTelefon() {
		$this->subject->setTelefon('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'telefon',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getPreiseReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getPreise()
		);
	}

	/**
	 * @test
	 */
	public function setPreiseForStringSetsPreise() {
		$this->subject->setPreise('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'preise',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getAusschliessenReturnsInitialValueForBool() {
		$this->assertSame(
			FALSE,
			$this->subject->getAusschliessen()
		);
	}

	/**
	 * @test
	 */
	public function setAusschliessenForBoolSetsAusschliessen() {
		$this->subject->setAusschliessen(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'ausschliessen',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLocationIdReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getLocationId()
		);
	}

	/**
	 * @test
	 */
	public function setLocationIdForStringSetsLocationId() {
		$this->subject->setLocationId('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'locationId',
			$this->subject
		);
	}
}
