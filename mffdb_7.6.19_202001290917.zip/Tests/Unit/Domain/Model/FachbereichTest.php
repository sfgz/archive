<?php

namespace Mff\Mffdb\Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \Mff\Mffdb\Domain\Model\Fachbereich.
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Daniel Rueegg <daten@verarbeitung.ch>
 */
class FachbereichTest extends \TYPO3\CMS\Core\Tests\UnitTestCase {
	/**
	 * @var \Mff\Mffdb\Domain\Model\Fachbereich
	 */
	protected $subject = NULL;

	public function setUp() {
		$this->subject = new \Mff\Mffdb\Domain\Model\Fachbereich();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getFachbereichnameReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getFachbereichname()
		);
	}

	/**
	 * @test
	 */
	public function setFachbereichnameForStringSetsFachbereichname() {
		$this->subject->setFachbereichname('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'fachbereichname',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getCloudKeyReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getCloudKey()
		);
	}

	/**
	 * @test
	 */
	public function setCloudKeyForStringSetsCloudKey() {
		$this->subject->setCloudKey('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'cloudKey',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getHidePublicReturnsInitialValueForBool() {
		$this->assertSame(
			FALSE,
			$this->subject->getHidePublic()
		);
	}

	/**
	 * @test
	 */
	public function setHidePublicForBoolSetsHidePublic() {
		$this->subject->setHidePublic(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'hidePublic',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getLongSubjectReturnsInitialValueForBool() {
		$this->assertSame(
			FALSE,
			$this->subject->getLongSubject()
		);
	}

	/**
	 * @test
	 */
	public function setLongSubjectForBoolSetsLongSubject() {
		$this->subject->setLongSubject(TRUE);

		$this->assertAttributeEquals(
			TRUE,
			'longSubject',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFbKurzklassenReturnsInitialValueForKurzklasse() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getFbKurzklassen()
		);
	}

	/**
	 * @test
	 */
	public function setFbKurzklassenForObjectStorageContainingKurzklasseSetsFbKurzklassen() {
		$fbKurzklassen = new \Mff\Mffdb\Domain\Model\Kurzklasse();
		$objectStorageHoldingExactlyOneFbKurzklassen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneFbKurzklassen->attach($fbKurzklassen);
		$this->subject->setFbKurzklassen($objectStorageHoldingExactlyOneFbKurzklassen);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneFbKurzklassen,
			'fbKurzklassen',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addFbKurzklassenToObjectStorageHoldingFbKurzklassen() {
		$fbKurzklassen = new \Mff\Mffdb\Domain\Model\Kurzklasse();
		$fbKurzklassenObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$fbKurzklassenObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($fbKurzklassen));
		$this->inject($this->subject, 'fbKurzklassen', $fbKurzklassenObjectStorageMock);

		$this->subject->addFbKurzklassen($fbKurzklassen);
	}

	/**
	 * @test
	 */
	public function removeFbKurzklassenFromObjectStorageHoldingFbKurzklassen() {
		$fbKurzklassen = new \Mff\Mffdb\Domain\Model\Kurzklasse();
		$fbKurzklassenObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$fbKurzklassenObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($fbKurzklassen));
		$this->inject($this->subject, 'fbKurzklassen', $fbKurzklassenObjectStorageMock);

		$this->subject->removeFbKurzklassen($fbKurzklassen);

	}

	/**
	 * @test
	 */
	public function getFbTeachersReturnsInitialValueForTeacherRelation() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getFbTeachers()
		);
	}

	/**
	 * @test
	 */
	public function setFbTeachersForObjectStorageContainingTeacherRelationSetsFbTeachers() {
		$fbTeacher = new \Mff\Mffdb\Domain\Model\TeacherRelation();
		$objectStorageHoldingExactlyOneFbTeachers = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneFbTeachers->attach($fbTeacher);
		$this->subject->setFbTeachers($objectStorageHoldingExactlyOneFbTeachers);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneFbTeachers,
			'fbTeachers',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addFbTeacherToObjectStorageHoldingFbTeachers() {
		$fbTeacher = new \Mff\Mffdb\Domain\Model\TeacherRelation();
		$fbTeachersObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$fbTeachersObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($fbTeacher));
		$this->inject($this->subject, 'fbTeachers', $fbTeachersObjectStorageMock);

		$this->subject->addFbTeacher($fbTeacher);
	}

	/**
	 * @test
	 */
	public function removeFbTeacherFromObjectStorageHoldingFbTeachers() {
		$fbTeacher = new \Mff\Mffdb\Domain\Model\TeacherRelation();
		$fbTeachersObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$fbTeachersObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($fbTeacher));
		$this->inject($this->subject, 'fbTeachers', $fbTeachersObjectStorageMock);

		$this->subject->removeFbTeacher($fbTeacher);

	}

	/**
	 * @test
	 */
	public function getFbKursregelnReturnsInitialValueForKursregel() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getFbKursregeln()
		);
	}

	/**
	 * @test
	 */
	public function setFbKursregelnForObjectStorageContainingKursregelSetsFbKursregeln() {
		$fbKursregeln = new \Mff\Mffdb\Domain\Model\Kursregel();
		$objectStorageHoldingExactlyOneFbKursregeln = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneFbKursregeln->attach($fbKursregeln);
		$this->subject->setFbKursregeln($objectStorageHoldingExactlyOneFbKursregeln);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneFbKursregeln,
			'fbKursregeln',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addFbKursregelnToObjectStorageHoldingFbKursregeln() {
		$fbKursregeln = new \Mff\Mffdb\Domain\Model\Kursregel();
		$fbKursregelnObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$fbKursregelnObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($fbKursregeln));
		$this->inject($this->subject, 'fbKursregeln', $fbKursregelnObjectStorageMock);

		$this->subject->addFbKursregeln($fbKursregeln);
	}

	/**
	 * @test
	 */
	public function removeFbKursregelnFromObjectStorageHoldingFbKursregeln() {
		$fbKursregeln = new \Mff\Mffdb\Domain\Model\Kursregel();
		$fbKursregelnObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$fbKursregelnObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($fbKursregeln));
		$this->inject($this->subject, 'fbKursregeln', $fbKursregelnObjectStorageMock);

		$this->subject->removeFbKursregeln($fbKursregeln);

	}
}
