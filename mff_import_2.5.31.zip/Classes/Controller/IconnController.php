<?php
namespace Mff\MffImport\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * IconnController
 */
class IconnController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * conf
	 * Configuration
	 *
	 * @var array
	 */
	public $conf = array(
	      'iconnPath'=>'' ,
	      'iconnFile'=>'' 
	);
	
	/**
	 * action upload
	 *
	 * @return void
	 */
	public function uploadAction() {
	    $ts = $this->configurationManager->getConfiguration('FullTypoScript');
	    
	    $this->settings = $ts['plugin.']['tx_mffimport_iconn.']['settings.'] ;
	    $this->conf['iconnPath'] = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($this->settings['iconnPath']) ;
	    $this->conf['iconnFile'] = $this->conf['iconnPath'] . $this->settings['iconnFile'];
		$this->settings['formname'] = 'uploadform';
		
		$this->view->assign( 'formname' , $this->settings['formname'] );
		
		// the name of upload-button is ecoklasse
		if($this->request->hasArgument('ecoklasse')) {
		    $uploadOk = $this->uploadCsvFile( $this->conf['iconnPath'] );
		    $schedulerFilesTask = new \Mff\MffImport\Command\FixRelationsCommandController();
		    // the FixRelationsCommandController()->fixTable() calls 
		    // -> StudClassFromFileCommandController() that sanitizes the file and renames it!
		    $messages =$schedulerFilesTask->fixTable('ecoklasse');
		    $this->addFlashMessage('Datei umbenannt zu ' . pathinfo( $this->conf['iconnFile'] , PATHINFO_BASENAME ) , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		    
		    if(is_array($messages)){
				foreach($messages as $errNr => $msgMainrows){
					foreach($msgMainrows as $msgRows){
						if( $errNr ){
								++$hasErrors;
								$this->addFlashMessage(''.$errNr.': '.$msgRows, '',  \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
						}else{
								$errPieces = explode( ' ' , trim($msgRows) );
								if($errPieces[0] != 0) $this->addFlashMessage(''.$msgRows, '',  \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
						}
					}
				}
		    }
		    $this->addFlashMessage('Lernende mit Klassen verbunden am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		}
		$iconnfile = (file_exists($this->conf['iconnFile'])) ? filemtime($this->conf['iconnFile']): '' ;
		$this->view->assign('iconnfile', $iconnfile);
	}

	/**
	 * handles file upload and deletion 
	 * returns string with filename, if action successful
	 *
	 * @param string $uploadDir
	 * @return string
	 */
	public function uploadCsvFile( $uploadDir  ) {
		$fileName = '';
		if( !$this->request->hasArgument('dateiname') ) return;
		$extKeyPlgNam = 'tx_mffimport_is2import';
		if ($_FILES[$extKeyPlgNam]['tmp_name']['dateiname']) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name']['dateiname'];
			if( file_exists($uploadDir.$fileName) ) @unlink($uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name']['dateiname'] , $uploadDir.$fileName );
			$this->addFlashMessage('Datei "'.$fileName.'" hochgeladen.'  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}
		return $fileName;
	}

}
