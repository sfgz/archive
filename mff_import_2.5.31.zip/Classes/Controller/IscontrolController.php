<?php
namespace Mff\MffImport\Controller;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Dani Rüegg <dani@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * IscontrolController
 */
class IscontrolController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {
	
	/**
	 * dumpPath
	 * 
	 * @var string
	 */
	protected $dumpPath = '';
	
	/**
	 * jsonPath
	 * 
	 * @var string
	 */
	protected $jsonPath = '';
	
	/**
	 * fileList
	 * 
	 * @var array
	 */
	protected $fileList = array();

	/**
	 * tablesRepository
	 *
	 * @var \Mff\MffImport\Domain\Repository\TablesRepository
	 * @inject
	 */
	protected $tablesRepository = NULL;
	
	/**
	* Initializes the controller before invoking an action method.
	* @return void
	*/
	protected function initializeAction() {
	    $ts = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		//$rawTables = $ts['module.']['tx_mffimport_iscontrol.']['settings.']['tables'];
	    //$ts = $this->configurationManager->getConfiguration('FullTypoScript');
	    $settings = $ts['plugin.']['tx_mffimport_iconn.']['settings.'] ;
	    $this->conf['iconnPath'] = rtrim( \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName($settings['iconnPath']) , '/' ) . '/';
	    $this->conf['iconnFile'] = $this->conf['iconnPath'] . $settings['iconnFile'];

	    $extPath = dirname(dirname(dirname(__FILE__)));
	    $this->dumpPath = dirname(dirname(dirname($extPath))).'/uploads/tx_mffimport/backups';
	    $this->jsonPath = dirname(dirname(dirname($extPath))).'/uploads/tx_svconnectormff';
	}

	/**
	 * action info
	 *
	 * @return void
	 */
	public function infoAction() {
 		$tableDef = array( 
		    'Ecouser'=>'30,380,190,160',
		    'TeacherRelation'=>'660,380,190,160',
		    'Fachbereich'=>'680,10,195,195',
		    'Kursregel'=>'670,220,195,135',
		    'Fach'=>'450,210,195,175',
		    'Cloudquota'=>'230,15,195,135',
		    'Kurzklasse'=>'440,20,195,175',
		    'Klasse'=>'30,230,195,135',
		    'Kurs'=>'240,200,195,95',
		    'KurseKlassen'=>'220,305,215,20',
		    'Zimmer'=>'230,440,195,135',
		    'Stundenplan'=>'445,415,195,175',
		    'Kalender'=>'10,35,195,135',
 		);
 		$additionalTables = array( 
		    'Ecouser' => 'fe_users', 
		    'KurseKlassen' => 'tx_mffdb_kurs_klasse_mm'
 		);
 		$tableInfo = array();
  		// prepend default-strings to short-name of tables
		foreach( array_keys($tableDef) as $shortName ) $tableInfo[$shortName]['tablename'] = 'tx_mffdb_domain_model_'.strtolower($shortName);
 		// override name of additional tables
 		foreach( $additionalTables as $shortName => $tabNam ) $tableInfo[$shortName]['tablename'] = $tabNam;
 		foreach($tableInfo as $shortName => $tabRow ){
		    $tableInfo[$shortName]['fields'] = $this->tablesRepository->execQueryStatement( 'SHOW COLUMNS FROM '.$tabRow['tablename'] );
		    foreach( array_keys($tableInfo[$shortName]['fields']) as $ix  ){
			unset($tableInfo[$shortName]['fields'][$ix]['Null']);
			unset($tableInfo[$shortName]['fields'][$ix]['Default']);
		    }
		    $rawCords = explode( ',' , $tableDef[$shortName] );
		    $rawCords[2] += $rawCords[0];
		    $rawCords[3] += $rawCords[1];
		    $tableInfo[$shortName]['coords'] = implode( ',' , $rawCords);
 		}
 		ksort($tableInfo);
		$this->view->assign('tableInfo', $tableInfo  );
	}

	/**
	 * action import 
	 * import again from cached json-file
	 *
	 * @return void
	 */
	public function importAction() {
	
		if($this->request->hasArgument('backup')) {
		    $this->backup_actions();

		}elseif($this->request->hasArgument('unlinkJson')) {
		    $fileToUnlink = $this->request->getArgument('unlinkJson');
		    unlink($this->jsonPath.'/'.$fileToUnlink.'.txt');
		    $this->addFlashMessage('Deleted file from '.date('d.m.y H:i',$fileToUnlink).' on '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('importfile')) {
		    $this->import_jsonfile();
		    
		}

		$extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['svconnector_mff']);
		$this->view->assign('extConf', $extConf);
		
		$fileSizeSum = $this->read_file_list( $this->jsonPath , 'txt');
		$this->view->assign('filelist', $this->fileList);
		$this->view->assign('fileSizeSum', $fileSizeSum  );
		
		$ts = $this->configurationManager->getConfiguration('FullTypoScript');
		$baseUrl = $ts['config.']['baseURL'] . 'uploads/tx_svconnectormff/';
		$this->view->assign('url2archive', $baseUrl);
	}
	
	/**
	 * import_jsonfile
	 *
	 * @return void
	 */
	public function import_jsonfile() {
		$filnam = $this->request->getArgument('importfile').'.txt';
		$filePathName = $this->jsonPath . '/' . $filnam;
		$tabIndex = array( 'teacher'=>0 , 'students'=>1 );
		$startpos = strpos($filnam,'_')+1;
		$tabPartNam = substr( $filnam , $startpos , strlen($filnam)-($startpos+4) );
		// prefix tablename if not table fe_users
		if( isset($tabIndex[$tabPartNam]) ){
		    $tableName =  'fe_users';
		    $index = $tabIndex[$tabPartNam];
		}else{
		    $tableName = 'tx_mffdb_domain_model_'.$tabPartNam ;
		    $index = 0;
		}
		// try to run external importer
		if(!isset($GLOBALS['TCA'][$tableName]['ctrl']['external'][$index]['parameters'])){
		      $this->addFlashMessage('ERROR: No TCA definition found for table '.$tableName.'. File: <a target="_blank" href="/uploads/tx_svconnectormff/'.$filnam.'">'.$filnam.'</a>.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		      return false;
		}elseif( !file_exists($filePathName) ){
		      $this->addFlashMessage('ERROR: File '.$filePathName.' not found.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		      return false;
		}else{
		      $GLOBALS['TCA'][$tableName]['ctrl']['external'][$index]['parameters']['filename'] = $filePathName ;
		      // Instantiate the import object
		      $importer = new \Cobweb\ExternalImport\Importer;
		      $messages = $importer->synchronizeData($tableName, $index);
		      unset($GLOBALS['TCA'][$tableName]['ctrl']['external'][$index]['parameters']['filename']);
		      $globalStatus = 'OK';
		      if (count($messages['error']) > 0) {
			      $globalStatus = 'ERROR';
		      } elseif (count($messages['warning']) > 0) {
			      $globalStatus = 'WARNING';
		      }
		      if ($globalStatus != 'OK') {
			  $this->addFlashMessage('One or more '.$globalStatus.' happened while importing table '.$tableName.'.', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		      }else{
			  $this->addFlashMessage('table '.$tableName.' processed: ' . implode( ", \n" , $messages[0] ) . '.' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		      }
		}
		return true;
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {

		$this->actions_controller();

		$extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);
		$this->view->assign('extConf', $extConf);
		$ts = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$mffDbExtConf = $ts['plugin.']['tx_mffdb_fbv.']['settings.'] ;//
		$mffDbExtConf['storagePid'] = $ts['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'] ;//
		$this->view->assign('mffDbExtConf', $mffDbExtConf);
		
		$iconnfile = (file_exists($this->conf['iconnFile'])) ? filemtime($this->conf['iconnFile']): '' ;
		$this->view->assign('iconnfile', $iconnfile);
		
		$fileSizeSum = $this->read_file_list( $this->dumpPath );
		$this->view->assign('filelist', $this->fileList);
		$this->view->assign('fileSizeSum', $fileSizeSum  );
		
		$ts = $this->configurationManager->getConfiguration('FullTypoScript');
		$baseUrl = $ts['config.']['baseURL'] . 'uploads/tx_mffimport/backups/';
		$this->view->assign('url2archive', $baseUrl);
	}

	/**
	 * action list
	 *
	 * @return void
	 */
	public function actions_controller() {
		if($this->request->hasArgument('backup')) {
		    $this->backup_actions();

		}elseif($this->request->hasArgument('restore')) {
		    $this->backup_actions();
		    $fileToRestore = $this->request->getArgument('restore');
		    $error = $this->restore_from_dump($fileToRestore);
		    if( $error ) {
			$this->addFlashMessage('There are '.count($error).' Errors', '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }else{
			$filesize = round( filesize($this->dumpPath.'/'.$fileToRestore.'.sql') / 1024 , 1 );
			$restoreText = 'Restored file from '.date('d.m.y H:i',$fileToRestore) . ' ('.$filesize.' Kb) ';
			$schedulerTask = new \Mff\MffImport\Command\FixRelationsCommandController();
			$executed['Planteacher'] = $schedulerTask->fixTable('planteacher')==true ? 1 : 0;
			$executed['Ecoklasse'] = $schedulerTask->fixTable('ecoklasse')==true ? 1 : 0;
			$executed['Kurzklasse'] = $schedulerTask->fixTable('kurzklasse')==true ? 1 : 0;
			$schedulerTask = new \Mff\MffImport\Command\TeacherrelationsCommandController();
			$executed['Teacherrelations'] = $schedulerTask->execute()==true ? 1 : 0;
			$schedulerTask = new \Mff\MffImport\Command\KursregelCommandController();
			$executed['Kursregel'] = $schedulerTask->execute()==true ? 1 : 0;
			if( array_sum($executed) == count($executed)){
			    $this->addFlashMessage($restoreText.'and executed all intendet Actions on '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
			}else{
			    $this->addFlashMessage($restoreText.'but executed only '.array_sum($executed).' from '.count($executed).' intendet Actions on '.date('d.m.y H:i').' ('.implode( ', ' , array_keys($executed) ).'='.implode( '' , $executed ).')' , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
			}
		    }
		    
		}elseif($this->request->hasArgument('clean')) {
		    $this->backup_actions();
		    $schedulerTask = new \Mff\MffImport\Command\CleartableCommandController();
		    $counter = $schedulerTask->execute();
		    if( count($counter) ){
		    $msg = array();
		    foreach( $counter as $nam => $sum ){ $msg[] = $nam.'='.$sum ; }
			$this->addFlashMessage('Cleared "'.array_sum($counter).'" recordsets in tables "timetable ('.implode( ', ' , $msg ).')" on '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		    }else{
			$this->addFlashMessage('Tables clearing failed! On '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		    }
		    
		}elseif($this->request->hasArgument('clearfiles')) {
		    $schedulerFilesTask = new \Mff\MffImport\Command\ClearfilesCommandController();
		    $schedulerFilesTask->execute();
		    $this->addFlashMessage('Cleared files on '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('unlinkSql')) {
		    $fileToUnlink = $this->request->getArgument('unlinkSql');
		    unlink($this->dumpPath.'/'.$fileToUnlink.'.sql');
		    $this->addFlashMessage('Deleted file from '.date('d.m.y H:i',$fileToUnlink).' on '.date('d.m.y H:i') , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('kursregel')) {
		    $schedulerFilesTask = new \Mff\MffImport\Command\KursregelCommandController();
		    $schedulerFilesTask->execute();
		    $this->addFlashMessage('Kursregeln auf Fach angewendet am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('teacherrelations')) {
		    $schedulerFilesTask = new \Mff\MffImport\Command\TeacherrelationsCommandController();
		    $schedulerFilesTask->execute();
		    $this->addFlashMessage('Lehrpersonen mit Fachbereichen verbunden am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		
		}elseif($this->request->hasArgument('ecoklasse')) {
		    $uploadOk = $this->uploadCsvFile( $this->conf['iconnPath']  );
		    $schedulerFilesTask = new \Mff\MffImport\Command\FixRelationsCommandController();
		    $messages =$schedulerFilesTask->fixTable('ecoklasse');
		    if(is_array($messages)){
			foreach($messages as $errNr => $msgMainrows){
			    foreach($msgMainrows as $msgRows){
				    if( $errNr ){
					++$hasErrors;
					$this->addFlashMessage(''.$errNr.': '.$msgRows, '',  \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
				    }else{
					$errPieces = explode( ' ' , trim($msgRows) );
					if($errPieces[0] != 0) $this->addFlashMessage(''.$msgRows, '',  \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
				    }
			    }
			}
		    }
		    $this->addFlashMessage('Lernende mit Klassen verbunden am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('planteacher')) {
		    $schedulerFilesTask = new \Mff\MffImport\Command\FixRelationsCommandController();
		    $schedulerFilesTask->fixTable('planteacher');
		    $this->addFlashMessage('Stundenplan mit Lehrpersonen verbunden am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}elseif($this->request->hasArgument('kurzklasse')) {
		    $schedulerFilesTask = new \Mff\MffImport\Command\KurzklasseCommandController();
		    $schedulerFilesTask->execute();
		    $this->addFlashMessage('Klassen mit Kurzklassen verbunden am '.date('d.m.y H:i')  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		
		}
	}

	/**
	 * handles file upload and deletion 
	 * returns string with filename, if action successful
	 *
	 * @param string $uploadDir
	 * @return string
	 */
	public function uploadCsvFile( $uploadDir  ) {
		$fileName = '';
		if( !$this->request->hasArgument('dateiname') ) return;
		$extKeyPlgNam = 'tx_mffimport_user_mffimportiscontrol';
		if ($_FILES[$extKeyPlgNam]['tmp_name']['dateiname']) {
			// UPLOAD
			$fileName = $_FILES[$extKeyPlgNam]['name']['dateiname'];
			if( file_exists($uploadDir.$fileName) ) @unlink($uploadDir.$fileName);
			\TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name']['dateiname'] , $uploadDir.$fileName );
			$this->addFlashMessage('Datei "'.$fileName.'" hochgeladen.'  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
		}else{
			$this->addFlashMessage('Datei "'.$_FILES[$extKeyPlgNam]['tmp_name']['dateiname'].'" nicht hochgeladen.'  , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
		}
		return $fileName;
	}
	
	/**
	 * restore_from_dump
	 *
	 * @param string $fileToRestore
	 * @return void
	 */
	public function restore_from_dump($fileToRestore) {
		$restoreCommand = 'mysql -h '.TYPO3_db_host.' -u '.TYPO3_db_username.' -p'.TYPO3_db_password.' '.TYPO3_db.' < '.$this->dumpPath.'/'.$fileToRestore.'.sql ';
		exec($restoreCommand,$error);
		return $error;
	}
	
	/**
	 * backup_actions
	 *
	 * @return void
	 */
	public function backup_actions() {
		$settings = $this->configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$rawTables = $settings['module.']['tx_mffimport_iscontrol.']['settings.']['tables'];
		
		$schedulerTask = new \Mff\MffImport\Command\SqldumpCommandController();
		$schedulerTask->execute();
		$this->addFlashMessage('Backup saved '.date('d.m.y H:i') . ' with Tables: '.$rawTables , '', \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
		return true;
	}
	
	/**
	 * create a list of files 
	 * and return the sum of all filesizes
	 *
	 * @return int
	 */
	public function read_file_list( $path , $suffix='sql') {
		$d = dir( $path );
		$filelist = array();
		$fileSizeSum = 0;
		while (false !== ($entry = $d->read())) {
		      $filename = pathinfo($entry , PATHINFO_FILENAME);
		      $extension = pathinfo($entry , PATHINFO_EXTENSION);
		      if( $suffix == $extension && ($suffix !='sql' || is_numeric($filename) ) ){
			  $filelist[$filename]['filename'] = $filename;
			  $filSize = filesize($path.'/'.$entry);
			  $filelist[$filename]['size'] = round( $filSize / 1024 , 3 );
			  $filelist[$filename]['date'] = filemtime( $path.'/'.$entry );
			  $filelist[$filename]['nameparts'] = explode( '_' , $filename );
			  $fileSizeSum += $filSize;
		      }
		}
		$d->close();
		krsort($filelist);
		$this->fileList = $filelist;
		
		$roundetFileSizes = round( $fileSizeSum / 1024 , 1 );
		if( $roundetFileSizes > 1024 ) {
		    $formattedSum = number_format( $roundetFileSizes / 1024  , 1 , '.' , "'" ) . ' MB';
		}else{
		    $formattedSum = number_format( $roundetFileSizes  , 1 , '.' , "'" ) . ' KB';
		}

		return $formattedSum;
	}
}
