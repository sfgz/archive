<?php
namespace Mff\MffImport\Utility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <daten@verarbeitung.ch>, medienformfarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class AdjustScoolclassUtility
 */

class AdjustScoolclassUtility implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * AdjustScoolclass
	 * adjusts wrong or missing whitespace eg. HFIAD 17 A, LA17B (instead HF17 A)
	 *
	 * @param string shortClass
	 * @return string formatted as schoolclass name like 'KLS17 B'
	 */
	public function AdjustScoolclass( $shortClass ) {
			// hack since LA18*C on 25 Feb 2019
			$shortClass = str_replace( '*' , ' ' , $shortClass );
			
			$aClassShort = explode( ' ' , $shortClass );
		    $yearPart = substr( $aClassShort[0] , strlen($aClassShort[0])-2 );
		    if( strlen($aClassShort[0]) >2 && is_numeric($yearPart) ){
					// classshort is delivered like 'PBB15 A' but we need the 'PBB' part
					$classPart = substr( $aClassShort[0] , 0 , strlen($aClassShort[0])-2 );
					$classSection = $aClassShort[1];
					$fullClassShort = $shortClass;
		    }else{
				// maybe wrong or missing whitespace HFIAD 17 A, LA17B
				$tShortClass = str_replace( ' ' , '' , $shortClass );
				$wordParts = array('kurz'=>'','jahr'=>'','zug'=>'');
				for( $z=0 ; $z < strlen($tShortClass) ; ++$z) {
					$testChar = substr( $tShortClass , $z , 1 );
					if( is_numeric($testChar) ){
						$wordParts['jahr'] .= $testChar;
					}else{
						if( empty($wordParts['jahr']) ){
							$wordParts['kurz'] .= $testChar;
						}else{
							$wordParts['zug'] .= $testChar;
						}
					}
				}
				if(!empty($wordParts['kurz'])){
					$classPart = $wordParts['kurz'];
					$yearPart = $wordParts['jahr'];
					$classSection = $wordParts['zug'];
					$fullClassShort = $wordParts['kurz'] . $wordParts['jahr'] . ' ' . $wordParts['zug'];
				}else{
					$classPart = $aClassShort[0];
					$yearPart = '';
					$classSection = '';
					$fullClassShort = $shortClass;
				}
		    }
		    return  $fullClassShort;
// 		    return array( $fullClassShort , $classPart , $yearPart , $classSection );
	}

}
