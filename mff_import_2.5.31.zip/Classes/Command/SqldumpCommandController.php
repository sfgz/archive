<?php
namespace Mff\MffImport\Command;
/**
 * Class SqldumpCommandController
 */
class SqldumpCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
    public function execute(){
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$rawTables = explode(',',$settings['module.']['tx_mffimport_iscontrol.']['settings.']['tables']);
		$prefix = 'tx_mffdb_domain_model_';
		foreach($rawTables as $tab){$aTablenames[] = $prefix . trim($tab);}
		
		$tabelle = implode( ' ' , $aTablenames );
		$extPath = dirname(dirname(dirname(__FILE__)));
		$tempPath  = dirname(dirname(dirname($extPath))).'/uploads/tx_mffimport/backups';
		$createCommand = 'mysqldump -h ' . TYPO3_db_host . 
					  ' -u ' . TYPO3_db_username .
					  ' -p' . TYPO3_db_password . 
					  ' ' . TYPO3_db . ' ' . $tabelle . 
					  ' -r ' . $tempPath . '/' . time() . '.sql ';
		exec($createCommand,$error);
		return count($aTablenames);
    }
}