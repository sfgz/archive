<?php
namespace Mff\MffImport\Command;

/**
 * Class KursregelCommandController
 * Creates relations between tx_mffdb_domain_model_fachbereich and tx_mffdb_domain_model_fach
 * over tx_mffdb_domain_model_kursregel
 * 
 * used for Courses without classes 
 * or for the ABU-courses 
 */

  
class KursregelCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {

	/**
	 * fachRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\FachRepository
	 */
	protected $fachRepository = NULL;

	/**
	 * kursregelRepository
	 *
	 * @var \Mff\Mffdb\Domain\Repository\KursregelRepository
	 */
	protected $kursregelRepository = NULL;
	    
	protected $propertyMapper ;

	public function execute(){

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$this->propertyMapper = $objectManager->get('TYPO3\\CMS\\Extbase\\Property\\PropertyMapper');
		
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$extConf['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		$querySettings = $objectManager->get('TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings');
		$querySettings->setStoragePageIds( array($extConf['storagePid']) );

		$this->fachRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\FachRepository');
		$this->fachRepository->setDefaultQuerySettings($querySettings);
		
		$this->kursregelRepository = $objectManager->get('Mff\\Mffdb\\Domain\\Repository\\KursregelRepository');
		$this->kursregelRepository->setDefaultQuerySettings($querySettings);
		

		// TODO: This UPDATE-query is a hack to unset field 'fach_kursregel' - see below
		$GLOBALS['TYPO3_DB']->exec_UPDATEquery('tx_mffdb_domain_model_fach', '' , array( 'fach_kursregel'=>0 ) );

		$fachRecordsets = $this->fachRepository->findAll();
		$kursregelRecordsets = $this->kursregelRepository->findAll();
		
		$regeln = array();
		foreach( $fachRecordsets as $fachRow ){
		    $fachkurz =  $fachRow->getFachkurz() ;
		    if(empty($fachkurz))continue;
// 		    TODO: find a way to unset at first the field FachKursregel, following does not work:
// 		          $fachRow->setFachKursregel( $this->propertyMapper->convert( '0' , '\Mff\Mffdb\Domain\Model\Kursregel' )   );
// 		          $fachRepository->update($fachRow);
// 		    now done by $GLOBALS['TYPO3_DB']->exec_UPDATEquery() - see above
		    $fachArr = explode(' ' , $fachkurz );
		    $prefixFachkurz = $fachArr[0];
		    if( is_numeric($prefixFachkurz) ){ // numeric value could be from field1 to field2 (with 2 fields)
			foreach( $kursregelRecordsets as $regelRow ){
			    $regeln['wertAb'] = $regelRow->getWertAb();
			    $regeln['wertBis'] = $regelRow->getWertBis();
			    if( !is_numeric($regeln['wertAb']) ) continue;
			    if( $prefixFachkurz == $regeln['wertAb'] || 
					( $prefixFachkurz >= $regeln['wertAb'] && $prefixFachkurz <= $regeln['wertBis'] ) 
			    ){
						// dont touch if the right Kursregel-id is already set.
						$regelId = $this->propertyMapper->convert( $regelRow->getUid() , '\Mff\Mffdb\Domain\Model\Kursregel' ) ;
						if( $fachRow->getFachKursregel() ==  $regelId) break;
						// set the Kursregel-id
						$fachRow->setFachKursregel(  $regelRow  );
						$this->fachRepository->update($fachRow);
						break;
			    }
			}
		    }else{ // non-numeric value has only one field (no wertBis)
			foreach( $kursregelRecordsets as $regelRow ){
			    $regeln['wertAb'] = $regelRow->getWertAb();
			    if( $fachkurz == $regeln['wertAb'] ){
				// dont touch if the right Kursregel-id is already set.
				$regelId = $this->propertyMapper->convert( $regelRow->getUid() , '\Mff\Mffdb\Domain\Model\Kursregel' ) ;
				if( $fachRow->getFachKursregel() ==  $regelId) break;
				// set the Kursregel-id
				$fachRow->setFachKursregel(  $regelRow  );
				$this->fachRepository->update($fachRow);
				break;
			    }
			}
		    }
		}

		$persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');
 		$persistenceManager->persistAll();
		return true;
	}
	
}
