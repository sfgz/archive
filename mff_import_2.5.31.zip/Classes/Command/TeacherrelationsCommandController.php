<?php
namespace Mff\MffImport\Command;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Dani Rüegg <dani@verarbeitung.ch>, MedienFormFarbe
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TeacherrelationsCommandController
 * Creates relations between tx_mffdb_domain_model_fachbereich and fe_users
 * 
 * this relations are stored in table tx_mffdb_domain_model_teacherrelation
 * they can also be edited manually in List view of template Teacherrelation 
 * 
 */
class TeacherrelationsCommandController extends \TYPO3\CMS\Scheduler\Task\AbstractTask {
	    
	public $extConf = array(); // Extension configuration

	public function init(){ 
		// why not overwrite the constructor? for some reason the call parent::__construct(); does not work.
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);
		$this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

		$configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
 		$this->extConf['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
 		$this->extConf['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
 		$this->extConf['abuFbUid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['abuFbUid'];
		$this->extConf['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		$this->teacherRelationRepository = $this->objectManager->get('Mff\\Mffdb\\Domain\\Repository\\TeacherRelationRepository');
		$this->extConf['init'] = 1;
	}

	public function execute( ){
		if( !isset($this->extConf['init']) ) $this->init();
		$counter = 0;
		if( !isset($this->extConf['days_past']) ) {
		    $passedDays = ceil( 30.5 * $this->extConf['daterange_teacher_relations'] );
		}else{
		    $passedDays = $this->extConf['days_past']; 
		}
		
		// first make shure whe have correct relations between tx_mffdb_domain_model_stundenplan and fe_users
		$schedulerFixRelTask = new \Mff\MffImport\Command\FixRelationsCommandController();
		$schedulerFixRelTask->fixTable('planteacher');

		// look up for possible relations and crete them
		$teacherRelation = $this->evaluateTeacherRelations($passedDays);
		$createResult = $this->createAutoRelations( $teacherRelation );

		$schedulerGroupsTask = new \Mff\MffImport\Command\UsergroupsCommandController();
		$schedulerGroupsTask->execute();
		return $createResult;
	}
	
	public function deleteAutoRelations( $teacherRelation = array() ) {
	    // deletes auto-generated  recordsets if they are not in incoming $teacherRelation
		return $GLOBALS['TYPO3_DB']->exec_DELETEquery('tx_mffdb_domain_model_teacherrelation', ' hidden = 0 AND NOT auto_reference = ""');
	}
	public function createAutoRelations( $teacherRelation = array() ) {
	    // auto-generates recordsets from incoming $teacherRelation
		if( !isset($this->extConf['init']) ) $this->init();
		$teaRelRepository = $this->teacherRelationRepository->callSqlStatement( 'SELECT * FROM tx_mffdb_domain_model_teacherrelation;' );
		foreach($teaRelRepository as $row){
		      $existingRow[ $row['tea_ecouser'] ][ $row['fachbereich'] ]=$row;
		}
		
		foreach($teacherRelation as $teaUid=>$teaRow){
		    foreach($teaRow as $fbNr=>$row){
			  if( !isset($existingRow[$row['plan_teacher']][$fbNr]) ){
				$values=array();
				$values['pid'] = $this->extConf['storagePid'] ;
				$values['fachbereich'] = $fbNr ;
				$values['auto_reference'] =  $row['plan_teacher'].'.'.$fbNr ;
				$values['tea_ecouser'] = $row['plan_teacher'] ;
				$values['tstamp'] =  time();
				$values['crdate'] =  time();
				$query = $GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_mffdb_domain_model_teacherrelation', $values);
			  }
		    }
		}
		return true;
	}
	
	public function evaluateTeacherRelations($passedDays , $teacherRelation = array() ) {
		// sample Klassen and Kurse in array $calcRelation[ teacherUsername ][ fachbereichNr ]
		if( !isset($this->extConf['init']) ) $this->init();
		$calcRelation = array();
		$abuKlassen = array();
		$classesByTeacher['Klassen'] = $this->teacherRelationRepository->getTeachersFachbereich( 'Klassen' , $passedDays );
		$classesByTeacher['Kurse'] = $this->teacherRelationRepository->getTeachersFachbereich( 'Kurse' , $passedDays );
		foreach($classesByTeacher as $cat=>$catRow){
		    foreach($catRow as $row){
			if( !isset($calcRelation[ $row['username'] ][ $row['fachbereichNr'] ]['recordset']) ) $calcRelation[ $row['username'] ][ $row['fachbereichNr'] ]['recordset'] = $row;
			$calcRelation[ $row['username'] ][ $row['fachbereichNr'] ]['categorys'][$cat][$row['content']]=$row['content'];
		    }
		}
		// sample abuClasses in array $abuKlassen[ teacherUsername ][ fachbereichNr ]
		$abuClasses = $this->teacherRelationRepository->getTeachersFachbereich( 'AbuKlassen' , $passedDays );
		foreach($abuClasses as $row) $abuKlassen[ $row['username'] ][ $row['content'] ]=$row['content'];

		// denormalize tables: glue values from rows and cells together in array $teacherRelation
		foreach($calcRelation as $username=>$userRow){
			foreach($userRow as $fbId=>$fbRow){
			      if(empty($fbId)) continue;
			      // if there is no recordset, create a new one. in this case delete existing recordset without fb (fb=0)
			      if( !is_array($teacherRelation[$username][$fbId]) ){
				  $teacherRelation[$username][$fbId] = $calcRelation[ $username ][ $fbId ]['recordset'];
				  if( is_array($teacherRelation[$username][0]) ) unset( $teacherRelation[$username][0] );
			      }
			      foreach($fbRow['categorys'] as $cat=>$catRow){
				  // implode contents from the 3 tables (Klassen, Kurse, AbuKlassen )
				  if( $fbId == $this->extConf['abuFbUid'] && isset($abuKlassen[$username]) ){
					$grp = 'Klassen: '.implode( ', ' , $abuKlassen[$username] ).' (' . implode( ',' , $catRow ) .')';
				  }else{
					$grp = $cat . ': ' . implode( ', ' , $catRow );
				  }
				  // create the field 'groups'. Once done, append the values if there are more than one table.
				  if( !isset($teacherRelation[$username][$fbId]['groups']) ){
				      $teacherRelation[$username][$fbId]['groups'] = $grp; 
				  }else{ 
				      $teacherRelation[$username][$fbId]['groups'] .= ' '.$grp; 
				  }
			      }
			}
		}
		return $teacherRelation;
	}
	
}
