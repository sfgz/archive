<?php
/***************************************************************
*  Copyright notice
*
*  (c) 2007-2014 Francois Suter (Cobweb) <typo3@cobweb.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Hooks for the 'mff_import' extension
 *
 * @author		Daniel Rueegg, Francois Suter (Cobweb) <typo3@cobweb.ch>
 * @package		TYPO3
 * @subpackage	tx_mffimport
 */
class tx_mfficonn_hook implements \TYPO3\CMS\Core\SingletonInterface {

	/**
	 * subMethod
	 *
	 * @var array
	 */
	protected $subMethod = array(
		    'ID'  => 'renderUsersClass',
		    'pid' => 'renderTimetable',
		    'PersonID' => 'renderUserFromFile',
	);

	/**
	 * extConf
	 *
	 * @var array
	 */
	protected $extConf;

	/**
	 * __construct
	 */
	public function __construct() {
		$this->extConf = unserialize($GLOBALS['TYPO3_CONF_VARS']['EXT']['extConf']['mff_import']);

		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		
		$this->extConf['studentPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['studentPid'];
		$this->extConf['teacherPid'] = $settings['plugin.']['tx_mffdb_fbv.']['settings.']['teacherPid'];
		$this->extConf['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];
	}

	/**
	 * This method responds to the "processResponse" hook of the svconnector_csv class.
	 * This main method calls a table related sub-method, depending on first fieldname.
	 * It expects the header-row of the table as fiednames
	 * 
	 *
	 * @param array $data The records to transform
	 * @param tx_externalimport_importer $pObj A reference to the svconnector_csv object. Not used.
	 * @return array
	 */
	function processResponse($data, $pObj) {
		// get table header with fieldnames
		foreach( $data as $uid=>$userrow ){
		    $fieldnames = array_flip($userrow);
		    break;
		}
		// prove if method exists and fieldname ist registered in subMethod
		if( empty($userrow[0]) ) return $data;
		
		if( !isset($this->subMethod[$userrow[0]]) ) {
            // data is used as it is
            return $data;
		}
		
		$subMethod = $this->subMethod[$userrow[0]];
		if( !method_exists( $this , $subMethod ) ) return $data;
		
		return $this->$subMethod( $data , $fieldnames );
	}
	
	/**
	 * renderTimetable
	 *
	 * @param array $data The records to transform
	 * @param array $fieldnames The header-row of the table
	 * @return array
	 */
	function renderTimetable( $data , $fieldnames ) {
	      return $data;
	}
	
    /**
        * renderUserFromFile
        *  append pid fullname password=0 gid
        *  
        * @param array $data The records to transform
        * @param array $fieldnames The header-row of the table
        * @return array
        */
    function renderUserFromFile( $data , $fieldnames ) {
        // create a array with classShort as alphanumeric key and classId as value
        $klasseRecordsets = $this->getRepository('Klasse');
        foreach( $klasseRecordsets as $klasserow ){
                $classId = $klasserow->getClassId();
                $kurzbezeichnung = str_replace( ' ' , '-' , $klasserow->getClassShort());
                $idxListe[$kurzbezeichnung]=$classId;
        }
        
		$classAdjustHelper = new \Mff\MffImport\Utility\AdjustScoolclassUtility();
        foreach( $data as $uid => $userrow ){
                $data[$uid]['pid'] = $this->extConf['studentPid'];
                $data[$uid]['name'] = trim( $userrow['Vorname'] . ' ' . $userrow['Nachname'] );
                $data[$uid]['password'] = 0;
                $data[$uid]['gid'] = $this->extConf['userGroupId'].','.$this->extConf['studentGroupId'];
                $cleanClassname = $classAdjustHelper->AdjustScoolclass( $userrow['Klasse'] );
                $mainClass = str_replace( ' ' , '-' , $cleanClassname );
                $data[$uid]['ClassID'] = $idxListe[$mainClass];
        }
        return $data;
    }
	
	/**
	 * renderUsersClass
	 *
	 * @param array $data The records to transform
	 * @param array $fieldnames The header-row of the table
	 * @return array
	 */
	function renderUsersClass( $data , $fieldnames ) {
		// the input data contains already the correct username, regardless if file comes from is2 or iconn
		// create a array with classShort as alphanumeric key and classId as value
		$klasseRecordsets = $this->getRepository('Klasse');
		foreach( $klasseRecordsets as $klasserow ){
		      $classId = $klasserow->getClassId();
		      $kurzbezeichnung = str_replace( ' ' , '-' , $klasserow->getClassShort());
		      $idxListe[$kurzbezeichnung]=$classId;
		}
		// replace alphanumeric value width classId of class
		// outputs a array with 2 fields Klassen and Benutzername
		// if class is missed, user dont gets imported
		$output = array();
		foreach( $data as $uid=>$userrow ){
		      if(!empty($userrow[$fieldnames['Klassen']])){
				$aKlassen = explode( ',' , $userrow[$fieldnames['Klassen']] );
 				$mainClass = str_replace( ' ' , '-' , $aKlassen[0]);
//				$mainClass = $aKlassen[0];
				$output[$uid]['Klassen'] = $idxListe[$mainClass];
				$output[$uid]['Benutzername'] = $userrow[$fieldnames['Benutzername']];
		      }
 		}
 		return $output;
	}

	/**
	 * returns the object of a Model like "Klasse" or "Kurs"
	 *
	 * @param string $table The name of table to return
	 * @return array
	 */
	protected function getRepository( $table ) {
		$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
		$configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
		$settings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
		$storage['storagePid'] = $settings['plugin.']['tx_mffdb_fbv.']['persistence.']['storagePid'];

		$querySettings = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
		$querySettings->setStoragePageIds( $storage );
		// Repository instanziieren
		$oneRepository = $objectManager->get( str_replace( '##TABLENAME##' , ucfirst($table) , 'Mff\Mffdb\Domain\Repository\##TABLENAME##Repository') );
		$oneRepository->setDefaultQuerySettings($querySettings);
		return $oneRepository->findAll();
	}
}
