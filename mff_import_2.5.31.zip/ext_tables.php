<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}
// mff_import/ext_tables.php

if (TYPO3_MODE === 'BE') {

	/**
	 * Registers a Backend Module
	 */
	\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
		'Mff.' . $_EXTKEY,
		'user',	 // Make module a submodule of 'user'
		'iscontrol',	// Submodule key
		'',	// Position e.g. after:setup
		array(
			'Iscontrol' => 'list,info,import'
		),
		array(
			'access' => 'user,group',
			'icon'   => 'EXT:' . $_EXTKEY . '/ext_icon.gif',
			'labels' => 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang_iscontrol.xlf',
		)
	);
	
	// Custom CSS include
	$TBE_STYLES['inDocStyles_TBEstyle'] .= '@import "EXT:' . $_EXTKEY . '/Resources/Public/Css/be_Iscontrol.css";';
	$GLOBALS['TBE_STYLES']['skins'][$_EXTKEY] = array (
	    'name' => $_EXTKEY,
	    'stylesheetDirectories' => array(
		'css' => 'EXT:' . $_EXTKEY . '/Resources/Public/Css/'
	    )
	);
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Mff.' . $_EXTKEY,
	'is2import',
	'is2import'
);

// TCA definitions for plugin external_import, 
//     extends definitions from mffdb
// 60 - Location via mff to tx_mffdb_domain_model_zimmer
// 121 - Subject via mff to tx_mffdb_domain_model_fach
// 167 - Class via mff to tx_mffdb_domain_model_klasse
// 262 fe_users
//   - Teacher via mff to fe_users
//   - Students via mff to fe_users, check in tx_mffdb_domain_model_klasse if class is old. Students needs Klasse from above
// 422 iConn-Klassen bei Lernenden einsetzen (StudClassFromFileCommandController)
// 452 - Course via mff to tx_mffdb_domain_model_kurs. Course needs Klasse and Fach from above
// 537 - Timetable via mff to tx_mffdb_domain_model_stundenplan. Timetable needs Course, Zimmer + Teacher from above
// 657 - Calendar via mff to tx_mffdb_domain_model_kalender





### location
// Load description of table tx_mffdb_domain_model_zimmer
// t3lib_div::loadTCA('tx_mffdb_domain_model_zimmer');
// $GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['ctrl']['default_sortby'] = 'ORDER BY haus,zimmer';

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/location',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'zimmer_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'location_id',
		'enforcePid' => TRUE,
		'priority' => 100,
		'disabledOperations' => '',
		'description' => 'Importiert zimmer'
	)
);
// Add the external information for each column
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['columns']['location_id']['external'] = array(
	0 => array(
		'field' => 'ID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['columns']['zimmer']['external'] = array(
	0 => array(
		'field' => 'room'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['columns']['haus']['external'] = array(
	0 => array(
		'field' => 'building'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_zimmer']['columns']['besonderes']['external'] = array(
	0 => array(
		'field' => 'Description'
	)
);





### subject
// Load description of table tx_mffdb_domain_model_fach
// t3lib_div::loadTCA('tx_mffdb_domain_model_fach');
// 28.11.18 source subject is not integer
// we extract the subjects from table course

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_fach']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/course',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'fach_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'subject_id',
		'enforcePid' => TRUE,
		'priority' => 200,
		'disabledOperations' => 'delete',
		'description' => 'Importiert fach'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_fach']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	),
);
$GLOBALS['TCA']['tx_mffdb_domain_model_fach']['columns']['subject_id']['external'] = array(
	0 => array(
		'field' => 'ID'
	),
);
$GLOBALS['TCA']['tx_mffdb_domain_model_fach']['columns']['fachkurz']['external'] = array(
	0 => array(
		'field' => 'SubjectShort'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_fach']['columns']['fachbezeichnung']['external'] = array(
	0 => array(
		'field' => 'Subject'
	)
);
// $GLOBALS['TCA']['tx_mffdb_domain_model_fach']['columns']['hidden']['external'] = array(
// 	0 => array(
// 		'field' => 'hidden'
// 	)
// );


### class
// Load description of table tx_mffdb_domain_model_klasse
// t3lib_div::loadTCA('tx_mffdb_domain_model_klasse');

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/class',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'klasse_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'ref_class_id',
		'enforcePid' => TRUE,
		'priority' => 320,
		'disabledOperations' => 'delete',
		'description' => 'Importiert klasse'
	)
);

$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['ref_class_id']['external'] = array(
	0 => array(
		'field' => 'ID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['class_id']['external'] = array(
	0 => array(
		'field' => 'ID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['class_short']['external'] = array(
	0 => array(
		'field' => 'ClassShort'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klassenname']['external'] = array(
	0 => array(
		'field' => 'Class'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['department_id']['external'] = array(
	0 => array(
		'field' => 'DepartmentID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klasse_start']['external'] = array(
	0 => array(
		'field' => 'klasse_start'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klasse_ende']['external'] = array(
	0 => array(
		'field' => 'klasse_ende'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klasse_jahr']['external'] = array(
	0 => array(
		'field' => 'klasse_jahr'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klasse_kurz']['external'] = array(
	0 => array(
		'field' => 'klasse_kurz'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['klasse_zug']['external'] = array(
	0 => array(
		'field' => 'klasse_zug'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['classteacher_id']['external'] = array(
	0 => array(
		'field' => 'TeacherID'
	)
);
// realised later with own commandController
// $GLOBALS['TCA']['tx_mffdb_domain_model_klasse']['columns']['kurzklasse']['external'] = array(
// 	0 => array(
// 		'field' => 'klasse_kurz',
//                      'mapping' => array(
//                              'table' => 'tx_mffdb_domain_model_kurzklasse',
//                              'reference_field' => 'kurzbezeichnung'
//                      )
// 	)
// );

### Teacher and Students
// t3lib_div::loadTCA('fe_users');
$GLOBALS['TCA']['fe_users']['ctrl']['default_sortby'] = 'ORDER BY uid';

// Add the external information to the ctrl section
$GLOBALS['TCA']['fe_users']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/teacher',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'teacher_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'eco_key',
		'enforcePid' => FALSE,
		'priority' => 410,
		'disabledOperations' => 'delete',
		'description' => 'Importiert teacher'
	),
	1 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://intranet.tam.ch/bgz/rest/legicarddata',
			'usr' => 'rest-legicard',
			'pwd' => 'ct6BX7DBcdB9M5f',
			'encoding' => 'utf8',
			'hook' => 'students_processResponse'
		),
		'data' => 'array',
		'referenceUid' => 'eco_key',
		'enforcePid' => FALSE,
		'priority' => 420,
		'disabledOperations' => 'delete',
		'description' => 'Importiert students'
	),
	3 => array(
		'connector' => 'csv',
		'parameters' => array(
			'filename' => 'uploads/tx_mffimport/iconn/iconnusers.csv',
			'delimiter' => ';',
			'text_qualifier' => '"',
			'skip_rows' => '1',
			'encoding' => 'UTF-8',
			'locale' => 'de_CH.UTF-8'
		),
		'data' => 'array',
		'referenceUid' => 'eco_key',
		'enforcePid' => FALSE,
		'priority' => 425,
		'disabledOperations' => 'delete',
		'description' => 'iConn-Klassen zu Lernenden importieren'
	),
);


$GLOBALS['TCA']['fe_users']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	),
	1 => array(
		'field' => 'pid'
	),
	3 => array(
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['gender']['external'] = array(
	0 => array(
		'field' => 'gender'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['eco_key']['external'] = array(
	0 => array(
		'field' => 'ID'
	),
	1 => array(
		'field' => 'PersonID'
	),
	3 => array(
		'field' => 'PersonID'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['username']['external'] = array(
	0 => array(
		'field' => 'Username'
	),
	1 => array(
		'field' => 'Username'
	),
	3 => array(
		'field' => 'Benutzername'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['first_name']['external'] = array(
	0 => array(
		'field' => 'GivenName',
		'disabledOperations' => 'update'
	),
	1 => array(
		'field' => 'GivenName',
		'disabledOperations' => 'update'
	),
	3 => array(
		'field' => 'Vorname',
		'disabledOperations' => 'update'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['last_name']['external'] = array(
	0 => array(
		'field' => 'Lastname',
		'disabledOperations' => 'update'
	),
	1 => array(
		'field' => 'Lastname',
		'disabledOperations' => 'update'
	),
	3 => array(
		'field' => 'Nachname',
		'disabledOperations' => 'update'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['name']['external'] = array(
	0 => array(
		'field' => 'name'
	),
	1 => array(
		'field' => 'name'
	),
	3 => array(
		'field' => 'name'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['email']['external'] = array(
	0 => array(
		'field' => 'Email'
	),
	1 => array(
		'field' => 'Email'
	),
	3 => array(
		'field' => 'EMail'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['password']['external'] = array(
	0 => array(
		'field' => 'password',
		'disabledOperations' => 'update'
	),
	1 => array(
		'field' => 'password',
		'disabledOperations' => 'update'
	),
	3 => array(
		'field' => 'password',
		'disabledOperations' => 'update'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['eco_acronym']['external'] = array(
	0 => array(
		'field' => 'Acronym'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['usergroup']['external'] = array(
	0 => array(
		'field' => 'gid',
	),
	1 => array(
		'field' => 'gid',
		'disabledOperations' => 'update'
	),
	3 => array(
		'field' => 'gid',
		'disabledOperations' => 'update'
	)
);
$GLOBALS['TCA']['fe_users']['columns']['tx_extbase_type']['external'] = array(
	0 => array(
		'value' => 'Tx_Mffdb_Ecouser'
	),
	1 => array(
		'value' => 'Tx_Mffdb_Ecouser'
	),
	3 => array(
		'value' => 'Tx_Mffdb_Ecouser'
	)
);

$GLOBALS['TCA']['fe_users']['columns']['eco_klasse']['external'] = array(
	1 => array(
		'field' => 'ClassID',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_klasse',
			'reference_field' => 'class_id'
		)
	),
	3 => array(
		'field' => 'ClassID',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_klasse',
			'reference_field' => 'class_id'
		)
	)
);

$GLOBALS['TCA']['fe_users']['columns']['ref_class_id']['external'] = array(
	1 => array(
		'field' => 'ClassID'
	),
	3 => array(
		'field' => 'ClassID'
	)
);



### iConn-Klassen users
### do not enforce pid cause maybe also some teachers are students in a advanced studium
$GLOBALS['TCA']['fe_users']['ctrl']['external'][2] = array(
		'connector' => 'csv',
		'parameters' => array(
			'filename' => 'uploads/tx_mffimport/iconn/iconnusers.csv',
			'delimiter' => ';',
			'text_qualifier' => '"',
			'skip_rows' => '1',
			'encoding' => 'UTF-8',
			'locale' => 'de_CH.UTF-8'
		),
		'data' => 'array',
		'referenceUid' => 'username',
		'enforcePid' => TRUE,
		'priority' => 1020,
		'disabledOperations' => 'delete,insert',
		'description' => 'iConn-Klassen bei Lernenden einsetzen (StudClassFromFileCommandController)'
);
$GLOBALS['TCA']['fe_users']['columns']['username']['external'][2] = array(
	'field' => 'Benutzername'
);
$GLOBALS['TCA']['fe_users']['columns']['ref_class_id']['external'][2] = array(
	'field' => 'Klassen'
);
// FIXME how delete missing users from pid plugin.tx_mffdb_fbv.settings.studentPid ?
### Info for table import above, the File gets pre-processed
### if field 'Benutzername' is missing, then extract it from 'EMail'
### if field 'Klassen' is missing, then try to find field 'Klasse' and rename it.

### course
// Load description of table tx_mffdb_domain_model_kurs
// t3lib_div::loadTCA('tx_mffdb_domain_model_kurs');

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/course',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'kurs_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'ref_course_id',
		'enforcePid' => TRUE,
		'priority' => 500,
		'description' => 'Importiert kurs (viele Daten)'
	)
);
//		'disabledOperations' => 'insert',
// 284 ds/min
// 4050 DS + 4130 relDS 14.25 min: 15:10:30 ... (15:11:17 network-connection) ... 15:24:45
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['ref_course_id']['external'] = array(
	0 => array(
		'field' => 'course_id'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['course_id']['external'] = array(
	0 => array(
		'field' => 'course_id'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	)
);

$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['kurse_klassen']['external'] = array(
	0 => array(
		'field' => 'class_id',
		'MM' => array(
			'mapping' => array(
				'table' => 'tx_mffdb_domain_model_klasse',
				'reference_field' => 'class_id',
			)
		)
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['kurs_start']['external'] = array(
	0 => array(
		'field' => 'kurs_start'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['kurs_ende']['external'] = array(
	0 => array(
		'field' => 'kurs_ende'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['department_id']['external'] = array(
	0 => array(
		'field' => 'department_id'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['course_short']['external'] = array(
	0 => array(
		'field' => 'CourseShort'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kurs']['columns']['fach']['external'] = array(
	0 => array(
		'field' => 'subject_id',
                     'mapping' => array(
                             'table' => 'tx_mffdb_domain_model_fach',
                             'reference_field' => 'subject_id'
                     )
	)
);




### timetable
// Load description of table tx_mffdb_domain_model_stundenplan
// t3lib_div::loadTCA('tx_mffdb_domain_model_stundenplan');

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://api.tam.ch/bgz/data/source/timetable',
			'usr' => 'rest-viewdata',
			'pwd' => 'BkVSZUtMjNJHmWJZbkbr',
			'hook' => 'stundenplan_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'ref_timetable_id',
		'enforcePid' => TRUE,
		'priority' => 600,
		'description' => 'Importiert stundenplan (viele Daten)'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['pid']['external'] = array(
	0 => array( 
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['ref_timetable_id']['external'] = array(
	0 => array( 
		'field' => 'ID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['timetable_id']['external'] = array(
	0 => array( 
		'field' => 'ID'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_start']['external'] = array(
	0 => array(
		  'field' => 'plan_start'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_ende']['external'] = array(
	0 => array(
		  'field' => 'plan_ende'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_tag']['external'] = array(
	0 => array(
		  'field' => 'Weekday'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_periodizitaet']['external'] = array(
	0 => array( 
		'field' => 'Periodicity',
		'mapping' => array(
			'valueMap' => array(
				'' => '1',
				'0' => '1',
				'1' => '1',
				'2' => '2',
				'3' => '3',
				'4' => '4',
				'5' => '5',
				'6' => '6',
				'7' => '7',
				'8' => '8'
			)
		),
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['zeit_ab']['external'] = array(
	0 => array( 
		'field' => 'StartTime'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['zeit_bis']['external'] = array(
	0 => array( 
		'field' => 'EndTime'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['bemerkung']['external'] = array(
	0 => array( 
		'field' => 'Note'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['kurs']['external'] = array(
	0 => array(
		'field' => 'CourseID',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_kurs',
			'reference_field' => 'course_id'
		)
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_zimmer']['external'] = array(
	0 => array(
		'field' => 'LocationID',
		'mapping' => array(
			'table' => 'tx_mffdb_domain_model_zimmer',
			'reference_field' => 'location_id'
		)
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['plan_teacher']['external'] = array(
	0 => array(
		'field' => 'TeacherID',
		'mapping' => array(
			'table' => 'fe_users',
			'reference_field' => 'eco_key'
		)
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_stundenplan']['columns']['ref_teacher_ecokey']['external'] = array(
	0 => array(
		'field' => 'TeacherID'
	)
);


### calendar
// Load description of table tx_mffdb_domain_model_kalender
// t3lib_div::loadTCA('tx_mffdb_domain_model_kalender');
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['ctrl']['default_sortby'] = 'ORDER BY beginn';

// Add the external information to the ctrl section
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['ctrl']['external'] = array(
	0 => array(
		'connector' => 'mff',
		'parameters' => array(
			'uri' => 'https://tcs.tam.ch/home/termine@medienformfarbe.ch/calendar?fmt=json&query=tag:urlaub',
			'hook' => 'kalender_processResponse',
			'encoding' => 'utf8'
		),
		'data' => 'array',
		'referenceUid' => 'code',
		'enforcePid' => TRUE,
		'priority' => 700,
		'description' => 'Importiert kalender'
	),
);

// Add the external information for each column
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['pid']['external'] = array(
	0 => array(
		'field' => 'pid'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['ferientext']['external'] = array(
	0 => array(
		'field' => 'name'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['code']['external'] = array(
	0 => array(
		'field' => 'code'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['beginn']['external'] = array(
	0 => array(
		'field' => 'beginn_localtime'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['ende']['external'] = array(
	0 => array(
		'field' => 'ende_localtime'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['semestergrenze']['external'] = array(
	0 => array(
		'field' => 'semestergrenze'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['privat']['external'] = array(
	0 => array(
		'field' => 'privat'
	)
);
$GLOBALS['TCA']['tx_mffdb_domain_model_kalender']['columns']['ganztag']['external'] = array(
	0 => array(
		'field' => 'allDay'
	)
);
